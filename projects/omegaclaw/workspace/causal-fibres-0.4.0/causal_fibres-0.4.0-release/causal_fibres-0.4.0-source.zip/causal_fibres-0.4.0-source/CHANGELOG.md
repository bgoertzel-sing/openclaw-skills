# Changelog

## 0.4.0

- Reframed the package as a comparative structural-adaptation toolkit.
- Added dense, SAE, grouped sparse, orthogonal, and contextual-bundle representations.
- Added SAE + steering and LoRA baselines.
- Added frozen-interface observability probes and capacity curves.
- Added exact-gradient responsibility gates and demoted learned highways from the default path.
- Added controlled low-rank substrate co-adaptation and anchor trust regions.
- Added deployment-honest settlement, matched-compute, held-out routing, and finite-curriculum evaluation.
- Added overcomplete dictionary operator audits and conservative module certification.
- Added critique-driven staged configs, examples, and documentation.


## 0.3.0

- Replaced the single-start QR/Adam joint block diagonalizer with a robust
  global-to-local solver.
- Added approximate symmetric-commutant analysis and identifiability
  diagnostics.
- Added random-combination spectral-affinity initializers with balanced block
  partitioning.
- Added exact small-problem affinity partitioning and balanced spectral
  clustering for larger problems.
- Added multi-start candidate selection and monotone Riemannian refinement on
  the orthogonal group.
- Added initialization and restart diagnostics to joint-diagonalization results.
- Added regression tests for randomly oriented, internally nontrivial blocks
  and moderate operator noise.

## 0.2.0

- Added Hugging Face-style hidden-state adapter.
- Added explicit intermediate writes to the generic hook adapter.
- Added pooled and tokenwise multi-site predictors.
- Added adaptive Levenberg-Marquardt PC solver and matrix-free CG.
- Added factor-error encoders, novelty projection, and richer causal highways.
- Added Procrustes transport initialization and transport diagnostics.
- Added Gauss-Newton, empirical-Fisher, operator sketches, and joint diagonalizer.
- Added intervention policies, fingerprint uncertainty, and stable fibre registry.
- Added mutable symbolic store and contrastive symbolic-head loss.
- Added masked Transformer distillation losses and causal-LM label shifting.
- Added continual-learning runner and function-space commutator utility.
- Added atomic checkpoints, reproducibility helpers, logging callbacks, CLI,
  expanded examples, documentation, and a 31-test suite.

## 0.1.0

- Initial architectural scaffold for terminal PC residuals, causal routing,
  operator audits, interventions, lifecycle proposals, and symbolic heads.
