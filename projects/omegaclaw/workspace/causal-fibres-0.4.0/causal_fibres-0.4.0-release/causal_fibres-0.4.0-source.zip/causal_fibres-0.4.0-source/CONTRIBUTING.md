# Contributing

This is an alpha research package. Contributions should preserve the separation
between architecture adapters, state solvers, credit sources, persistent update
rules, and causal audits.

Before submitting changes:

```bash
python -m pip install -e '.[dev]'
pytest
python -m compileall src
ruff check src tests examples
```

New architecture adapters should include:

- a small fake-model unit test;
- explicit tensor-shape documentation;
- a statement of whether intermediate writes are supported;
- a reversible no-sidecar control;
- a note about cache or suffix-recomputation semantics.

New causal claims should include an intervention or operator-level audit rather
than relying only on task loss.
