"""Compare actual finite update orders rather than only local commutators."""

from __future__ import annotations

import json

import torch
from torch import nn

from causal_fibres.evaluation import FiniteCurriculumLoopEvaluator


def main() -> None:
    model = nn.Linear(2, 2, bias=False)
    with torch.no_grad():
        model.weight.copy_(torch.eye(2))
    probes = torch.tensor([[1.0, 0.5], [-0.5, 1.0]])

    def update(module: nn.Module, context: str):
        with torch.no_grad():
            weight = module.weight
            if context == "rotate":
                rotation = torch.tensor([[0.0, -1.0], [1.0, 0.0]])
                weight.add_(0.15 * rotation @ weight)
            elif context == "scale":
                weight[0].mul_(1.2)
            elif context == "shear":
                weight[1].add_(0.25 * weight[0])
            else:
                raise KeyError(context)
        return {"weight_norm": float(module.weight.detach().norm())}

    evaluator = FiniteCurriculumLoopEvaluator(
        model,
        update_fn=update,
        output_fn=lambda module: module(probes),
        distance_fn=lambda first, second: ((first - second) ** 2).mean(),
    )
    report = evaluator.evaluate(
        {
            "RSH": ["rotate", "scale", "shear"],
            "HSR": ["shear", "scale", "rotate"],
            "SRH": ["scale", "rotate", "shear"],
        }
    )
    print(json.dumps(report.to_dict(), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
