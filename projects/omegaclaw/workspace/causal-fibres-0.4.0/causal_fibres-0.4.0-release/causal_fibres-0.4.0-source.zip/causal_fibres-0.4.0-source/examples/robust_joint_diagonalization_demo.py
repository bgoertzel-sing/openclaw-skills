"""Recover randomly oriented common invariant blocks with the 0.3 solver."""

from __future__ import annotations

import torch

from causal_fibres.operators import (
    JointBlockDiagonalizer,
    joint_block_diagonalization_loss,
)


def random_spd(size: int, generator: torch.Generator, shift: float = 0.5) -> torch.Tensor:
    matrix = torch.randn(size, size, generator=generator)
    return matrix @ matrix.T + shift * torch.eye(size)


def main() -> None:
    torch.manual_seed(0)
    block_sizes = [2, 2]
    true_basis = torch.linalg.qr(torch.randn(4, 4)).Q
    true_blocks = (true_basis[:, :2], true_basis[:, 2:])

    operators = []
    for context in range(5):
        generator = torch.Generator().manual_seed(70_000 + context)
        left = random_spd(2, generator)
        right = random_spd(2, generator) + 3.0 * torch.eye(2)
        operators.append(
            true_basis @ torch.block_diag(left, right) @ true_basis.T
        )

    result = JointBlockDiagonalizer(
        block_sizes,
        initializer="auto",
        restarts=6,
        steps=300,
        learning_rate=0.2,
        seed=0,
    ).fit(operators)

    true_loss = joint_block_diagonalization_loss(operators, true_blocks)
    print(f"true block loss:      {float(true_loss):.3e}")
    print(f"recovered block loss: {result.report.block_loss:.3e}")
    print(f"selected initializer: {result.initializer}")
    print(f"orthogonality error:  {result.orthogonality_error:.3e}")
    if result.commutant is not None:
        print(f"commutant status:     {result.commutant.status}")
        print(
            "commutant nullity:    "
            f"{result.commutant.estimated_nullity}/"
            f"{result.commutant.expected_nullity}"
        )


if __name__ == "__main__":
    main()
