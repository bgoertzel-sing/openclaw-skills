"""Load a package YAML config and run the built-in smoke test."""

from __future__ import annotations

from pathlib import Path

from causal_fibres.core import CFEConfig
from causal_fibres.diagnostics import run_smoke_test


def main() -> None:
    path = Path(__file__).resolve().parents[1] / "configs" / "toy_smoke.yaml"
    config = CFEConfig.from_yaml(path)
    result = run_smoke_test(seed=config.runtime.seed, steps=10)
    print(config.to_dict())
    print(result)
    if not result.passed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
