"""Template for a frozen Hugging Face causal LM plus terminal fibre sidecar.

This file is intentionally not tied to a downloadable model or dataset. Replace
the placeholders with locally available checkpoints and a dataloader.
"""

from __future__ import annotations

import torch

from causal_fibres.architectures import HFHiddenStatesAdapter
from causal_fibres.fibres import IdentityPooler
from causal_fibres.recipes import build_terminal_transformer_sidecar
from causal_fibres.solvers import LevenbergMarquardtPCSolver
from causal_fibres.training import DistillationWeights, PartialDistillationTrainer


def build_trainer(base_model, teacher_model, hidden_size: int, vocab_size: int):
    adapter = HFHiddenStatesAdapter(
        base_model,
        layers={"embedding": 0, "middle": 4, "late": 7},
        remove_batch_keys=("labels",),
    )
    sidecar = build_terminal_transformer_sidecar(
        {"embedding": hidden_size, "middle": hidden_size, "late": hidden_size},
        vocab_size,
        n_fibres=8,
        fibre_dim=16,
        site_poolers={
            "embedding": IdentityPooler(),
            "middle": IdentityPooler(),
            "late": IdentityPooler(),
        },
        top_k=3,
        router_temperature=2.0,
        residual_scale=0.02,
        trainable_scale=True,
    )
    return PartialDistillationTrainer(
        adapter,
        sidecar,
        teacher=lambda batch: teacher_model(
            **{key: value for key, value in batch.items() if key != "labels"}
        ).logits,
        solver=LevenbergMarquardtPCSolver(steps=2, damping=0.1, cg_max_iter=24),
        optimizer=torch.optim.AdamW(sidecar.parameters(), lr=3e-4, weight_decay=0.01),
        temperature=2.0,
        causal_lm_shift=True,
        weights=DistillationWeights(
            deploy_kd=1.0,
            settled_kd=0.25,
            amortization=1.0,
            predictor_prior=0.1,
            absolute_state=0.01,
            gauge=0.01,
            anchor_kl=0.02,
        ),
    )
