"""Show why controlled substrate plasticity may be needed after observability fails."""

from __future__ import annotations

import json

import torch
from torch import nn

from causal_fibres.substrate import (
    AlternatingResidualBaseTrainer,
    AnchorTrustRegion,
    LowRankBasePlasticity,
)


class TinyBase(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.encoder = nn.Linear(6, 4, bias=False)
        self.head = nn.Linear(4, 4, bias=False)
        with torch.no_grad():
            self.encoder.weight.zero_()
            self.encoder.weight[:, :4].copy_(torch.eye(4))
            self.head.weight.copy_(torch.eye(4))

    def hidden(self, inputs):
        return self.encoder(inputs)

    def forward(self, inputs):
        return self.head(self.hidden(inputs))


def mse(first, second):
    return ((first - second) ** 2).mean()


def main() -> None:
    torch.manual_seed(5)
    inputs = torch.randn(600, 6)
    teacher = inputs @ torch.randn(6, 4)
    base = TinyBase()
    for parameter in base.parameters():
        parameter.requires_grad_(False)
    residual = nn.Sequential(nn.Linear(4, 16), nn.GELU(), nn.Linear(16, 4))
    residual_optimizer = torch.optim.AdamW(residual.parameters(), lr=5e-3)
    # Frozen interface phase.
    for _ in range(180):
        hidden = base.hidden(inputs[:450]).detach()
        prediction = base.head(hidden).detach() + residual(hidden)
        loss = mse(prediction, teacher[:450])
        residual_optimizer.zero_grad(set_to_none=True)
        loss.backward()
        residual_optimizer.step()
    with torch.no_grad():
        frozen_loss = mse(base(inputs[450:]) + residual(base.hidden(inputs[450:])), teacher[450:])

    # Controlled low-rank substrate co-adaptation.
    plasticity = LowRankBasePlasticity(base, rank=2, module_names=["encoder"], alpha=4.0)
    substrate_optimizer = torch.optim.AdamW(plasticity.parameters(), lr=3e-3)
    residual_optimizer = torch.optim.AdamW(residual.parameters(), lr=3e-3)
    anchor_inputs = inputs[:100]
    with torch.no_grad():
        # The LoRA delta is zero at initialization, so this is the original-base anchor.
        anchor_reference = base(anchor_inputs).detach()
    trust = AnchorTrustRegion(kind="mse", radius=0.02, weight=0.2)
    trainer = AlternatingResidualBaseTrainer(
        residual_parameters=residual.parameters(),
        substrate_parameters=plasticity.parameters(),
        residual_optimizer=residual_optimizer,
        substrate_optimizer=substrate_optimizer,
        residual_steps=2,
        substrate_steps=1,
    )

    for _ in range(160):
        indices = torch.randint(0, 450, (96,))
        batch = inputs[indices]
        target = teacher[indices]

        def residual_loss():
            hidden = base.hidden(batch)
            return mse(base.head(hidden) + residual(hidden), target)

        def substrate_loss():
            hidden = base.hidden(batch)
            task = mse(base.head(hidden) + residual(hidden), target)
            anchor = trust(base(anchor_inputs), anchor_reference)
            return task + anchor

        trainer.step(residual_loss, substrate_loss)

    with torch.no_grad():
        coadapted_loss = mse(
            base(inputs[450:]) + residual(base.hidden(inputs[450:])), teacher[450:]
        )
        anchor_drift = mse(base(anchor_inputs), anchor_reference)
    print(
        json.dumps(
            {
                "frozen_interface_validation_mse": float(frozen_loss),
                "coadapted_validation_mse": float(coadapted_loss),
                "anchor_drift_mse": float(anchor_drift),
                "low_rank_report": plasticity.report().__dict__,
            },
            indent=2,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
