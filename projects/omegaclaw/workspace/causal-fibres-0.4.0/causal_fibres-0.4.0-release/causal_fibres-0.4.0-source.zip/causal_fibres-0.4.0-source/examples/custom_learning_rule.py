"""Minimal demonstration that persistent learning is replaceable independently."""

from __future__ import annotations

from causal_fibres.training import CallableUpdateRule


def local_update(context):
    # Application-specific local/Hebbian/evolutionary updates can inspect
    # context.predicted, context.settled, context.losses, and context.cache.
    return {"custom_update_applied": 1.0}


rule = CallableUpdateRule(local_update)
print(rule)
