"""Run the frozen-read observability falsifier across several synthetic layers."""

from __future__ import annotations

import json

import torch

from causal_fibres.observability import FrozenReadProbe, audit_layers


def main() -> None:
    torch.manual_seed(3)
    samples = 600
    latent = torch.randn(samples, 8)
    output_dim = 5
    teacher_correction = latent @ torch.randn(8, output_dim) * 0.35
    base_logits = 0.1 * torch.randn(samples, output_dim)
    teacher_logits = base_logits + teacher_correction
    features = {
        "early": torch.cat([latent[:, :2], torch.randn(samples, 8)], dim=-1),
        "middle": torch.cat([latent[:, :5], torch.randn(samples, 5)], dim=-1),
        "late": latent @ torch.randn(8, 10),
    }
    train_features = {name: value[:450] for name, value in features.items()}
    validation_features = {name: value[450:] for name, value in features.items()}
    report = audit_layers(
        train_features,
        validation_features,
        base_logits[:450],
        teacher_logits[:450],
        base_logits[450:],
        teacher_logits[450:],
        probe_factory=lambda name, width: FrozenReadProbe(
            width,
            output_dim,
            kind="low_rank",
            capacity=8,
            steps=140,
            learning_rate=8e-3,
            seed=len(name),
        ),
    )
    print(json.dumps(report.to_dict(), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
