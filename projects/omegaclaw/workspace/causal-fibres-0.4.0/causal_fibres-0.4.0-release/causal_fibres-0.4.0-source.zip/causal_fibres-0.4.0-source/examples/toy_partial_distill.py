"""Small runnable frozen-backbone partial-distillation example."""

from __future__ import annotations

import torch
from torch import nn

from causal_fibres.architectures import HookedModuleAdapter
from causal_fibres.credit import SoftTopKRouter
from causal_fibres.fibres import LinearFibreBank, MultiSiteFibrePredictor, TerminalFibreSidecar
from causal_fibres.solvers import GradientPCSolver
from causal_fibres.training import DistillationWeights, PartialDistillationTrainer


class Backbone(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.hidden = nn.Linear(6, 16)
        self.output = nn.Linear(16, 4)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.output(torch.tanh(self.hidden(x)))


def main() -> None:
    torch.manual_seed(5)
    base = Backbone()
    adapter = HookedModuleAdapter(
        base,
        sites={"hidden": "hidden"},
        widths={"hidden": 16},
        freeze=True,
    )
    predictor = MultiSiteFibrePredictor({"hidden": 16}, 4, 4, hidden_dim=32)
    writer = LinearFibreBank(4, 4, 4)
    router = SoftTopKRouter(4, 4, top_k=2, temperature=2.0)
    sidecar = TerminalFibreSidecar(
        predictor,
        writer,
        router,
        residual_scale=0.1,
        trainable_scale=True,
    )

    def teacher(x: torch.Tensor) -> torch.Tensor:
        correction = torch.stack(
            (x[:, 0], -x[:, 1], 0.5 * x[:, 2], -0.7 * x[:, 3]), dim=-1
        )
        return base(x) + correction

    trainer = PartialDistillationTrainer(
        adapter,
        sidecar,
        teacher,
        GradientPCSolver(steps=2, step_size=0.25),
        torch.optim.AdamW(sidecar.parameters(), lr=1e-2),
        temperature=1.0,
        weights=DistillationWeights(
            deploy_kd=1.0,
            settled_kd=0.25,
            amortization=0.5,
            predictor_prior=0.1,
            absolute_state=0.02,
        ),
    )

    batch = torch.randn(128, 6)
    for step in range(201):
        ctx = trainer.train_step(batch)
        if step % 40 == 0:
            print(
                f"step={step:03d} "
                f"deploy_kd={ctx.losses['loss_deploy_kd'].item():.4f} "
                f"clamped_kd={ctx.losses['loss_settled_kd'].item():.4f} "
                f"energy={ctx.metrics['energy_final']:.4f}"
            )


if __name__ == "__main__":
    main()
