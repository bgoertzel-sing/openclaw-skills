"""Compare dense, orthogonal, SAE, grouped-SAE, and contextual representations.

The data are generated from an overcomplete sparse dictionary with three
context-dependent rotations. This is a toy representation contest, not a claim
about real Transformer feature geometry.
"""

from __future__ import annotations

import json

import torch
import torch.nn.functional as F

from causal_fibres.representations import (
    ContextualFibreBundle,
    DenseResidualRepresentation,
    GroupedSparseDictionary,
    OrthogonalFibreRepresentation,
    RepresentationSteeringContest,
    RepresentationSteeringModel,
    SparseAutoencoder,
)


def make_data(seed: int = 0):
    torch.manual_seed(seed)
    n_samples = 900
    input_dim = 12
    atoms = 24
    output_dim = 6
    contexts = 3
    dictionary = F.normalize(torch.randn(atoms, input_dim), dim=-1)
    code = torch.zeros(n_samples, atoms)
    indices = torch.topk(torch.rand(n_samples, atoms), k=3, dim=-1).indices
    amplitudes = 0.5 + torch.rand(n_samples, 3)
    code.scatter_(1, indices, amplitudes)
    context_ids = torch.randint(0, contexts, (n_samples,))
    context = F.one_hot(context_ids, num_classes=contexts).to(torch.float32)
    rotations = []
    for _ in range(contexts):
        q, _ = torch.linalg.qr(torch.randn(input_dim, input_dim))
        rotations.append(q)
    canonical_hidden = code @ dictionary
    hidden = torch.stack(
        [canonical_hidden[i] @ rotations[int(context_ids[i])].T for i in range(n_samples)]
    )
    hidden = hidden + 0.01 * torch.randn_like(hidden)
    base_logits = 0.05 * torch.randn(n_samples, output_dim)
    teacher_logits = base_logits + code @ (torch.randn(atoms, output_dim) * 0.2)
    return hidden, context, base_logits, teacher_logits


def main() -> None:
    hidden, context, base, teacher = make_data()
    train = slice(0, 700)
    validation = slice(700, None)
    groups = [list(range(index, min(index + 6, 24))) for index in range(0, 24, 4)]
    models = {
        "dense": RepresentationSteeringModel(
            DenseResidualRepresentation(12, 8), code_width=8, output_dim=6
        ),
        "orthogonal": RepresentationSteeringModel(
            OrthogonalFibreRepresentation(12, 4, 2), code_width=8, output_dim=6
        ),
        "sae": RepresentationSteeringModel(
            SparseAutoencoder(12, 24, top_k=3), code_width=24, output_dim=6
        ),
        "grouped_sae": RepresentationSteeringModel(
            GroupedSparseDictionary(12, 24, groups=groups, top_k=3),
            code_width=24,
            output_dim=6,
        ),
        "contextual_bundle": RepresentationSteeringModel(
            ContextualFibreBundle(12, 4, 2, context_dim=3),
            code_width=8,
            output_dim=6,
        ),
    }
    contest = RepresentationSteeringContest(
        models,
        pretrain_steps=80,
        steering_steps=140,
        batch_size=96,
        learning_rate=4e-3,
        joint_finetune=False,
        seed=4,
    )
    result = contest.fit(
        hidden[train],
        base[train],
        teacher[train],
        hidden[validation],
        base[validation],
        teacher[validation],
        train_context=context[train],
        validation_context=context[validation],
    )
    print(json.dumps(result.to_dict(), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
