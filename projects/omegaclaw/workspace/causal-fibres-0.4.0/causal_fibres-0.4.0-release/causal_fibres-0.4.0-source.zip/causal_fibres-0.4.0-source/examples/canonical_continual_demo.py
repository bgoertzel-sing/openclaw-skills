"""Canonical binary fibres with strict context-local adaptation."""

from __future__ import annotations

import torch
from torch import nn

from causal_fibres.architectures import HookedModuleAdapter
from causal_fibres.recipes import build_canonical_binary_factor_sidecar
from causal_fibres.solvers import LevenbergMarquardtPCSolver
from causal_fibres.training import DistillationWeights, PartialDistillationTrainer


class Backbone(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, output_dim: int) -> None:
        super().__init__()
        self.hidden = nn.Sequential(nn.Linear(input_dim, hidden_dim), nn.Tanh())
        self.output = nn.Linear(hidden_dim, output_dim)

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        return self.output(self.hidden(inputs))


def factor_states(inputs: torch.Tensor, flip_factor: int | None = None) -> torch.Tensor:
    values = torch.where(inputs[:, :4] >= 0, 4.0, -4.0)
    if flip_factor is not None:
        values = values.clone()
        values[:, flip_factor] *= -1
    return values.unsqueeze(-1)


def factor_accuracy(logits: torch.Tensor, inputs: torch.Tensor, flip_factor: int | None = None) -> float:
    pairs = logits.reshape(logits.shape[0], 4, 2)
    labels = (inputs[:, :4] >= 0).long()
    if flip_factor is not None:
        labels = labels.clone()
        labels[:, flip_factor] = 1 - labels[:, flip_factor]
    return float((pairs.argmax(dim=-1) == labels).float().mean())


def main() -> None:
    torch.manual_seed(3)
    base = Backbone(8, 24, 8)
    adapter = HookedModuleAdapter(
        base,
        sites={"hidden": "hidden"},
        widths={"hidden": 24},
        freeze=True,
    )
    sidecar = build_canonical_binary_factor_sidecar(
        {"hidden": 24},
        4,
        predictor_hidden_dim=32,
        known_support=False,
    )

    def teacher(inputs: torch.Tensor, flip_factor: int | None = None) -> torch.Tensor:
        with torch.no_grad():
            correction = sidecar.writer(factor_states(inputs, flip_factor))
            return base(inputs) + correction

    inputs = torch.randn(512, 8)
    trainer = PartialDistillationTrainer(
        adapter,
        sidecar,
        teacher=lambda batch: teacher(batch),
        solver=LevenbergMarquardtPCSolver(steps=2, damping=0.1, cg_max_iter=12),
        optimizer=torch.optim.Adam(sidecar.predictor.parameters(), lr=1e-2),
        weights=DistillationWeights(
            deploy_kd=1.0,
            settled_kd=0.25,
            amortization=1.0,
            predictor_prior=0.1,
            absolute_state=0.01,
        ),
        temperature=1.0,
    )
    for _ in range(300):
        trainer.train_step(inputs)
    before = trainer.evaluate_step(inputs, settle=False).output
    assert before is not None
    print("pre-adaptation accuracy:", factor_accuracy(before, inputs))

    # Adapt only fibre 0 to a remapped convention. The other three predictor
    # branches and fixed write dictionary are not in the optimizer.
    branch0 = sidecar.predictor.branches[0]
    adaptation = PartialDistillationTrainer(
        adapter,
        sidecar,
        teacher=lambda batch: teacher(batch, flip_factor=0),
        solver=LevenbergMarquardtPCSolver(steps=2, damping=0.1, cg_max_iter=12),
        optimizer=torch.optim.Adam(branch0.parameters(), lr=1e-2),
        weights=DistillationWeights(
            deploy_kd=1.0,
            settled_kd=0.25,
            amortization=1.0,
            predictor_prior=0.1,
            absolute_state=0.01,
        ),
        temperature=1.0,
    )
    unrelated_before = before.reshape(-1, 4, 2)[:, 1:].clone()
    for _ in range(160):
        adaptation.train_step(inputs)
    after = adaptation.evaluate_step(inputs, settle=False).output
    assert after is not None
    unrelated_after = after.reshape(-1, 4, 2)[:, 1:]
    print("post-adaptation accuracy:", factor_accuracy(after, inputs, flip_factor=0))
    print("unrelated max logit drift:", float((unrelated_after - unrelated_before).abs().max()))


if __name__ == "__main__":
    main()
