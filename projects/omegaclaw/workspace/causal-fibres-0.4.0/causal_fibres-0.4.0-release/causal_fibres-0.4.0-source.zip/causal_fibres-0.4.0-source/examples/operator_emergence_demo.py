"""Recover a common causal block basis from rotated context operators."""

from __future__ import annotations

import torch

from causal_fibres.operators import JointBlockDiagonalizer, emergence_report


def main() -> None:
    torch.manual_seed(4)
    angle = torch.tensor(0.63)
    rotation = torch.tensor(
        [
            [torch.cos(angle), 0.0, -torch.sin(angle), 0.0],
            [0.0, torch.cos(angle), 0.0, -torch.sin(angle)],
            [torch.sin(angle), 0.0, torch.cos(angle), 0.0],
            [0.0, torch.sin(angle), 0.0, torch.cos(angle)],
        ]
    )
    operators = [
        rotation @ torch.diag(torch.tensor([1.0, 1.0, 4.0, 4.0])) @ rotation.T,
        rotation @ torch.diag(torch.tensor([2.0, 2.0, 7.0, 7.0])) @ rotation.T,
        rotation @ torch.diag(torch.tensor([5.0, 5.0, 1.0, 1.0])) @ rotation.T,
    ]
    identity_blocks = (torch.eye(4)[:, :2], torch.eye(4)[:, 2:])
    before = emergence_report(operators, identity_blocks)
    result = JointBlockDiagonalizer([2, 2], steps=400, learning_rate=0.03).fit(operators)
    print("before:", before.to_dict())
    print("after:", result.report.to_dict())
    print("final block loss:", result.losses[-1])


if __name__ == "__main__":
    main()
