"""Demonstrate deployment-honest settlement reporting."""

from __future__ import annotations

import json

import torch

from causal_fibres.evaluation import FreeSettlementEvaluator


def main() -> None:
    target = torch.tensor([1.0, -1.0])
    evaluator = FreeSettlementEvaluator(lambda output: ((output - target) ** 2).mean())
    report = evaluator.evaluate(
        predictor_fn=lambda: torch.tensor([0.2, -0.1]),
        free_fn=lambda: torch.tensor([0.25, -0.15]),
        constrained_fn=lambda: torch.tensor([0.85, -0.8]),
        clamped_fn=lambda: target.clone(),
        metadata={"new_test_time_information": "retrieved symbolic constraint in constrained mode"},
    )
    print(json.dumps(report.to_dict(), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
