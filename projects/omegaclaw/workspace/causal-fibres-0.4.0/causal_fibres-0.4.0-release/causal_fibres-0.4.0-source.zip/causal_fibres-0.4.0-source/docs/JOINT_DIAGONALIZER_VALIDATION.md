# JointBlockDiagonalizer regression validation

The 0.3 solver was evaluated on the exact stress family that defeated the 0.2 single-start QR/Adam implementation.  Each trial used five randomly generated symmetric positive-definite context operators with a shared, randomly oriented pair of two-dimensional invariant blocks and non-diagonal internal block structure.

| Seed | 0.2 fitted loss | 0.3 fitted loss | 0.3 initializer | 0.2 steps | 0.3 steps |
|---:|---:|---:|---|---:|---:|
| 0 | 0.555981 | 5.842e-13 | `commutant:6` | 141 | 10 |
| 1 | 2.58275 | 3.307e-13 | `spectral:2` | 132 | 11 |
| 2 | 0.296102 | 1.661e-13 | `commutant:21` | 141 | 11 |

Mean 0.2 fitted loss: **1.14494**.
Mean 0.3 fitted loss: **3.603e-13**.

All three 0.3 runs reached numerical-zero off-block energy, matching the known generating decomposition.  The selected global initializer varied across seeds, which is expected: both approximate-commutant and spectral-affinity routes are valid and the multi-start stage selects the best candidate.

## Additional checks

- Ten exact random-block regression cases across two- and three-block systems were exercised during development.
- A moderate symmetric-noise case recovered the generating subspaces to less than 0.02 radians average principal-angle error.
- Scalar/reducible blocks were recovered using the centre of the commutant and signature-aware tie breaking.
- Repeated isomorphic modules produced a `repeated_or_underidentified` diagnostic rather than an overconfident decomposition.
- Returned orthogonality errors remained below `1e-5` in the automated suite.

## Interpretation

The specific 0.2 limitation is overcome for the intended dense small/moderate audit regime.  The problem remains intrinsically non-identifiable when the operator family contains repeated isomorphic copies or insufficient context variation; version 0.3 reports this through the commutant-centre diagnostics.
