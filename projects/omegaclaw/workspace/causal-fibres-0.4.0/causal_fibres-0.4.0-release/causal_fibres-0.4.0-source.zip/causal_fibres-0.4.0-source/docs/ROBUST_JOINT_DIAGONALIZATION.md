# Robust common-block discovery

`JointBlockDiagonalizer` estimates common invariant blocks of a family of dense,
usually self-adjoint context operators:

```python
from causal_fibres.operators import JointBlockDiagonalizer

solver = JointBlockDiagonalizer(
    block_sizes=[8, 8, 8, 8],
    initializer="auto",
    restarts=6,
    steps=500,
    normalized=True,
    seed=7,
)
result = solver.fit(context_operators)
```

The 0.3 implementation is designed for the case in which the desired blocks may
be far from the coordinate axes and the operators have rich, non-diagonal
structure inside each block.

## Why the old local solve could fail

The block objective

\[
    \sum_c \sum_{q<r} \|U_q^T H_c U_r\|_F^2
\]

is non-convex on the flag manifold.  Optimizing a QR-parameterized basis from a
single identity-like start can settle in a poor local solution even if an exact
common decomposition exists.

## Global-to-local algorithm

### 1. Approximate commutant initializer

For symmetric matrices, the package searches the symmetric matrix space for
matrices `X` with small residuals

\[
    [X,H_c] = XH_c-H_cX \approx 0
\]

for every context.  If the family consists of `k` multiplicity-free irreducible
blocks, the symmetric commutant has dimension `k`; a generic commutant element
is scalar on each block.  Its eigenspaces therefore expose the common blocks.

The package builds the commutator linear system in a Frobenius-orthonormal
symmetric-matrix basis and computes its smallest right singular vectors.  It
then computes the **centre of the approximate commutant**.  This extra step is
important when an operator is scalar or reducible inside a block: the full
commutant can be large, while its centre still recovers the canonical block
projectors.  Several generic central elements are formed and their eigenspaces
are partitioned into the requested block sizes.

The result includes:

```python
result.commutant.status
result.commutant.estimated_nullity
result.commutant.expected_nullity
result.commutant.nullity_gap_ratio
result.commutant.singular_values
```

Interpretation:

- `multiplicity_free`: the numerical commutant dimension matches the block
  count with a clear gap;
- `repeated_or_underidentified`: the centre is smaller than the requested block
  count, indicating repeated isomorphic copies or contexts that do not separate
  the requested fibres;
- `finer_structure_detected`: the centre contains more distinguishable
  components than requested;
- `approximate_or_noisy`: the expected commutant is not numerically exact, so
  the decomposition should be treated as approximate.

The dense commutant initializer is used only up to
`commutant_max_dimension` because its matrix-space cost grows quadratically in
state dimension.

### 2. Spectral-affinity initializer

For each random coefficient vector, the solver diagonalizes a generic linear
combination of the context operators.  In an exact common-block family, each
resulting eigenvector lies inside one true invariant block.  The package then
forms the affinity

\[
    A_{ij}=\sum_c |v_i^T H_c v_j|^2 / \|H_c\|_F^2,
\]

which is zero across exact blocks and usually positive within a rich block.
Eigenvectors are grouped into the prescribed sizes by:

- an exact global balanced partition when the combinatorics are small;
- balanced spectral clustering otherwise.

This provides a scalable alternative and an independent check on the
commutant initializer.

### 3. Multi-start selection

The solver scores and briefly refines the best candidates from:

- approximate commutants;
- spectral affinities;
- a user-supplied basis;
- the identity basis;
- random orthogonal starts.

The best warm-start is selected for full refinement.

### 4. Riemannian refinement

The basis is refined directly on the orthogonal group.  If `G` is the Euclidean
gradient and `Q` the current basis, the tangent generator is

\[
    \Omega = \tfrac12(Q^T G-G^T Q).
\]

A Cayley retraction applies an orthogonal update approximating
`Q exp(-eta Omega)`.  An Armijo line search makes accepted objective steps
monotone.  This avoids the distortions and flat directions caused by optimizing
an unconstrained raw matrix through QR on every forward pass.

## Result diagnostics

```python
print(result.initializer)
print(result.report.to_dict())
print(result.diagnostics_dict())
```

`result.initialization_records` lists all scored initializers.
`result.restart_summaries` records warm-start performance, gradient norm, and
line-search failures.  `result.orthogonality_error` verifies the returned basis.

## Recommended use

For small residual-state audits:

```python
solver = JointBlockDiagonalizer(
    block_sizes,
    normalized=True,
    initializer="auto",
    restarts=6,
    steps=500,
)
```

Use `normalized=True` when context operators have very different Frobenius
scales.  Pass an independently motivated `initial_basis` when symbolic labels,
known causal factors, or a previous checkpoint provide one.

Do not interpret a low block loss alone as proof of real-world causality.
Combine it with intervention fingerprints, observability, controllability,
router fidelity, and update-commutator audits.

## Limitations

- The commutant construction is dense and intended for small or moderate audit
  spaces, not full billion-parameter Hessians.
- Repeated isomorphic blocks are fundamentally non-identifiable without extra
  context variation or symmetry breaking; the solver reports rather than hides
  this condition.
- Strong operator noise can make a different approximate block basis achieve a
  lower objective than the generating basis.
- `allowed_coupling` objectives are supported in refinement, but the commutant
  initializer is skipped when nonzero allowed cross-block couplings are present.
