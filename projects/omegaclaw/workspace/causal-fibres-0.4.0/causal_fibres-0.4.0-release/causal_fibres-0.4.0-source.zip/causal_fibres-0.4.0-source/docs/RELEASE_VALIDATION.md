# Release validation: causal-fibres 0.4.0

## Environment

- Python 3.13.5
- PyTorch 2.10.0 CPU
- NumPy 2.3.5
- CUDA unavailable in the validation sandbox

The declared support floor remains Python 3.10 and PyTorch 2.1. The included CI
workflow targets Python 3.10--3.12.

## Automated checks

- 54 automated tests passed;
- `compileall` passed for source, tests, and examples;
- all YAML configurations validated;
- CLI `doctor`, `smoke-test`, and `list-representations` passed;
- wheel and source distribution built successfully;
- wheel installed into a clean target directory and exercised;
- source distribution installed into a clean target directory with
  `--no-build-isolation` and exercised.

The sandbox is offline and could not download an isolated setuptools build
dependency for a default sdist installation. This was an environment limitation,
not a source-package failure.

## Runnable examples

All runnable pre-0.4 examples passed, including terminal partial distillation,
continual adaptation, robust JBD, and operator emergence.

The five new examples also passed:

### Representation contest

The synthetic superposition/context-rotation example compared dense, SAE,
grouped SAE, orthogonal, and contextual-bundle steering models. The contextual
bundle had the lowest validation KL in this particular toy. SAE and grouped SAE
were retained as mandatory rivals; the example is not a general ranking claim.

### Observability control

Teacher-gap closure differed strongly by synthetic layer:

- early: about 0.184;
- middle: about 0.576;
- late: approximately 1.0.

This demonstrates that the frozen read interface can be a decisive bottleneck.

### Controlled co-adaptation

Validation MSE improved from about 1.746 under the frozen interface to about
0.671 after rank-2 substrate co-adaptation. Anchor drift was measured rather
than hidden.

### Finite curriculum order

Three complete update orders produced a maximum output-space distance of about
0.00166, demonstrating finite order measurement independent of local
commutator calculations.

### Settlement modes

Losses were reported separately:

- predictor only: 0.7250;
- free settlement: 0.6425;
- constrained settlement with additional information: 0.03125;
- teacher-clamped diagnostic: 0.0.

The clamped value is labeled as an oracle diagnostic.

## Clean-wheel smoke

The installed wheel exercised:

- overcomplete SAE coding;
- orthogonal fibre coding;
- observability probing;
- LoRA injection;
- held-out routing metrics;
- conservative certification;
- new configuration defaults.

## Remaining limitations

Validation does not establish real-Transformer causal emergence. It establishes
software coherence for the comparative and falsification-oriented workflow.
Large-model native adapters, distributed execution, dynamic tensor mutation,
and production symbolic integration remain future work.
