# Experiment checklist

## Interface and baselines

- [ ] ordinary BP residual on the exact proposed reads and writes;
- [ ] layerwise teacher-gap observability report;
- [ ] capacity curve;
- [ ] dense adapter;
- [ ] LoRA;
- [ ] SAE + steering;
- [ ] matched parameter, active-feature, wall-clock, and deployment-compute report.

## Representation contest

- [ ] dense bottleneck;
- [ ] SAE;
- [ ] grouped overcomplete dictionary;
- [ ] orthogonal fibres;
- [ ] contextual bundle where appropriate;
- [ ] held-out factor or intervention tests;
- [ ] no claim of causality from reconstruction alone.

## Plasticity and continual learning

- [ ] exact-gradient baseline;
- [ ] supplied-support upper bound;
- [ ] learned responsibility gate;
- [ ] replay and parameter-isolation controls;
- [ ] held-out-context routing;
- [ ] finite curriculum permutations;
- [ ] local commutator metrics compared with finite outcomes.

## Substrate plasticity

- [ ] frozen result recorded first;
- [ ] low-rank target modules documented;
- [ ] anchor drift measured;
- [ ] ordinary LoRA comparison;
- [ ] full fine-tuning comparison when affordable.

## PC/ePC

- [ ] predictor only;
- [ ] free settlement;
- [ ] constrained settlement and source of new information stated;
- [ ] teacher-clamped result labeled oracle diagnostic;
- [ ] matched recurrent/feed-forward compute baseline;
- [ ] energy descent not treated as causal certification.

## Highway

- [ ] explicit reason exact gradients are insufficient;
- [ ] held-out-context transfer test;
- [ ] comparison against exact gradients plus learned gates;
- [ ] transport conditioning and path consistency;
- [ ] cost or locality benefit measured.

## Symbolic cap

- [ ] large enough template set;
- [ ] hard negatives;
- [ ] compositional held-out tests;
- [ ] rule-mediated feedback changes behavior selectively;
- [ ] retrieval accuracy not used as the sole scientific result.
