# Partial Transformer distillation workflow

## Objective

Given a frozen student backbone `F0` and a stronger teacher `FT`, learn a small
structured residual `R` such that

```text
F(x) = F0(x) + R(x)
```

while making the residual suitable for:

- short PC/ePC-style state settlement;
- causal responsibility routing;
- context-local continual updates;
- explicit symbolic or semantic-frame alignment.

## Stage 0: frozen interface audit

Choose hidden-state sites and an output write location. Train an ordinary BP
sidecar with the same parameter budget. Measure teacher-gap closure for each
known factor and the full output distribution.

A failure at this stage indicates an observability or controllability problem,
not a PC problem.

## Stage 1: terminal latent sidecar

Use

```text
z0 = predictor(cached hidden states)
logits = base logits + writer(z)
```

and settle `z` under

```text
E(z) = KD(base + writer(z), teacher)
     + lambda_prior ||z - z0||^2 / 2
     + lambda_abs ||z||^2 / 2.
```

Train the predictor using both direct predictor-only KD and regression toward
the settled state.

Report:

- predictor-only loss;
- settled/clamped loss;
- amortization gap;
- settlement iterations and energy descent;
- wall-clock cost.

## Stage 2: gauge and metric hardening

Normalize writer norms or otherwise fix the state/write scale gauge. Compare
state-PC against damped LM/ePC settlement. For large states, replace true
Hessian curvature with a Gauss-Newton or empirical-Fisher metric.

## Stage 3: supplied factor fibres

For synthetic or richly annotated data, define canonical factor errors and
known supports. Constrain or fix write dictionaries where possible. This is the
cleanest proof-of-mechanism condition.

## Stage 4: learned causal highway

Train a factor-error encoder, responsibility router, and error transport against
an exact residual-gradient oracle. Keep an oracle blend:

```text
credit = alpha * oracle + (1 - alpha) * learned_highway.
```

Decrease `alpha` only when held-out audits pass.

## Stage 5: continual learning

Split each mature fibre into shared core and local shell. Use novelty filtering
for core writes, context-local gates for shells, and update-order commutator
audits.

## Stage 6: symbolic cap

Project fibre states into a static template key space. Validate retrieval and
selective symbolic feedback before connecting an external graph store or
asynchronous consolidation service.

## Recommended first GPU arms

- G0: BP sidecar.
- G1: exact-credit PC sidecar.
- G2: damped LM/ePC sidecar.
- G3: dense learned feedback.
- G4: known-support causal highway.
- G5: learned soft causal router plus transport.

Run matched-token, matched-update, and matched-wall-clock comparisons. Use at
least three seeds for exploratory work and five for a report-quality result.

## Version 0.4 prerequisite sequence

The terminal PC sidecar remains supported, but it is no longer the first
scientific condition. Run, in order:

1. frozen-read observability control;
2. dense/LoRA/SAE/structured representation contest;
3. exact-gradient plasticity gates and held-out-context tests;
4. controlled low-rank base co-adaptation when needed;
5. PC/ePC settlement at matched deployment compute;
6. learned highway only with an explicit locality, cost, or transfer reason;
7. symbolic cap only when additional test-time information is available.

A teacher-clamped settled state is an oracle diagnostic. The deployed result is
predictor-only or a clearly specified free/constrained settlement mode.
