# Deployment-honest evaluation

## Settlement modes

### Predictor only

The deployed feed-forward map from available features.

### Free settlement

Iterative inference with no information unavailable to the predictor. This can
show optimization or recurrent-compute benefits but not an information gain.

### Constrained settlement

Inference with new test-time information such as retrieval, persistent memory,
multimodal consistency, symbolic rules, or environment feedback.

### Teacher-clamped diagnostic

Oracle analysis using target or teacher information. Never report this as
deployment performance.

## Finite curricula

For context updates `U_A`, `U_B`, and `U_C`, evaluate complete sequences:

```math
U_C U_B U_A \theta_0,
\quad U_A U_B U_C \theta_0,
\quad U_B U_A U_C \theta_0.
```

Measure function-space distance on fixed old and new probes. Local commutators
are useful only insofar as they predict these finite effects.

## Held-out support routing

Train routers on some contexts and report support precision, recall,
off-support mass, and current-task performance on unseen contexts or
compositions. A router that only memorizes training task IDs has not learned a
transferable causal support function.

## Symbolic tests

Small template tables are API tests. Scientific evidence requires hard
negatives, compositional retrieval, unseen arguments, rule-mediated feedback,
and selective behavioral effects.
