# Colleague quick start

## Install

```bash
python -m pip install causal_fibres-0.4.0-py3-none-any.whl
causal-fibres doctor
causal-fibres smoke-test
causal-fibres list-representations
```

## Do not begin with a learned highway

Start with:

1. a frozen-read BP observability probe;
2. a dense/LoRA/SAE/structured representation contest;
3. exact gradients plus support-conditioned plasticity;
4. held-out-context routing and finite curriculum orders.

Only then test low-rank base co-adaptation, PC settlement, learned credit, or a
symbolic cap.

## Run examples

```bash
python examples/observability_control_demo.py
python examples/representation_contest_superposition_demo.py
python examples/finite_curriculum_order_demo.py
python examples/low_rank_coadaptation_demo.py
python examples/settlement_modes_demo.py
```

## Use the staged configs

```text
transformer_stage0_representation_contest.yaml
transformer_stage1_gated_plasticity.yaml
transformer_stage2_coadaptation.yaml
transformer_stage3_pc_constraints.yaml
transformer_stage4_optional_highway.yaml
```

## Reporting rules

Always separate:

- predictor-only performance;
- free settlement;
- constrained settlement with new information;
- teacher-clamped oracle diagnostics.

Always include SAE + steering and ordinary LoRA at matched budget.
