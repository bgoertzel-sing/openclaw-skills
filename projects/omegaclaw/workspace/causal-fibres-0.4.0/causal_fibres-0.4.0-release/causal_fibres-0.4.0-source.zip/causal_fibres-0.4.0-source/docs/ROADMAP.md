# Roadmap

## Near term

- native GPT-2/Llama/GLM residual-stream adapters;
- matched-budget representation-contest runner for real checkpoints;
- large-scale SAE integration and feature-steering reports;
- matrix-free Fisher/Gauss-Newton support for grouped dictionaries and bundles;
- held-out-context router training utilities;
- distributed finite curriculum-order evaluation;
- automatic report generation.

## Medium term

- structured low-rank contextual transports for large fibre bundles;
- dynamic split/merge with optimizer-state migration;
- persistent core/shell parameter partitions;
- asynchronous intervention workers;
- serious symbolic-cap benchmarks with hard negatives and rule feedback;
- Hyperon/MORK plugin.

## Research questions

- When do SAE groups outperform orthogonal fibres for continual learning?
- Can low-rank base co-adaptation create observability without destroying
  pretrained competence?
- Do local support leakage metrics predict finite curriculum sensitivity?
- Does PC settlement add value beyond matched recurrent adapters when no new
  information is introduced?
- Can a learned highway generalize credit to novel contexts better than exact
  gradients plus learned plasticity gates?
