# Extending causal-fibres

## New architecture adapter

Implement `BaseArchitectureAdapter` and return a `ForwardRecord` with:

- the final output tensor;
- named site tensors whose final dimension matches `SiteSpec.width`;
- useful auxiliary data such as masks and labels.

Implement `forward_with_writes` only when write semantics are explicit. Add a
fake-model unit test and document cache or suffix-recomputation behavior.

## New state solver

Implement `StateSolver.solve(initial, energy_fn, create_graph=False)`. Return a
`SolveResult` with energy history and diagnostics. Solvers should not update
persistent model parameters.

## New persistent learning rule

Implement `ParameterUpdateRule.step(ctx)`. The rule may use autograd, local
Hebbian updates, natural gradient, evolution, or a discrete structural update.

## New credit source

Return a `CreditPacket` in canonical fibre coordinates. Keep responsibility and
transport separate whenever possible.

## New context operator

Implement `dimension` and `matvec`. Dense materialization is optional. This is
enough for randomized sketches and many emergence audits.

## New symbolic store

Implement `query(keys, top_k)` returning scores, template keys, and values. The
core package does not assume a particular vector index or symbolic substrate.

## Plugin packages

Recommended optional package boundaries:

- `causal_fibres_hf`: native model-family adapters and distributed training.
- `causal_fibres_hyperon`: MORK/MeTTa template store and graph operations.
- `causal_fibres_kfac`: scalable Fisher and K-FAC metrics.
- `causal_fibres_viz`: dashboards and report generation.

## Adding a representation family

Implement an `nn.Module` with:

```python
encode(inputs, context=None)
decode(code, context=None)
forward(inputs, context=None) -> RepresentationOutput
interpretability_budget(inputs=None)
```

Register it in an application recipe rather than changing the package-wide
default. Representation models should expose interventions and group structure
when meaningful, but must not label features causal without certification.

## Adding an operator chart

Orthogonal block audits and overcomplete dictionary audits are separate
plugins. A new chart should state:

- synthesis and analysis maps;
- non-uniqueness or gauge assumptions;
- operator reconstruction error;
- sparsity or block metric;
- identifiability diagnostics.
