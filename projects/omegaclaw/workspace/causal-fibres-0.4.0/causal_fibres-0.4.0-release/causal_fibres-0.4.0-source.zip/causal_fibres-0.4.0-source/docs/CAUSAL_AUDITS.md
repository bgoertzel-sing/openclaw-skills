# Causal and emergence audits

Task loss is not sufficient to establish causal modularity. The package uses a
progressive certification ladder.

## Functional value

Ablate a fibre and measure the loss or behavior change. This shows that the
fibre matters but not that it is selective.

## Intervention selectivity

Perturb one fibre and compare intended versus unintended output effects.

## Responsibility fidelity

Compare router responsibilities with measured repair effects from small
interventions. Report precision, recall, calibration, and uncertainty.

## Off-support credit

Measure the fraction of state or parameter update mass outside a known or
inferred causal support.

## Operator block structure

Estimate context-conditioned operators `H_c` and minimize cross-block energy:

```text
sum_c sum_{q != r} ||U_q^T H_c U_r||_F^2.
```

Report context signatures, signature gaps, and pairwise emergence ratios.

## Transport fidelity

Report intervention alignment, path consistency, metric distortion, and
transport condition number. A correct router with a bad transport is still a
bad causal highway.

## Update commutators

Starting from the same checkpoint, compare one small update in orders `A -> B`
and `B -> A`. Use a function-space distance, not only parameter distance.

## Continual retention

Report old-context loss after every context, sequential-versus-joint gaps, and
the confusion graph of context pairs with both causal overlap and significant
noncommutativity.

## Semantic stability

When labels or templates exist, test whether fibre meaning survives seeds,
curriculum permutations, and base-model updates.

## Overcomplete and context-dependent alternatives

Do not interpret failure of joint block diagonalization as failure of all
structured representations. Compare:

- SAE atom interventions;
- grouped SAE fingerprint matrices;
- dictionary-coordinate operator sparsity;
- context-conditioned bundle transport consistency.

Use `audit_dictionary_operators` for overcomplete charts and
`NovelContextRoutingEvaluator` for held-out support generalization.
