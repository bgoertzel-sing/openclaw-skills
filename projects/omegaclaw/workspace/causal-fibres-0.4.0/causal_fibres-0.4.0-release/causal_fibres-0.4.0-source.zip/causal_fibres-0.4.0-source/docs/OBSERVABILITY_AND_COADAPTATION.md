# Observability and controlled substrate co-adaptation

## Frozen-read falsifier

Let `h` be the proposed frozen Transformer features, `f0` the base logits, and
`fT` the teacher logits. Fit an ordinary residual `R`:

```math
f_S = f_0 + R(h).
```

Report teacher-gap closure

```math
1 - \frac{\mathrm{KL}(f_T \Vert f_S)}
         {\mathrm{KL}(f_T \Vert f_0)}.
```

If a sufficiently expressive ordinary residual cannot close the gap, the
selected interface is not adequate for a frozen PC/CC sidecar. Change read
layers, pooling, write position, or allow substrate plasticity.

## Layerwise and capacity audits

Use `audit_layers` to compare read sites and `fit_capacity_curve` to identify
how much residual capacity is needed. Record held-out factors and combinations,
not only aggregate KD.

## Controlled low-rank co-adaptation

After the frozen control, selected base projections may receive LoRA updates:

```math
W = W_0 + \frac{\alpha}{r} B A.
```

Use an anchor trust region:

```math
L = L_{\mathrm{task}}
  + \lambda [D(f_{\mathrm{current}}, f_{\mathrm{anchor}})-\rho]_+^2.
```

Alternate residual and substrate steps so that structural objectives cannot
silently rewrite the entire base.

## Required comparisons

- frozen dense residual;
- frozen SAE + steering;
- frozen preferred structured representation;
- low-rank co-adaptive version;
- ordinary LoRA;
- full fine-tuning when affordable.
