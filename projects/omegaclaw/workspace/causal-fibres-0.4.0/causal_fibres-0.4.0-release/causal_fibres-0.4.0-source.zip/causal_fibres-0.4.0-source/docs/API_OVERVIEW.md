# API overview

## Core records

- `ForwardRecord`: backbone output and named captured sites.
- `FibreState`: canonical state, gates, prior, and write permissions.
- `StepContext`: mutable training and audit record.
- `CreditPacket`: canonical fibre-space learning message.
- `CFEConfig`: nested validated configuration.
- `CheckpointManager`: atomic research checkpoint format.

## Architecture adapters

- `FunctionalAdapter`: user-supplied forward and site functions.
- `HookedModuleAdapter`: arbitrary PyTorch named modules, with optional writes.
- `HFHiddenStatesAdapter`: Hugging Face-style hidden-state tuples and logits.

Adapters define architecture semantics. The remainder of the package sees only
named sites and output tensors.

## Fibre mechanics

- `MultiSiteFibrePredictor`, `IndependentFibrePredictor`
- `LinearFibreBank`
- `TerminalFibreSidecar`
- `FibrePlasticityController` for context-local persistent writes
- `IdentityPooler`, `MaskedMeanPooler`, `LastTokenPooler`, `AttentionPooler`
- gauge and contribution-balance losses

## Solvers

- `NoOpStateSolver`
- `GradientPCSolver`
- `PreconditionedPCSolver`
- `LevenbergMarquardtPCSolver`
- `ExplicitDampedHessianPreconditioner`
- `conjugate_gradient`

Solvers optimize transient latent state. They do not determine how persistent
parameters are updated.

## Credit and transport

- `AutogradOracleCredit`
- `DenseLinearCredit`
- `CausalHighwayCredit`
- `OracleBlend`
- `KnownSupportRouter`, `SoftTopKRouter`, `InfluenceRouter`
- `LinearFactorErrorEncoder`
- `SubspaceNoveltyFilter`
- `LinearErrorTransport`, `SiteTransportBank`
- Procrustes, path-consistency, and metric-compatibility utilities

## Operators and emergence

- `AutogradHessianOperator`
- `AutogradGaussNewtonOperator`
- `PerSampleGradientFisherOperator`
- `DenseOperator`, `CallableOperator`, `SumOperator`
- randomized range and Hutchinson trace estimators
- `JointBlockDiagonalizer` -- commutant/spectral multi-start discovery plus Riemannian refinement
- `JointDiagonalizationResult` -- basis, blocks, emergence report, and solver diagnostics
- `approximate_symmetric_commutant` -- low-residual commuting-matrix analysis
- `CommutantDiagnostics` -- nullity, singular-gap, and identifiability warnings
- `emergence_report`

## Interventions and lifecycle

- `FibreInterventionEngine`
- `FingerprintTracker`
- `RandomDirectionalPolicy`, `AblationPolicy`
- `FibreRegistry`, `FibreDescriptor`, `FibreStatus`
- `ThresholdLifecyclePolicy`, `LifecycleManager`

## Training

- `PartialDistillationTrainer`
- `CFEEngine`
- callbacks and schedules
- masked KD and causal-LM cross entropy
- continual-learning retention and commutator utilities

## Symbolic

- `TemplateStore` protocol
- `StaticTemplateStore`, `MutableTemplateStore`
- `SymbolicFibreHead`

## Version 0.4 structural-adaptation APIs

### Competing representations

```python
from causal_fibres.representations import (
    DenseResidualRepresentation,
    SparseAutoencoder,
    GroupedSparseDictionary,
    OrthogonalFibreRepresentation,
    ContextualFibreBundle,
    RepresentationContest,
    RepresentationSteeringContest,
)
```

### Observability

```python
from causal_fibres.observability import (
    FrozenReadProbe,
    audit_layers,
    fit_capacity_curve,
)
```

### Baselines and substrate plasticity

```python
from causal_fibres.baselines import (
    DenseAdapterBaseline,
    LoRALinear,
    SAEFeatureSteering,
    ReplayBuffer,
    ParameterIsolationBaseline,
)
from causal_fibres.substrate import (
    LowRankBasePlasticity,
    AnchorTrustRegion,
    AlternatingResidualBaseTrainer,
)
```

### Evaluation and certification

```python
from causal_fibres.evaluation import (
    FreeSettlementEvaluator,
    MatchedComputeEvaluator,
    FiniteCurriculumLoopEvaluator,
    NovelContextRoutingEvaluator,
)
from causal_fibres.certification import ModuleCertifier, CertificationEvidence
```

### Overcomplete operator audit

```python
from causal_fibres.operators import audit_dictionary_operators
```
