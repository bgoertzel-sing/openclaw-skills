# Software design

## Purpose

`causal-fibres` is a comparative structural-adaptation toolkit. It supports
orthogonal causal fibres, but it does not assume they are the default geometry
of trained neural networks.

The top-level pipeline is:

```text
architecture adapter
    -> frozen observability control
    -> representation contest
    -> exact-gradient plasticity test
    -> optional substrate co-adaptation
    -> optional PC/ePC state inference
    -> optional learned highway
    -> optional symbolic cap
    -> finite-horizon and causal certification
```

## Separation of concerns

```text
architecture reads/writes        != representation model
representation model             != persistent update rule
state settlement                 != new test-time information
causal responsibility            != coordinate transport
exact task credit                != plasticity permission
local commutator                 != finite curriculum outcome
functional feature               != causally identified mechanism
```

## Package layers

### `architectures`

Captures named states and applies writes without deciding how those states are
represented or learned.

### `representations`

Competing models of latent organization:

- dense;
- sparse overcomplete;
- grouped sparse;
- orthogonal block;
- context-conditioned bundle.

### `baselines`

Dense adapters, LoRA, SAE steering, replay, and parameter isolation.

### `observability`

Tests whether the proposed frozen interface can express the teacher correction.

### `substrate`

Low-rank co-adaptation and anchor trust regions.

### `fibres` and `credit`

Canonical fibre mechanics, exact-gradient gates, and optional learned credit
transport.

### `solvers`

State-PC and ePC-like inference. Solvers are not assumed to improve deployment
unless free or constrained settlement wins at matched compute.

### `operators`

Common-block and overcomplete dictionary-coordinate structural audits.

### `evaluation`

Settlement modes, matched compute, held-out routing, and finite curricula.

### `certification`

Conservative evidence levels for learned modules.

### `symbolic`

Store-neutral symbolic retrieval and feedback contracts.

## Extension rules

A new representation should implement:

```python
encode(inputs, context=None)
decode(code, context=None)
forward(inputs, context=None) -> RepresentationOutput
interpretability_budget(inputs=None)
```

A new architecture plugin should expose stable named sites and explicit write
semantics. A new update rule should not need to know whether the representation
is an SAE, orthogonal fibres, or a contextual bundle.

## Safe default

The default scientific recipe is:

```text
dense representation
+ frozen base
+ exact autograd credit
+ no PC settlement
+ observability and SAE baseline required
```

Each additional mechanism must earn its place through the stage gates in
`causal_fibres.recipes.structural`.
