"""Compatibility shim for older packaging tools; metadata lives in pyproject.toml."""

from setuptools import setup

setup()
