import torch

from causal_fibres.symbolic import MutableTemplateStore, SymbolicFibreHead


def test_symbolic_head_retrieval_and_mutable_store():
    torch.manual_seed(2)
    keys = torch.eye(4)
    values = torch.randn(4, 3)
    store = MutableTemplateStore(keys, values)
    head = SymbolicFibreHead(2, 2, 4, 3, top_k=2)
    state = torch.randn(5, 2, 2)
    output = head.retrieve(state, store)
    assert output.queries.shape == (5, 2, 4)
    assert output.summary.shape == (5, 2, 3)
    assert output.feedback.shape == (5, 2, 2)
    old_size = store.size
    indices = store.add(torch.randn(1, 4), torch.randn(1, 3), [{"name": "new"}])
    assert store.size == old_size + 1
    assert indices == [old_size]
