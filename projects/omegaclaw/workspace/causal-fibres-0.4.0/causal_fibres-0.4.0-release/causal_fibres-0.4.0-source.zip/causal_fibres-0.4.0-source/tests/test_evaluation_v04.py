import torch
from torch import nn

from causal_fibres.evaluation import (
    FiniteCurriculumLoopEvaluator,
    FreeSettlementEvaluator,
    NovelContextRoutingEvaluator,
)


def test_settlement_modes_keep_clamped_diagnostic_separate():
    target = torch.tensor([1.0])
    evaluator = FreeSettlementEvaluator(lambda output: ((output - target) ** 2).mean())
    report = evaluator.evaluate(
        predictor_fn=lambda: torch.tensor([0.0]),
        free_fn=lambda: torch.tensor([0.2]),
        constrained_fn=lambda: torch.tensor([0.8]),
        clamped_fn=lambda: torch.tensor([1.0]),
    )
    assert report.predictor_to_constrained_gain > report.predictor_to_free_gain
    assert report.amortization_gap == 1.0
    assert "oracle diagnostic" in report.metadata["warning"]


def test_finite_curriculum_evaluator_detects_order_dependence():
    model = nn.Linear(1, 1, bias=False)
    with torch.no_grad():
        model.weight.fill_(1.0)

    def update(module, context):
        with torch.no_grad():
            if context == "scale":
                module.weight.mul_(2.0)
            else:
                module.weight.add_(1.0)
        return None

    evaluator = FiniteCurriculumLoopEvaluator(
        model,
        update_fn=update,
        output_fn=lambda module: module(torch.ones(1, 1)),
        distance_fn=lambda first, second: ((first - second) ** 2).mean(),
    )
    report = evaluator.evaluate({"AB": ["scale", "shift"], "BA": ["shift", "scale"]})
    assert report.maximum_order_distance > 0
    assert torch.allclose(model.weight, torch.ones_like(model.weight))


def test_novel_context_routing_reports_generalization():
    evaluator = NovelContextRoutingEvaluator()
    support = torch.tensor([[1, 0, 0], [0, 1, 0]], dtype=torch.bool)
    train = torch.tensor([[0.9, 0.05, 0.05], [0.05, 0.9, 0.05]])
    held = torch.tensor([[0.7, 0.2, 0.1], [0.2, 0.6, 0.2]])
    report = evaluator.evaluate(
        training_responsibility=train,
        training_support=support,
        held_out_responsibility=held,
        held_out_support=support,
        top_k=1,
    )
    assert report.training.f1 == 1.0
    assert report.held_out.f1 == 1.0
    assert report.held_out.off_support_mass > report.training.off_support_mass
