import torch

from causal_fibres.fibres import (
    FibrePlasticityController,
    IndependentFibrePredictor,
    LinearFibreBank,
)


def test_plasticity_controller_masks_inactive_branch_and_writer():
    predictor = IndependentFibrePredictor({"h": 3}, 2, 1, hidden_dim=None)
    writer = LinearFibreBank(2, 1, 4)
    sites = {"h": torch.randn(5, 3)}
    state = predictor(sites)
    output = writer(state)
    output.square().mean().backward()
    controller = FibrePlasticityController(
        2,
        predictor=predictor,
        writer=writer,
        mask=torch.tensor([True, False]),
    )
    metrics = controller.apply()
    for parameter in predictor.branches[1].parameters():
        assert parameter.grad is not None
        assert torch.count_nonzero(parameter.grad) == 0
    assert torch.count_nonzero(writer.weight.grad[1]) == 0
    assert metrics["plasticity_masked_fraction"] > 0


def test_responsibility_gradient_gate_scales_exact_gradients():
    from causal_fibres.fibres import ResponsibilityGradientGate

    first = torch.nn.Parameter(torch.tensor([1.0]))
    second = torch.nn.Parameter(torch.tensor([1.0]))
    (first.square() + second.square()).backward()
    gate = ResponsibilityGradientGate([[first], [second]])
    metrics = gate.apply(torch.tensor([1.0, 0.25]))
    assert torch.allclose(first.grad, torch.tensor([2.0]))
    assert torch.allclose(second.grad, torch.tensor([0.5]))
    assert metrics["gradient_retained_fraction"] < 1.0
