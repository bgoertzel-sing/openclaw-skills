from types import SimpleNamespace

import torch
from torch import nn

from causal_fibres.architectures import HFHiddenStatesAdapter, HookedModuleAdapter


class TinyHookModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.hidden = nn.Linear(3, 4, bias=False)
        self.out = nn.Linear(4, 2, bias=False)

    def forward(self, x):
        return self.out(self.hidden(x))


def test_hooked_adapter_intermediate_write_changes_output():
    torch.manual_seed(0)
    model = TinyHookModel()
    adapter = HookedModuleAdapter(
        model,
        sites={"hidden": "hidden"},
        widths={"hidden": 4},
        freeze=True,
    )
    x = torch.randn(2, 3)
    base = adapter.forward_base(x)
    write = torch.ones_like(base.sites["hidden"])
    changed = adapter.forward_with_writes(x, {"hidden": write})
    assert not torch.allclose(base.output, changed.output)
    assert base.sites["hidden"].shape == (2, 4)


class FakeHFModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.config = SimpleNamespace(hidden_size=6)
        self.embedding = nn.Embedding(11, 6)
        self.blocks = nn.ModuleList([nn.Linear(6, 6) for _ in range(2)])
        self.head = nn.Linear(6, 11)

    def forward(self, input_ids, output_hidden_states=False, return_dict=True, use_cache=False, **kwargs):
        del use_cache, kwargs
        hidden = self.embedding(input_ids)
        states = [hidden]
        for block in self.blocks:
            hidden = torch.tanh(block(hidden))
            states.append(hidden)
        output = SimpleNamespace(logits=self.head(hidden), hidden_states=tuple(states))
        return output if return_dict else (output.logits, output.hidden_states)


def test_hf_hidden_states_adapter_without_transformers_dependency():
    model = FakeHFModel()
    adapter = HFHiddenStatesAdapter(model, layers={"embedding": 0, "late": 2})
    batch = {
        "input_ids": torch.randint(0, 11, (3, 5)),
        "attention_mask": torch.ones(3, 5, dtype=torch.long),
    }
    record = adapter.forward_base(batch)
    assert record.output.shape == (3, 5, 11)
    assert record.sites["embedding"].shape == (3, 5, 6)
    assert record.sites["late"].shape == (3, 5, 6)
