import torch

from causal_fibres.interventions import (
    FibreInterventionEngine,
    FingerprintTracker,
    InterventionSpec,
)
from causal_fibres.lifecycle import (
    FibreEvent,
    FibreEventType,
    FibreRegistry,
    FibreStatus,
    LifecycleManager,
    ThresholdLifecyclePolicy,
)


def test_intervention_engine_detects_repair():
    state = torch.tensor([[[2.0], [0.5]]])
    engine = FibreInterventionEngine(epsilon=1e-3)

    def compose(value):
        return value.sum(dim=-2)

    def loss(output):
        return (output - 1.0).square().mean()

    results = engine.evaluate(
        state,
        [InterventionSpec(fibre=0, mode="replace", value=torch.tensor([0.5]))],
        compose,
        loss,
    )
    assert results[0].repair_effect > 0


def test_fingerprint_tracker_and_registry_lifecycle():
    tracker = FingerprintTracker(3, 2, decay=0.5)
    tracker.update(0, 0, 1.0)
    tracker.update(1, 1, 1.0)
    assert float(tracker.conditioning()) >= 0
    state = tracker.state_dict()
    restored = FingerprintTracker(3, 2)
    restored.load_state_dict(state)
    assert torch.allclose(restored.values, tracker.values)

    registry = FibreRegistry.create(4, reserve_fraction=0.25)
    manager = LifecycleManager(registry)
    pending = manager.apply(
        [
            FibreEvent(FibreEventType.PROMOTE, fibres=(0,)),
            FibreEvent(FibreEventType.SPLIT, fibres=(1,)),
        ]
    )
    assert registry.by_index(0).status == FibreStatus.CONSOLIDATED
    assert pending[0].kind == FibreEventType.SPLIT


def test_threshold_policy_proposes_spawn_and_merge():
    policy = ThresholdLifecyclePolicy()
    events = policy.propose(
        {
            "unexplained_error_fraction": 0.5,
            "reserve_fibres": 2,
            "duplicate_similarity": {(0, 1): 0.99},
        }
    )
    kinds = {event.kind for event in events}
    assert FibreEventType.SPAWN in kinds
    assert FibreEventType.MERGE in kinds
