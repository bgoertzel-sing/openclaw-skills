import torch

from causal_fibres.core.types import ForwardRecord
from causal_fibres.credit.router import KnownSupportRouter, SoftTopKRouter
from causal_fibres.fibres import LinearFibreBank, MultiSiteFibrePredictor, TerminalFibreSidecar


def test_known_support_router_is_exact():
    features = torch.randn(3, 4, 2)
    support = torch.tensor([[1, 0, 1, 0]], dtype=torch.float32)
    router = KnownSupportRouter()
    gate = router(features, known_support=support)
    assert gate.shape == (3, 4)
    assert torch.equal(gate[0], support[0])


def test_soft_topk_router_budget():
    features = torch.randn(5, 6, 3)
    router = SoftTopKRouter(6, 3, top_k=2)
    gate = router(features)
    assert gate.shape == (5, 6)
    assert torch.allclose(gate.sum(dim=-1), torch.ones(5), atol=1e-6)
    assert (gate > 0).sum(dim=-1).max().item() <= 2


def test_terminal_sidecar_shapes():
    predictor = MultiSiteFibrePredictor({"a": 7, "b": 5}, 4, 3)
    writer = LinearFibreBank(4, 3, 2)
    router = SoftTopKRouter(4, 3, top_k=2)
    sidecar = TerminalFibreSidecar(predictor, writer, router)
    record = ForwardRecord(
        output=torch.randn(8, 2),
        sites={"a": torch.randn(8, 7), "b": torch.randn(8, 5)},
    )
    state = sidecar.predict(record)
    output = sidecar.compose(record, state)
    assert state.value.shape == (8, 4, 3)
    assert state.gate.shape == (8, 4)
    assert output.shape == (8, 2)
