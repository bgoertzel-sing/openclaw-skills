import torch

from causal_fibres.operators import audit_dictionary_operators, dictionary_operator_coordinates


def test_overcomplete_dictionary_operator_audit():
    torch.manual_seed(0)
    dictionary = torch.nn.functional.normalize(torch.randn(8, 4), dim=-1)
    operator = torch.randn(4, 4)
    coordinates = dictionary_operator_coordinates(operator, dictionary)
    assert coordinates.shape == (8, 8)
    groups = torch.zeros(2, 8)
    groups[0, :4] = 1
    groups[1, 4:] = 1
    report = audit_dictionary_operators([operator], dictionary, group_membership=groups)
    assert report.dictionary_rank == 4
    assert report.mean_off_group_fraction is not None
    assert 0 <= report.mean_coordinate_sparsity <= 1
