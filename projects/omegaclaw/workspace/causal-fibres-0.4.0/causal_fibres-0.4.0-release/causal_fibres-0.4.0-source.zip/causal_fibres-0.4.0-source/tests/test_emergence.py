import torch

from causal_fibres.operators import (
    emergence_report,
    joint_block_diagonalization_loss,
    pairwise_emergence_ratio,
)


def test_true_blocks_have_zero_cross_energy_and_large_ratio():
    operators = [
        torch.diag(torch.tensor([1.0, 1.0, 3.0, 3.0])),
        torch.diag(torch.tensor([2.0, 2.0, 5.0, 5.0])),
    ]
    blocks = (torch.eye(4)[:, :2], torch.eye(4)[:, 2:])
    loss = joint_block_diagonalization_loss(operators, blocks)
    ratios = pairwise_emergence_ratio(operators, blocks, estimation_noise=1e-3)
    report = emergence_report(operators, blocks, estimation_noise=1e-3)
    assert float(loss) < 1e-10
    assert float(ratios[0, 1]) > 1e6
    assert report.signature_gap > 0


def test_rotated_blocks_have_cross_energy():
    angle = torch.tensor(0.4)
    rotation = torch.tensor(
        [
            [torch.cos(angle), 0.0, -torch.sin(angle), 0.0],
            [0.0, torch.cos(angle), 0.0, -torch.sin(angle)],
            [torch.sin(angle), 0.0, torch.cos(angle), 0.0],
            [0.0, torch.sin(angle), 0.0, torch.cos(angle)],
        ]
    )
    operators = [torch.diag(torch.tensor([1.0, 1.0, 4.0, 4.0]))]
    blocks = (rotation[:, :2], rotation[:, 2:])
    loss = joint_block_diagonalization_loss(operators, blocks)
    assert float(loss) > 0.1
