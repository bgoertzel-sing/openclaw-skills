import torch

from causal_fibres.solvers import LevenbergMarquardtPCSolver


def test_lm_solver_handles_anisotropic_quadratic():
    target = torch.tensor([1.5, -2.0])
    scale = torch.tensor([100.0, 0.25])

    def energy(state):
        return 0.5 * (scale * (state - target).square()).sum()

    solver = LevenbergMarquardtPCSolver(steps=5, damping=0.1, cg_max_iter=8)
    result = solver.solve(torch.zeros_like(target), energy)
    assert result.energies[-1] < result.energies[0] * 1e-4
    assert torch.allclose(result.state.detach(), target, atol=2e-2)
    assert "damping_history" in result.diagnostics
