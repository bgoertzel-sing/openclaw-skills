import torch

from causal_fibres.core.types import ForwardRecord
from causal_fibres.recipes import (
    build_canonical_binary_factor_sidecar,
    canonical_binary_factor_write,
)


def test_canonical_binary_write_has_selective_support():
    weight = canonical_binary_factor_write(3)
    assert weight.shape == (3, 1, 6)
    assert torch.count_nonzero(weight[0]) == 2
    assert torch.count_nonzero(weight[0, :, 2:]) == 0


def test_canonical_binary_sidecar_known_support():
    sidecar = build_canonical_binary_factor_sidecar({"h": 4}, 2)
    record = ForwardRecord(output=torch.zeros(3, 4), sites={"h": torch.randn(3, 4)})
    support = torch.tensor([[1.0, 0.0]]).expand(3, -1)
    state = sidecar.predict(record, known_support=support)
    output = sidecar.compose(record, state)
    assert output.shape == (3, 4)
    assert torch.all(state.gate[:, 1] == 0)
