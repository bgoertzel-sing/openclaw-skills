from causal_fibres.core import CFEConfig


def test_new_config_sections_and_conservative_defaults():
    config = CFEConfig().validate()
    assert config.representation.kind == "dense"
    assert config.evaluation.require_sae_baseline
    assert config.substrate.kind == "frozen"
    assert config.credit.kind == "oracle_gated"
    restored = CFEConfig.from_mapping(config.to_dict())
    assert restored.representation.dictionary_size == config.representation.dictionary_size
