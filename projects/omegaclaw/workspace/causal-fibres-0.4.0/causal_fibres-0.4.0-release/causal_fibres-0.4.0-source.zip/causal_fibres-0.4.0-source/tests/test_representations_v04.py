import torch

from causal_fibres.representations import (
    ContextualFibreBundle,
    GroupedSparseDictionary,
    OrthogonalFibreRepresentation,
    SparseAutoencoder,
)


def test_sparse_autoencoder_is_overcomplete_and_topk():
    torch.manual_seed(0)
    model = SparseAutoencoder(6, 12, top_k=3)
    inputs = torch.randn(8, 6)
    output = model(inputs)
    assert output.code.shape == (8, 12)
    assert output.reconstruction.shape == inputs.shape
    assert torch.all((output.code != 0).sum(dim=-1) <= 3)
    assert model.dictionary.shape == (12, 6)
    assert torch.allclose(model.dictionary.norm(dim=-1), torch.ones(12), atol=1e-5)


def test_grouped_dictionary_supports_overlap():
    model = GroupedSparseDictionary(
        5,
        8,
        groups=[[0, 1, 2], [2, 3, 4], [5, 6, 7]],
        top_k=2,
    )
    inputs = torch.randn(4, 5)
    output = model(inputs)
    activity = model.group_activity(output.code)
    assert activity.shape == (4, 3)
    gate = torch.tensor([[1.0, 0.0, 0.0]]).expand(4, -1)
    gated = model.apply_group_gate(output.code, gate)
    assert torch.all(gated[..., 3:] == 0)


def test_orthogonal_fibres_have_orthonormal_basis():
    model = OrthogonalFibreRepresentation(8, 2, 3)
    inputs = torch.randn(7, 8)
    output = model(inputs)
    basis = model.basis
    assert output.code.shape == (7, 2, 3)
    assert torch.allclose(basis.T @ basis, torch.eye(6), atol=1e-5)
    projector = model.fibre_projector(0)
    assert torch.allclose(projector, projector.T, atol=1e-6)


def test_contextual_bundle_transport_is_orthogonal_and_path_consistent():
    torch.manual_seed(1)
    model = ContextualFibreBundle(7, 2, 2, context_dim=3, transport_strength=0.5)
    # Make the transport non-trivial.
    with torch.no_grad():
        model.transport_generator.weight.normal_(std=0.1)
    context_a = torch.randn(5, 3)
    context_b = torch.randn(5, 3)
    context_c = torch.randn(5, 3)
    transport = model.transport_matrix(context_a)
    eye = torch.eye(4).expand(5, 4, 4)
    assert torch.allclose(transport.transpose(-1, -2) @ transport, eye, atol=1e-5)
    assert float(model.path_consistency_loss(context_a, context_b, context_c).detach()) < 1e-10
    output = model(torch.randn(5, 7), context=context_a)
    assert output.code.shape == (5, 2, 2)
