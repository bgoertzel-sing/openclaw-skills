from pathlib import Path

import torch
from torch import nn

from causal_fibres.core import CFEConfig, CheckpointManager
from causal_fibres.lifecycle import FibreRegistry


def test_config_roundtrip_yaml_and_json(tmp_path: Path):
    config = CFEConfig()
    config.fibre.n_fibres = 6
    config.router.top_k = 3
    config.validate()
    yaml_path = tmp_path / "config.yaml"
    json_path = tmp_path / "config.json"
    config.to_yaml(yaml_path)
    config.to_json(json_path)
    assert CFEConfig.from_yaml(yaml_path).fibre.n_fibres == 6
    assert CFEConfig.from_json(json_path).router.top_k == 3


def test_checkpoint_roundtrip(tmp_path: Path):
    torch.manual_seed(1)
    model = nn.Linear(3, 2)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-2)
    x = torch.randn(4, 3)
    model(x).square().mean().backward()
    optimizer.step()
    expected = {name: value.detach().clone() for name, value in model.state_dict().items()}
    registry = FibreRegistry.create(4, reserve_fraction=0.25)
    path = tmp_path / "checkpoint.pt"
    CheckpointManager.save(
        path,
        model=model,
        optimizer=optimizer,
        step=12,
        config=CFEConfig(),
        fibre_registry=registry.to_dict(),
        metrics={"loss": 0.25},
    )
    with torch.no_grad():
        for parameter in model.parameters():
            parameter.zero_()
    payload = CheckpointManager.load(path, model=model, optimizer=optimizer)
    assert payload["step"] == 12
    for name, value in model.state_dict().items():
        assert torch.allclose(value, expected[name])
    inspected = CheckpointManager.inspect(path)
    assert inspected["metrics"]["loss"] == 0.25
