import torch

from causal_fibres.observability import FrozenReadProbe, fit_capacity_curve


def _data():
    torch.manual_seed(0)
    features = torch.randn(320, 10)
    base = torch.randn(320, 6) * 0.2
    correction = features @ torch.randn(10, 6) * 0.4
    teacher = base + correction
    return (
        features[:240],
        base[:240],
        teacher[:240],
        features[240:],
        base[240:],
        teacher[240:],
    )


def test_frozen_read_probe_closes_teacher_gap():
    values = _data()
    probe = FrozenReadProbe(10, 6, kind="low_rank", capacity=10, steps=160, learning_rate=1e-2)
    result = probe.fit(*values)
    assert result.teacher_gap_closure > 0.9
    assert result.validation_loss < result.base_loss


def test_teacher_gap_capacity_curve():
    values = _data()
    curve = fit_capacity_curve(
        [2, 6, 10],
        probe_factory=lambda capacity: FrozenReadProbe(
            10,
            6,
            kind="low_rank",
            capacity=capacity,
            steps=100,
            learning_rate=1e-2,
            seed=capacity,
        ),
        train_features=values[0],
        train_base_logits=values[1],
        train_teacher_logits=values[2],
        validation_features=values[3],
        validation_base_logits=values[4],
        validation_teacher_logits=values[5],
    )
    assert len(curve.points) == 3
    assert curve.points[-1].result.teacher_gap_closure > curve.points[0].result.teacher_gap_closure
    assert curve.minimum_capacity_for(0.8) is not None
