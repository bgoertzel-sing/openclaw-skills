import torch

from causal_fibres.core.types import ForwardRecord
from causal_fibres.fibres import (
    LastTokenPooler,
    LinearFibreBank,
    MaskedMeanPooler,
    MultiSiteFibrePredictor,
    TerminalFibreSidecar,
)


def test_poolers_respect_mask():
    values = torch.tensor([[[1.0], [3.0], [9.0]], [[2.0], [4.0], [8.0]]])
    mask = torch.tensor([[1, 1, 0], [1, 0, 0]], dtype=torch.bool)
    mean = MaskedMeanPooler()(values, mask=mask)
    last = LastTokenPooler()(values, mask=mask)
    assert torch.allclose(mean.squeeze(-1), torch.tensor([2.0, 2.0]))
    assert torch.allclose(last.squeeze(-1), torch.tensor([3.0, 2.0]))


def test_predictor_with_poolers_and_sidecar_active_mask():
    predictor = MultiSiteFibrePredictor(
        {"a": 3, "b": 3},
        3,
        2,
        site_poolers={"a": MaskedMeanPooler(), "b": LastTokenPooler()},
    )
    writer = LinearFibreBank(3, 2, 4)
    sidecar = TerminalFibreSidecar(
        predictor,
        writer,
        residual_scale=1.0,
        active_mask=torch.tensor([True, False, True]),
    )
    record = ForwardRecord(
        output=torch.zeros(2, 4),
        sites={"a": torch.randn(2, 5, 3), "b": torch.randn(2, 5, 3)},
    )
    state = sidecar.predict(record, context={"attention_mask": torch.ones(2, 5)})
    assert state.value.shape == (2, 3, 2)
    assert state.gate is not None
    assert torch.all(state.gate[:, 1] == 0)
