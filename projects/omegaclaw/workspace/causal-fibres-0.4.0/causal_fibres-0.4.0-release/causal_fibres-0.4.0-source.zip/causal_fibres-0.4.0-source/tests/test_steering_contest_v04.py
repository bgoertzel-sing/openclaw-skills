import torch

from causal_fibres.representations import (
    DenseResidualRepresentation,
    RepresentationSteeringContest,
    RepresentationSteeringModel,
    SparseAutoencoder,
)


def test_representation_steering_contest_runs_dense_and_sae():
    torch.manual_seed(0)
    hidden = torch.randn(160, 8)
    base = torch.randn(160, 4) * 0.1
    teacher = base + hidden @ torch.randn(8, 4) * 0.2
    models = {
        "dense": RepresentationSteeringModel(
            DenseResidualRepresentation(8, 6), code_width=6, output_dim=4
        ),
        "sae": RepresentationSteeringModel(
            SparseAutoencoder(8, 12, top_k=3), code_width=12, output_dim=4
        ),
    }
    contest = RepresentationSteeringContest(
        models,
        pretrain_steps=10,
        steering_steps=20,
        batch_size=64,
        learning_rate=1e-2,
    )
    result = contest.fit(
        hidden[:120],
        base[:120],
        teacher[:120],
        hidden[120:],
        base[120:],
        teacher[120:],
    )
    assert set(result.entries) == {"dense", "sae"}
    assert result.entries[result.winner].validation_kl >= 0
