from causal_fibres.core import RepresentationConfig
from causal_fibres.recipes import StructuralStage, build_representation, stage_gate
from causal_fibres.representations import SparseAutoencoder


def test_representation_builder_and_stage_gates():
    model = build_representation(
        RepresentationConfig(kind="sae", dictionary_size=16, top_k=4),
        input_dim=8,
    )
    assert isinstance(model, SparseAutoencoder)
    blocked = stage_gate(
        StructuralStage.LEARNED_HIGHWAY,
        observability_gap_closure=0.9,
        representation_has_winner=True,
        learned_support_f1=0.9,
        exact_gradient_is_bottleneck=False,
    )
    assert not blocked.allowed
    allowed = stage_gate(
        StructuralStage.LEARNED_HIGHWAY,
        observability_gap_closure=0.9,
        representation_has_winner=True,
        learned_support_f1=0.9,
        exact_gradient_is_bottleneck=True,
    )
    assert allowed.allowed
