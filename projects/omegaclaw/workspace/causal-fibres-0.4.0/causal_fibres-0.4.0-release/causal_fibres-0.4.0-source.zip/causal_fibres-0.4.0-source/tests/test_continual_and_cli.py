import torch
from torch import nn

from causal_fibres.cli import main
from causal_fibres.training import function_space_update_commutator


class TwoParameterModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.value = nn.Parameter(torch.zeros(2))


def test_disjoint_updates_commute_in_function_space():
    model = TwoParameterModel()

    def update_a(candidate):
        with torch.no_grad():
            candidate.value[0] += 1.0

    def update_b(candidate):
        with torch.no_grad():
            candidate.value[1] -= 2.0

    distance = function_space_update_commutator(
        model,
        update_a,
        update_b,
        evaluate=lambda candidate: candidate.value.detach().clone(),
        distance=lambda left, right: (left - right).norm(),
    )
    assert distance == 0.0


def test_cli_smoke_test_runs():
    assert main(["smoke-test", "--steps", "5"]) == 0
