import torch

from causal_fibres.solvers import GradientPCSolver, PreconditionedPCSolver


def test_gradient_pc_decreases_quadratic_energy():
    target = torch.tensor([1.0, -2.0, 0.5])
    initial = torch.zeros_like(target)
    solver = GradientPCSolver(steps=8, step_size=0.5, backtracking=True)
    result = solver.solve(initial, lambda state: 0.5 * (state - target).square().sum())
    assert result.energies[-1] < result.energies[0]
    assert torch.allclose(result.state.detach(), target, atol=1e-2)


def test_preconditioned_pc_decreases_energy():
    target = torch.tensor([2.0, -1.0])
    scale = torch.tensor([10.0, 0.5])

    def energy(state):
        return 0.5 * (scale * (state - target).square()).sum()

    def preconditioner(state, gradient, energy_fn):
        del state, energy_fn
        return gradient / scale

    solver = PreconditionedPCSolver(preconditioner, steps=2, step_size=1.0)
    result = solver.solve(torch.zeros_like(target), energy)
    assert result.energies[-1] < result.energies[0]
    assert torch.allclose(result.state.detach(), target, atol=1e-5)
