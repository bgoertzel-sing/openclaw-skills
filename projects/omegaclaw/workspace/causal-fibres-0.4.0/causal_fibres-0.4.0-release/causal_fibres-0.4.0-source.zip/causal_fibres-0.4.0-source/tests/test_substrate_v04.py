import torch
from torch import nn

from causal_fibres.baselines import LoRALinear
from causal_fibres.substrate import (
    AlternatingResidualBaseTrainer,
    AnchorTrustRegion,
    LowRankBasePlasticity,
)


def test_low_rank_base_plasticity_and_merge():
    model = nn.Sequential(nn.Linear(4, 6), nn.ReLU(), nn.Linear(6, 3))
    manager = LowRankBasePlasticity(model, rank=2, module_names=["0"])
    assert isinstance(model[0], LoRALinear)
    report = manager.report()
    assert report.trainable_parameters > 0
    assert report.trainable_fraction < 1
    inputs = torch.randn(2, 4)
    output_before = model(inputs)
    manager.merge_()
    assert isinstance(model[0], nn.Linear)
    output_after = model(inputs)
    assert torch.allclose(output_before, output_after, atol=1e-6)


def test_anchor_trust_region_zero_inside_radius():
    penalty = AnchorTrustRegion(kind="mse", radius=0.1, weight=2.0)
    anchor = torch.zeros(3, 4)
    current = torch.full((3, 4), 0.1)
    assert float(penalty(current, anchor)) == 0.0
    assert float(penalty(torch.ones(3, 4), anchor)) > 0


def test_alternating_trainer_updates_both_parameter_groups():
    residual = nn.Parameter(torch.tensor(1.0))
    substrate = nn.Parameter(torch.tensor(-1.0))
    residual_optimizer = torch.optim.SGD([residual], lr=0.1)
    substrate_optimizer = torch.optim.SGD([substrate], lr=0.1)
    trainer = AlternatingResidualBaseTrainer(
        residual_parameters=[residual],
        substrate_parameters=[substrate],
        residual_optimizer=residual_optimizer,
        substrate_optimizer=substrate_optimizer,
        gradient_clip=None,
    )
    trainer.step(lambda: (residual - 0.0) ** 2, lambda: (substrate - 0.0) ** 2)
    assert abs(float(residual.detach())) < 1.0
    assert abs(float(substrate.detach())) < 1.0
