from causal_fibres.certification import (
    CertificationEvidence,
    ModuleCertifier,
    ModuleStatus,
)


def test_certifier_is_conservative_and_flags_underidentification():
    certifier = ModuleCertifier()
    result = certifier.certify(CertificationEvidence(underidentified=True))
    assert result.status == ModuleStatus.UNDERIDENTIFIED

    functional = certifier.certify(CertificationEvidence(unique_ablation_value=0.1))
    assert functional.status == ModuleStatus.FUNCTIONAL

    consolidated = certifier.certify(
        CertificationEvidence(
            unique_ablation_value=0.1,
            intervention_selectivity=5.0,
            intervention_repeatability=0.95,
            routing_precision=0.95,
            routing_recall=0.95,
            off_support_mass=0.01,
            fingerprint_condition=0.5,
            finite_order_distance=0.01,
            context_stability=0.95,
            retention_score=0.95,
        )
    )
    assert consolidated.status == ModuleStatus.CONSOLIDATED
