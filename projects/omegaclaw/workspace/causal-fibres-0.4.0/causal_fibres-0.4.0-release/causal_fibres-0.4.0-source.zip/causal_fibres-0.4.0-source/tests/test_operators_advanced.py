import torch

from causal_fibres.operators import (
    AutogradGaussNewtonOperator,
    DenseOperator,
    JointBlockDiagonalizer,
    hutchinson_trace,
    low_rank_projection,
    randomized_range,
    softmax_fisher_metric,
)


def test_gauss_newton_matches_dense_linear_case():
    matrix = torch.tensor([[1.0, 2.0], [-1.0, 0.5]])
    state = torch.tensor([0.2, -0.4])

    def forward(value):
        return matrix @ value

    def identity_metric(output, tangent):
        del output
        return tangent

    operator = AutogradGaussNewtonOperator(state, forward, identity_metric)
    dense = matrix.T @ matrix
    vector = torch.tensor([0.7, -0.3])
    assert torch.allclose(operator.matvec(vector), dense @ vector, atol=1e-6)


def test_randomized_sketch_and_hutchinson_trace():
    matrix = torch.diag(torch.tensor([5.0, 3.0, 1.0, 0.5]))
    operator = DenseOperator(matrix)
    basis = randomized_range(operator, rank=2, oversample=2)
    projected = low_rank_projection(operator, basis)
    assert projected.shape == (2, 2)
    estimate, stderr = hutchinson_trace(operator, probes=64)
    assert abs(estimate - float(matrix.trace())) < 1.0
    assert stderr >= 0


def test_joint_block_diagonalizer_reduces_loss():
    torch.manual_seed(3)
    angle = torch.tensor(0.55)
    rotation = torch.tensor(
        [
            [torch.cos(angle), 0.0, -torch.sin(angle), 0.0],
            [0.0, torch.cos(angle), 0.0, -torch.sin(angle)],
            [torch.sin(angle), 0.0, torch.cos(angle), 0.0],
            [0.0, torch.sin(angle), 0.0, torch.cos(angle)],
        ]
    )
    operators = [
        rotation @ torch.diag(torch.tensor([1.0, 1.0, 4.0, 4.0])) @ rotation.T,
        rotation @ torch.diag(torch.tensor([2.0, 2.0, 7.0, 7.0])) @ rotation.T,
    ]
    result = JointBlockDiagonalizer([2, 2], steps=300, learning_rate=0.03).fit(operators)
    assert result.report.block_loss <= result.losses[0] + 1e-8
    assert result.report.block_loss < 1e-3
    assert result.orthogonality_error < 1e-5


def test_softmax_fisher_metric_is_centered():
    logits = torch.randn(2, 5)
    tangent = torch.ones_like(logits)
    metric_tangent = softmax_fisher_metric(logits, tangent)
    assert torch.allclose(metric_tangent, torch.zeros_like(metric_tangent), atol=1e-6)


def _random_spd(generator: torch.Generator, shift: float = 0.5) -> torch.Tensor:
    matrix = torch.randn(2, 2, generator=generator)
    return matrix @ matrix.T + shift * torch.eye(2)


def _subspace_distance(left: torch.Tensor, right: torch.Tensor) -> float:
    singular_values = torch.linalg.svdvals(left.T @ right).clamp(0.0, 1.0)
    return float(torch.acos(singular_values.min()))


def _permutation_invariant_block_error(
    recovered: tuple[torch.Tensor, ...],
    truth: tuple[torch.Tensor, ...],
) -> float:
    direct = 0.5 * (
        _subspace_distance(recovered[0], truth[0])
        + _subspace_distance(recovered[1], truth[1])
    )
    swapped = 0.5 * (
        _subspace_distance(recovered[0], truth[1])
        + _subspace_distance(recovered[1], truth[0])
    )
    return min(direct, swapped)


def test_joint_block_diagonalizer_recovers_random_internal_blocks():
    # This is the stress case that defeated the 0.2 single-start QR/Adam solver:
    # the common invariant blocks are randomly oriented and each context has a
    # different, internally non-diagonal SPD operator inside each block.
    for seed in range(3):
        torch.manual_seed(seed)
        true_basis = torch.linalg.qr(torch.randn(4, 4)).Q
        true_blocks = (true_basis[:, :2], true_basis[:, 2:])
        operators = []
        for context in range(5):
            generator = torch.Generator().manual_seed(70_000 + 20 * seed + context)
            left = _random_spd(generator)
            right = _random_spd(generator) + 3.0 * torch.eye(2)
            operators.append(
                true_basis @ torch.block_diag(left, right) @ true_basis.T
            )

        result = JointBlockDiagonalizer(
            [2, 2],
            steps=300,
            learning_rate=0.2,
            seed=seed,
        ).fit(operators)

        assert result.report.block_loss < 1e-8
        assert _permutation_invariant_block_error(result.blocks, true_blocks) < 2e-3
        assert result.commutant is not None
        assert result.commutant.status == "multiplicity_free"
        assert result.commutant.estimated_nullity == 2


def test_joint_block_diagonalizer_is_stable_under_moderate_noise():
    torch.manual_seed(11)
    true_basis = torch.linalg.qr(torch.randn(4, 4)).Q
    true_blocks = (true_basis[:, :2], true_basis[:, 2:])
    operators = []
    for context in range(5):
        generator = torch.Generator().manual_seed(80_000 + context)
        left = _random_spd(generator)
        right = _random_spd(generator) + 3.0 * torch.eye(2)
        clean = true_basis @ torch.block_diag(left, right) @ true_basis.T
        noise = torch.randn(4, 4)
        noise = 0.03 * 0.5 * (noise + noise.T)
        operators.append(clean + noise)

    result = JointBlockDiagonalizer(
        [2, 2],
        steps=400,
        learning_rate=0.2,
        seed=11,
    ).fit(operators)

    assert _permutation_invariant_block_error(result.blocks, true_blocks) < 0.02
    assert result.report.block_loss < 0.01
    assert result.commutant is not None
    assert result.commutant.status == "approximate_or_noisy"


def test_commutant_centre_recovers_scalar_blocks_and_signature_tie_break():
    angle = torch.tensor(0.63)
    rotation = torch.tensor(
        [
            [torch.cos(angle), 0.0, -torch.sin(angle), 0.0],
            [0.0, torch.cos(angle), 0.0, -torch.sin(angle)],
            [torch.sin(angle), 0.0, torch.cos(angle), 0.0],
            [0.0, torch.sin(angle), 0.0, torch.cos(angle)],
        ]
    )
    operators = [
        rotation @ torch.diag(torch.tensor(diagonal)) @ rotation.T
        for diagonal in (
            [1.0, 1.0, 4.0, 4.0],
            [2.0, 2.0, 7.0, 7.0],
            [5.0, 5.0, 1.0, 1.0],
        )
    ]
    result = JointBlockDiagonalizer([2, 2], steps=100, seed=4).fit(operators)
    assert result.report.block_loss < 1e-8
    assert result.report.signature_gap > 5.0
    assert result.commutant is not None
    assert result.commutant.estimated_nullity == 6
    assert result.commutant.estimated_center_nullity == 2
    assert result.commutant.status == "multiplicity_free"


def test_commutant_centre_flags_repeated_isomorphic_modules():
    from causal_fibres.operators import approximate_symmetric_commutant

    operators = []
    for seed in range(3):
        generator = torch.Generator().manual_seed(seed)
        matrix = torch.randn(2, 2, generator=generator)
        matrix = matrix @ matrix.T + torch.eye(2)
        operators.append(torch.kron(matrix, torch.eye(2)))
    analysis = approximate_symmetric_commutant(operators, expected_nullity=2)
    diagnostics = analysis.diagnostics
    assert diagnostics.estimated_nullity > diagnostics.expected_nullity
    assert diagnostics.estimated_center_nullity == 1
    assert diagnostics.status == "repeated_or_underidentified"
