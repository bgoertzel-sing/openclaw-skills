import torch

from causal_fibres.credit import (
    LinearErrorTransport,
    SoftTopKRouter,
    SubspaceNoveltyFilter,
    orthogonal_procrustes,
    path_consistency_loss,
    sparsemax,
)


def test_sparsemax_produces_sparse_probabilities():
    logits = torch.tensor([[3.0, 1.0, -2.0]])
    probabilities = sparsemax(logits)
    assert torch.allclose(probabilities.sum(dim=-1), torch.ones(1))
    assert (probabilities == 0).sum() >= 1


def test_soft_router_straight_through_is_one_hot_forward():
    router = SoftTopKRouter(4, 2, straight_through=True)
    gates = router(torch.randn(3, 4, 2))
    assert torch.allclose(gates.sum(dim=-1), torch.ones(3))
    assert torch.equal((gates.detach() > 0).sum(dim=-1), torch.ones(3, dtype=torch.long))


def test_novelty_filter_removes_assimilated_direction():
    novelty = SubspaceNoveltyFilter(2, 3, max_rank=2)
    assert novelty.add_direction(0, torch.tensor([1.0, 0.0, 0.0]))
    error = torch.tensor([[[2.0, 3.0, 0.0], [1.0, 2.0, 3.0]]])
    filtered = novelty(error)
    assert abs(float(filtered[0, 0, 0])) < 1e-6
    assert torch.allclose(filtered[0, 1], error[0, 1])


def test_error_transport_and_procrustes():
    transport = LinearErrorTransport(2, 2, 2, 2, identity_init=True)
    errors = torch.tensor([[[1.0, 2.0], [3.0, 4.0]]])
    responsibility = torch.eye(2).unsqueeze(0)
    message = transport(errors, responsibility)
    assert torch.allclose(message, errors)

    angle = torch.tensor(0.4)
    rotation = torch.tensor(
        [[torch.cos(angle), -torch.sin(angle)], [torch.sin(angle), torch.cos(angle)]]
    )
    source = torch.randn(100, 2)
    target = source @ rotation
    estimated = orthogonal_procrustes(source, target)
    assert torch.allclose(estimated, rotation, atol=1e-5)
    assert float(path_consistency_loss(rotation, torch.eye(2), rotation)) < 1e-10
