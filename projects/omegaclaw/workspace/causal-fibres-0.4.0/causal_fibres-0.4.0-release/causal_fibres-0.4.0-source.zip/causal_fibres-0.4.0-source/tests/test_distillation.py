import torch
from torch import nn

from causal_fibres.architectures import HookedModuleAdapter
from causal_fibres.credit.router import SoftTopKRouter
from causal_fibres.fibres import LinearFibreBank, MultiSiteFibrePredictor, TerminalFibreSidecar
from causal_fibres.solvers import GradientPCSolver
from causal_fibres.training import DistillationWeights, PartialDistillationTrainer


class TinyBackbone(nn.Module):
    def __init__(self):
        super().__init__()
        self.hidden = nn.Linear(4, 8)
        self.out = nn.Linear(8, 2)

    def forward(self, x):
        return self.out(torch.tanh(self.hidden(x)))


def test_partial_distillation_trainer_reduces_deploy_kd():
    torch.manual_seed(7)
    base = TinyBackbone()
    adapter = HookedModuleAdapter(
        base,
        sites={"hidden": "hidden"},
        widths={"hidden": 8},
        freeze=True,
    )
    predictor = MultiSiteFibrePredictor({"hidden": 8}, 2, 2, hidden_dim=16)
    writer = LinearFibreBank(2, 2, 2)
    router = SoftTopKRouter(2, 2, top_k=2, temperature=1.5)
    sidecar = TerminalFibreSidecar(
        predictor,
        writer,
        router,
        residual_scale=0.2,
        trainable_scale=True,
    )

    def teacher(x):
        return base(x) + torch.stack((1.2 * x[:, 0], -0.8 * x[:, 1]), dim=-1)

    optimizer = torch.optim.Adam(sidecar.parameters(), lr=2e-2)
    trainer = PartialDistillationTrainer(
        adapter,
        sidecar,
        teacher,
        GradientPCSolver(steps=2, step_size=0.25),
        optimizer,
        temperature=1.0,
        weights=DistillationWeights(
            deploy_kd=1.0,
            settled_kd=0.2,
            amortization=0.5,
            predictor_prior=0.1,
            absolute_state=0.02,
        ),
    )
    x = torch.randn(64, 4)
    first = trainer.train_step(x).losses["loss_deploy_kd"].item()
    last = first
    for _ in range(79):
        last = trainer.train_step(x).losses["loss_deploy_kd"].item()
    assert last < first * 0.6
