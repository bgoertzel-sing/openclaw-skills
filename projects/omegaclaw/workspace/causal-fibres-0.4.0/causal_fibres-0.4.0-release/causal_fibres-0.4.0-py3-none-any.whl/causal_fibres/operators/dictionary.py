from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Sequence

import torch
from torch import Tensor


@dataclass
class DictionaryOperatorMetrics:
    coordinate_sparsity: float
    reconstruction_error: float
    off_group_fraction: float | None
    condition_number: float


@dataclass
class DictionaryOperatorReport:
    per_context: list[DictionaryOperatorMetrics]
    mean_coordinate_sparsity: float
    mean_reconstruction_error: float
    mean_off_group_fraction: float | None
    dictionary_rank: int

    def to_dict(self) -> dict[str, object]:
        return {
            "per_context": [asdict(value) for value in self.per_context],
            "mean_coordinate_sparsity": self.mean_coordinate_sparsity,
            "mean_reconstruction_error": self.mean_reconstruction_error,
            "mean_off_group_fraction": self.mean_off_group_fraction,
            "dictionary_rank": self.dictionary_rank,
        }


def dictionary_operator_coordinates(
    operator: Tensor,
    dictionary: Tensor,
    *,
    rcond: float = 1e-6,
) -> Tensor:
    """Represent a hidden-space operator in an overcomplete dictionary chart.

    ``dictionary`` has shape ``[n_atoms, hidden_dim]`` and acts as the synthesis
    matrix ``S = dictionary.T``. The returned coordinate operator is
    ``pinv(S) @ H @ S``. In an overcomplete dictionary it is not unique; this
    minimum-norm chart is an audit coordinate system, not a causal proof.
    """

    if operator.ndim != 2 or operator.shape[0] != operator.shape[1]:
        raise ValueError("operator must be square")
    if dictionary.ndim != 2 or dictionary.shape[1] != operator.shape[0]:
        raise ValueError("dictionary must have shape [n_atoms, operator_dim]")
    synthesis = dictionary.transpose(-1, -2)
    analysis = torch.linalg.pinv(synthesis, rtol=rcond)
    return analysis @ operator @ synthesis


def _group_allowed_mask(group_membership: Tensor) -> Tensor:
    if group_membership.ndim != 2:
        raise ValueError("group_membership must have shape [n_groups, n_atoms]")
    membership = group_membership > 0
    return (membership.transpose(-1, -2).to(torch.float32) @ membership.to(torch.float32)) > 0


def audit_dictionary_operators(
    operators: Sequence[Tensor],
    dictionary: Tensor,
    *,
    group_membership: Tensor | None = None,
    sparsity_threshold: float = 1e-3,
    rcond: float = 1e-6,
) -> DictionaryOperatorReport:
    if not operators:
        raise ValueError("At least one operator is required")
    synthesis = dictionary.transpose(-1, -2)
    analysis = torch.linalg.pinv(synthesis, rtol=rcond)
    allowed = None if group_membership is None else _group_allowed_mask(group_membership).to(dictionary.device)
    values: list[DictionaryOperatorMetrics] = []
    for operator in operators:
        coordinates = analysis @ operator @ synthesis
        reconstructed = synthesis @ coordinates @ analysis
        error = torch.linalg.norm(reconstructed - operator) / torch.linalg.norm(operator).clamp_min(1e-12)
        scale = coordinates.abs().amax().clamp_min(1e-12)
        sparsity = (coordinates.abs() <= sparsity_threshold * scale).to(torch.float32).mean()
        off_group = None
        if allowed is not None:
            total = coordinates.square().sum().clamp_min(1e-12)
            off_group = float((coordinates.square() * (~allowed).to(coordinates)).sum() / total)
        singular = torch.linalg.svdvals(coordinates)
        nonzero = singular[singular > singular.max().clamp_min(1e-12) * rcond]
        condition = float(nonzero.max() / nonzero.min()) if nonzero.numel() else float("inf")
        values.append(
            DictionaryOperatorMetrics(
                coordinate_sparsity=float(sparsity),
                reconstruction_error=float(error),
                off_group_fraction=off_group,
                condition_number=condition,
            )
        )
    off_values = [value.off_group_fraction for value in values if value.off_group_fraction is not None]
    return DictionaryOperatorReport(
        per_context=values,
        mean_coordinate_sparsity=sum(value.coordinate_sparsity for value in values) / len(values),
        mean_reconstruction_error=sum(value.reconstruction_error for value in values) / len(values),
        mean_off_group_fraction=(None if not off_values else sum(off_values) / len(off_values)),
        dictionary_rank=int(torch.linalg.matrix_rank(synthesis)),
    )
