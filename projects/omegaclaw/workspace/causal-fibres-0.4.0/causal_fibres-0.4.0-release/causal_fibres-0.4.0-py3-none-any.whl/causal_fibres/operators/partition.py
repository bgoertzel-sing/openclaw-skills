from __future__ import annotations

from collections import Counter
from functools import lru_cache
from itertools import combinations
import math
from typing import Sequence

import torch
from torch import Tensor


def _validate_block_sizes(block_sizes: Sequence[int], dimension: int) -> tuple[int, ...]:
    sizes = tuple(int(size) for size in block_sizes)
    if not sizes or any(size <= 0 for size in sizes):
        raise ValueError("block_sizes must contain positive integers")
    if sum(sizes) != dimension:
        raise ValueError("block_sizes must sum to dimension")
    return sizes


def _reorder_groups_by_requested_sizes(
    groups: Sequence[tuple[int, tuple[int, ...]]],
    requested: Sequence[int],
) -> tuple[Tensor, ...]:
    pools: dict[int, list[tuple[int, ...]]] = {}
    for size, group in groups:
        pools.setdefault(size, []).append(group)
    result: list[Tensor] = []
    for size in requested:
        candidates = pools.get(int(size), [])
        if not candidates:
            raise RuntimeError("Could not match discovered groups to requested block sizes")
        result.append(torch.tensor(candidates.pop(0), dtype=torch.long))
    return tuple(result)


def partition_sorted_eigenvalues(
    eigenvalues: Tensor,
    block_sizes: Sequence[int],
) -> tuple[Tensor, ...]:
    """Partition sorted eigenvalues into near-constant groups of prescribed sizes.

    The block order is treated as unidentifiable.  Dynamic programming selects an
    ordering of the size multiset that minimizes within-segment squared variation,
    then the segments are returned in the caller's requested size order.
    """

    if eigenvalues.ndim != 1:
        raise ValueError("eigenvalues must be one-dimensional")
    sizes = _validate_block_sizes(block_sizes, eigenvalues.numel())
    values = eigenvalues.detach().to(dtype=torch.float64, device="cpu")
    counts0 = tuple(sorted(Counter(sizes).items()))

    prefix = torch.cat([torch.zeros(1, dtype=values.dtype), values.cumsum(0)])
    prefix2 = torch.cat([torch.zeros(1, dtype=values.dtype), values.square().cumsum(0)])

    def segment_cost(start: int, length: int) -> float:
        end = start + length
        total = prefix[end] - prefix[start]
        total2 = prefix2[end] - prefix2[start]
        variance_sum = total2 - total.square() / max(1, length)
        return float(variance_sum.clamp_min(0.0))

    @lru_cache(maxsize=None)
    def solve(position: int, counts: tuple[tuple[int, int], ...]):
        if not counts:
            return (0.0, ()) if position == values.numel() else (float("inf"), ())
        best_cost = float("inf")
        best_sequence: tuple[int, ...] = ()
        for index, (size, count) in enumerate(counts):
            if count <= 0 or position + size > values.numel():
                continue
            updated = list(counts)
            if count == 1:
                updated.pop(index)
            else:
                updated[index] = (size, count - 1)
            tail_cost, tail_sequence = solve(position + size, tuple(updated))
            cost = segment_cost(position, size) + tail_cost
            if cost < best_cost:
                best_cost = cost
                best_sequence = (size,) + tail_sequence
        return best_cost, best_sequence

    _, sequence = solve(0, counts0)
    if not sequence:
        raise RuntimeError("Failed to partition eigenvalues")
    groups: list[tuple[int, tuple[int, ...]]] = []
    start = 0
    for size in sequence:
        group = tuple(range(start, start + size))
        groups.append((size, group))
        start += size
    return _reorder_groups_by_requested_sizes(groups, sizes)


def _partition_count(block_sizes: Sequence[int]) -> float:
    n = sum(block_sizes)
    log_count = math.lgamma(n + 1)
    multiplicities = Counter(block_sizes)
    for size in block_sizes:
        log_count -= math.lgamma(size + 1)
    for count in multiplicities.values():
        log_count -= math.lgamma(count + 1)
    return math.exp(min(log_count, 700.0))


def exact_balanced_affinity_partition(
    affinity: Tensor,
    block_sizes: Sequence[int],
    *,
    max_partitions: int = 200_000,
) -> tuple[Tensor, ...] | None:
    """Globally maximize within-block affinity for a small balanced partition.

    Blocks are unlabeled.  The recursion chooses the block containing the smallest
    remaining vertex, eliminating label permutations.  ``None`` is returned when
    the combinatorial search would exceed ``max_partitions``.
    """

    if affinity.ndim != 2 or affinity.shape[0] != affinity.shape[1]:
        raise ValueError("affinity must be square")
    n = affinity.shape[0]
    sizes = _validate_block_sizes(block_sizes, n)
    if _partition_count(sizes) > max_partitions:
        return None
    weights = 0.5 * (affinity.detach().to(dtype=torch.float64, device="cpu") + affinity.T.detach().to(dtype=torch.float64, device="cpu"))
    weights.fill_diagonal_(0.0)
    all_mask = (1 << n) - 1
    counts0 = tuple(sorted(Counter(sizes).items()))

    @lru_cache(maxsize=None)
    def within(mask: int) -> float:
        indices = [index for index in range(n) if mask & (1 << index)]
        if len(indices) < 2:
            return 0.0
        block = weights[indices][:, indices]
        return float(block.sum() * 0.5)

    @lru_cache(maxsize=None)
    def solve(mask: int, counts: tuple[tuple[int, int], ...]):
        if not counts:
            return (0.0, ()) if mask == 0 else (-float("inf"), ())
        if mask == 0:
            return -float("inf"), ()
        anchor = (mask & -mask).bit_length() - 1
        remaining_indices = [
            index for index in range(anchor + 1, n) if mask & (1 << index)
        ]
        best_score = -float("inf")
        best_groups: tuple[tuple[int, tuple[int, ...]], ...] = ()
        for size_index, (size, count) in enumerate(counts):
            if size > mask.bit_count():
                continue
            for companions in combinations(remaining_indices, size - 1):
                group = (anchor,) + companions
                group_mask = 0
                for item in group:
                    group_mask |= 1 << item
                updated = list(counts)
                if count == 1:
                    updated.pop(size_index)
                else:
                    updated[size_index] = (size, count - 1)
                tail_score, tail_groups = solve(mask ^ group_mask, tuple(updated))
                score = within(group_mask) + tail_score
                if score > best_score:
                    best_score = score
                    best_groups = ((size, tuple(sorted(group))),) + tail_groups
        return best_score, best_groups

    score, groups = solve(all_mask, counts0)
    if not groups or not math.isfinite(score):
        return None
    return _reorder_groups_by_requested_sizes(groups, sizes)


def _balanced_assignment(distances: Tensor, capacities: Sequence[int]) -> Tensor:
    """Greedy capacity-constrained assignment used inside balanced k-means."""

    n, k = distances.shape
    remaining = [int(value) for value in capacities]
    assignment = torch.full((n,), -1, dtype=torch.long, device=distances.device)
    sorted_distances, preferences = torch.sort(distances, dim=1)
    if k > 1:
        margins = sorted_distances[:, 1] - sorted_distances[:, 0]
    else:
        margins = torch.full((n,), float("inf"), device=distances.device)
    order = torch.argsort(margins, descending=True)
    for point in order.tolist():
        for cluster in preferences[point].tolist():
            if remaining[cluster] > 0:
                assignment[point] = cluster
                remaining[cluster] -= 1
                break
    if bool((assignment < 0).any()):
        raise RuntimeError("Balanced assignment failed")
    return assignment


def spectral_balanced_affinity_partition(
    affinity: Tensor,
    block_sizes: Sequence[int],
    *,
    restarts: int = 12,
    iterations: int = 40,
    generator: torch.Generator | None = None,
) -> tuple[Tensor, ...]:
    """Approximate balanced spectral clustering with prescribed cluster sizes."""

    if affinity.ndim != 2 or affinity.shape[0] != affinity.shape[1]:
        raise ValueError("affinity must be square")
    n = affinity.shape[0]
    sizes = _validate_block_sizes(block_sizes, n)
    k = len(sizes)
    weights = affinity.detach().to(dtype=torch.float64)
    weights = 0.5 * (weights + weights.T)
    weights = weights.clamp_min(0.0)
    weights.fill_diagonal_(0.0)
    degree = weights.sum(dim=1).clamp_min(1e-12)
    inv_sqrt = degree.rsqrt()
    laplacian = torch.eye(n, dtype=weights.dtype, device=weights.device) - (
        inv_sqrt[:, None] * weights * inv_sqrt[None, :]
    )
    _, embedding = torch.linalg.eigh(laplacian)
    embedding = embedding[:, :k]
    embedding = embedding / embedding.norm(dim=1, keepdim=True).clamp_min(1e-12)

    best_score = -float("inf")
    best_assignment: Tensor | None = None
    if generator is None:
        generator = torch.Generator(device=embedding.device)
        generator.manual_seed(0)

    for restart in range(max(1, restarts)):
        first = restart % n if restart < n else int(
            torch.randint(n, (), generator=generator, device=embedding.device)
        )
        centers = [embedding[first]]
        while len(centers) < k:
            current = torch.stack(centers)
            distance = torch.cdist(embedding, current).square().min(dim=1).values
            if float(distance.sum()) <= 1e-12:
                candidate = len(centers) % n
            else:
                probability = distance / distance.sum()
                candidate = int(
                    torch.multinomial(probability, 1, generator=generator).item()
                )
            centers.append(embedding[candidate])
        centroids = torch.stack(centers)
        assignment = torch.zeros(n, dtype=torch.long, device=embedding.device)
        for _ in range(iterations):
            distances = torch.cdist(embedding, centroids).square()
            updated = _balanced_assignment(distances, sizes)
            if torch.equal(updated, assignment):
                assignment = updated
                break
            assignment = updated
            new_centroids = []
            for cluster in range(k):
                members = embedding[assignment == cluster]
                new_centroids.append(members.mean(dim=0))
            centroids = torch.stack(new_centroids)
        score = 0.0
        for cluster in range(k):
            indices = torch.nonzero(assignment == cluster, as_tuple=False).flatten()
            score += float(weights[indices][:, indices].sum() * 0.5)
        if score > best_score:
            best_score = score
            best_assignment = assignment.clone()

    if best_assignment is None:
        raise RuntimeError("Spectral partitioning failed")
    groups = []
    for cluster, size in enumerate(sizes):
        indices = torch.nonzero(best_assignment == cluster, as_tuple=False).flatten()
        if indices.numel() != size:
            raise RuntimeError("Spectral partition produced an incorrect cluster size")
        groups.append(indices.cpu())
    return tuple(groups)
