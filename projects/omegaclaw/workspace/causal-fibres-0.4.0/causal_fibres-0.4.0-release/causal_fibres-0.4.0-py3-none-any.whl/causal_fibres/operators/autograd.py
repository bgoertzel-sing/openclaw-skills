from __future__ import annotations

from collections.abc import Callable

import torch
from torch import Tensor

from .linear_operator import LinearOperator


class AutogradHessianOperator(LinearOperator):
    """Hessian-vector products for a scalar loss and a residual state."""

    def __init__(self, loss: Tensor, state: Tensor, *, damping: float = 0.0) -> None:
        if loss.ndim:
            loss = loss.mean()
        if not state.requires_grad:
            raise ValueError("state must require gradients")
        self.loss = loss
        self.state = state
        self.shape = state.shape
        self.damping = damping
        self.gradient = torch.autograd.grad(loss, state, create_graph=True, retain_graph=True)[0]

    @property
    def dimension(self) -> int:
        return self.state.numel()

    def matvec(self, vector: Tensor) -> Tensor:
        vector_state = vector.reshape(self.shape).to(self.state)
        product = (self.gradient * vector_state).sum()
        hvp = torch.autograd.grad(product, self.state, retain_graph=True)[0]
        return hvp.reshape(-1) + self.damping * vector.reshape(-1).to(hvp)


class PerSampleGradientFisherOperator(LinearOperator):
    """Empirical Fisher from per-sample gradients ``[samples, dimension]``."""

    def __init__(self, per_sample_gradients: Tensor, *, damping: float = 0.0) -> None:
        if per_sample_gradients.ndim != 2:
            raise ValueError("per_sample_gradients must have shape [samples, dim]")
        self.gradients = per_sample_gradients
        self.damping = damping

    @property
    def dimension(self) -> int:
        return int(self.gradients.shape[1])

    def matvec(self, vector: Tensor) -> Tensor:
        vector = vector.to(self.gradients)
        projected = self.gradients @ vector
        result = self.gradients.T @ projected / max(1, self.gradients.shape[0])
        return result + self.damping * vector


class AutogradGaussNewtonOperator(LinearOperator):
    """Matrix-free ``J^T G J`` operator.

    ``forward_fn`` maps a state tensor to an output tensor. ``metric_fn`` maps
    ``(output, tangent)`` to ``G @ tangent``. For logit-space distillation,
    ``softmax_fisher_metric`` is a useful metric function.
    """

    def __init__(
        self,
        state: Tensor,
        forward_fn: Callable[[Tensor], Tensor],
        metric_fn: Callable[[Tensor, Tensor], Tensor],
        *,
        damping: float = 0.0,
    ) -> None:
        self.state = state.detach()
        self.forward_fn = forward_fn
        self.metric_fn = metric_fn
        self.damping = damping

    @property
    def dimension(self) -> int:
        return self.state.numel()

    def matvec(self, vector: Tensor) -> Tensor:
        direction = vector.reshape_as(self.state).to(self.state)
        base = self.state.detach().requires_grad_(True)
        output, tangent = torch.autograd.functional.jvp(
            self.forward_fn,
            base,
            direction,
            create_graph=True,
            strict=False,
        )
        metric_tangent = self.metric_fn(output, tangent)
        vjp = torch.autograd.grad(output, base, grad_outputs=metric_tangent)[0]
        return vjp.reshape(-1).detach() + self.damping * vector.reshape(-1).to(vjp)


def softmax_fisher_metric(logits: Tensor, tangent: Tensor, temperature: float = 1.0) -> Tensor:
    temp = max(float(temperature), 1e-6)
    probabilities = torch.softmax(logits / temp, dim=-1)
    scaled = tangent / temp
    centered = scaled - (probabilities * scaled).sum(dim=-1, keepdim=True)
    return probabilities * centered / temp


def empirical_fisher_matrix(per_sample_gradients: Tensor) -> Tensor:
    if per_sample_gradients.ndim != 2:
        raise ValueError("per_sample_gradients must have shape [samples, dim]")
    return per_sample_gradients.T @ per_sample_gradients / max(1, per_sample_gradients.shape[0])
