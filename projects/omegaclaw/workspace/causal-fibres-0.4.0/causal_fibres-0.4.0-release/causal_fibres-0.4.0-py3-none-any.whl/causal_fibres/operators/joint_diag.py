from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Sequence

import torch
from torch import Tensor

from .commutant import (
    CommutantAnalysis,
    CommutantDiagnostics,
    approximate_symmetric_commutant,
)
from .emergence import (
    EmergenceReport,
    emergence_report,
    joint_block_diagonalization_loss,
)
from .partition import (
    exact_balanced_affinity_partition,
    partition_sorted_eigenvalues,
    spectral_balanced_affinity_partition,
)


@dataclass
class InitializationRecord:
    name: str
    loss: float
    signature_gap: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class RestartSummary:
    initializer: str
    initial_loss: float
    final_loss: float
    final_signature_gap: float
    steps: int
    converged: bool
    final_gradient_norm: float
    line_search_failures: int

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class JointDiagonalizationResult:
    basis: Tensor
    blocks: tuple[Tensor, ...]
    losses: list[float]
    report: EmergenceReport
    initializer: str = "unknown"
    initialization_records: tuple[InitializationRecord, ...] = ()
    restart_summaries: tuple[RestartSummary, ...] = ()
    commutant: CommutantDiagnostics | None = None
    converged: bool = False
    orthogonality_error: float = 0.0

    def diagnostics_dict(self) -> dict[str, Any]:
        return {
            "initializer": self.initializer,
            "converged": self.converged,
            "orthogonality_error": self.orthogonality_error,
            "initialization_records": [item.to_dict() for item in self.initialization_records],
            "restart_summaries": [item.to_dict() for item in self.restart_summaries],
            "commutant": None if self.commutant is None else self.commutant.to_dict(),
        }


@dataclass
class _Candidate:
    name: str
    basis: Tensor
    loss: float
    signature_gap: float
    metadata: dict[str, Any]


@dataclass
class _Refinement:
    basis: Tensor
    losses: list[float]
    converged: bool
    final_gradient_norm: float
    line_search_failures: int


def _blocks_from_basis(basis: Tensor, block_sizes: Sequence[int]) -> tuple[Tensor, ...]:
    result = []
    start = 0
    for size in block_sizes:
        result.append(basis[:, start : start + size])
        start += size
    return tuple(result)


def _canonical_qr(matrix: Tensor) -> Tensor:
    q, r = torch.linalg.qr(matrix)
    sign = torch.sign(torch.diagonal(r))
    sign = torch.where(sign == 0, torch.ones_like(sign), sign)
    return q * sign.unsqueeze(0)


def _skew(matrix: Tensor) -> Tensor:
    return 0.5 * (matrix - matrix.T)


class JointBlockDiagonalizer:
    """Robust common block-basis discovery for dense context operators.

    Version 0.3 replaces the single identity-initialized QR/Adam solve with a
    global-to-local pipeline:

    1. an approximate-commutant initializer for small/moderate dense systems;
    2. random-combination spectral-affinity initializers;
    3. multiple orthogonal restarts;
    4. monotone Riemannian refinement on the orthogonal group;
    5. explicit identifiability diagnostics from the commutant spectrum.

    The commutant method is particularly effective when the operator family is
    approximately multiplicity-free: a generic symmetric matrix commuting with
    all context operators is nearly scalar on each common invariant block, so
    its eigenspaces expose the blocks without a local basis search.
    """

    def __init__(
        self,
        block_sizes: Sequence[int],
        *,
        steps: int = 500,
        learning_rate: float = 0.25,
        tolerance: float = 1e-9,
        gradient_tolerance: float = 1e-8,
        patience: int = 12,
        allowed_coupling: Tensor | None = None,
        normalized: bool = False,
        symmetrize: bool = True,
        initializer: str = "auto",
        restarts: int = 6,
        warmup_steps: int | None = None,
        random_restarts: int = 2,
        commutant_max_dimension: int = 32,
        commutant_trials: int = 24,
        commutant_relative_threshold: float = 1e-6,
        spectral_trials: int = 12,
        spectral_cluster_restarts: int = 12,
        signature_affinity_weight: float = 0.1,
        exact_partition_max_partitions: int = 200_000,
        selection_absolute_tolerance: float = 1e-10,
        selection_relative_tolerance: float = 1e-6,
        line_search_steps: int = 20,
        armijo: float = 1e-4,
        minimum_step_size: float = 1e-7,
        maximum_step_size: float = 2.0,
        seed: int = 0,
    ) -> None:
        self.block_sizes = tuple(int(size) for size in block_sizes)
        if not self.block_sizes or any(size <= 0 for size in self.block_sizes):
            raise ValueError("block_sizes must contain positive integers")
        if steps < 0:
            raise ValueError("steps must be non-negative")
        if learning_rate <= 0:
            raise ValueError("learning_rate must be positive")
        if restarts <= 0:
            raise ValueError("restarts must be positive")
        if initializer not in {"auto", "commutant", "spectral", "identity", "random"}:
            raise ValueError(
                "initializer must be one of auto, commutant, spectral, identity, random"
            )
        self.steps = int(steps)
        self.learning_rate = float(learning_rate)
        self.tolerance = float(tolerance)
        self.gradient_tolerance = float(gradient_tolerance)
        self.patience = int(patience)
        self.allowed_coupling = allowed_coupling
        self.normalized = bool(normalized)
        self.symmetrize = bool(symmetrize)
        self.initializer = initializer
        self.restarts = int(restarts)
        self.warmup_steps = warmup_steps
        self.random_restarts = int(random_restarts)
        self.commutant_max_dimension = int(commutant_max_dimension)
        self.commutant_trials = int(commutant_trials)
        self.commutant_relative_threshold = float(commutant_relative_threshold)
        self.spectral_trials = int(spectral_trials)
        self.spectral_cluster_restarts = int(spectral_cluster_restarts)
        self.signature_affinity_weight = float(signature_affinity_weight)
        self.exact_partition_max_partitions = int(exact_partition_max_partitions)
        self.selection_absolute_tolerance = float(selection_absolute_tolerance)
        self.selection_relative_tolerance = float(selection_relative_tolerance)
        self.line_search_steps = int(line_search_steps)
        self.armijo = float(armijo)
        self.minimum_step_size = float(minimum_step_size)
        self.maximum_step_size = float(maximum_step_size)
        self.seed = int(seed)

    def _prepare_operators(self, operators: Sequence[Tensor]) -> tuple[Tensor, ...]:
        if not operators:
            raise ValueError("At least one operator is required")
        dimension = operators[0].shape[0]
        if any(operator.ndim != 2 or operator.shape != (dimension, dimension) for operator in operators):
            raise ValueError("All operators must be square with equal dimension")
        if sum(self.block_sizes) != dimension:
            raise ValueError("block_sizes must sum to operator dimension")
        if any(operator.device != operators[0].device for operator in operators):
            raise ValueError("All operators must be on the same device")
        if any(operator.dtype != operators[0].dtype for operator in operators):
            raise ValueError("All operators must have the same dtype")
        prepared = []
        for operator in operators:
            matrix = 0.5 * (operator + operator.T) if self.symmetrize else operator
            prepared.append(matrix)
        return tuple(prepared)

    def _loss(self, operators: Sequence[Tensor], basis: Tensor) -> Tensor:
        return joint_block_diagonalization_loss(
            operators,
            _blocks_from_basis(basis, self.block_sizes),
            allowed_coupling=self.allowed_coupling,
            normalized=self.normalized,
        )

    def _candidate(self, name: str, basis: Tensor, operators: Sequence[Tensor], **metadata: Any) -> _Candidate:
        q = _canonical_qr(basis)
        blocks = _blocks_from_basis(q, self.block_sizes)
        value = float(self._loss(operators, q).detach())
        signatures = []
        for block in blocks:
            signatures.append(
                torch.stack(
                    [torch.trace(block.T @ operator @ block) / block.shape[1] for operator in operators]
                )
            )
        signature_matrix = torch.stack(signatures)
        if signature_matrix.shape[0] < 2:
            gap = float("inf")
        else:
            distances = torch.cdist(signature_matrix, signature_matrix)
            eye = torch.eye(distances.shape[0], dtype=torch.bool, device=distances.device)
            gap = float(distances.masked_fill(eye, float("inf")).min())
        return _Candidate(
            name=name,
            basis=q.detach(),
            loss=value,
            signature_gap=gap,
            metadata=metadata,
        )

    def _sort_candidates(self, candidates: list[_Candidate]) -> None:
        if not candidates:
            return
        best_loss = min(item.loss for item in candidates)
        tolerance = max(
            self.selection_absolute_tolerance,
            self.selection_relative_tolerance * abs(best_loss),
        )
        candidates.sort(
            key=lambda item: (
                0 if item.loss <= best_loss + tolerance else 1,
                item.loss if item.loss > best_loss + tolerance else 0.0,
                -item.signature_gap,
            )
        )

    def _commutant_candidates(
        self,
        operators: Sequence[Tensor],
        generator: torch.Generator,
    ) -> tuple[list[_Candidate], CommutantAnalysis | None]:
        dimension = operators[0].shape[0]
        if dimension > self.commutant_max_dimension:
            return [], None
        if self.allowed_coupling is not None and bool(self.allowed_coupling.any()):
            return [], None
        analysis = approximate_symmetric_commutant(
            operators,
            expected_nullity=len(self.block_sizes),
            normalized=True,
            relative_threshold=self.commutant_relative_threshold,
        )
        matrices = analysis.matrices
        candidates: list[_Candidate] = []
        for trial in range(max(1, self.commutant_trials)):
            if trial == 0:
                coefficients = torch.arange(
                    1,
                    matrices.shape[0] + 1,
                    dtype=matrices.dtype,
                    device=matrices.device,
                )
            else:
                coefficients = torch.randn(
                    matrices.shape[0],
                    dtype=matrices.dtype,
                    device=matrices.device,
                    generator=generator,
                )
            coefficients = coefficients / coefficients.norm().clamp_min(1e-12)
            commuting_matrix = torch.einsum("k,kij->ij", coefficients, matrices)
            eigenvalues, eigenvectors = torch.linalg.eigh(commuting_matrix)
            groups = partition_sorted_eigenvalues(eigenvalues, self.block_sizes)
            basis = torch.cat(
                [eigenvectors[:, group.to(eigenvectors.device)] for group in groups],
                dim=1,
            )
            candidates.append(
                self._candidate(
                    f"commutant:{trial}",
                    basis,
                    operators,
                    cluster_variance=float(
                        sum(
                            (
                                eigenvalues[group.to(eigenvalues.device)]
                                - eigenvalues[group.to(eigenvalues.device)].mean()
                            ).square().sum()
                            for group in groups
                        )
                    ),
                )
            )
        self._sort_candidates(candidates)
        return candidates, analysis

    def _spectral_candidates(
        self,
        operators: Sequence[Tensor],
        generator: torch.Generator,
    ) -> list[_Candidate]:
        dimension = operators[0].shape[0]
        candidates: list[_Candidate] = []
        for trial in range(max(1, self.spectral_trials)):
            coefficients = torch.randn(
                len(operators),
                dtype=operators[0].dtype,
                device=operators[0].device,
                generator=generator,
            )
            coefficients = coefficients / coefficients.norm().clamp_min(1e-12)
            combination = sum(
                coefficient * operator
                for coefficient, operator in zip(coefficients, operators)
            )
            _, eigenvectors = torch.linalg.eigh(0.5 * (combination + combination.T))
            coupling_affinity = operators[0].new_zeros((dimension, dimension))
            signatures = []
            for operator in operators:
                transformed = eigenvectors.T @ operator @ eigenvectors
                scale = operator.square().sum().clamp_min(1e-12)
                normalized_transformed = transformed / scale.sqrt()
                coupling_affinity = coupling_affinity + normalized_transformed.square()
                signatures.append(torch.diagonal(normalized_transformed))
            coupling_affinity.fill_diagonal_(0.0)
            maximum_coupling = coupling_affinity.max().clamp_min(0.0)
            if float(maximum_coupling) > 1e-12:
                affinity = coupling_affinity / maximum_coupling
            else:
                affinity = coupling_affinity

            # Commuting/scalar blocks have little off-diagonal coupling in the
            # combination eigenbasis.  Their per-eigenvector context signatures
            # still identify which eigendirections belong together.
            signature_matrix = torch.stack(signatures, dim=1)
            signature_distance = torch.cdist(signature_matrix, signature_matrix).square()
            positive = signature_distance[signature_distance > 1e-12]
            if positive.numel():
                bandwidth = positive.median().clamp_min(1e-12)
                signature_affinity = torch.exp(-signature_distance / bandwidth)
                signature_affinity.fill_diagonal_(0.0)
                weight = 1.0 if float(maximum_coupling) <= 1e-12 else self.signature_affinity_weight
                affinity = affinity + weight * signature_affinity
            affinity.fill_diagonal_(0.0)
            groups = exact_balanced_affinity_partition(
                affinity,
                self.block_sizes,
                max_partitions=self.exact_partition_max_partitions,
            )
            partition_method = "exact"
            if groups is None:
                groups = spectral_balanced_affinity_partition(
                    affinity,
                    self.block_sizes,
                    restarts=self.spectral_cluster_restarts,
                    generator=generator,
                )
                partition_method = "balanced_spectral"
            basis = torch.cat(
                [eigenvectors[:, group.to(eigenvectors.device)] for group in groups],
                dim=1,
            )
            candidates.append(
                self._candidate(
                    f"spectral:{trial}",
                    basis,
                    operators,
                    partition_method=partition_method,
                )
            )
        self._sort_candidates(candidates)
        return candidates

    def _initial_candidates(
        self,
        operators: Sequence[Tensor],
        *,
        initial_basis: Tensor | None,
        generator: torch.Generator,
    ) -> tuple[list[_Candidate], CommutantAnalysis | None]:
        dimension = operators[0].shape[0]
        candidates: list[_Candidate] = []
        commutant_analysis: CommutantAnalysis | None = None
        if initial_basis is not None:
            if initial_basis.shape != (dimension, dimension):
                raise ValueError("initial_basis must have shape [dimension, dimension]")
            candidates.append(self._candidate("user", initial_basis.to(operators[0]), operators))

        if self.initializer in {"auto", "commutant"}:
            commutant_candidates, commutant_analysis = self._commutant_candidates(
                operators, generator
            )
            candidates.extend(commutant_candidates[: max(2, self.restarts)])
            if self.initializer == "commutant" and not commutant_candidates:
                raise ValueError(
                    "The commutant initializer is unavailable for this dimension or allowed-coupling mask"
                )

        if self.initializer in {"auto", "spectral"}:
            candidates.extend(
                self._spectral_candidates(operators, generator)[: max(2, self.restarts)]
            )

        if self.initializer in {"auto", "identity"}:
            candidates.append(
                self._candidate(
                    "identity",
                    torch.eye(
                        dimension,
                        dtype=operators[0].dtype,
                        device=operators[0].device,
                    ),
                    operators,
                )
            )

        if self.initializer in {"auto", "random"}:
            count = max(1, self.random_restarts) if self.initializer == "random" else self.random_restarts
            for restart in range(count):
                random_matrix = torch.randn(
                    (dimension, dimension),
                    dtype=operators[0].dtype,
                    device=operators[0].device,
                    generator=generator,
                )
                candidates.append(
                    self._candidate(f"random:{restart}", random_matrix, operators)
                )

        if not candidates:
            raise RuntimeError("No initialization candidates were generated")
        self._sort_candidates(candidates)
        return candidates, commutant_analysis

    def _refine(
        self,
        operators: Sequence[Tensor],
        initial_basis: Tensor,
        *,
        steps: int,
    ) -> _Refinement:
        basis = _canonical_qr(initial_basis).detach()
        current_loss = float(self._loss(operators, basis).detach())
        losses = [current_loss]
        best_basis = basis.clone()
        best_loss = current_loss
        step_size = self.learning_rate
        stable_steps = 0
        line_search_failures = 0
        converged = current_loss <= self.tolerance
        final_gradient_norm = float("inf")
        identity = torch.eye(
            basis.shape[0], dtype=basis.dtype, device=basis.device
        )

        for iteration in range(max(0, steps)):
            variable = basis.detach().requires_grad_(True)
            loss = self._loss(operators, variable)
            gradient = torch.autograd.grad(loss, variable)[0]
            generator = _skew(variable.T @ gradient)
            final_gradient_norm = float(torch.linalg.matrix_norm(generator).detach())
            if final_gradient_norm <= self.gradient_tolerance:
                converged = True
                break

            accepted = False
            trial_step = step_size
            gradient_square = final_gradient_norm**2
            candidate_loss = current_loss
            for _ in range(self.line_search_steps):
                rotation = torch.linalg.solve(
                    identity + 0.5 * trial_step * generator.detach(),
                    identity - 0.5 * trial_step * generator.detach(),
                )
                candidate = basis @ rotation
                candidate_loss = float(self._loss(operators, candidate).detach())
                armijo_target = current_loss - self.armijo * trial_step * gradient_square
                if candidate_loss <= armijo_target or candidate_loss < current_loss:
                    basis = candidate.detach()
                    accepted = True
                    step_size = min(
                        self.maximum_step_size,
                        max(self.minimum_step_size, trial_step * 1.35),
                    )
                    break
                trial_step *= 0.5
                if trial_step < self.minimum_step_size:
                    break

            if not accepted:
                line_search_failures += 1
                step_size *= 0.25
                if step_size < self.minimum_step_size:
                    break
                continue

            if (iteration + 1) % 25 == 0:
                basis = _canonical_qr(basis)
            losses.append(candidate_loss)
            relative_improvement = abs(current_loss - candidate_loss) / max(
                1.0, abs(current_loss)
            )
            current_loss = candidate_loss
            if current_loss < best_loss:
                best_loss = current_loss
                best_basis = basis.clone()
            if relative_improvement <= self.tolerance:
                stable_steps += 1
                if stable_steps >= self.patience:
                    converged = True
                    break
            else:
                stable_steps = 0

        if best_loss < current_loss:
            basis = best_basis
            if not losses or losses[-1] != best_loss:
                losses.append(best_loss)
        return _Refinement(
            basis=basis.detach(),
            losses=losses,
            converged=converged,
            final_gradient_norm=final_gradient_norm,
            line_search_failures=line_search_failures,
        )

    def fit(
        self,
        operators: Sequence[Tensor],
        *,
        initial_basis: Tensor | None = None,
    ) -> JointDiagonalizationResult:
        prepared = self._prepare_operators(operators)
        generator = torch.Generator(device=prepared[0].device)
        generator.manual_seed(self.seed)
        candidates, commutant_analysis = self._initial_candidates(
            prepared,
            initial_basis=initial_basis,
            generator=generator,
        )
        initialization_records = tuple(
            InitializationRecord(item.name, item.loss, item.signature_gap, item.metadata)
            for item in candidates
        )

        selected_candidates = candidates[: min(self.restarts, len(candidates))]
        if self.warmup_steps is None:
            warmup_steps = min(120, max(0, self.steps // 4))
        else:
            warmup_steps = max(0, min(self.steps, int(self.warmup_steps)))

        restart_summaries: list[RestartSummary] = []
        warm_results: list[tuple[_Candidate, _Refinement]] = []
        for candidate in selected_candidates:
            refined = self._refine(
                prepared,
                candidate.basis,
                steps=warmup_steps,
            )
            final_candidate = self._candidate(
                candidate.name, refined.basis, prepared, **candidate.metadata
            )
            final_loss = final_candidate.loss
            restart_summaries.append(
                RestartSummary(
                    initializer=candidate.name,
                    initial_loss=candidate.loss,
                    final_loss=final_loss,
                    final_signature_gap=final_candidate.signature_gap,
                    steps=max(0, len(refined.losses) - 1),
                    converged=refined.converged,
                    final_gradient_norm=refined.final_gradient_norm,
                    line_search_failures=refined.line_search_failures,
                )
            )
            warm_results.append((candidate, refined))

        warm_candidates = [
            self._candidate(candidate.name, refined.basis, prepared, **candidate.metadata)
            for candidate, refined in warm_results
        ]
        self._sort_candidates(warm_candidates)
        best_name = warm_candidates[0].name
        best_candidate, best_warm = next(
            item for item in warm_results if item[0].name == best_name
        )
        remaining_steps = max(0, self.steps - warmup_steps)
        final_refinement = self._refine(
            prepared,
            best_warm.basis,
            steps=remaining_steps,
        )
        losses = list(best_warm.losses)
        if final_refinement.losses:
            if losses and abs(losses[-1] - final_refinement.losses[0]) <= 1e-15:
                losses.extend(final_refinement.losses[1:])
            else:
                losses.extend(final_refinement.losses)

        basis = final_refinement.basis.detach()
        preliminary_orthogonality_error = float(
            torch.linalg.matrix_norm(
                basis.T @ basis
                - torch.eye(
                    basis.shape[0], dtype=basis.dtype, device=basis.device
                )
            )
        )
        if preliminary_orthogonality_error > 1e-5:
            basis = _canonical_qr(basis).detach()
        blocks = tuple(block.detach() for block in _blocks_from_basis(basis, self.block_sizes))
        report = emergence_report(
            prepared,
            blocks,
            allowed_coupling=self.allowed_coupling,
            normalized=self.normalized,
        )
        orthogonality_error = float(
            torch.linalg.matrix_norm(
                basis.T @ basis
                - torch.eye(
                    basis.shape[0], dtype=basis.dtype, device=basis.device
                )
            )
        )
        if not losses or abs(losses[-1] - report.block_loss) > 1e-15:
            losses.append(report.block_loss)
        return JointDiagonalizationResult(
            basis=basis,
            blocks=blocks,
            losses=losses,
            report=report,
            initializer=best_candidate.name,
            initialization_records=initialization_records,
            restart_summaries=tuple(restart_summaries),
            commutant=None if commutant_analysis is None else commutant_analysis.diagnostics,
            converged=best_warm.converged or final_refinement.converged,
            orthogonality_error=orthogonality_error,
        )
