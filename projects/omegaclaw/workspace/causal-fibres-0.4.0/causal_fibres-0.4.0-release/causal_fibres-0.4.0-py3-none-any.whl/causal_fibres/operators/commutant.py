from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Sequence

import torch
from torch import Tensor


@dataclass
class CommutantDiagnostics:
    """Diagnostics for the commutant and its centre.

    The full commutant detects invariant structure but can be larger than the
    requested block count when operators are scalar or otherwise reducible
    inside a block.  The centre of the commutant identifies the canonical
    isotypic blocks.  Repeated isomorphic copies reduce the centre dimension and
    are therefore reported as intrinsically underidentified.
    """

    expected_nullity: int
    estimated_nullity: int
    estimated_center_nullity: int
    relative_threshold: float
    singular_values: list[float]
    center_singular_values: list[float]
    selected_residuals: list[float]
    selected_center_residuals: list[float]
    nullity_gap_ratio: float
    center_gap_ratio: float
    status: str
    message: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class CommutantAnalysis:
    commutant_matrices: Tensor
    center_matrices: Tensor
    diagnostics: CommutantDiagnostics

    @property
    def matrices(self) -> Tensor:
        """Backward-compatible alias for the central initializer matrices."""

        return self.center_matrices


def symmetric_matrix_basis(
    dimension: int,
    *,
    dtype: torch.dtype,
    device: torch.device,
) -> Tensor:
    """Return a Frobenius-orthonormal basis of symmetric matrices."""

    matrices: list[Tensor] = []
    for row in range(dimension):
        matrix = torch.zeros((dimension, dimension), dtype=dtype, device=device)
        matrix[row, row] = 1.0
        matrices.append(matrix)
    scale = 2.0**-0.5
    for row in range(dimension):
        for column in range(row + 1, dimension):
            matrix = torch.zeros((dimension, dimension), dtype=dtype, device=device)
            matrix[row, column] = scale
            matrix[column, row] = scale
            matrices.append(matrix)
    return torch.stack(matrices)


def _ascending_svd(system: Tensor) -> tuple[Tensor, Tensor]:
    _, singular_values_desc, vh = torch.linalg.svd(system, full_matrices=False)
    return singular_values_desc.flip(0), vh


def _estimated_nullity(
    singular_values: Tensor,
    relative_threshold: float,
    *,
    absolute_threshold: float = 1e-12,
) -> tuple[int, float]:
    maximum = float(singular_values.max()) if singular_values.numel() else 0.0
    threshold = max(absolute_threshold, relative_threshold * max(maximum, 1e-30))
    return int((singular_values <= threshold).sum()), threshold


def _gap_ratio(singular_values: Tensor, count: int) -> float:
    if count <= 0 or count >= singular_values.numel():
        return float("inf")
    return float(singular_values[count]) / max(float(singular_values[count - 1]), 1e-30)


def approximate_symmetric_commutant(
    operators: Sequence[Tensor],
    *,
    expected_nullity: int,
    normalized: bool = True,
    relative_threshold: float = 1e-6,
    analysis_dtype: torch.dtype = torch.float64,
) -> CommutantAnalysis:
    """Estimate the symmetric commutant and its central block projectors.

    For a family generating ``A = direct_sum_j M(d_j)``, the symmetric
    commutant is block-scalar and its dimension equals the block count.  If an
    operator block is internally reducible or scalar, the commutant becomes
    larger; taking the centre of that commutant recovers the canonical central
    blocks.  If multiple requested blocks are isomorphic repeated copies, the
    centre is smaller than the requested count, correctly signalling that the
    copies are not identifiable from this operator family alone.
    """

    if not operators:
        raise ValueError("At least one operator is required")
    dimension = operators[0].shape[0]
    matrix_space_dimension = dimension * (dimension + 1) // 2
    if expected_nullity <= 0:
        raise ValueError("expected_nullity must be positive")
    if expected_nullity > matrix_space_dimension:
        raise ValueError("expected_nullity exceeds the symmetric matrix-space dimension")
    device = operators[0].device
    basis = symmetric_matrix_basis(
        dimension,
        dtype=analysis_dtype,
        device=device,
    )
    columns = []
    for operator in operators:
        matrix = 0.5 * (operator + operator.T)
        matrix = matrix.to(dtype=analysis_dtype)
        if normalized:
            matrix = matrix / torch.linalg.matrix_norm(matrix).clamp_min(1e-12)
        left = torch.einsum("ab,kbc->kac", matrix, basis)
        right = torch.einsum("kab,bc->kac", basis, matrix)
        columns.append((left - right).reshape(basis.shape[0], -1).T)
    commutator_system = torch.cat(columns, dim=0)
    singular_values, vh = _ascending_svd(commutator_system)
    estimated_nullity, _ = _estimated_nullity(singular_values, relative_threshold)
    commutant_count = min(
        matrix_space_dimension,
        max(expected_nullity, estimated_nullity),
    )
    commutant_coefficients = vh[-commutant_count:].T
    commutant_matrices = torch.einsum(
        "mk,mij->kij", commutant_coefficients, basis
    )

    # Find the centre of the approximate commutant by solving for combinations
    # that commute with every selected commutant basis element.
    center_columns = []
    for target in commutant_matrices:
        left = torch.einsum("kij,jl->kil", commutant_matrices, target)
        right = torch.einsum("ij,kjl->kil", target, commutant_matrices)
        center_columns.append((left - right).reshape(commutant_count, -1).T)
    center_system = torch.cat(center_columns, dim=0)
    center_singular_values, center_vh = _ascending_svd(center_system)
    estimated_center_nullity, _ = _estimated_nullity(
        center_singular_values, relative_threshold
    )
    center_count = min(
        commutant_count,
        max(expected_nullity, estimated_center_nullity),
    )
    center_coefficients = center_vh[-center_count:].T
    center_matrices = torch.einsum(
        "rk,rij->kij", center_coefficients, commutant_matrices
    )
    # The einsum above returns [center_count, n, n].  Symmetrize tiny numerical
    # drift introduced by the nested SVDs.
    center_matrices = 0.5 * (center_matrices + center_matrices.transpose(-1, -2))

    nullity_gap_ratio = _gap_ratio(singular_values, expected_nullity)
    center_gap_ratio = _gap_ratio(center_singular_values, expected_nullity)

    if (
        estimated_center_nullity == expected_nullity
        and center_gap_ratio >= 10.0
        and estimated_nullity >= expected_nullity
    ):
        status = "multiplicity_free"
        if estimated_nullity > expected_nullity:
            message = (
                "The full commutant is larger than the requested block count, but "
                "its centre has the expected dimension.  The blocks are identifiable "
                "even though some have internal reducible or scalar structure."
            )
        else:
            message = (
                "The centre of the observed commutant matches the requested block "
                "count with a clear singular-value gap."
            )
    elif estimated_center_nullity < expected_nullity and estimated_nullity >= expected_nullity:
        status = "repeated_or_underidentified"
        message = (
            "The full commutant supports the requested number of directions, but its "
            "centre is smaller than the requested block count.  Some requested fibres "
            "are repeated isomorphic copies or are not separated by the available "
            "contexts; extra interventions or symmetry breaking are needed."
        )
    elif estimated_center_nullity > expected_nullity:
        status = "finer_structure_detected"
        message = (
            "The operator family contains more central invariant components than the "
            "requested block count.  The requested blocks merge distinguishable structure."
        )
    else:
        status = "approximate_or_noisy"
        message = (
            "The expected central block count is only approximate numerically.  The "
            "family may be noisy, weakly separated, or insufficiently sampled."
        )

    diagnostics = CommutantDiagnostics(
        expected_nullity=expected_nullity,
        estimated_nullity=estimated_nullity,
        estimated_center_nullity=estimated_center_nullity,
        relative_threshold=relative_threshold,
        singular_values=singular_values.detach().cpu().tolist(),
        center_singular_values=center_singular_values.detach().cpu().tolist(),
        selected_residuals=singular_values[:commutant_count].detach().cpu().tolist(),
        selected_center_residuals=center_singular_values[:center_count].detach().cpu().tolist(),
        nullity_gap_ratio=nullity_gap_ratio,
        center_gap_ratio=center_gap_ratio,
        status=status,
        message=message,
    )
    return CommutantAnalysis(
        commutant_matrices=commutant_matrices.to(dtype=operators[0].dtype),
        center_matrices=center_matrices.to(dtype=operators[0].dtype),
        diagnostics=diagnostics,
    )
