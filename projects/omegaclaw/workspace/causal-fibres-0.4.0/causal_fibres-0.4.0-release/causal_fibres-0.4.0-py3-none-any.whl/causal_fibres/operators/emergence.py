from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Sequence

import torch
from torch import Tensor, nn


class OrthonormalBlockBasis(nn.Module):
    """Trainable orthonormal basis partitioned into fixed-size candidate fibres."""

    def __init__(self, dimension: int, block_sizes: Sequence[int]) -> None:
        super().__init__()
        if sum(block_sizes) != dimension:
            raise ValueError("block_sizes must sum to dimension")
        self.dimension = dimension
        self.block_sizes = tuple(int(size) for size in block_sizes)
        initial = torch.eye(dimension) + 0.01 * torch.randn(dimension, dimension)
        self.raw = nn.Parameter(initial)

    def matrix(self) -> Tensor:
        q, _ = torch.linalg.qr(self.raw)
        return q

    def blocks(self) -> tuple[Tensor, ...]:
        q = self.matrix()
        result = []
        start = 0
        for size in self.block_sizes:
            result.append(q[:, start : start + size])
            start += size
        return tuple(result)


def joint_block_diagonalization_loss(
    operators: Sequence[Tensor],
    blocks: Sequence[Tensor],
    *,
    allowed_coupling: Tensor | None = None,
    normalized: bool = False,
) -> Tensor:
    if not operators:
        raise ValueError("At least one operator is required")
    total = operators[0].new_zeros(())
    scale = operators[0].new_zeros(())
    count = 0
    for operator in operators:
        operator_scale = operator.square().sum().clamp_min(1e-12) if normalized else 1.0
        for q, left in enumerate(blocks):
            for r, right in enumerate(blocks):
                if q >= r:
                    continue
                if allowed_coupling is not None and bool(allowed_coupling[q, r]):
                    continue
                cross = left.T @ operator @ right
                total = total + cross.square().sum() / operator_scale
                count += 1
        scale = scale + operator_scale if isinstance(operator_scale, Tensor) else scale
    del scale
    return total / max(1, count)


def context_signatures(operators: Sequence[Tensor], blocks: Sequence[Tensor]) -> Tensor:
    values = []
    for block in blocks:
        block_values = []
        for operator in operators:
            block_values.append(torch.trace(block.T @ operator @ block) / block.shape[1])
        values.append(torch.stack(block_values))
    return torch.stack(values)


def signature_gap(signatures: Tensor) -> Tensor:
    if signatures.shape[0] < 2:
        return signatures.new_tensor(float("inf"))
    distances = torch.cdist(signatures, signatures)
    eye = torch.eye(distances.shape[0], device=distances.device, dtype=torch.bool)
    return distances.masked_fill(eye, float("inf")).min()


def pairwise_emergence_ratio(
    operators: Sequence[Tensor],
    blocks: Sequence[Tensor],
    *,
    estimation_noise: float = 0.0,
) -> Tensor:
    signatures = context_signatures(operators, blocks)
    n = len(blocks)
    ratios = signatures.new_full((n, n), float("inf"))
    for q in range(n):
        for r in range(q + 1, n):
            numerator = (signatures[q] - signatures[r]).square().sum()
            denominator = signatures.new_tensor(estimation_noise**2)
            for operator in operators:
                denominator = denominator + 4.0 * (
                    blocks[q].T @ operator @ blocks[r]
                ).square().sum()
            ratio = numerator / denominator.clamp_min(1e-12)
            ratios[q, r] = ratio
            ratios[r, q] = ratio
    return ratios


def commutator_norm(left: Tensor, right: Tensor, *, normalized: bool = False) -> Tensor:
    commutator = left @ right - right @ left
    value = torch.linalg.matrix_norm(commutator)
    if normalized:
        value = value / (
            torch.linalg.matrix_norm(left) * torch.linalg.matrix_norm(right) + 1e-12
        )
    return value


def commutator_matrix(operators: Sequence[Tensor], *, normalized: bool = True) -> Tensor:
    if not operators:
        raise ValueError("At least one operator is required")
    result = operators[0].new_zeros((len(operators), len(operators)))
    for i in range(len(operators)):
        for j in range(i + 1, len(operators)):
            value = commutator_norm(operators[i], operators[j], normalized=normalized)
            result[i, j] = result[j, i] = value
    return result


@dataclass
class EmergenceReport:
    block_loss: float
    signature_gap: float
    min_emergence_ratio: float
    max_commutator: float
    signatures: list[list[float]]
    emergence_ratios: list[list[float]]
    commutators: list[list[float]]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def emergence_report(
    operators: Sequence[Tensor],
    blocks: Sequence[Tensor],
    *,
    estimation_noise: float = 0.0,
    allowed_coupling: Tensor | None = None,
    normalized: bool = False,
) -> EmergenceReport:
    loss = joint_block_diagonalization_loss(
        operators,
        blocks,
        allowed_coupling=allowed_coupling,
        normalized=normalized,
    )
    signatures = context_signatures(operators, blocks)
    ratios = pairwise_emergence_ratio(
        operators, blocks, estimation_noise=estimation_noise
    )
    finite = ratios[torch.isfinite(ratios)]
    min_ratio = float(finite.min()) if finite.numel() else float("inf")
    commutators = commutator_matrix(operators)
    max_comm = float(commutators.max()) if commutators.numel() else 0.0
    serializable_ratios = torch.nan_to_num(
        ratios, posinf=torch.finfo(ratios.dtype).max
    )
    return EmergenceReport(
        block_loss=float(loss.detach()),
        signature_gap=float(signature_gap(signatures).detach()),
        min_emergence_ratio=min_ratio,
        max_commutator=max_comm,
        signatures=signatures.detach().cpu().tolist(),
        emergence_ratios=serializable_ratios.detach().cpu().tolist(),
        commutators=commutators.detach().cpu().tolist(),
    )
