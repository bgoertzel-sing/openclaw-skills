from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable

import torch
from torch import Tensor


class LinearOperator(ABC):
    @property
    @abstractmethod
    def dimension(self) -> int:
        raise NotImplementedError

    @abstractmethod
    def matvec(self, vector: Tensor) -> Tensor:
        raise NotImplementedError

    def to_dense(
        self,
        *,
        device: torch.device | str | None = None,
        dtype: torch.dtype | None = None,
        max_dimension: int | None = None,
    ) -> Tensor:
        if max_dimension is not None and self.dimension > max_dimension:
            raise ValueError(
                f"Operator dimension {self.dimension} exceeds max_dimension={max_dimension}"
            )
        eye = torch.eye(self.dimension, device=device, dtype=dtype)
        columns = [self.matvec(eye[:, index]).reshape(-1) for index in range(self.dimension)]
        return torch.stack(columns, dim=1)

    def quadratic_form(self, vector: Tensor) -> Tensor:
        flat = vector.reshape(-1)
        return torch.dot(flat, self.matvec(flat).reshape(-1))


class DenseOperator(LinearOperator):
    def __init__(self, matrix: Tensor, *, symmetrize: bool = False) -> None:
        if matrix.ndim != 2 or matrix.shape[0] != matrix.shape[1]:
            raise ValueError("matrix must be square")
        self.matrix = 0.5 * (matrix + matrix.T) if symmetrize else matrix

    @property
    def dimension(self) -> int:
        return int(self.matrix.shape[0])

    def matvec(self, vector: Tensor) -> Tensor:
        return self.matrix @ vector.to(self.matrix)


class CallableOperator(LinearOperator):
    def __init__(self, dimension: int, fn: Callable[[Tensor], Tensor]) -> None:
        if dimension <= 0:
            raise ValueError("dimension must be positive")
        self._dimension = dimension
        self.fn = fn

    @property
    def dimension(self) -> int:
        return self._dimension

    def matvec(self, vector: Tensor) -> Tensor:
        return self.fn(vector)


class SumOperator(LinearOperator):
    def __init__(self, operators: list[LinearOperator] | tuple[LinearOperator, ...]) -> None:
        if not operators:
            raise ValueError("At least one operator is required")
        dimensions = {operator.dimension for operator in operators}
        if len(dimensions) != 1:
            raise ValueError("All operators must have equal dimension")
        self.operators = tuple(operators)

    @property
    def dimension(self) -> int:
        return self.operators[0].dimension

    def matvec(self, vector: Tensor) -> Tensor:
        return sum((operator.matvec(vector) for operator in self.operators), torch.zeros_like(vector))
