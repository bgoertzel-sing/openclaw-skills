from __future__ import annotations

import torch
from torch import Tensor

from .linear_operator import LinearOperator


@torch.no_grad()
def randomized_range(
    operator: LinearOperator,
    rank: int,
    *,
    oversample: int = 8,
    power_iterations: int = 1,
    device: torch.device | str | None = None,
    dtype: torch.dtype | None = None,
    generator: torch.Generator | None = None,
) -> Tensor:
    if rank <= 0:
        raise ValueError("rank must be positive")
    width = min(operator.dimension, rank + max(0, oversample))
    omega = torch.randn(
        operator.dimension,
        width,
        device=device,
        dtype=dtype,
        generator=generator,
    )
    samples = torch.stack([operator.matvec(omega[:, i]) for i in range(width)], dim=1)
    q, _ = torch.linalg.qr(samples, mode="reduced")
    for _ in range(power_iterations):
        samples = torch.stack([operator.matvec(q[:, i]) for i in range(q.shape[1])], dim=1)
        q, _ = torch.linalg.qr(samples, mode="reduced")
    return q[:, : min(rank, q.shape[1])]


@torch.no_grad()
def low_rank_projection(operator: LinearOperator, basis: Tensor) -> Tensor:
    columns = [operator.matvec(basis[:, i]) for i in range(basis.shape[1])]
    action = torch.stack(columns, dim=1)
    return basis.T @ action


@torch.no_grad()
def hutchinson_trace(
    operator: LinearOperator,
    probes: int = 32,
    *,
    device: torch.device | str | None = None,
    dtype: torch.dtype | None = None,
    generator: torch.Generator | None = None,
) -> tuple[float, float]:
    if probes <= 0:
        raise ValueError("probes must be positive")
    estimates = []
    for _ in range(probes):
        vector = torch.randint(
            0,
            2,
            (operator.dimension,),
            device=device,
            generator=generator,
        ).to(dtype=dtype or torch.float32)
        vector = vector.mul_(2).sub_(1)
        estimates.append(torch.dot(vector, operator.matvec(vector).to(vector)))
    values = torch.stack(estimates)
    return float(values.mean()), float(values.std(unbiased=probes > 1) / probes**0.5)
