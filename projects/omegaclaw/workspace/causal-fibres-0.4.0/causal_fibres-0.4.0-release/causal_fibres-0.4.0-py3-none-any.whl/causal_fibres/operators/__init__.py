"""Context operators, sketches, joint block diagonalization, and audits."""

from .autograd import (
    AutogradGaussNewtonOperator,
    AutogradHessianOperator,
    PerSampleGradientFisherOperator,
    empirical_fisher_matrix,
    softmax_fisher_metric,
)
from .emergence import (
    EmergenceReport,
    OrthonormalBlockBasis,
    commutator_matrix,
    commutator_norm,
    context_signatures,
    emergence_report,
    joint_block_diagonalization_loss,
    pairwise_emergence_ratio,
    signature_gap,
)
from .commutant import (
    CommutantAnalysis,
    CommutantDiagnostics,
    approximate_symmetric_commutant,
    symmetric_matrix_basis,
)
from .joint_diag import (
    InitializationRecord,
    JointBlockDiagonalizer,
    JointDiagonalizationResult,
    RestartSummary,
)
from .linear_operator import CallableOperator, DenseOperator, LinearOperator, SumOperator
from .sketch import hutchinson_trace, low_rank_projection, randomized_range

__all__ = [
    "AutogradGaussNewtonOperator",
    "AutogradHessianOperator",
    "PerSampleGradientFisherOperator",
    "empirical_fisher_matrix",
    "softmax_fisher_metric",
    "EmergenceReport",
    "OrthonormalBlockBasis",
    "commutator_matrix",
    "commutator_norm",
    "context_signatures",
    "emergence_report",
    "joint_block_diagonalization_loss",
    "pairwise_emergence_ratio",
    "signature_gap",
    "CommutantAnalysis",
    "CommutantDiagnostics",
    "approximate_symmetric_commutant",
    "symmetric_matrix_basis",
    "InitializationRecord",
    "JointBlockDiagonalizer",
    "JointDiagonalizationResult",
    "RestartSummary",
    "CallableOperator",
    "DenseOperator",
    "LinearOperator",
    "SumOperator",
    "hutchinson_trace",
    "low_rank_projection",
    "randomized_range",
]

from .dictionary import (
    DictionaryOperatorMetrics,
    DictionaryOperatorReport,
    audit_dictionary_operators,
    dictionary_operator_coordinates,
)

__all__ += [
    "DictionaryOperatorMetrics",
    "DictionaryOperatorReport",
    "dictionary_operator_coordinates",
    "audit_dictionary_operators",
]
