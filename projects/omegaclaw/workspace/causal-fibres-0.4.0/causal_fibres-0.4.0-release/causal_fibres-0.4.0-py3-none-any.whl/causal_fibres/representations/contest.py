from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Callable, Mapping

import torch
from torch import Tensor, nn

from .base import InterpretabilityBudget, RepresentationMetrics, RepresentationModel, representation_metrics


@dataclass
class ContestEntry:
    name: str
    train_loss: float
    validation_loss: float
    metrics: RepresentationMetrics
    budget: InterpretabilityBudget
    history: list[float] = field(default_factory=list)

    def to_dict(self) -> dict[str, object]:
        value = asdict(self)
        value["metrics"] = asdict(self.metrics)
        value["budget"] = asdict(self.budget)
        return value


@dataclass
class RepresentationContestResult:
    entries: dict[str, ContestEntry]
    winner: str
    selection_metric: str

    def to_dict(self) -> dict[str, object]:
        return {
            "winner": self.winner,
            "selection_metric": self.selection_metric,
            "entries": {name: entry.to_dict() for name, entry in self.entries.items()},
        }


class RepresentationContest:
    """Matched-data comparison of competing representation classes.

    This is intentionally simple and transparent.  Large experiments should
    provide application-specific trainers, but can retain the same report
    schema and interpretability-budget accounting.
    """

    def __init__(
        self,
        models: Mapping[str, nn.Module],
        *,
        learning_rate: float = 3e-3,
        steps: int = 500,
        batch_size: int = 128,
        seed: int = 0,
    ) -> None:
        if not models:
            raise ValueError("At least one representation model is required")
        if steps <= 0 or batch_size <= 0 or learning_rate <= 0:
            raise ValueError("learning rate, steps, and batch size must be positive")
        self.models = dict(models)
        self.learning_rate = float(learning_rate)
        self.steps = steps
        self.batch_size = batch_size
        self.seed = seed

    def fit(
        self,
        train_inputs: Tensor,
        validation_inputs: Tensor,
        *,
        train_context: Tensor | None = None,
        validation_context: Tensor | None = None,
        extra_loss_fn: Callable[[str, nn.Module, object, Tensor], Tensor] | None = None,
    ) -> RepresentationContestResult:
        generator = torch.Generator(device="cpu").manual_seed(self.seed)
        entries: dict[str, ContestEntry] = {}
        for name, model in self.models.items():
            model.train()
            optimizer = torch.optim.AdamW(model.parameters(), lr=self.learning_rate)
            history: list[float] = []
            for _ in range(self.steps):
                indices = torch.randint(
                    0,
                    train_inputs.shape[0],
                    (min(self.batch_size, train_inputs.shape[0]),),
                    generator=generator,
                    device="cpu",
                ).to(train_inputs.device)
                batch = train_inputs.index_select(0, indices)
                context = None
                if train_context is not None:
                    context = train_context.index_select(0, indices)
                output = model(batch, context=context)
                loss = output.total_loss
                if extra_loss_fn is not None:
                    loss = loss + extra_loss_fn(name, model, output, batch)
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                optimizer.step()
                history.append(float(loss.detach()))
            model.eval()
            with torch.no_grad():
                train_output = model(train_inputs, context=train_context)
                validation_output = model(validation_inputs, context=validation_context)
            train_loss = float(train_output.total_loss)
            validation_loss = float(validation_output.total_loss)
            metrics = representation_metrics(
                model, validation_inputs, context=validation_context
            )
            budget = model.interpretability_budget(validation_inputs)
            entries[name] = ContestEntry(
                name=name,
                train_loss=train_loss,
                validation_loss=validation_loss,
                metrics=metrics,
                budget=budget,
                history=history,
            )
        winner = min(entries, key=lambda key: entries[key].validation_loss)
        return RepresentationContestResult(
            entries=entries,
            winner=winner,
            selection_metric="validation_loss",
        )
