from __future__ import annotations

import math

import torch
from torch import Tensor, nn
from torch.nn import functional as F

from .base import InterpretabilityBudget, RepresentationOutput, trainable_parameter_count


def _topk_mask(values: Tensor, k: int) -> Tensor:
    if k >= values.shape[-1]:
        return torch.ones_like(values, dtype=torch.bool)
    indices = torch.topk(values, k=k, dim=-1, sorted=False).indices
    mask = torch.zeros_like(values, dtype=torch.bool)
    mask.scatter_(-1, indices, True)
    return mask


class SparseAutoencoder(nn.Module):
    """Overcomplete sparse autoencoder suitable as a mandatory rival baseline.

    The model deliberately drops orthogonality.  Decoder atoms are normalized
    at use time, permitting superposed and overcomplete feature dictionaries.
    """

    def __init__(
        self,
        input_dim: int,
        dictionary_size: int,
        *,
        top_k: int | None = None,
        sparsity_weight: float = 1e-3,
        reconstruction_weight: float = 1.0,
        tied_encoder: bool = False,
        nonlinearity: str = "relu",
        unit_decoder: bool = True,
    ) -> None:
        super().__init__()
        if input_dim <= 0 or dictionary_size <= 0:
            raise ValueError("input_dim and dictionary_size must be positive")
        if top_k is not None and not 0 < top_k <= dictionary_size:
            raise ValueError("top_k must lie in [1, dictionary_size]")
        if sparsity_weight < 0 or reconstruction_weight < 0:
            raise ValueError("loss weights must be non-negative")
        if nonlinearity not in {"relu", "softplus", "identity"}:
            raise ValueError("nonlinearity must be relu, softplus, or identity")
        self.input_dim = input_dim
        self.dictionary_size = dictionary_size
        self.top_k = top_k
        self.sparsity_weight = float(sparsity_weight)
        self.reconstruction_weight = float(reconstruction_weight)
        self.tied_encoder = tied_encoder
        self.nonlinearity = nonlinearity
        self.unit_decoder = unit_decoder
        self.encoder = None if tied_encoder else nn.Linear(input_dim, dictionary_size, bias=False)
        self.encoder_bias = nn.Parameter(torch.zeros(dictionary_size))
        self.decoder_weight = nn.Parameter(
            torch.randn(dictionary_size, input_dim) / math.sqrt(max(input_dim, 1))
        )
        self.decoder_bias = nn.Parameter(torch.zeros(input_dim))

    @property
    def dictionary(self) -> Tensor:
        if self.unit_decoder:
            return F.normalize(self.decoder_weight, dim=-1, eps=1e-8)
        return self.decoder_weight

    def preactivations(self, inputs: Tensor) -> Tensor:
        centred = inputs - self.decoder_bias
        if self.tied_encoder:
            value = centred @ self.dictionary.transpose(-1, -2)
        else:
            assert self.encoder is not None
            value = self.encoder(centred)
        return value + self.encoder_bias

    def encode(self, inputs: Tensor, *, context: Tensor | None = None) -> Tensor:
        del context
        if inputs.shape[-1] != self.input_dim:
            raise ValueError("Unexpected input feature width")
        values = self.preactivations(inputs)
        if self.nonlinearity == "relu":
            values = F.relu(values)
        elif self.nonlinearity == "softplus":
            values = F.softplus(values)
        if self.top_k is not None:
            positive_scores = values.abs() if self.nonlinearity == "identity" else values
            values = values * _topk_mask(positive_scores, self.top_k).to(values.dtype)
        return values

    def decode(self, code: Tensor, *, context: Tensor | None = None) -> Tensor:
        del context
        if code.shape[-1] != self.dictionary_size:
            raise ValueError("Unexpected sparse-code width")
        return code @ self.dictionary + self.decoder_bias

    def forward(self, inputs: Tensor, *, context: Tensor | None = None) -> RepresentationOutput:
        code = self.encode(inputs, context=context)
        reconstruction = self.decode(code, context=context)
        reconstruction_loss = self.reconstruction_weight * torch.mean(
            (reconstruction - inputs) ** 2
        )
        sparsity_loss = self.sparsity_weight * code.abs().mean()
        active = code.abs() > 1e-8
        feature_activity = active.reshape(-1, self.dictionary_size).to(torch.float32).mean(dim=0)
        dead_fraction = (feature_activity <= 1e-8).to(torch.float32).mean()
        return RepresentationOutput(
            code=code,
            reconstruction=reconstruction,
            losses={
                "loss_reconstruction": reconstruction_loss,
                "loss_sparsity": sparsity_loss,
            },
            metadata={
                "kind": "sparse_autoencoder",
                "active_fraction": float(active.to(torch.float32).mean().detach()),
                "dead_fraction": float(dead_fraction.detach()),
            },
        )

    def intervene(
        self,
        code: Tensor,
        feature_indices: Tensor | list[int],
        *,
        value: float | Tensor = 0.0,
        mode: str = "replace",
    ) -> Tensor:
        indices = torch.as_tensor(feature_indices, device=code.device, dtype=torch.long)
        result = code.clone()
        if mode == "replace":
            result[..., indices] = torch.as_tensor(value, device=code.device, dtype=code.dtype)
        elif mode == "add":
            result[..., indices] = result[..., indices] + torch.as_tensor(
                value, device=code.device, dtype=code.dtype
            )
        elif mode == "scale":
            result[..., indices] = result[..., indices] * torch.as_tensor(
                value, device=code.device, dtype=code.dtype
            )
        else:
            raise ValueError("mode must be replace, add, or scale")
        return result

    def interpretability_budget(self, inputs: Tensor | None = None) -> InterpretabilityBudget:
        mean_active = float(self.top_k or self.dictionary_size)
        if inputs is not None:
            with torch.no_grad():
                code = self.encode(inputs)
            mean_active = float((code.abs() > 1e-8).to(torch.float32).sum(dim=-1).mean())
        return InterpretabilityBudget(
            trainable_parameters=trainable_parameter_count(self),
            code_width=self.dictionary_size,
            mean_active_features=mean_active,
        )
