from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Mapping

import torch
from torch import Tensor, nn

from causal_fibres.training.losses import temperature_kl

from .base import RepresentationModel


class RepresentationSteeringModel(nn.Module):
    """Turn any representation model into a residual steering baseline."""

    def __init__(
        self,
        representation: nn.Module,
        code_width: int,
        output_dim: int,
        *,
        freeze_representation: bool = False,
    ) -> None:
        super().__init__()
        self.representation = representation
        self.code_width = code_width
        self.output_dim = output_dim
        self.steering = nn.Linear(code_width, output_dim)
        nn.init.zeros_(self.steering.weight)
        nn.init.zeros_(self.steering.bias)
        if freeze_representation:
            for parameter in representation.parameters():
                parameter.requires_grad_(False)

    def representation_output(self, hidden: Tensor, context: Tensor | None = None):
        return self.representation(hidden, context=context)

    def forward(self, hidden: Tensor, *, context: Tensor | None = None) -> tuple[Tensor, object]:
        output = self.representation_output(hidden, context=context)
        code = output.code.reshape(*hidden.shape[:-1], -1)
        if code.shape[-1] != self.code_width:
            raise ValueError(
                f"Configured code_width={self.code_width}, observed {code.shape[-1]}"
            )
        return self.steering(code), output


@dataclass
class SteeringContestEntry:
    name: str
    base_kl: float
    validation_kl: float
    teacher_gap_closure: float
    reconstruction_mse: float
    mean_active_features: float
    trainable_parameters: int
    representation_parameters: int
    steering_parameters: int
    history: list[float] = field(default_factory=list)

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass
class SteeringContestResult:
    entries: dict[str, SteeringContestEntry]
    winner: str

    def to_dict(self) -> dict[str, object]:
        return {
            "winner": self.winner,
            "entries": {name: entry.to_dict() for name, entry in self.entries.items()},
        }


class RepresentationSteeringContest:
    """Head-to-head task comparison of dense, SAE, fibre, and bundle representations."""

    def __init__(
        self,
        models: Mapping[str, RepresentationSteeringModel],
        *,
        temperature: float = 2.0,
        pretrain_steps: int = 200,
        steering_steps: int = 300,
        batch_size: int = 128,
        learning_rate: float = 3e-3,
        joint_finetune: bool = False,
        reconstruction_weight_during_steering: float = 0.1,
        seed: int = 0,
    ) -> None:
        if not models:
            raise ValueError("At least one steering model is required")
        self.models = dict(models)
        self.temperature = float(temperature)
        self.pretrain_steps = pretrain_steps
        self.steering_steps = steering_steps
        self.batch_size = batch_size
        self.learning_rate = float(learning_rate)
        self.joint_finetune = joint_finetune
        self.reconstruction_weight_during_steering = float(
            reconstruction_weight_during_steering
        )
        self.seed = seed

    def _indices(self, size: int, generator: torch.Generator, device: torch.device) -> Tensor:
        return torch.randint(
            0,
            size,
            (min(self.batch_size, size),),
            generator=generator,
            device="cpu",
        ).to(device)

    def fit(
        self,
        train_hidden: Tensor,
        train_base_logits: Tensor,
        train_teacher_logits: Tensor,
        validation_hidden: Tensor,
        validation_base_logits: Tensor,
        validation_teacher_logits: Tensor,
        *,
        train_context: Tensor | None = None,
        validation_context: Tensor | None = None,
    ) -> SteeringContestResult:
        entries: dict[str, SteeringContestEntry] = {}
        for offset, (name, model) in enumerate(self.models.items()):
            representation_parameters = sum(parameter.numel() for parameter in model.representation.parameters())
            steering_parameters = sum(parameter.numel() for parameter in model.steering.parameters())
            ever_trainable_parameters = representation_parameters + steering_parameters
            generator = torch.Generator(device="cpu").manual_seed(self.seed + offset)
            model.to(train_hidden.device, dtype=train_hidden.dtype)
            # Stage 1: fit the representation without task labels.
            representation_optimizer = torch.optim.AdamW(
                [parameter for parameter in model.representation.parameters() if parameter.requires_grad],
                lr=self.learning_rate,
            )
            model.train()
            for _ in range(self.pretrain_steps):
                indices = self._indices(train_hidden.shape[0], generator, train_hidden.device)
                hidden = train_hidden.index_select(0, indices)
                context = None if train_context is None else train_context.index_select(0, indices)
                output = model.representation(hidden, context=context)
                representation_optimizer.zero_grad(set_to_none=True)
                output.total_loss.backward()
                representation_optimizer.step()
            if not self.joint_finetune:
                for parameter in model.representation.parameters():
                    parameter.requires_grad_(False)
            task_optimizer = torch.optim.AdamW(
                [parameter for parameter in model.parameters() if parameter.requires_grad],
                lr=self.learning_rate,
            )
            history: list[float] = []
            for _ in range(self.steering_steps):
                indices = self._indices(train_hidden.shape[0], generator, train_hidden.device)
                hidden = train_hidden.index_select(0, indices)
                base = train_base_logits.index_select(0, indices)
                teacher = train_teacher_logits.index_select(0, indices)
                context = None if train_context is None else train_context.index_select(0, indices)
                residual, representation_output = model(hidden, context=context)
                task_loss = temperature_kl(
                    base + residual,
                    teacher,
                    temperature=self.temperature,
                )
                loss = task_loss
                if self.joint_finetune:
                    loss = loss + self.reconstruction_weight_during_steering * representation_output.total_loss
                task_optimizer.zero_grad(set_to_none=True)
                loss.backward()
                task_optimizer.step()
                history.append(float(loss.detach()))
            model.eval()
            with torch.no_grad():
                residual, representation_output = model(
                    validation_hidden, context=validation_context
                )
                base_kl = temperature_kl(
                    validation_base_logits,
                    validation_teacher_logits,
                    temperature=self.temperature,
                )
                validation_kl = temperature_kl(
                    validation_base_logits + residual,
                    validation_teacher_logits,
                    temperature=self.temperature,
                )
                reconstruction_mse = torch.mean(
                    (representation_output.reconstruction - validation_hidden) ** 2
                )
                code = representation_output.code.reshape(validation_hidden.shape[0], -1)
                active = (code.abs() > 1e-8).to(torch.float32).sum(dim=-1).mean()
            base_value = float(base_kl)
            validation_value = float(validation_kl)
            entries[name] = SteeringContestEntry(
                name=name,
                base_kl=base_value,
                validation_kl=validation_value,
                teacher_gap_closure=1.0 - validation_value / max(base_value, 1e-12),
                reconstruction_mse=float(reconstruction_mse),
                mean_active_features=float(active),
                trainable_parameters=ever_trainable_parameters,
                representation_parameters=representation_parameters,
                steering_parameters=steering_parameters,
                history=history,
            )
        winner = min(entries, key=lambda key: entries[key].validation_kl)
        return SteeringContestResult(entries=entries, winner=winner)
