from __future__ import annotations

import torch
from torch import Tensor, nn

from .base import InterpretabilityBudget, RepresentationOutput, trainable_parameter_count


class ContextualFibreBundle(nn.Module):
    """Canonical fibres with context-dependent local coordinate charts.

    The chart is an orthogonal Cayley transform generated from context.  This
    representation relaxes the fixed-global-basis assumption while retaining a
    canonical latent space for interventions, plasticity gates, and symbolic
    bindings.
    """

    def __init__(
        self,
        input_dim: int,
        n_fibres: int,
        fibre_dim: int,
        context_dim: int,
        *,
        hidden_dim: int | None = None,
        transport_strength: float = 0.25,
        transport_regularization: float = 1e-3,
        reconstruction_weight: float = 1.0,
    ) -> None:
        super().__init__()
        if min(input_dim, n_fibres, fibre_dim, context_dim) <= 0:
            raise ValueError("all dimensions must be positive")
        self.input_dim = input_dim
        self.n_fibres = n_fibres
        self.fibre_dim = fibre_dim
        self.total_dim = n_fibres * fibre_dim
        self.context_dim = context_dim
        self.transport_strength = float(transport_strength)
        self.transport_regularization = float(transport_regularization)
        self.reconstruction_weight = float(reconstruction_weight)
        encoder_input = input_dim + context_dim
        if hidden_dim is None:
            self.encoder = nn.Linear(encoder_input, self.total_dim)
        else:
            self.encoder = nn.Sequential(
                nn.Linear(encoder_input, hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, self.total_dim),
            )
        self.transport_generator = nn.Linear(context_dim, self.total_dim * self.total_dim)
        nn.init.zeros_(self.transport_generator.weight)
        nn.init.zeros_(self.transport_generator.bias)
        self.decoder = nn.Linear(self.total_dim, input_dim)

    def _context(self, inputs: Tensor, context: Tensor | None) -> Tensor:
        if context is None:
            return inputs.new_zeros(*inputs.shape[:-1], self.context_dim)
        if context.shape[:-1] != inputs.shape[:-1] or context.shape[-1] != self.context_dim:
            raise ValueError("context must match input sample axes and context_dim")
        return context.to(inputs)

    def transport_matrix(self, context: Tensor) -> Tensor:
        raw = self.transport_generator(context)
        raw = raw.reshape(*context.shape[:-1], self.total_dim, self.total_dim)
        skew = 0.5 * (raw - raw.transpose(-1, -2)) * self.transport_strength
        eye = torch.eye(self.total_dim, device=context.device, dtype=context.dtype)
        eye = eye.expand(*context.shape[:-1], self.total_dim, self.total_dim)
        return torch.linalg.solve(eye - 0.5 * skew, eye + 0.5 * skew)

    def encode(self, inputs: Tensor, *, context: Tensor | None = None) -> Tensor:
        if inputs.shape[-1] != self.input_dim:
            raise ValueError("Unexpected input feature width")
        context_value = self._context(inputs, context)
        canonical = self.encoder(torch.cat([inputs, context_value], dim=-1))
        return canonical.reshape(*inputs.shape[:-1], self.n_fibres, self.fibre_dim)

    def local_code(self, canonical_code: Tensor, context: Tensor) -> Tensor:
        if canonical_code.shape[-2:] != (self.n_fibres, self.fibre_dim):
            raise ValueError("Unexpected canonical fibre shape")
        flat = canonical_code.reshape(*canonical_code.shape[:-2], self.total_dim)
        transport = self.transport_matrix(context)
        return torch.matmul(transport, flat.unsqueeze(-1)).squeeze(-1)

    def decode(self, code: Tensor, *, context: Tensor | None = None) -> Tensor:
        if code.shape[-2:] != (self.n_fibres, self.fibre_dim):
            raise ValueError("Unexpected canonical fibre shape")
        flat_reference = code.reshape(*code.shape[:-2], self.total_dim)
        if context is None:
            context = flat_reference.new_zeros(*flat_reference.shape[:-1], self.context_dim)
        local = self.local_code(code, context)
        return self.decoder(local)

    def transport_between(self, source_context: Tensor, target_context: Tensor) -> Tensor:
        source = self.transport_matrix(source_context)
        target = self.transport_matrix(target_context)
        return target @ source.transpose(-1, -2)

    def path_consistency_loss(
        self,
        context_a: Tensor,
        context_b: Tensor,
        context_c: Tensor,
    ) -> Tensor:
        direct = self.transport_between(context_a, context_c)
        via = self.transport_between(context_b, context_c) @ self.transport_between(
            context_a, context_b
        )
        return torch.mean((direct - via) ** 2)

    def forward(self, inputs: Tensor, *, context: Tensor | None = None) -> RepresentationOutput:
        context_value = self._context(inputs, context)
        canonical = self.encode(inputs, context=context_value)
        local = self.local_code(canonical, context_value)
        reconstruction = self.decoder(local)
        transport = self.transport_matrix(context_value)
        eye = torch.eye(self.total_dim, device=inputs.device, dtype=inputs.dtype)
        orthogonality = torch.mean(
            (transport.transpose(-1, -2) @ transport - eye) ** 2
        )
        reconstruction_loss = self.reconstruction_weight * torch.mean(
            (reconstruction - inputs) ** 2
        )
        transport_loss = self.transport_regularization * orthogonality
        return RepresentationOutput(
            code=canonical,
            reconstruction=reconstruction,
            losses={
                "loss_reconstruction": reconstruction_loss,
                "loss_transport_metric": transport_loss,
            },
            metadata={
                "kind": "contextual_fibre_bundle",
                "local_code": local,
                "transport": transport,
                "transport_orthogonality": float(orthogonality.detach()),
            },
        )

    def interpretability_budget(self, inputs: Tensor | None = None) -> InterpretabilityBudget:
        mean_active = float(self.total_dim)
        if inputs is not None:
            with torch.no_grad():
                context = inputs.new_zeros(*inputs.shape[:-1], self.context_dim)
                code = self.encode(inputs, context=context).reshape(
                    *inputs.shape[:-1], self.total_dim
                )
            mean_active = float((code.abs() > 1e-8).to(torch.float32).sum(dim=-1).mean())
        return InterpretabilityBudget(
            trainable_parameters=trainable_parameter_count(self),
            code_width=self.total_dim,
            mean_active_features=mean_active,
            group_count=self.n_fibres,
        )
