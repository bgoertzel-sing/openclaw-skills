from __future__ import annotations

from collections.abc import Sequence

import torch
from torch import Tensor

from .base import InterpretabilityBudget, RepresentationOutput, trainable_parameter_count
from .sae import SparseAutoencoder


class GroupedSparseDictionary(SparseAutoencoder):
    """Overcomplete sparse dictionary with possibly overlapping fibre groups.

    Groups are interpretive and plasticity units over SAE atoms.  They need not
    be orthogonal or disjoint, which makes this representation compatible with
    superposition while retaining module-level audits and routing.
    """

    def __init__(
        self,
        input_dim: int,
        dictionary_size: int,
        groups: Sequence[Sequence[int]],
        *,
        top_k: int | None = None,
        sparsity_weight: float = 1e-3,
        group_sparsity_weight: float = 1e-3,
        reconstruction_weight: float = 1.0,
        tied_encoder: bool = False,
        nonlinearity: str = "relu",
        unit_decoder: bool = True,
    ) -> None:
        super().__init__(
            input_dim,
            dictionary_size,
            top_k=top_k,
            sparsity_weight=sparsity_weight,
            reconstruction_weight=reconstruction_weight,
            tied_encoder=tied_encoder,
            nonlinearity=nonlinearity,
            unit_decoder=unit_decoder,
        )
        if not groups:
            raise ValueError("At least one group is required")
        membership = torch.zeros(len(groups), dictionary_size)
        for group_index, group in enumerate(groups):
            if not group:
                raise ValueError("Groups may not be empty")
            for atom_index in group:
                if not 0 <= int(atom_index) < dictionary_size:
                    raise IndexError(atom_index)
                membership[group_index, int(atom_index)] = 1.0
        if torch.any(membership.sum(dim=-1) == 0):
            raise ValueError("Every group must contain at least one atom")
        self.register_buffer("group_membership", membership)
        self.group_sparsity_weight = float(group_sparsity_weight)

    @property
    def n_groups(self) -> int:
        return int(self.group_membership.shape[0])

    def group_activity(self, code: Tensor, *, reduction: str = "l2") -> Tensor:
        expanded = code.unsqueeze(-2) * self.group_membership.to(code)
        if reduction == "l2":
            return torch.sqrt(torch.sum(expanded**2, dim=-1) + 1e-12)
        if reduction == "l1":
            return expanded.abs().sum(dim=-1)
        if reduction == "max":
            return expanded.abs().amax(dim=-1)
        raise ValueError("reduction must be l2, l1, or max")

    def group_mask(self, group_gate: Tensor) -> Tensor:
        """Convert group gates into an atom mask using max-union semantics."""

        if group_gate.shape[-1] != self.n_groups:
            raise ValueError("Unexpected group-gate width")
        expanded = group_gate.unsqueeze(-1) * self.group_membership.to(group_gate)
        return expanded.amax(dim=-2)

    def apply_group_gate(self, code: Tensor, group_gate: Tensor) -> Tensor:
        return code * self.group_mask(group_gate)

    def forward(self, inputs: Tensor, *, context: Tensor | None = None) -> RepresentationOutput:
        output = super().forward(inputs, context=context)
        activity = self.group_activity(output.code)
        group_sparsity = self.group_sparsity_weight * activity.mean()
        output.losses["loss_group_sparsity"] = group_sparsity
        output.metadata.update(
            {
                "kind": "grouped_sparse_dictionary",
                "group_activity": activity,
                "group_membership": self.group_membership,
            }
        )
        return output

    def interpretability_budget(self, inputs: Tensor | None = None) -> InterpretabilityBudget:
        base = super().interpretability_budget(inputs)
        return InterpretabilityBudget(
            trainable_parameters=trainable_parameter_count(self),
            code_width=base.code_width,
            mean_active_features=base.mean_active_features,
            group_count=self.n_groups,
        )
