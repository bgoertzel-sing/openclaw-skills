from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Protocol, runtime_checkable

import torch
from torch import Tensor, nn


@dataclass
class RepresentationOutput:
    """Result returned by a representation model.

    ``code`` may be dense, sparse, grouped, or fibre-shaped.  The final
    reconstruction always has the same shape as the input unless a model is
    explicitly configured as a non-reconstructive feature extractor.
    """

    code: Tensor
    reconstruction: Tensor
    losses: dict[str, Tensor] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def total_loss(self) -> Tensor:
        if not self.losses:
            return self.reconstruction.new_zeros(())
        values = list(self.losses.values())
        total = values[0].new_zeros(())
        for value in values:
            if value.numel() != 1:
                raise ValueError("Representation losses must be scalar tensors")
            total = total + value
        return total

    def detached(self) -> "RepresentationOutput":
        return RepresentationOutput(
            code=self.code.detach(),
            reconstruction=self.reconstruction.detach(),
            losses={name: value.detach() for name, value in self.losses.items()},
            metadata=dict(self.metadata),
        )


@dataclass(frozen=True)
class InterpretabilityBudget:
    """Lightweight budget used for matched representation comparisons."""

    trainable_parameters: int
    code_width: int
    mean_active_features: float
    group_count: int | None = None
    deployment_flops_proxy: float | None = None


@dataclass
class RepresentationMetrics:
    reconstruction_mse: float
    code_l1: float
    active_fraction: float
    dead_fraction: float
    parameter_count: int
    metadata: dict[str, Any] = field(default_factory=dict)


@runtime_checkable
class RepresentationModel(Protocol):
    """Protocol shared by orthogonal, SAE, and contextual representations."""

    def encode(self, inputs: Tensor, *, context: Tensor | None = None) -> Tensor:
        ...

    def decode(self, code: Tensor, *, context: Tensor | None = None) -> Tensor:
        ...

    def forward(self, inputs: Tensor, *, context: Tensor | None = None) -> RepresentationOutput:
        ...

    def interpretability_budget(self, inputs: Tensor | None = None) -> InterpretabilityBudget:
        ...


def trainable_parameter_count(module: nn.Module) -> int:
    return sum(parameter.numel() for parameter in module.parameters() if parameter.requires_grad)


def representation_metrics(
    model: RepresentationModel,
    inputs: Tensor,
    *,
    context: Tensor | None = None,
    activation_tolerance: float = 1e-8,
) -> RepresentationMetrics:
    with torch.no_grad():
        result = model.forward(inputs, context=context)
    code = result.code
    reconstruction = result.reconstruction
    mse = torch.mean((reconstruction - inputs) ** 2)
    flat_code = result.metadata.get("flat_code")
    if isinstance(flat_code, Tensor):
        code_for_metrics = flat_code
    elif code.ndim >= 3 and result.metadata.get("kind") in {
        "orthogonal_fibres",
        "contextual_fibre_bundle",
    }:
        code_for_metrics = code.reshape(*code.shape[:-2], -1)
    else:
        code_for_metrics = code
    active = code_for_metrics.abs() > activation_tolerance
    feature_width = code_for_metrics.shape[-1] if code_for_metrics.ndim > 1 else code_for_metrics.shape[0]
    feature_activity = active.to(torch.float32).reshape(-1, feature_width).mean(dim=0)
    dead = feature_activity <= activation_tolerance
    module = model if isinstance(model, nn.Module) else None
    return RepresentationMetrics(
        reconstruction_mse=float(mse),
        code_l1=float(code_for_metrics.abs().mean()),
        active_fraction=float(active.to(torch.float32).mean()),
        dead_fraction=float(dead.to(torch.float32).mean()),
        parameter_count=0 if module is None else trainable_parameter_count(module),
        metadata=dict(result.metadata),
    )


def flatten_samples(tensor: Tensor) -> tuple[Tensor, torch.Size]:
    """Flatten all leading sample axes while preserving the feature axis."""

    if tensor.ndim < 2:
        raise ValueError("Expected a tensor with at least one sample axis and one feature axis")
    sample_shape = tensor.shape[:-1]
    return tensor.reshape(-1, tensor.shape[-1]), sample_shape


def restore_samples(tensor: Tensor, sample_shape: torch.Size) -> Tensor:
    return tensor.reshape(*sample_shape, tensor.shape[-1])


def merge_losses(
    base: Mapping[str, Tensor],
    additional: Mapping[str, Tensor],
) -> dict[str, Tensor]:
    result = dict(base)
    for name, value in additional.items():
        if name in result:
            raise KeyError(f"Duplicate representation loss name: {name}")
        result[name] = value
    return result
