"""Competing representation models for structured adaptation experiments."""

from .base import (
    InterpretabilityBudget,
    RepresentationMetrics,
    RepresentationModel,
    RepresentationOutput,
    representation_metrics,
    trainable_parameter_count,
)
from .bundle import ContextualFibreBundle
from .contest import ContestEntry, RepresentationContest, RepresentationContestResult
from .dense import DenseResidualRepresentation
from .grouped import GroupedSparseDictionary
from .orthogonal import OrthogonalFibreRepresentation
from .sae import SparseAutoencoder
from .steering import (
    RepresentationSteeringContest,
    RepresentationSteeringModel,
    SteeringContestEntry,
    SteeringContestResult,
)

__all__ = [
    "InterpretabilityBudget",
    "RepresentationMetrics",
    "RepresentationModel",
    "RepresentationOutput",
    "representation_metrics",
    "trainable_parameter_count",
    "DenseResidualRepresentation",
    "OrthogonalFibreRepresentation",
    "SparseAutoencoder",
    "GroupedSparseDictionary",
    "ContextualFibreBundle",
    "ContestEntry",
    "RepresentationContest",
    "RepresentationContestResult",
    "RepresentationSteeringModel",
    "RepresentationSteeringContest",
    "SteeringContestEntry",
    "SteeringContestResult",
]
