from __future__ import annotations

import torch
from torch import Tensor, nn

from .base import InterpretabilityBudget, RepresentationOutput, trainable_parameter_count


def _orthonormal_columns(raw: Tensor) -> Tensor:
    q, r = torch.linalg.qr(raw, mode="reduced")
    diagonal = torch.diagonal(r)
    signs = torch.where(diagonal >= 0, torch.ones_like(diagonal), -torch.ones_like(diagonal))
    return q * signs.unsqueeze(0)


class OrthogonalFibreRepresentation(nn.Module):
    """Fixed-width orthogonal direct-sum representation.

    This is the representation class closest to the original common-invariant
    subspace theory.  It is intentionally one contender among several, not the
    package-wide default.
    """

    def __init__(
        self,
        input_dim: int,
        n_fibres: int,
        fibre_dim: int,
        *,
        reconstruction_weight: float = 1.0,
        centre: bool = True,
    ) -> None:
        super().__init__()
        total_dim = n_fibres * fibre_dim
        if input_dim <= 0 or n_fibres <= 0 or fibre_dim <= 0:
            raise ValueError("input_dim, n_fibres, and fibre_dim must be positive")
        if total_dim > input_dim:
            raise ValueError("Orthogonal fibres require n_fibres * fibre_dim <= input_dim")
        self.input_dim = input_dim
        self.n_fibres = n_fibres
        self.fibre_dim = fibre_dim
        self.total_dim = total_dim
        self.reconstruction_weight = float(reconstruction_weight)
        raw = torch.randn(input_dim, total_dim) / max(input_dim, 1) ** 0.5
        self.raw_basis = nn.Parameter(raw)
        if centre:
            self.centre = nn.Parameter(torch.zeros(input_dim))
        else:
            self.register_buffer("centre", torch.zeros(input_dim), persistent=False)

    @property
    def basis(self) -> Tensor:
        return _orthonormal_columns(self.raw_basis)

    def encode(self, inputs: Tensor, *, context: Tensor | None = None) -> Tensor:
        del context
        if inputs.shape[-1] != self.input_dim:
            raise ValueError("Unexpected input feature width")
        flat = (inputs - self.centre) @ self.basis
        return flat.reshape(*inputs.shape[:-1], self.n_fibres, self.fibre_dim)

    def decode(self, code: Tensor, *, context: Tensor | None = None) -> Tensor:
        del context
        if code.shape[-2:] != (self.n_fibres, self.fibre_dim):
            raise ValueError("Unexpected fibre-code shape")
        flat = code.reshape(*code.shape[:-2], self.total_dim)
        return flat @ self.basis.transpose(-1, -2) + self.centre

    def forward(self, inputs: Tensor, *, context: Tensor | None = None) -> RepresentationOutput:
        code = self.encode(inputs, context=context)
        reconstruction = self.decode(code, context=context)
        reconstruction_loss = self.reconstruction_weight * torch.mean(
            (reconstruction - inputs) ** 2
        )
        orthogonality = torch.mean(
            (self.basis.transpose(-1, -2) @ self.basis - torch.eye(
                self.total_dim, device=inputs.device, dtype=inputs.dtype
            )) ** 2
        )
        return RepresentationOutput(
            code=code,
            reconstruction=reconstruction,
            losses={
                "loss_reconstruction": reconstruction_loss,
                "loss_orthogonality": orthogonality,
            },
            metadata={"kind": "orthogonal_fibres", "basis": self.basis},
        )

    def fibre_projector(self, fibre_index: int) -> Tensor:
        if not 0 <= fibre_index < self.n_fibres:
            raise IndexError(fibre_index)
        start = fibre_index * self.fibre_dim
        block = self.basis[:, start : start + self.fibre_dim]
        return block @ block.transpose(-1, -2)

    def ablate_fibre(self, code: Tensor, fibre_index: int) -> Tensor:
        result = code.clone()
        result[..., fibre_index, :] = 0
        return result

    def interpretability_budget(self, inputs: Tensor | None = None) -> InterpretabilityBudget:
        mean_active = float(self.total_dim)
        if inputs is not None:
            with torch.no_grad():
                code = self.encode(inputs).reshape(*inputs.shape[:-1], self.total_dim)
            mean_active = float((code.abs() > 1e-8).to(torch.float32).sum(dim=-1).mean())
        return InterpretabilityBudget(
            trainable_parameters=trainable_parameter_count(self),
            code_width=self.total_dim,
            mean_active_features=mean_active,
            group_count=self.n_fibres,
        )
