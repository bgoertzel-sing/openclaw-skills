from __future__ import annotations

import torch
from torch import Tensor, nn

from .base import InterpretabilityBudget, RepresentationOutput, trainable_parameter_count


class DenseResidualRepresentation(nn.Module):
    """Dense bottleneck baseline for representation contests.

    This deliberately makes no sparsity or causal claim.  It is the baseline a
    structured representation must beat at a matched parameter or deployment
    budget.
    """

    def __init__(
        self,
        input_dim: int,
        code_dim: int,
        *,
        hidden_dim: int | None = None,
        activation: str = "gelu",
    ) -> None:
        super().__init__()
        if input_dim <= 0 or code_dim <= 0:
            raise ValueError("input_dim and code_dim must be positive")
        self.input_dim = input_dim
        self.code_dim = code_dim
        activation_module: nn.Module
        if activation == "gelu":
            activation_module = nn.GELU()
        elif activation == "relu":
            activation_module = nn.ReLU()
        elif activation == "tanh":
            activation_module = nn.Tanh()
        else:
            raise ValueError(f"Unsupported activation: {activation}")
        if hidden_dim is None:
            self.encoder = nn.Sequential(nn.Linear(input_dim, code_dim), activation_module)
            self.decoder = nn.Linear(code_dim, input_dim)
        else:
            if hidden_dim <= 0:
                raise ValueError("hidden_dim must be positive")
            self.encoder = nn.Sequential(
                nn.Linear(input_dim, hidden_dim),
                activation_module,
                nn.Linear(hidden_dim, code_dim),
            )
            self.decoder = nn.Sequential(
                nn.Linear(code_dim, hidden_dim),
                activation_module,
                nn.Linear(hidden_dim, input_dim),
            )

    def encode(self, inputs: Tensor, *, context: Tensor | None = None) -> Tensor:
        del context
        if inputs.shape[-1] != self.input_dim:
            raise ValueError("Unexpected input feature width")
        return self.encoder(inputs)

    def decode(self, code: Tensor, *, context: Tensor | None = None) -> Tensor:
        del context
        if code.shape[-1] != self.code_dim:
            raise ValueError("Unexpected code width")
        return self.decoder(code)

    def forward(self, inputs: Tensor, *, context: Tensor | None = None) -> RepresentationOutput:
        code = self.encode(inputs, context=context)
        reconstruction = self.decode(code, context=context)
        reconstruction_loss = torch.mean((reconstruction - inputs) ** 2)
        return RepresentationOutput(
            code=code,
            reconstruction=reconstruction,
            losses={"loss_reconstruction": reconstruction_loss},
            metadata={"kind": "dense"},
        )

    def interpretability_budget(self, inputs: Tensor | None = None) -> InterpretabilityBudget:
        mean_active = float(self.code_dim)
        if inputs is not None:
            with torch.no_grad():
                code = self.encode(inputs)
            mean_active = float((code.abs() > 1e-8).to(torch.float32).sum(dim=-1).mean())
        return InterpretabilityBudget(
            trainable_parameters=trainable_parameter_count(self),
            code_width=self.code_dim,
            mean_active_features=mean_active,
        )
