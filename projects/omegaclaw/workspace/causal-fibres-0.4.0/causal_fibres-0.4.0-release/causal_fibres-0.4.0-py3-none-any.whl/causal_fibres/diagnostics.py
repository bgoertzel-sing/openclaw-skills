from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import Tensor, nn

from causal_fibres.architectures import HookedModuleAdapter
from causal_fibres.recipes import build_terminal_transformer_sidecar
from causal_fibres.solvers import GradientPCSolver
from causal_fibres.training import DistillationWeights, PartialDistillationTrainer


class _TinyNetwork(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, output_dim: int) -> None:
        super().__init__()
        self.hidden = nn.Sequential(nn.Linear(input_dim, hidden_dim), nn.Tanh())
        self.output = nn.Linear(hidden_dim, output_dim)

    def forward(self, inputs: Tensor) -> Tensor:
        return self.output(self.hidden(inputs))


@dataclass
class SmokeTestResult:
    initial_loss: float
    final_loss: float
    energy_monotone: bool
    steps: int

    @property
    def passed(self) -> bool:
        return self.final_loss < self.initial_loss and self.energy_monotone


def run_smoke_test(seed: int = 0, steps: int = 12) -> SmokeTestResult:
    torch.manual_seed(seed)
    input_dim, hidden_dim, output_dim = 5, 8, 4
    teacher = _TinyNetwork(input_dim, hidden_dim, output_dim)
    base = _TinyNetwork(input_dim, hidden_dim, output_dim)
    with torch.no_grad():
        for parameter in teacher.parameters():
            parameter.mul_(1.4)
    adapter = HookedModuleAdapter(
        base,
        sites={"hidden": "hidden"},
        widths={"hidden": hidden_dim},
        freeze=True,
    )
    sidecar = build_terminal_transformer_sidecar(
        {"hidden": hidden_dim},
        output_dim,
        n_fibres=4,
        fibre_dim=2,
        top_k=2,
        residual_scale=0.1,
        trainable_scale=False,
    )
    optimizer = torch.optim.Adam(sidecar.parameters(), lr=2e-2)
    trainer = PartialDistillationTrainer(
        adapter,
        sidecar,
        teacher=lambda batch: teacher(batch),
        solver=GradientPCSolver(steps=2, step_size=0.25),
        optimizer=optimizer,
        weights=DistillationWeights(
            deploy_kd=1.0,
            settled_kd=0.25,
            amortization=1.0,
            predictor_prior=0.1,
            absolute_state=0.01,
            gauge=0.01,
        ),
        temperature=1.5,
    )
    inputs = torch.randn(32, input_dim)
    losses: list[float] = []
    energy_monotone = True
    for _ in range(steps):
        context = trainer.train_step(inputs)
        losses.append(float(context.losses["loss_deploy_kd"].detach()))
        solve = context.cache["solve"]
        energy_monotone = energy_monotone and all(
            right <= left + 1e-7 for left, right in zip(solve.energies, solve.energies[1:])
        )
    return SmokeTestResult(losses[0], losses[-1], energy_monotone, steps)
