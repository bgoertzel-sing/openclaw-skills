from __future__ import annotations

from collections.abc import Callable
from typing import Any


class PluginRegistry:
    """Tiny explicit registry; external packages may register architecture/solver plugins."""

    def __init__(self) -> None:
        self._items: dict[str, Callable[..., Any]] = {}

    def register(self, name: str, factory: Callable[..., Any]) -> None:
        if name in self._items:
            raise KeyError(f"Plugin already registered: {name}")
        self._items[name] = factory

    def create(self, name: str, **kwargs: Any) -> Any:
        try:
            factory = self._items[name]
        except KeyError as exc:
            available = ", ".join(sorted(self._items)) or "<none>"
            raise KeyError(f"Unknown plugin {name!r}; available: {available}") from exc
        return factory(**kwargs)

    def names(self) -> tuple[str, ...]:
        return tuple(sorted(self._items))
