from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any, Mapping

import torch
from torch import nn

from .config import CFEConfig
from .reproducibility import capture_rng_state, restore_rng_state


def _torch_load(path: str | Path, map_location: Any = None) -> dict[str, Any]:
    try:
        return torch.load(path, map_location=map_location, weights_only=False)
    except TypeError:  # PyTorch versions predating the weights_only argument
        return torch.load(path, map_location=map_location)


class CheckpointManager:
    """Atomic package checkpoint writer.

    Checkpoints contain model, optimizer, optional scheduler/scaler state,
    configuration, fibre registry data, metrics, and RNG state. The format is a
    normal ``torch.save`` dictionary so colleagues can inspect it without this
    class.
    """

    FORMAT_VERSION = 1

    @classmethod
    def save(
        cls,
        path: str | Path,
        *,
        model: nn.Module,
        optimizer: torch.optim.Optimizer | None = None,
        scheduler: Any = None,
        scaler: Any = None,
        step: int = 0,
        epoch: int = 0,
        config: CFEConfig | Mapping[str, Any] | None = None,
        fibre_registry: Mapping[str, Any] | None = None,
        metrics: Mapping[str, float] | None = None,
        extra: Mapping[str, Any] | None = None,
    ) -> Path:
        destination = Path(path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(config, CFEConfig):
            config_data: Mapping[str, Any] | None = config.to_dict()
        else:
            config_data = config
        payload: dict[str, Any] = {
            "format_version": cls.FORMAT_VERSION,
            "step": int(step),
            "epoch": int(epoch),
            "model": model.state_dict(),
            "config": None if config_data is None else dict(config_data),
            "fibre_registry": dict(fibre_registry or {}),
            "metrics": dict(metrics or {}),
            "rng_state": capture_rng_state(),
            "extra": dict(extra or {}),
        }
        if optimizer is not None:
            payload["optimizer"] = optimizer.state_dict()
        if scheduler is not None:
            payload["scheduler"] = scheduler.state_dict()
        if scaler is not None:
            payload["scaler"] = scaler.state_dict()

        fd, temporary_name = tempfile.mkstemp(
            prefix=destination.name + ".",
            suffix=".tmp",
            dir=str(destination.parent),
        )
        os.close(fd)
        temporary = Path(temporary_name)
        try:
            torch.save(payload, temporary)
            os.replace(temporary, destination)
        finally:
            if temporary.exists():
                temporary.unlink()
        return destination

    @classmethod
    def load(
        cls,
        path: str | Path,
        *,
        model: nn.Module | None = None,
        optimizer: torch.optim.Optimizer | None = None,
        scheduler: Any = None,
        scaler: Any = None,
        map_location: str | torch.device | None = "cpu",
        strict: bool = True,
        restore_rng: bool = False,
    ) -> dict[str, Any]:
        payload = _torch_load(path, map_location)
        if int(payload.get("format_version", 0)) > cls.FORMAT_VERSION:
            raise RuntimeError("Checkpoint was produced by a newer causal-fibres version")
        if model is not None:
            model.load_state_dict(payload["model"], strict=strict)
        if optimizer is not None and "optimizer" in payload:
            optimizer.load_state_dict(payload["optimizer"])
        if scheduler is not None and "scheduler" in payload:
            scheduler.load_state_dict(payload["scheduler"])
        if scaler is not None and "scaler" in payload:
            scaler.load_state_dict(payload["scaler"])
        if restore_rng and "rng_state" in payload:
            restore_rng_state(payload["rng_state"])
        return payload

    @staticmethod
    def inspect(path: str | Path) -> dict[str, Any]:
        payload = _torch_load(path, "cpu")
        return {
            "format_version": payload.get("format_version"),
            "step": payload.get("step"),
            "epoch": payload.get("epoch"),
            "config": payload.get("config"),
            "fibre_registry": payload.get("fibre_registry"),
            "metrics": payload.get("metrics"),
            "extra": payload.get("extra"),
            "model_tensor_count": len(payload.get("model", {})),
        }

    @staticmethod
    def write_manifest(path: str | Path, information: Mapping[str, Any]) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(dict(information), handle, indent=2, sort_keys=True, default=str)
        return path
