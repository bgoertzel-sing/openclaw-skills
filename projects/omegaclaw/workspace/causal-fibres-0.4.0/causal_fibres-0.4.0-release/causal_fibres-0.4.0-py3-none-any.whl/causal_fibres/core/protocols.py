from __future__ import annotations

from typing import Any, Callable, Mapping, Protocol, Sequence, runtime_checkable

from torch import Tensor, nn

from .types import CreditPacket, ForwardRecord, SiteSpec, SolveResult, StepContext

EnergyFn = Callable[[Tensor], Tensor]


@runtime_checkable
class ArchitectureAdapter(Protocol):
    """Map an arbitrary model into named read/write sites."""

    @property
    def site_specs(self) -> Sequence[SiteSpec]: ...

    def forward_base(self, batch: Any) -> ForwardRecord: ...


@runtime_checkable
class IntervenableArchitectureAdapter(ArchitectureAdapter, Protocol):
    def forward_with_writes(self, batch: Any, writes: Mapping[str, Tensor]) -> ForwardRecord: ...


@runtime_checkable
class FibrePredictor(Protocol):
    def __call__(self, sites: Mapping[str, Tensor], context: Any = None) -> Tensor: ...


@runtime_checkable
class FibreRouter(Protocol):
    def __call__(
        self,
        features: Tensor,
        context: Any = None,
        known_support: Tensor | None = None,
    ) -> Tensor: ...


@runtime_checkable
class StateSolver(Protocol):
    def solve(
        self,
        initial: Tensor,
        energy_fn: EnergyFn,
        *,
        create_graph: bool = False,
    ) -> SolveResult: ...


@runtime_checkable
class CreditSource(Protocol):
    def compute(self, ctx: StepContext) -> CreditPacket: ...


@runtime_checkable
class ParameterUpdateRule(Protocol):
    def step(self, ctx: StepContext) -> Mapping[str, float]: ...


@runtime_checkable
class ContextOperator(Protocol):
    @property
    def dimension(self) -> int: ...

    def matvec(self, vector: Tensor) -> Tensor: ...


@runtime_checkable
class InterventionPolicy(Protocol):
    def propose(self, ctx: StepContext) -> Sequence[Any]: ...


@runtime_checkable
class LifecyclePolicy(Protocol):
    def update(self, ctx: StepContext, module: nn.Module) -> Mapping[str, Any]: ...


@runtime_checkable
class SymbolicStore(Protocol):
    def query(self, keys: Tensor, top_k: int) -> tuple[Tensor, Tensor, Tensor]:
        """Return ``(scores, template_keys, template_values)``."""
        ...
