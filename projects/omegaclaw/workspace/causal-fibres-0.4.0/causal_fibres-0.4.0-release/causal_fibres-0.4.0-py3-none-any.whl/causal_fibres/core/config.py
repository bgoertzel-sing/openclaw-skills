from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Mapping


def _positive(name: str, value: float) -> None:
    if value <= 0:
        raise ValueError(f"{name} must be positive, got {value}")


def _nonnegative(name: str, value: float) -> None:
    if value < 0:
        raise ValueError(f"{name} must be non-negative, got {value}")


@dataclass
class FibreConfig:
    n_fibres: int = 8
    fibre_dim: int = 16
    predictor_hidden_dim: int | None = 128
    predictor_fusion: str = "weighted_sum"
    context_dim: int | None = None
    fixed_write_norm: float | None = 1.0
    residual_scale: float = 0.05
    trainable_scale: bool = False
    reserve_fraction: float = 0.25

    def validate(self) -> None:
        if self.n_fibres <= 0 or self.fibre_dim <= 0:
            raise ValueError("n_fibres and fibre_dim must be positive")
        if self.predictor_fusion not in {"weighted_sum", "concat"}:
            raise ValueError("predictor_fusion must be 'weighted_sum' or 'concat'")
        if self.predictor_hidden_dim is not None and self.predictor_hidden_dim <= 0:
            raise ValueError("predictor_hidden_dim must be positive or None")
        if self.context_dim is not None and self.context_dim <= 0:
            raise ValueError("context_dim must be positive or None")
        if self.fixed_write_norm is not None:
            _positive("fixed_write_norm", self.fixed_write_norm)
        _nonnegative("residual_scale", self.residual_scale)
        if not 0 <= self.reserve_fraction < 1:
            raise ValueError("reserve_fraction must lie in [0, 1)")


@dataclass
class RouterConfig:
    kind: str = "soft_topk"
    top_k: int | None = 2
    temperature: float = 2.0
    minimum_temperature: float = 0.25
    straight_through: bool = False
    min_gate: float = 0.0

    def validate(self, n_fibres: int | None = None) -> None:
        if self.kind not in {"none", "soft_topk", "known_support", "influence"}:
            raise ValueError(f"Unknown router kind: {self.kind}")
        if self.top_k is not None and self.top_k <= 0:
            raise ValueError("top_k must be positive or None")
        if n_fibres is not None and self.top_k is not None and self.top_k > n_fibres:
            raise ValueError("top_k may not exceed n_fibres")
        _positive("temperature", self.temperature)
        _positive("minimum_temperature", self.minimum_temperature)
        if self.minimum_temperature > self.temperature:
            raise ValueError("minimum_temperature may not exceed temperature")
        if self.min_gate < 0:
            raise ValueError("min_gate must be non-negative")


@dataclass
class SolverConfig:
    kind: str = "gradient_pc"
    steps: int = 2
    step_size: float = 0.2
    damping: float = 0.1
    tolerance: float = 1e-5
    backtracking: bool = True
    max_backtracks: int = 8
    cg_max_iter: int = 32
    adaptive_damping: bool = True

    def validate(self) -> None:
        if self.kind not in {"gradient_pc", "preconditioned_pc", "lm_pc", "none"}:
            raise ValueError(f"Unknown solver kind: {self.kind}")
        if self.steps < 0:
            raise ValueError("steps must be non-negative")
        _positive("step_size", self.step_size)
        _nonnegative("damping", self.damping)
        _nonnegative("tolerance", self.tolerance)
        if self.max_backtracks < 0 or self.cg_max_iter <= 0:
            raise ValueError("invalid backtracking or CG iteration count")


@dataclass
class DistillationConfig:
    temperature: float = 2.0
    deploy_kd: float = 1.0
    settled_kd: float = 0.25
    cross_entropy: float = 0.0
    amortization: float = 1.0
    predictor_prior: float = 0.1
    absolute_state: float = 0.01
    gauge: float = 0.01
    anchor_kl: float = 0.0
    gradient_clip: float | None = 1.0
    gradient_accumulation_steps: int = 1
    ignore_index: int = -100
    causal_lm_shift: bool = False

    def validate(self) -> None:
        _positive("temperature", self.temperature)
        for name in (
            "deploy_kd",
            "settled_kd",
            "cross_entropy",
            "amortization",
            "predictor_prior",
            "absolute_state",
            "gauge",
            "anchor_kl",
        ):
            _nonnegative(name, float(getattr(self, name)))
        if self.gradient_clip is not None:
            _positive("gradient_clip", self.gradient_clip)
        if self.gradient_accumulation_steps <= 0:
            raise ValueError("gradient_accumulation_steps must be positive")


@dataclass
class CreditConfig:
    kind: str = "oracle_gated"
    oracle_alpha: float = 1.0
    factor_count: int | None = None
    factor_error_dim: int | None = None
    path_weight: float = 0.0
    metric_weight: float = 0.0
    novelty_weight: float = 0.0

    def validate(self) -> None:
        if self.kind not in {"oracle", "oracle_gated", "dense", "causal_highway", "blend"}:
            raise ValueError(f"Unknown credit kind: {self.kind}")
        if not 0 <= self.oracle_alpha <= 1:
            raise ValueError("oracle_alpha must lie in [0, 1]")
        for name in ("path_weight", "metric_weight", "novelty_weight"):
            _nonnegative(name, float(getattr(self, name)))


@dataclass
class RepresentationConfig:
    """Competing representation family configuration.

    ``dense`` is the conservative default. Orthogonal fibres, sparse
    autoencoders, grouped overcomplete dictionaries, and contextual bundles
    should be compared rather than assumed.
    """

    kind: str = "dense"
    candidates: tuple[str, ...] = (
        "dense",
        "sae",
        "grouped_sae",
        "orthogonal",
        "contextual_bundle",
    )
    code_dim: int = 32
    dictionary_size: int = 128
    top_k: int | None = 8
    group_count: int = 8
    sparsity_weight: float = 1e-3
    group_sparsity_weight: float = 1e-3
    context_dim: int | None = None
    transport_strength: float = 0.25

    def validate(self) -> None:
        allowed = {"dense", "sae", "grouped_sae", "orthogonal", "contextual_bundle"}
        if self.kind not in allowed:
            raise ValueError(f"Unknown representation kind: {self.kind}")
        if not self.candidates or any(candidate not in allowed for candidate in self.candidates):
            raise ValueError("representation candidates must be non-empty and recognized")
        if self.code_dim <= 0 or self.dictionary_size <= 0 or self.group_count <= 0:
            raise ValueError("representation dimensions must be positive")
        if self.top_k is not None and not 0 < self.top_k <= self.dictionary_size:
            raise ValueError("representation top_k must lie in [1, dictionary_size]")
        _nonnegative("sparsity_weight", self.sparsity_weight)
        _nonnegative("group_sparsity_weight", self.group_sparsity_weight)
        if self.context_dim is not None and self.context_dim <= 0:
            raise ValueError("context_dim must be positive or None")
        _nonnegative("transport_strength", self.transport_strength)


@dataclass
class SubstrateConfig:
    """Frozen or controlled low-rank substrate-plasticity configuration."""

    kind: str = "frozen"
    rank: int = 8
    alpha: float | None = None
    dropout: float = 0.0
    target_modules: tuple[str, ...] = ()
    anchor_kind: str = "symmetric_kl"
    anchor_weight: float = 0.1
    trust_radius: float = 0.01
    minimum_observability_gap: float = 0.5
    alternating_residual_steps: int = 1
    alternating_substrate_steps: int = 1

    def validate(self) -> None:
        if self.kind not in {"frozen", "low_rank"}:
            raise ValueError("substrate kind must be frozen or low_rank")
        if self.rank <= 0:
            raise ValueError("substrate rank must be positive")
        if self.alpha is not None:
            _positive("substrate alpha", self.alpha)
        if not 0 <= self.dropout < 1:
            raise ValueError("substrate dropout must lie in [0, 1)")
        if self.anchor_kind not in {"symmetric_kl", "mse", "cosine"}:
            raise ValueError("unsupported anchor_kind")
        _nonnegative("anchor_weight", self.anchor_weight)
        _nonnegative("trust_radius", self.trust_radius)
        if not 0 <= self.minimum_observability_gap <= 1:
            raise ValueError("minimum_observability_gap must lie in [0, 1]")
        if self.alternating_residual_steps < 0 or self.alternating_substrate_steps < 0:
            raise ValueError("alternating step counts must be non-negative")
        if self.alternating_residual_steps + self.alternating_substrate_steps == 0:
            raise ValueError("at least one alternating step is required")


@dataclass
class EvaluationConfig:
    """Deployment-honest and rival-baseline evaluation configuration."""

    require_observability_control: bool = True
    require_sae_baseline: bool = True
    observability_capacities: tuple[int, ...] = (4, 8, 16, 32)
    settlement_modes: tuple[str, ...] = (
        "predictor_only",
        "free_settlement",
        "constrained_settlement",
        "teacher_clamped_diagnostic",
    )
    finite_curriculum_orders: int = 4
    evaluate_novel_context_routing: bool = True
    matched_wall_clock: bool = True

    def validate(self) -> None:
        if not self.observability_capacities or any(value <= 0 for value in self.observability_capacities):
            raise ValueError("observability capacities must be positive")
        allowed = {
            "predictor_only",
            "free_settlement",
            "constrained_settlement",
            "teacher_clamped_diagnostic",
        }
        if any(mode not in allowed for mode in self.settlement_modes):
            raise ValueError("unknown settlement evaluation mode")
        if self.finite_curriculum_orders < 2:
            raise ValueError("finite_curriculum_orders must be at least two")


@dataclass
class AuditConfig:
    intervention_interval: int = 200
    operator_interval: int = 500
    structure_interval: int = 2000
    true_intervention_fraction: float = 0.02
    operator_rank: int = 32
    max_operator_dimension: int = 4096

    def validate(self) -> None:
        for name in ("intervention_interval", "operator_interval", "structure_interval"):
            if getattr(self, name) < 0:
                raise ValueError(f"{name} must be non-negative")
        if not 0 <= self.true_intervention_fraction <= 1:
            raise ValueError("true_intervention_fraction must lie in [0, 1]")
        if self.operator_rank <= 0 or self.max_operator_dimension <= 0:
            raise ValueError("operator dimensions must be positive")


@dataclass
class SymbolicConfig:
    enabled: bool = False
    key_dim: int = 64
    value_dim: int = 64
    top_k: int = 4
    temperature: float = 1.0
    key_loss_weight: float = 0.0
    contrastive_loss_weight: float = 0.0
    feedback_scale: float = 0.0

    def validate(self) -> None:
        if self.key_dim <= 0 or self.value_dim <= 0 or self.top_k <= 0:
            raise ValueError("symbolic dimensions and top_k must be positive")
        _positive("symbolic temperature", self.temperature)
        for name in ("key_loss_weight", "contrastive_loss_weight", "feedback_scale"):
            _nonnegative(name, float(getattr(self, name)))


@dataclass
class RuntimeConfig:
    seed: int = 0
    device: str = "auto"
    dtype: str = "float32"
    amp: bool = False
    deterministic: bool = False
    checkpoint_interval: int = 1000
    output_dir: str = "runs/default"

    def validate(self) -> None:
        if self.dtype not in {"float32", "float16", "bfloat16", "float64"}:
            raise ValueError(f"Unsupported dtype: {self.dtype}")
        if self.checkpoint_interval < 0:
            raise ValueError("checkpoint_interval must be non-negative")


@dataclass
class CFEConfig:
    fibre: FibreConfig = field(default_factory=FibreConfig)
    router: RouterConfig = field(default_factory=RouterConfig)
    solver: SolverConfig = field(default_factory=SolverConfig)
    distillation: DistillationConfig = field(default_factory=DistillationConfig)
    credit: CreditConfig = field(default_factory=CreditConfig)
    representation: RepresentationConfig = field(default_factory=RepresentationConfig)
    substrate: SubstrateConfig = field(default_factory=SubstrateConfig)
    evaluation: EvaluationConfig = field(default_factory=EvaluationConfig)
    audit: AuditConfig = field(default_factory=AuditConfig)
    symbolic: SymbolicConfig = field(default_factory=SymbolicConfig)
    runtime: RuntimeConfig = field(default_factory=RuntimeConfig)
    metadata: dict[str, Any] = field(default_factory=dict)

    def validate(self) -> "CFEConfig":
        self.fibre.validate()
        self.router.validate(self.fibre.n_fibres)
        self.solver.validate()
        self.distillation.validate()
        self.credit.validate()
        self.representation.validate()
        self.substrate.validate()
        self.evaluation.validate()
        self.audit.validate()
        self.symbolic.validate()
        self.runtime.validate()
        return self

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "CFEConfig":
        # Small compatibility bridge for 0.1-era configuration files. Unknown
        # application fields are retained under metadata rather than discarded.
        raw = dict(value)
        fibre_data = dict(raw.get("fibre", {}))
        router_data = dict(raw.get("router", {}))
        if "soft_top_k" in fibre_data and "top_k" not in router_data:
            router_data["top_k"] = fibre_data.pop("soft_top_k")
        if "router_temperature" in fibre_data and "temperature" not in router_data:
            router_data["temperature"] = fibre_data.pop("router_temperature")

        solver_data = dict(raw.get("solver", {}))
        if solver_data.get("kind") == "damped_gauss_newton":
            solver_data["kind"] = "lm_pc"

        distillation_data = dict(raw.get("distillation", {}))
        legacy_training = raw.get("training", {})
        if isinstance(legacy_training, Mapping):
            legacy_map = {
                "temperature": "temperature",
                "deploy_kd_weight": "deploy_kd",
                "settled_kd_weight": "settled_kd",
                "amortization_weight": "amortization",
                "predictor_prior_weight": "predictor_prior",
                "absolute_state_weight": "absolute_state",
                "gauge_weight": "gauge",
            }
            for old_name, new_name in legacy_map.items():
                if old_name in legacy_training and new_name not in distillation_data:
                    distillation_data[new_name] = legacy_training[old_name]

        known = {
            "fibre",
            "router",
            "solver",
            "distillation",
            "credit",
            "representation",
            "substrate",
            "evaluation",
            "audit",
            "symbolic",
            "runtime",
            "metadata",
        }
        metadata = dict(raw.get("metadata", {}))
        for key, item in raw.items():
            if key not in known:
                metadata.setdefault(key, item)

        config = cls(
            fibre=FibreConfig(**fibre_data),
            router=RouterConfig(**router_data),
            solver=SolverConfig(**solver_data),
            distillation=DistillationConfig(**distillation_data),
            credit=CreditConfig(**raw.get("credit", {})),
            representation=RepresentationConfig(**raw.get("representation", {})),
            substrate=SubstrateConfig(**raw.get("substrate", {})),
            evaluation=EvaluationConfig(**raw.get("evaluation", {})),
            audit=AuditConfig(**raw.get("audit", {})),
            symbolic=SymbolicConfig(**raw.get("symbolic", {})),
            runtime=RuntimeConfig(**raw.get("runtime", {})),
            metadata=metadata,
        )
        return config.validate()

    @classmethod
    def from_yaml(cls, path: str | Path) -> "CFEConfig":
        try:
            import yaml
        except ImportError as exc:
            raise RuntimeError("Install causal-fibres[config] to load YAML") from exc
        with open(path, "r", encoding="utf-8") as handle:
            value = yaml.safe_load(handle) or {}
        if not isinstance(value, Mapping):
            raise TypeError("YAML root must be a mapping")
        return cls.from_mapping(value)

    @classmethod
    def from_json(cls, path: str | Path) -> "CFEConfig":
        with open(path, "r", encoding="utf-8") as handle:
            value = json.load(handle)
        if not isinstance(value, Mapping):
            raise TypeError("JSON root must be a mapping")
        return cls.from_mapping(value)

    def to_yaml(self, path: str | Path) -> None:
        try:
            import yaml
        except ImportError as exc:
            raise RuntimeError("Install causal-fibres[config] to write YAML") from exc
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as handle:
            yaml.safe_dump(self.to_dict(), handle, sort_keys=False)

    def to_json(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(self.to_dict(), handle, indent=2, sort_keys=True)
