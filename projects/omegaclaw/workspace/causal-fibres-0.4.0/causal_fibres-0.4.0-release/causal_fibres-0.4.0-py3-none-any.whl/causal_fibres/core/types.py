from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, MutableMapping

import torch
from torch import Tensor


@dataclass(frozen=True)
class SiteSpec:
    """Description of an architectural read/write site.

    The final tensor dimension is always interpreted as the feature dimension.
    All leading dimensions are application-defined sample axes such as batch,
    token, node, pixel, or time.
    """

    name: str
    width: int
    kind: str = "hidden"
    write_mode: str = "add"
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("SiteSpec.name must be non-empty")
        if self.width <= 0:
            raise ValueError("SiteSpec.width must be positive")
        if self.write_mode not in {"add", "replace", "read_only"}:
            raise ValueError(f"Unsupported write_mode: {self.write_mode!r}")


@dataclass
class ForwardRecord:
    """Backbone output plus captured architectural sites."""

    output: Tensor
    sites: Mapping[str, Tensor]
    aux: MutableMapping[str, Any] = field(default_factory=dict)

    def detached(self) -> "ForwardRecord":
        return ForwardRecord(
            output=self.output.detach(),
            sites={name: value.detach() for name, value in self.sites.items()},
            aux=dict(self.aux),
        )

    def to(self, *args: Any, **kwargs: Any) -> "ForwardRecord":
        return ForwardRecord(
            output=self.output.to(*args, **kwargs),
            sites={name: value.to(*args, **kwargs) for name, value in self.sites.items()},
            aux=dict(self.aux),
        )


@dataclass
class FibreState:
    """Canonical fibre state.

    ``value`` has shape ``[..., n_fibres, fibre_dim]``. ``gate`` and
    ``write_permission`` have shape ``[..., n_fibres]``. Leading axes may be
    batch/token, batch/node, or any application-specific sample layout.
    """

    value: Tensor
    gate: Tensor | None = None
    prior: Tensor | None = None
    write_permission: Tensor | None = None
    metadata: MutableMapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.value.ndim < 2:
            raise ValueError("FibreState.value must end in [n_fibres, fibre_dim]")
        expected_gate_shape = self.value.shape[:-1]
        for name, tensor in (
            ("gate", self.gate),
            ("write_permission", self.write_permission),
        ):
            if tensor is not None and tensor.shape != expected_gate_shape:
                raise ValueError(
                    f"{name} shape {tuple(tensor.shape)} must equal "
                    f"{tuple(expected_gate_shape)}"
                )
        if self.prior is not None and self.prior.shape != self.value.shape:
            raise ValueError("FibreState.prior must match value shape")

    @property
    def n_fibres(self) -> int:
        return int(self.value.shape[-2])

    @property
    def fibre_dim(self) -> int:
        return int(self.value.shape[-1])

    def detached(self) -> "FibreState":
        return FibreState(
            value=self.value.detach(),
            gate=None if self.gate is None else self.gate.detach(),
            prior=None if self.prior is None else self.prior.detach(),
            write_permission=(
                None if self.write_permission is None else self.write_permission.detach()
            ),
            metadata=dict(self.metadata),
        )

    def clone(self) -> "FibreState":
        return FibreState(
            value=self.value.clone(),
            gate=None if self.gate is None else self.gate.clone(),
            prior=None if self.prior is None else self.prior.clone(),
            write_permission=(
                None if self.write_permission is None else self.write_permission.clone()
            ),
            metadata=dict(self.metadata),
        )

    def to(self, *args: Any, **kwargs: Any) -> "FibreState":
        return FibreState(
            value=self.value.to(*args, **kwargs),
            gate=None if self.gate is None else self.gate.to(*args, **kwargs),
            prior=None if self.prior is None else self.prior.to(*args, **kwargs),
            write_permission=(
                None
                if self.write_permission is None
                else self.write_permission.to(*args, **kwargs)
            ),
            metadata=dict(self.metadata),
        )


@dataclass
class SolveResult:
    state: Tensor
    energies: list[float]
    steps: int
    converged: bool
    diagnostics: MutableMapping[str, Any] = field(default_factory=dict)

    @property
    def energy_drop(self) -> float:
        if len(self.energies) < 2:
            return 0.0
        return float(self.energies[0] - self.energies[-1])


@dataclass
class CreditPacket:
    """Credit message represented in canonical fibre coordinates."""

    message: Tensor
    responsibility: Tensor | None = None
    factor_error: Tensor | None = None
    uncertainty: Tensor | None = None
    metadata: MutableMapping[str, Any] = field(default_factory=dict)

    def detached(self) -> "CreditPacket":
        return CreditPacket(
            message=self.message.detach(),
            responsibility=(
                None if self.responsibility is None else self.responsibility.detach()
            ),
            factor_error=None if self.factor_error is None else self.factor_error.detach(),
            uncertainty=None if self.uncertainty is None else self.uncertainty.detach(),
            metadata=dict(self.metadata),
        )


@dataclass
class InterventionResult:
    fibre_id: str | int
    context_id: Any
    baseline_loss: float
    intervened_loss: float
    repair: float
    output_delta_norm: float
    metrics: MutableMapping[str, float] = field(default_factory=dict)
    metadata: MutableMapping[str, Any] = field(default_factory=dict)


@dataclass
class StepContext:
    """Mutable record passed through training, audit, and plugin callbacks."""

    batch: Any
    context_id: Any
    forward: ForwardRecord
    predicted: FibreState
    step_index: int = 0
    phase: str | None = None
    teacher_output: Tensor | None = None
    target: Any = None
    settled: FibreState | None = None
    output: Tensor | None = None
    losses: MutableMapping[str, Tensor] = field(default_factory=dict)
    metrics: MutableMapping[str, float] = field(default_factory=dict)
    cache: MutableMapping[str, Any] = field(default_factory=dict)

    def scalar_losses(self) -> dict[str, float]:
        result: dict[str, float] = {}
        for name, value in self.losses.items():
            if isinstance(value, Tensor) and value.numel() == 1:
                result[name] = float(value.detach())
        return result

    def add_metric(self, name: str, value: float | Tensor) -> None:
        if isinstance(value, Tensor):
            if value.numel() != 1:
                raise ValueError(f"Metric {name!r} must be scalar")
            value = float(value.detach())
        self.metrics[name] = float(value)
