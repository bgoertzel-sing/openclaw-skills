from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch
from torch import Tensor

from .engine import InterventionSpec


@dataclass
class RandomDirectionalPolicy:
    n_fibres: int
    fibre_dim: int
    probes_per_audit: int = 4
    scale: float = 1e-2

    def propose(self, context: Any = None, *, generator: torch.Generator | None = None) -> list[InterventionSpec]:
        specs: list[InterventionSpec] = []
        for index in range(self.probes_per_audit):
            fibre = int(torch.randint(self.n_fibres, (1,), generator=generator))
            direction: Tensor = torch.randn(self.fibre_dim, generator=generator)
            direction = self.scale * direction / direction.norm().clamp_min(1e-8)
            specs.append(
                InterventionSpec(
                    fibre=fibre,
                    mode="add",
                    value=direction,
                    name=f"random_{index}",
                    context_id=context,
                )
            )
        return specs


@dataclass
class AblationPolicy:
    n_fibres: int

    def propose(self, context: Any = None) -> list[InterventionSpec]:
        return [
            InterventionSpec(fibre=fibre, mode="ablate", context_id=context)
            for fibre in range(self.n_fibres)
        ]
