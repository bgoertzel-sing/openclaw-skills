from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Mapping

import torch
from torch import Tensor


@dataclass(frozen=True)
class InterventionSpec:
    fibre: int
    mode: str = "ablate"  # ablate | add | replace | scale
    value: Tensor | float | None = None
    name: str | None = None
    context_id: Any = None
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass
class InterventionResult:
    spec: InterventionSpec
    baseline_loss: float
    intervened_loss: float
    repair_effect: float
    output_delta_norm: float
    metrics: dict[str, float] = field(default_factory=dict)


class FibreInterventionEngine:
    """Counterfactual audits over canonical fibre state.

    The caller supplies pure ``compose_fn(state) -> output`` and
    ``loss_fn(output) -> scalar`` functions. This keeps the engine independent
    of architecture and persistent learning rule.
    """

    def __init__(self, epsilon: float = 1e-3) -> None:
        if epsilon <= 0:
            raise ValueError("epsilon must be positive")
        self.epsilon = epsilon

    def apply(self, state: Tensor, spec: InterventionSpec) -> Tensor:
        if not 0 <= spec.fibre < state.shape[-2]:
            raise IndexError("fibre index out of range")
        changed = state.clone()
        index = [slice(None)] * changed.ndim
        index[-2] = spec.fibre
        index_tuple = tuple(index)
        if spec.mode == "ablate":
            changed[index_tuple] = 0
        elif spec.mode == "add":
            if spec.value is None:
                raise ValueError("add intervention requires value")
            changed[index_tuple] = changed[index_tuple] + torch.as_tensor(
                spec.value, device=changed.device, dtype=changed.dtype
            )
        elif spec.mode == "replace":
            if spec.value is None:
                raise ValueError("replace intervention requires value")
            changed[index_tuple] = torch.as_tensor(
                spec.value, device=changed.device, dtype=changed.dtype
            )
        elif spec.mode == "scale":
            if spec.value is None:
                raise ValueError("scale intervention requires value")
            changed[index_tuple] = changed[index_tuple] * float(spec.value)
        else:
            raise ValueError(f"Unknown intervention mode: {spec.mode}")
        return changed

    @torch.no_grad()
    def evaluate(
        self,
        state: Tensor,
        specs: list[InterventionSpec],
        compose_fn: Callable[[Tensor], Tensor],
        loss_fn: Callable[[Tensor], Tensor],
        *,
        metric_fns: Mapping[str, Callable[[Tensor, Tensor], Tensor | float]] | None = None,
    ) -> list[InterventionResult]:
        baseline_output = compose_fn(state)
        baseline_loss_tensor = loss_fn(baseline_output)
        baseline_loss = float(baseline_loss_tensor.mean())
        results: list[InterventionResult] = []
        for spec in specs:
            changed = self.apply(state, spec)
            output = compose_fn(changed)
            loss = float(loss_fn(output).mean())
            metrics: dict[str, float] = {}
            for name, fn in (metric_fns or {}).items():
                value = fn(baseline_output, output)
                metrics[name] = float(value.detach()) if isinstance(value, Tensor) else float(value)
            results.append(
                InterventionResult(
                    spec=spec,
                    baseline_loss=baseline_loss,
                    intervened_loss=loss,
                    repair_effect=baseline_loss - loss,
                    output_delta_norm=float((output - baseline_output).norm()),
                    metrics=metrics,
                )
            )
        return results

    def directional_repair(
        self,
        state: Tensor,
        fibre: int,
        direction: Tensor,
        compose_fn: Callable[[Tensor], Tensor],
        loss_fn: Callable[[Tensor], Tensor],
    ) -> Tensor:
        spec = InterventionSpec(fibre=fibre, mode="add", value=self.epsilon * direction)
        changed = self.apply(state, spec)
        baseline = loss_fn(compose_fn(state))
        perturbed = loss_fn(compose_fn(changed))
        return -(perturbed - baseline) / self.epsilon

    def finite_difference_jacobian(
        self,
        state: Tensor,
        compose_fn: Callable[[Tensor], Tensor],
        *,
        fibres: list[int] | None = None,
        directions: Tensor | None = None,
    ) -> Tensor:
        """Estimate output effects shaped ``[fibre, direction, output_flat]``."""

        selected = fibres or list(range(state.shape[-2]))
        if directions is None:
            directions = torch.eye(state.shape[-1], device=state.device, dtype=state.dtype)
        baseline = compose_fn(state).detach()
        effects = []
        for fibre in selected:
            local = []
            for direction in directions:
                changed = self.apply(
                    state,
                    InterventionSpec(
                        fibre=fibre,
                        mode="add",
                        value=self.epsilon * direction,
                    ),
                )
                local.append(((compose_fn(changed) - baseline) / self.epsilon).reshape(-1))
            effects.append(torch.stack(local))
        return torch.stack(effects)
