from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import Tensor


@dataclass
class FingerprintSnapshot:
    values: Tensor
    counts: Tensor
    second_moment: Tensor


class FingerprintTracker:
    """EMA of fibre effects across named probe contexts or targets."""

    def __init__(
        self,
        n_fibres: int,
        n_probes: int,
        *,
        decay: float = 0.95,
        device=None,
        dtype=torch.float32,
    ) -> None:
        if not 0 <= decay < 1:
            raise ValueError("decay must lie in [0, 1)")
        self.decay = decay
        self.values = torch.zeros(n_fibres, n_probes, device=device, dtype=dtype)
        self.second_moment = torch.zeros_like(self.values)
        self.counts = torch.zeros(n_fibres, n_probes, device=device, dtype=dtype)

    @torch.no_grad()
    def update(self, fibre: int, probe: int, effect: Tensor | float) -> None:
        value = torch.as_tensor(effect, device=self.values.device, dtype=self.values.dtype)
        self.values[fibre, probe].mul_(self.decay).add_((1 - self.decay) * value)
        self.second_moment[fibre, probe].mul_(self.decay).add_(
            (1 - self.decay) * value.square()
        )
        self.counts[fibre, probe].add_(1)

    def variance(self) -> Tensor:
        return (self.second_moment - self.values.square()).clamp_min(0)

    def uncertainty(self, eps: float = 1e-8) -> Tensor:
        return (self.variance() / self.counts.clamp_min(1)).sqrt().clamp_min(eps)

    def normalized(self, eps: float = 1e-8) -> Tensor:
        norm = self.values.norm(dim=-1, keepdim=True).clamp_min(eps)
        return self.values / norm

    def similarity(self, eps: float = 1e-8) -> Tensor:
        normalized = self.normalized(eps)
        return normalized @ normalized.T

    def conditioning(self) -> Tensor:
        singular = torch.linalg.svdvals(self.values.T)
        return singular.min() if singular.numel() else self.values.new_zeros(())

    def snapshot(self) -> FingerprintSnapshot:
        return FingerprintSnapshot(
            self.values.clone(), self.counts.clone(), self.second_moment.clone()
        )

    def state_dict(self) -> dict[str, Tensor | float]:
        return {
            "decay": self.decay,
            "values": self.values,
            "counts": self.counts,
            "second_moment": self.second_moment,
        }

    def load_state_dict(self, state: dict[str, Tensor | float]) -> None:
        self.decay = float(state.get("decay", self.decay))
        self.values.copy_(state["values"])
        self.counts.copy_(state["counts"])
        self.second_moment.copy_(state.get("second_moment", torch.zeros_like(self.values)))
