from __future__ import annotations

import torch
from torch import Tensor, nn


class LinearErrorTransport(nn.Module):
    """Transport factor-indexed errors into canonical fibre coordinates.

    Input errors have shape ``[..., n_factors, error_dim]`` and responsibilities
    have shape ``[..., n_factors, n_fibres]``. The output has shape
    ``[..., n_fibres, fibre_dim]``.
    """

    def __init__(
        self,
        n_factors: int,
        n_fibres: int,
        error_dim: int,
        fibre_dim: int,
        *,
        identity_init: bool = False,
    ) -> None:
        super().__init__()
        self.n_factors = n_factors
        self.n_fibres = n_fibres
        self.error_dim = error_dim
        self.fibre_dim = fibre_dim
        self.weight = nn.Parameter(
            torch.empty(n_factors, n_fibres, error_dim, fibre_dim)
        )
        nn.init.normal_(self.weight, std=error_dim**-0.5)
        if identity_init and error_dim == fibre_dim:
            with torch.no_grad():
                self.weight.zero_()
                for factor in range(min(n_factors, n_fibres)):
                    self.weight[factor, factor].copy_(torch.eye(error_dim))

    def forward(self, factor_error: Tensor, responsibility: Tensor) -> Tensor:
        if factor_error.shape[-2:] != (self.n_factors, self.error_dim):
            raise ValueError("Unexpected factor_error shape")
        if responsibility.shape[-2:] != (self.n_factors, self.n_fibres):
            raise ValueError("Unexpected responsibility shape")
        local = torch.einsum("...je,jqer->...jqr", factor_error, self.weight)
        return (local * responsibility.unsqueeze(-1)).sum(dim=-3)

    @torch.no_grad()
    def orthogonalize(self) -> None:
        if self.error_dim != self.fibre_dim:
            return
        flat = self.weight.reshape(-1, self.error_dim, self.fibre_dim)
        q, _ = torch.linalg.qr(flat)
        self.weight.copy_(q.reshape_as(self.weight))


class SiteTransportBank(nn.Module):
    """Translate canonical fibre states into site-local fibre coordinates."""

    def __init__(
        self,
        site_names: list[str] | tuple[str, ...],
        n_fibres: int,
        canonical_dim: int,
        local_dim: int | None = None,
    ) -> None:
        super().__init__()
        self.site_names = tuple(site_names)
        self.n_fibres = n_fibres
        self.canonical_dim = canonical_dim
        self.local_dim = local_dim or canonical_dim
        self.weight = nn.ParameterDict(
            {
                name: nn.Parameter(
                    torch.eye(self.canonical_dim, self.local_dim)
                    .unsqueeze(0)
                    .repeat(n_fibres, 1, 1)
                )
                for name in self.site_names
            }
        )

    def forward(self, site_name: str, state: Tensor) -> Tensor:
        if site_name not in self.weight:
            raise KeyError(f"Unknown transport site {site_name!r}")
        if state.shape[-2:] != (self.n_fibres, self.canonical_dim):
            raise ValueError("Unexpected canonical state shape")
        return torch.einsum("...qr,qrl->...ql", state, self.weight[site_name])


@torch.no_grad()
def orthogonal_procrustes(source: Tensor, target: Tensor) -> Tensor:
    """Return the orthogonal map minimizing ``||source @ T - target||``."""

    if source.ndim != 2 or target.ndim != 2 or source.shape[0] != target.shape[0]:
        raise ValueError("source and target must be [samples, dim] with equal samples")
    cross = source.transpose(0, 1) @ target
    u, _, vh = torch.linalg.svd(cross, full_matrices=False)
    return u @ vh


def metric_compatibility_loss(
    transport: Tensor,
    source_metric: Tensor,
    target_metric: Tensor,
) -> Tensor:
    pulled = transport.transpose(-1, -2) @ target_metric @ transport
    return (pulled - source_metric).square().mean()


def path_consistency_loss(direct: Tensor, leg1: Tensor, leg2: Tensor) -> Tensor:
    composed = leg1 @ leg2
    return (direct - composed).square().mean()


def transport_condition_number(transport: Tensor, eps: float = 1e-8) -> Tensor:
    singular_values = torch.linalg.svdvals(transport)
    return singular_values[..., 0] / singular_values[..., -1].clamp_min(eps)
