"""Causal credit sources, routers, error factorization, novelty, and transport."""

from causal_fibres.core.types import CreditPacket

from .factorization import FactorErrorPacket, KnownFactorErrorEncoder, LinearFactorErrorEncoder
from .novelty import SubspaceNoveltyFilter
from .router import InfluenceRouter, KnownSupportRouter, SoftTopKRouter, sparsemax
from .sources import AutogradOracleCredit, CausalHighwayCredit, DenseLinearCredit, OracleBlend
from .transport import (
    LinearErrorTransport,
    SiteTransportBank,
    metric_compatibility_loss,
    orthogonal_procrustes,
    path_consistency_loss,
    transport_condition_number,
)

__all__ = [
    "CreditPacket",
    "FactorErrorPacket",
    "KnownFactorErrorEncoder",
    "LinearFactorErrorEncoder",
    "SubspaceNoveltyFilter",
    "InfluenceRouter",
    "KnownSupportRouter",
    "SoftTopKRouter",
    "sparsemax",
    "AutogradOracleCredit",
    "CausalHighwayCredit",
    "DenseLinearCredit",
    "OracleBlend",
    "LinearErrorTransport",
    "SiteTransportBank",
    "metric_compatibility_loss",
    "orthogonal_procrustes",
    "path_consistency_loss",
    "transport_condition_number",
]
