from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import Tensor, nn

from causal_fibres.core.types import CreditPacket

from .novelty import SubspaceNoveltyFilter
from .transport import LinearErrorTransport


class AutogradOracleCredit:
    """Exact negative gradient with respect to a residual state."""

    @staticmethod
    def from_loss(loss: Tensor, state: Tensor, *, create_graph: bool = False) -> CreditPacket:
        gradient = torch.autograd.grad(
            loss,
            state,
            retain_graph=True,
            create_graph=create_graph,
            allow_unused=False,
        )[0]
        return CreditPacket(message=-gradient, metadata={"source": "autograd_oracle"})


class DenseLinearCredit(nn.Module):
    def __init__(self, error_dim: int, n_fibres: int, fibre_dim: int) -> None:
        super().__init__()
        self.n_fibres = n_fibres
        self.fibre_dim = fibre_dim
        self.linear = nn.Linear(error_dim, n_fibres * fibre_dim, bias=False)

    def forward(self, error: Tensor) -> CreditPacket:
        message = self.linear(error).reshape(
            *error.shape[:-1], self.n_fibres, self.fibre_dim
        )
        return CreditPacket(message=message, metadata={"source": "dense_linear"})


class CausalHighwayCredit(nn.Module):
    """Factorized, responsibility-routed error credit."""

    def __init__(
        self,
        transport: LinearErrorTransport,
        novelty_filter: SubspaceNoveltyFilter | None = None,
    ) -> None:
        super().__init__()
        self.transport = transport
        self.novelty_filter = novelty_filter

    def forward(
        self,
        factor_error: Tensor,
        responsibility: Tensor,
        novelty_mask: Tensor | None = None,
    ) -> CreditPacket:
        if self.novelty_filter is not None:
            factor_error = self.novelty_filter(factor_error)
        if novelty_mask is not None:
            factor_error = factor_error * novelty_mask.unsqueeze(-1)
        message = self.transport(factor_error, responsibility)
        return CreditPacket(
            message=message,
            responsibility=responsibility,
            factor_error=factor_error,
            metadata={"source": "causal_highway"},
        )


@dataclass
class OracleBlend:
    alpha: float = 1.0
    cosine_threshold: float = 0.8
    off_support_threshold: float = 0.1
    energy_ratio_threshold: float = 0.9

    def __post_init__(self) -> None:
        if not 0 <= self.alpha <= 1:
            raise ValueError("alpha must lie in [0, 1]")

    def combine(self, oracle: Tensor, learned: Tensor) -> Tensor:
        if oracle.shape != learned.shape:
            raise ValueError("oracle and learned credit must have identical shape")
        return self.alpha * oracle + (1.0 - self.alpha) * learned

    def update_from_audit(
        self,
        *,
        cosine: float,
        off_support: float,
        energy_ratio: float,
        decrement: float = 0.05,
        increment: float = 0.1,
    ) -> float:
        passes = (
            cosine >= self.cosine_threshold
            and off_support <= self.off_support_threshold
            and energy_ratio >= self.energy_ratio_threshold
        )
        if passes:
            self.alpha = max(0.0, self.alpha - decrement)
        else:
            self.alpha = min(1.0, self.alpha + increment)
        return self.alpha

    def state_dict(self) -> dict[str, float]:
        return {
            "alpha": self.alpha,
            "cosine_threshold": self.cosine_threshold,
            "off_support_threshold": self.off_support_threshold,
            "energy_ratio_threshold": self.energy_ratio_threshold,
        }

    def load_state_dict(self, state: dict[str, float]) -> None:
        self.alpha = float(state["alpha"])
        self.cosine_threshold = float(state.get("cosine_threshold", self.cosine_threshold))
        self.off_support_threshold = float(
            state.get("off_support_threshold", self.off_support_threshold)
        )
        self.energy_ratio_threshold = float(
            state.get("energy_ratio_threshold", self.energy_ratio_threshold)
        )
