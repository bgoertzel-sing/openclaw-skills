from __future__ import annotations

import torch
from torch import Tensor, nn


class SubspaceNoveltyFilter(nn.Module):
    """Project factor errors away from an assimilated shared subspace.

    The basis is stored as ``[factor, error_dim, max_rank]`` with per-factor
    active ranks. Updating the basis is explicit and should normally happen on
    audited, persistent innovations rather than every minibatch.
    """

    def __init__(self, n_factors: int, error_dim: int, max_rank: int = 8) -> None:
        super().__init__()
        self.n_factors = n_factors
        self.error_dim = error_dim
        self.max_rank = max_rank
        self.register_buffer("basis", torch.zeros(n_factors, error_dim, max_rank))
        self.register_buffer("rank", torch.zeros(n_factors, dtype=torch.long))

    def forward(self, error: Tensor) -> Tensor:
        if error.shape[-2:] != (self.n_factors, self.error_dim):
            raise ValueError("Unexpected factor error shape")
        result = error.clone()
        for factor in range(self.n_factors):
            rank = int(self.rank[factor])
            if rank == 0:
                continue
            basis = self.basis[factor, :, :rank].to(error)
            local = error[..., factor, :]
            projection = (local @ basis) @ basis.transpose(0, 1)
            result[..., factor, :] = local - projection
        return result

    @torch.no_grad()
    def add_direction(self, factor: int, direction: Tensor, eps: float = 1e-8) -> bool:
        if not 0 <= factor < self.n_factors:
            raise IndexError("factor index out of range")
        rank = int(self.rank[factor])
        if rank >= self.max_rank:
            return False
        vector = direction.detach().to(self.basis).reshape(-1)
        if vector.numel() != self.error_dim:
            raise ValueError("direction has wrong dimension")
        if rank:
            existing = self.basis[factor, :, :rank]
            vector = vector - existing @ (existing.transpose(0, 1) @ vector)
        norm = vector.norm()
        if float(norm) <= eps:
            return False
        self.basis[factor, :, rank] = vector / norm
        self.rank[factor] += 1
        return True

    @torch.no_grad()
    def clear(self, factor: int | None = None) -> None:
        if factor is None:
            self.basis.zero_()
            self.rank.zero_()
        else:
            self.basis[factor].zero_()
            self.rank[factor] = 0
