from __future__ import annotations

from typing import Any, Mapping

import torch
from torch import Tensor, nn


def sparsemax(logits: Tensor, dim: int = -1) -> Tensor:
    """Sparsemax transformation from Martins and Astudillo (2016)."""

    shifted = logits - logits.max(dim=dim, keepdim=True).values
    sorted_logits, _ = torch.sort(shifted, descending=True, dim=dim)
    cumulative = sorted_logits.cumsum(dim)
    count = logits.shape[dim]
    range_values = torch.arange(1, count + 1, device=logits.device, dtype=logits.dtype)
    view = [1] * logits.ndim
    view[dim] = count
    range_values = range_values.view(view)
    support = 1 + range_values * sorted_logits > cumulative
    support_size = support.sum(dim=dim, keepdim=True).clamp_min(1)
    tau = (cumulative.gather(dim, support_size - 1) - 1) / support_size.to(logits.dtype)
    return torch.clamp(shifted - tau, min=0)


class KnownSupportRouter(nn.Module):
    """Use externally supplied support masks; useful as an upper-bound control."""

    def __init__(self, normalize: bool = False) -> None:
        super().__init__()
        self.normalize = normalize

    def forward(
        self,
        features: Tensor,
        *,
        context: Any = None,
        known_support: Tensor | None = None,
    ) -> Tensor:
        del context
        if known_support is None:
            raise ValueError("KnownSupportRouter requires known_support")
        gate = known_support.to(device=features.device, dtype=features.dtype)
        target_shape = features.shape[:-1]
        if gate.shape != target_shape:
            gate = torch.broadcast_to(gate, target_shape)
        if self.normalize:
            gate = gate / gate.sum(dim=-1, keepdim=True).clamp_min(1e-8)
        return gate


class SoftTopKRouter(nn.Module):
    """Soft, optionally sparse and budgeted router over fibres.

    ``normalizer='softmax'`` keeps dense support before optional top-k masking.
    ``normalizer='sparsemax'`` can produce exact zeros while remaining soft.
    Straight-through hardening is available for late-stage experiments but is
    intentionally disabled by default.
    """

    def __init__(
        self,
        n_fibres: int,
        fibre_dim: int,
        *,
        top_k: int | None = None,
        temperature: float = 1.0,
        min_gate: float = 0.0,
        normalizer: str = "softmax",
        straight_through: bool = False,
    ) -> None:
        super().__init__()
        if n_fibres <= 0 or fibre_dim <= 0:
            raise ValueError("n_fibres and fibre_dim must be positive")
        if top_k is not None and not 0 < top_k <= n_fibres:
            raise ValueError("top_k must lie in [1, n_fibres] or be None")
        if normalizer not in {"softmax", "sparsemax"}:
            raise ValueError("normalizer must be 'softmax' or 'sparsemax'")
        self.n_fibres = n_fibres
        self.fibre_dim = fibre_dim
        self.top_k = top_k
        self.temperature = temperature
        self.min_gate = min_gate
        self.normalizer = normalizer
        self.straight_through = straight_through
        self.score_weight = nn.Parameter(torch.empty(n_fibres, fibre_dim))
        self.score_bias = nn.Parameter(torch.zeros(n_fibres))
        nn.init.normal_(self.score_weight, std=fibre_dim**-0.5)

    def scores(self, features: Tensor, context: Any = None) -> Tensor:
        if features.shape[-2:] != (self.n_fibres, self.fibre_dim):
            raise ValueError("Unexpected feature shape for router")
        scores = (features * self.score_weight).sum(dim=-1) + self.score_bias
        if isinstance(context, Mapping) and "router_bias" in context:
            scores = scores + context["router_bias"].to(scores)
        return scores

    def forward(
        self,
        features: Tensor,
        *,
        context: Any = None,
        known_support: Tensor | None = None,
    ) -> Tensor:
        scores = self.scores(features, context)
        support = None
        if known_support is not None:
            support = torch.broadcast_to(
                known_support.to(device=scores.device, dtype=torch.bool), scores.shape
            )
            if (~support).all(dim=-1).any():
                raise ValueError("known_support contains a sample with no active fibre")
            scores = scores.masked_fill(~support, float("-inf"))
        if self.top_k is not None and self.top_k < self.n_fibres:
            _, indices = torch.topk(scores, self.top_k, dim=-1)
            top_mask = torch.zeros_like(scores, dtype=torch.bool).scatter_(-1, indices, True)
            support = top_mask if support is None else support & top_mask
            scores = scores.masked_fill(~support, float("-inf"))
        scaled = scores / max(self.temperature, 1e-6)
        gates = torch.softmax(scaled, dim=-1) if self.normalizer == "softmax" else sparsemax(scaled)
        if self.min_gate > 0:
            gates = self.min_gate + (1.0 - self.min_gate * self.n_fibres) * gates
        if self.straight_through:
            hard_indices = gates.argmax(dim=-1, keepdim=True)
            hard = torch.zeros_like(gates).scatter_(-1, hard_indices, 1.0)
            gates = hard + gates - gates.detach()
        return gates

    def set_temperature(self, value: float) -> None:
        if value <= 0:
            raise ValueError("temperature must be positive")
        self.temperature = value

    @staticmethod
    def entropy(gates: Tensor, eps: float = 1e-12) -> Tensor:
        return -(gates * gates.clamp_min(eps).log()).sum(dim=-1).mean()

    @staticmethod
    def active_count(gates: Tensor, threshold: float = 1e-3) -> Tensor:
        return (gates > threshold).to(gates).sum(dim=-1).mean()


class InfluenceRouter(nn.Module):
    """Convert estimated repair influence and uncertainty into responsibility."""

    def __init__(
        self,
        temperature: float = 1.0,
        top_k: int | None = None,
        *,
        normalizer: str = "softmax",
    ) -> None:
        super().__init__()
        self.temperature = temperature
        self.top_k = top_k
        self.normalizer = normalizer

    def forward(
        self,
        influence: Tensor,
        uncertainty: Tensor | None = None,
        write_cost: Tensor | None = None,
    ) -> Tensor:
        score = influence
        if uncertainty is not None:
            score = score - uncertainty.to(score)
        if write_cost is not None:
            score = score - write_cost.to(score)
        if self.top_k is not None and self.top_k < score.shape[-1]:
            _, indices = torch.topk(score, self.top_k, dim=-1)
            mask = torch.zeros_like(score, dtype=torch.bool).scatter_(-1, indices, True)
            score = score.masked_fill(~mask, float("-inf"))
        scaled = score / max(self.temperature, 1e-6)
        return torch.softmax(scaled, dim=-1) if self.normalizer == "softmax" else sparsemax(scaled)
