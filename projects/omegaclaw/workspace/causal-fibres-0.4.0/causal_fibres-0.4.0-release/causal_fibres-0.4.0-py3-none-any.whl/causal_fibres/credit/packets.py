"""Backward-compatible credit packet import."""

from causal_fibres.core.types import CreditPacket

__all__ = ["CreditPacket"]
