from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, MutableMapping

from torch import Tensor, nn


@dataclass
class FactorErrorPacket:
    error: Tensor
    reconstruction: Tensor | None = None
    labels: Tensor | None = None
    metadata: MutableMapping[str, Any] = field(default_factory=dict)


class KnownFactorErrorEncoder(nn.Module):
    """Pass through externally supplied ``[..., factor, error_dim]`` errors."""

    def forward(self, error: Tensor) -> FactorErrorPacket:
        if error.ndim < 2:
            raise ValueError("factor error must end in [factor, error_dim]")
        return FactorErrorPacket(error=error, reconstruction=error)


class LinearFactorErrorEncoder(nn.Module):
    """Learn a low-dimensional factorization of a dense error vector."""

    def __init__(self, input_dim: int, n_factors: int, error_dim: int) -> None:
        super().__init__()
        self.input_dim = input_dim
        self.n_factors = n_factors
        self.error_dim = error_dim
        self.encoder = nn.Linear(input_dim, n_factors * error_dim)
        self.decoder = nn.Linear(n_factors * error_dim, input_dim, bias=False)

    def forward(self, error: Tensor) -> FactorErrorPacket:
        factors = self.encoder(error).reshape(
            *error.shape[:-1], self.n_factors, self.error_dim
        )
        reconstruction = self.decoder(factors.reshape(*error.shape[:-1], -1))
        return FactorErrorPacket(error=factors, reconstruction=reconstruction)

    def reconstruction_loss(self, packet: FactorErrorPacket, target: Tensor) -> Tensor:
        if packet.reconstruction is None:
            raise ValueError("packet has no reconstruction")
        return (packet.reconstruction - target).square().mean()
