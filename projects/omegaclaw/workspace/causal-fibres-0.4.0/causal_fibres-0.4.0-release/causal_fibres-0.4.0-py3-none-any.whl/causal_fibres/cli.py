from __future__ import annotations

import argparse
import importlib.util
import json
import platform
import sys
from pathlib import Path
from typing import Any

import numpy as np
import torch

from . import __version__
from .core import CFEConfig, CheckpointManager
from .diagnostics import run_smoke_test


def _doctor() -> dict[str, Any]:
    optional = {
        name: bool(importlib.util.find_spec(name))
        for name in ("yaml", "transformers", "accelerate", "matplotlib", "pandas")
    }
    return {
        "causal_fibres": __version__,
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "torch": torch.__version__,
        "numpy": np.__version__,
        "cuda_available": torch.cuda.is_available(),
        "cuda_device_count": torch.cuda.device_count() if torch.cuda.is_available() else 0,
        "optional_dependencies": optional,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="causal-fibres")
    parser.add_argument("--version", action="version", version=__version__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("doctor", help="Print environment and optional-dependency information")
    subparsers.add_parser(
        "list-representations",
        help="List competing structural representation families and required baselines",
    )

    validate = subparsers.add_parser("validate-config", help="Validate a YAML or JSON config")
    validate.add_argument("path")

    defaults = subparsers.add_parser("show-default-config", help="Print or write the default config")
    defaults.add_argument("--output")
    defaults.add_argument("--format", choices=("yaml", "json"), default="yaml")

    inspect = subparsers.add_parser("inspect-checkpoint", help="Inspect checkpoint metadata")
    inspect.add_argument("path")

    smoke = subparsers.add_parser("smoke-test", help="Run a tiny end-to-end CPU test")
    smoke.add_argument("--seed", type=int, default=0)
    smoke.add_argument("--steps", type=int, default=12)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "doctor":
        print(json.dumps(_doctor(), indent=2, sort_keys=True))
        return 0
    if args.command == "list-representations":
        print(json.dumps({
            "conservative_default": "dense",
            "representation_candidates": [
                "dense",
                "sae",
                "grouped_sae",
                "orthogonal",
                "contextual_bundle",
            ],
            "mandatory_baselines": ["dense_adapter", "lora", "sae_plus_steering"],
            "note": "Orthogonal causal fibres are one hypothesis, not a package assumption.",
        }, indent=2, sort_keys=True))
        return 0
    if args.command == "validate-config":
        path = Path(args.path)
        config = CFEConfig.from_json(path) if path.suffix.lower() == ".json" else CFEConfig.from_yaml(path)
        print(json.dumps(config.to_dict(), indent=2, sort_keys=True))
        return 0
    if args.command == "show-default-config":
        config = CFEConfig().validate()
        if args.output:
            if args.format == "json":
                config.to_json(args.output)
            else:
                config.to_yaml(args.output)
            print(args.output)
        elif args.format == "json":
            print(json.dumps(config.to_dict(), indent=2, sort_keys=True))
        else:
            try:
                import yaml
            except ImportError:
                print(json.dumps(config.to_dict(), indent=2, sort_keys=False))
            else:
                print(yaml.safe_dump(config.to_dict(), sort_keys=False), end="")
        return 0
    if args.command == "inspect-checkpoint":
        print(json.dumps(CheckpointManager.inspect(args.path), indent=2, sort_keys=True, default=str))
        return 0
    if args.command == "smoke-test":
        result = run_smoke_test(seed=args.seed, steps=args.steps)
        print(json.dumps(result.__dict__ | {"passed": result.passed}, indent=2, sort_keys=True))
        return 0 if result.passed else 1
    raise AssertionError("unreachable")


if __name__ == "__main__":
    raise SystemExit(main())
