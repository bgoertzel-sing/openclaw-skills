from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

import torch
from torch import Tensor


def resolve_device(value: str | torch.device = "auto") -> torch.device:
    if isinstance(value, torch.device):
        return value
    if value == "auto":
        if torch.cuda.is_available():
            return torch.device("cuda")
        if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            return torch.device("mps")
        return torch.device("cpu")
    return torch.device(value)


def resolve_dtype(name: str) -> torch.dtype:
    mapping = {
        "float16": torch.float16,
        "bfloat16": torch.bfloat16,
        "float32": torch.float32,
        "float64": torch.float64,
    }
    if name not in mapping:
        raise ValueError(f"Unknown dtype: {name}")
    return mapping[name]


def move_to_device(value: Any, device: torch.device | str, *, non_blocking: bool = False) -> Any:
    if isinstance(value, Tensor):
        return value.to(device, non_blocking=non_blocking)
    if isinstance(value, Mapping):
        return type(value)(
            (key, move_to_device(item, device, non_blocking=non_blocking))
            for key, item in value.items()
        )
    if isinstance(value, tuple):
        return tuple(move_to_device(item, device, non_blocking=non_blocking) for item in value)
    if isinstance(value, list):
        return [move_to_device(item, device, non_blocking=non_blocking) for item in value]
    return value
