"""General device and tensor utilities."""

from .device import move_to_device, resolve_device, resolve_dtype
from .tensors import (
    FlattenSpec,
    effective_rank,
    flatten_samples,
    flatten_state,
    participation_ratio,
    safe_cosine,
    unflatten_samples,
    unflatten_state,
)

__all__ = [
    "move_to_device",
    "resolve_device",
    "resolve_dtype",
    "FlattenSpec",
    "effective_rank",
    "flatten_samples",
    "flatten_state",
    "participation_ratio",
    "safe_cosine",
    "unflatten_samples",
    "unflatten_state",
]
