from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import Tensor


@dataclass(frozen=True)
class FlattenSpec:
    leading_shape: torch.Size
    feature_width: int


def flatten_samples(tensor: Tensor) -> tuple[Tensor, FlattenSpec]:
    if tensor.ndim < 2:
        raise ValueError("Expected at least one sample axis and one feature axis")
    spec = FlattenSpec(tensor.shape[:-1], tensor.shape[-1])
    return tensor.reshape(-1, tensor.shape[-1]), spec


def unflatten_samples(tensor: Tensor, spec: FlattenSpec) -> Tensor:
    if tensor.shape[-1] != spec.feature_width:
        raise ValueError(
            f"Feature width mismatch: {tensor.shape[-1]} != {spec.feature_width}"
        )
    return tensor.reshape(*spec.leading_shape, spec.feature_width)


def flatten_state(state: Tensor) -> tuple[Tensor, torch.Size]:
    shape = state.shape
    return state.reshape(-1), shape


def unflatten_state(vector: Tensor, shape: torch.Size) -> Tensor:
    return vector.reshape(shape)


def safe_cosine(a: Tensor, b: Tensor, eps: float = 1e-12) -> Tensor:
    av = a.reshape(-1)
    bv = b.reshape(-1)
    return torch.dot(av, bv) / (av.norm() * bv.norm() + eps)


def effective_rank(tensor: Tensor, eps: float = 1e-12) -> Tensor:
    """Entropy effective rank of samples-by-features data."""

    if tensor.ndim != 2:
        tensor = tensor.reshape(-1, tensor.shape[-1])
    centered = tensor - tensor.mean(dim=0, keepdim=True)
    singular = torch.linalg.svdvals(centered)
    probabilities = singular.square()
    probabilities = probabilities / probabilities.sum().clamp_min(eps)
    entropy = -(probabilities * probabilities.clamp_min(eps).log()).sum()
    return entropy.exp()


def participation_ratio(tensor: Tensor, eps: float = 1e-12) -> Tensor:
    if tensor.ndim != 2:
        tensor = tensor.reshape(-1, tensor.shape[-1])
    centered = tensor - tensor.mean(dim=0, keepdim=True)
    eigenvalues = torch.linalg.svdvals(centered).square()
    return eigenvalues.sum().square() / eigenvalues.square().sum().clamp_min(eps)
