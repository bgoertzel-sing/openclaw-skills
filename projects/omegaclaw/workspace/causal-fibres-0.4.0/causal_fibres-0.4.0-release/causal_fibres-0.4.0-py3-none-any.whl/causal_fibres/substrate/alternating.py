from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass, field
from typing import Any

import torch
from torch import Tensor, nn


@dataclass
class AlternatingStepResult:
    residual_losses: list[float] = field(default_factory=list)
    substrate_losses: list[float] = field(default_factory=list)
    metrics: dict[str, float] = field(default_factory=dict)


class AlternatingResidualBaseTrainer:
    """Alternate residual fitting with controlled substrate co-adaptation.

    Callers provide scalar loss closures because architecture-specific forward
    passes vary widely.  The trainer handles gradient ownership, clipping, and
    optimizer steps without conflating residual and substrate parameters.
    """

    def __init__(
        self,
        *,
        residual_parameters: Iterable[nn.Parameter],
        substrate_parameters: Iterable[nn.Parameter],
        residual_optimizer: torch.optim.Optimizer,
        substrate_optimizer: torch.optim.Optimizer,
        residual_steps: int = 1,
        substrate_steps: int = 1,
        gradient_clip: float | None = 1.0,
    ) -> None:
        if residual_steps < 0 or substrate_steps < 0 or residual_steps + substrate_steps == 0:
            raise ValueError("At least one alternating step is required")
        self.residual_parameters = list(residual_parameters)
        self.substrate_parameters = list(substrate_parameters)
        self.residual_optimizer = residual_optimizer
        self.substrate_optimizer = substrate_optimizer
        self.residual_steps = residual_steps
        self.substrate_steps = substrate_steps
        self.gradient_clip = gradient_clip

    @staticmethod
    def _set_requires(parameters: list[nn.Parameter], value: bool) -> None:
        for parameter in parameters:
            parameter.requires_grad_(value)

    def _run_phase(
        self,
        *,
        active_parameters: list[nn.Parameter],
        frozen_parameters: list[nn.Parameter],
        optimizer: torch.optim.Optimizer,
        loss_closure: Callable[[], Tensor | tuple[Tensor, Mapping[str, float]]],
    ) -> tuple[float, dict[str, float]]:
        self._set_requires(active_parameters, True)
        self._set_requires(frozen_parameters, False)
        optimizer.zero_grad(set_to_none=True)
        output = loss_closure()
        if isinstance(output, tuple):
            loss, metrics = output
        else:
            loss, metrics = output, {}
        if loss.numel() != 1:
            raise ValueError("loss_closure must return a scalar Tensor")
        loss.backward()
        if self.gradient_clip is not None:
            nn.utils.clip_grad_norm_(active_parameters, self.gradient_clip)
        optimizer.step()
        return float(loss.detach()), {key: float(value) for key, value in metrics.items()}

    def step(
        self,
        residual_loss_closure: Callable[[], Tensor | tuple[Tensor, Mapping[str, float]]],
        substrate_loss_closure: Callable[[], Tensor | tuple[Tensor, Mapping[str, float]]],
    ) -> AlternatingStepResult:
        result = AlternatingStepResult()
        try:
            for _ in range(self.residual_steps):
                loss, metrics = self._run_phase(
                    active_parameters=self.residual_parameters,
                    frozen_parameters=self.substrate_parameters,
                    optimizer=self.residual_optimizer,
                    loss_closure=residual_loss_closure,
                )
                result.residual_losses.append(loss)
                result.metrics.update({f"residual/{key}": value for key, value in metrics.items()})
            for _ in range(self.substrate_steps):
                loss, metrics = self._run_phase(
                    active_parameters=self.substrate_parameters,
                    frozen_parameters=self.residual_parameters,
                    optimizer=self.substrate_optimizer,
                    loss_closure=substrate_loss_closure,
                )
                result.substrate_losses.append(loss)
                result.metrics.update({f"substrate/{key}": value for key, value in metrics.items()})
        finally:
            self._set_requires(self.residual_parameters, True)
            self._set_requires(self.substrate_parameters, True)
        return result
