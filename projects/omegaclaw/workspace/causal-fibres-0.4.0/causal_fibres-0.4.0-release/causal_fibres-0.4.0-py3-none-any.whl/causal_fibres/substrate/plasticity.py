from __future__ import annotations

from collections.abc import Callable, Iterable
from dataclasses import dataclass

from torch import nn

from causal_fibres.baselines import inject_lora, iter_lora_modules, lora_parameters, merge_lora_


@dataclass
class LowRankPlasticityReport:
    replaced_modules: list[str]
    trainable_parameters: int
    total_parameters: int

    @property
    def trainable_fraction(self) -> float:
        return self.trainable_parameters / max(self.total_parameters, 1)


class LowRankBasePlasticity:
    """Controlled low-rank substrate co-adaptation.

    The base is frozen first, then selected linear modules receive LoRA updates.
    This is intended for the phase after frozen-interface observability has been
    established, not as an automatic default.
    """

    def __init__(
        self,
        model: nn.Module,
        *,
        rank: int,
        module_names: Iterable[str] | None = None,
        predicate: Callable[[str, nn.Linear], bool] | None = None,
        alpha: float | None = None,
        dropout: float = 0.0,
    ) -> None:
        self.model = model
        for parameter in model.parameters():
            parameter.requires_grad_(False)
        self.replaced_modules = inject_lora(
            model,
            rank=rank,
            module_names=module_names,
            predicate=predicate,
            alpha=alpha,
            dropout=dropout,
            freeze_base=True,
        )
        if not self.replaced_modules:
            raise ValueError("No modules were selected for low-rank plasticity")

    def parameters(self):
        return lora_parameters(self.model)

    def report(self) -> LowRankPlasticityReport:
        trainable = sum(parameter.numel() for parameter in self.parameters())
        total = sum(parameter.numel() for parameter in self.model.parameters())
        return LowRankPlasticityReport(
            replaced_modules=list(self.replaced_modules),
            trainable_parameters=trainable,
            total_parameters=total,
        )

    def delta_norms(self) -> dict[str, float]:
        return {
            name: float(module.delta_weight.detach().norm())
            for name, module in iter_lora_modules(self.model)
        }

    def merge_(self) -> list[str]:
        return merge_lora_(self.model)
