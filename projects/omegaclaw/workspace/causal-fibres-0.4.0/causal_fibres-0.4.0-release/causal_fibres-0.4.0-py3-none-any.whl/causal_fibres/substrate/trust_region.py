from __future__ import annotations

import torch
from torch import Tensor, nn

from causal_fibres.training.losses import symmetric_kl


class AnchorTrustRegion(nn.Module):
    """Penalty that keeps controlled substrate updates near an anchor model."""

    def __init__(
        self,
        *,
        kind: str = "symmetric_kl",
        radius: float = 0.0,
        weight: float = 1.0,
        temperature: float = 1.0,
        squared_hinge: bool = True,
    ) -> None:
        super().__init__()
        if kind not in {"symmetric_kl", "mse", "cosine"}:
            raise ValueError("kind must be symmetric_kl, mse, or cosine")
        if radius < 0 or weight < 0 or temperature <= 0:
            raise ValueError("invalid trust-region hyperparameters")
        self.kind = kind
        self.radius = float(radius)
        self.weight = float(weight)
        self.temperature = float(temperature)
        self.squared_hinge = squared_hinge

    def distance(self, current: Tensor, anchor: Tensor, *, mask: Tensor | None = None) -> Tensor:
        if current.shape != anchor.shape:
            raise ValueError("current and anchor outputs must have the same shape")
        if self.kind == "symmetric_kl":
            return symmetric_kl(current, anchor, temperature=self.temperature, mask=mask)
        if self.kind == "mse":
            difference = (current - anchor) ** 2
            if mask is None:
                return difference.mean()
            expanded = mask.to(difference)
            while expanded.ndim < difference.ndim:
                expanded = expanded.unsqueeze(-1)
            return (difference * expanded).sum() / expanded.expand_as(difference).sum().clamp_min(1e-12)
        current_flat = current.reshape(-1, current.shape[-1])
        anchor_flat = anchor.reshape(-1, anchor.shape[-1])
        similarity = torch.nn.functional.cosine_similarity(current_flat, anchor_flat, dim=-1)
        return (1.0 - similarity).mean()

    def forward(self, current: Tensor, anchor: Tensor, *, mask: Tensor | None = None) -> Tensor:
        distance = self.distance(current, anchor, mask=mask)
        excess = torch.relu(distance - self.radius)
        penalty = excess.square() if self.squared_hinge else excess
        return self.weight * penalty
