from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Callable, Mapping

import torch
from torch import Tensor, nn

from causal_fibres.training.losses import temperature_kl


class _LowRankResidual(nn.Module):
    def __init__(self, input_dim: int, output_dim: int, rank: int) -> None:
        super().__init__()
        self.read = nn.Linear(input_dim, rank, bias=False)
        self.write = nn.Linear(rank, output_dim, bias=False)
        nn.init.kaiming_uniform_(self.read.weight, a=5**0.5)
        nn.init.zeros_(self.write.weight)

    def forward(self, inputs: Tensor) -> Tensor:
        return self.write(self.read(inputs))


class _MLPResidual(nn.Module):
    def __init__(self, input_dim: int, output_dim: int, hidden_dim: int) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.LayerNorm(input_dim),
            nn.Linear(input_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, output_dim),
        )

    def forward(self, inputs: Tensor) -> Tensor:
        return self.network(inputs)


@dataclass
class ObservabilityResult:
    name: str
    base_loss: float
    train_loss: float
    validation_loss: float
    teacher_gap_closure: float
    parameter_count: int
    steps: int
    history: list[float] = field(default_factory=list)
    metadata: dict[str, object] = field(default_factory=dict)

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


class FrozenReadProbe:
    """Mandatory falsifier for a proposed frozen read interface.

    The probe learns an ordinary feed-forward residual from frozen features to
    teacher logits.  Failure here means that more elaborate PC/CC machinery is
    not being tested on an adequate interface.
    """

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        *,
        kind: str = "low_rank",
        capacity: int = 16,
        temperature: float = 2.0,
        learning_rate: float = 3e-3,
        steps: int = 500,
        batch_size: int = 128,
        weight_decay: float = 0.0,
        seed: int = 0,
    ) -> None:
        if min(input_dim, output_dim, capacity, steps, batch_size) <= 0:
            raise ValueError("dimensions and training counts must be positive")
        if kind not in {"linear", "low_rank", "mlp"}:
            raise ValueError("kind must be linear, low_rank, or mlp")
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.kind = kind
        self.capacity = capacity
        self.temperature = float(temperature)
        self.learning_rate = float(learning_rate)
        self.steps = steps
        self.batch_size = batch_size
        self.weight_decay = float(weight_decay)
        self.seed = seed
        if kind == "linear":
            self.model: nn.Module = nn.Linear(input_dim, output_dim)
            nn.init.zeros_(self.model.weight)
            nn.init.zeros_(self.model.bias)
        elif kind == "low_rank":
            self.model = _LowRankResidual(input_dim, output_dim, capacity)
        else:
            self.model = _MLPResidual(input_dim, output_dim, capacity)

    def fit(
        self,
        train_features: Tensor,
        train_base_logits: Tensor,
        train_teacher_logits: Tensor,
        validation_features: Tensor,
        validation_base_logits: Tensor,
        validation_teacher_logits: Tensor,
        *,
        mask: Tensor | None = None,
        extra_loss_fn: Callable[[Tensor, Tensor], Tensor] | None = None,
        name: str = "probe",
    ) -> ObservabilityResult:
        if train_features.shape[-1] != self.input_dim:
            raise ValueError("Unexpected train feature width")
        if train_base_logits.shape != train_teacher_logits.shape:
            raise ValueError("Training base and teacher logits must match")
        if validation_base_logits.shape != validation_teacher_logits.shape:
            raise ValueError("Validation base and teacher logits must match")
        if train_base_logits.shape[-1] != self.output_dim:
            raise ValueError("Unexpected output width")
        self.model.to(train_features.device, dtype=train_features.dtype)
        optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=self.learning_rate,
            weight_decay=self.weight_decay,
        )
        generator = torch.Generator(device="cpu").manual_seed(self.seed)
        history: list[float] = []
        self.model.train()
        for _ in range(self.steps):
            indices = torch.randint(
                0,
                train_features.shape[0],
                (min(self.batch_size, train_features.shape[0]),),
                generator=generator,
                device="cpu",
            ).to(train_features.device)
            features = train_features.index_select(0, indices)
            base = train_base_logits.index_select(0, indices)
            teacher = train_teacher_logits.index_select(0, indices)
            student = base + self.model(features)
            loss = temperature_kl(student, teacher, temperature=self.temperature)
            if extra_loss_fn is not None:
                loss = loss + extra_loss_fn(student, teacher)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()
            history.append(float(loss.detach()))
        self.model.eval()
        with torch.no_grad():
            train_student = train_base_logits + self.model(train_features)
            validation_student = validation_base_logits + self.model(validation_features)
            base_loss = temperature_kl(
                validation_base_logits,
                validation_teacher_logits,
                temperature=self.temperature,
                mask=mask,
            )
            train_loss = temperature_kl(
                train_student,
                train_teacher_logits,
                temperature=self.temperature,
            )
            validation_loss = temperature_kl(
                validation_student,
                validation_teacher_logits,
                temperature=self.temperature,
                mask=mask,
            )
        base_value = float(base_loss)
        validation_value = float(validation_loss)
        gap_closure = 1.0 - validation_value / max(base_value, 1e-12)
        return ObservabilityResult(
            name=name,
            base_loss=base_value,
            train_loss=float(train_loss),
            validation_loss=validation_value,
            teacher_gap_closure=gap_closure,
            parameter_count=sum(parameter.numel() for parameter in self.model.parameters()),
            steps=self.steps,
            history=history,
            metadata={"kind": self.kind, "capacity": self.capacity},
        )


@dataclass
class LayerwiseObservabilityReport:
    results: dict[str, ObservabilityResult]

    @property
    def best_layer(self) -> str:
        return max(self.results, key=lambda name: self.results[name].teacher_gap_closure)

    def to_dict(self) -> dict[str, object]:
        return {
            "best_layer": self.best_layer,
            "results": {name: result.to_dict() for name, result in self.results.items()},
        }


def audit_layers(
    train_features: Mapping[str, Tensor],
    validation_features: Mapping[str, Tensor],
    train_base_logits: Tensor,
    train_teacher_logits: Tensor,
    validation_base_logits: Tensor,
    validation_teacher_logits: Tensor,
    *,
    probe_factory: Callable[[str, int], FrozenReadProbe],
) -> LayerwiseObservabilityReport:
    results: dict[str, ObservabilityResult] = {}
    for name, features in train_features.items():
        if name not in validation_features:
            raise KeyError(f"Missing validation features for {name!r}")
        probe = probe_factory(name, features.shape[-1])
        results[name] = probe.fit(
            features,
            train_base_logits,
            train_teacher_logits,
            validation_features[name],
            validation_base_logits,
            validation_teacher_logits,
            name=name,
        )
    return LayerwiseObservabilityReport(results)
