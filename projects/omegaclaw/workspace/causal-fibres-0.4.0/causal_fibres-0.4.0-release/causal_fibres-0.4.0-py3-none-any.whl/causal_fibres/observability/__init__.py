"""Frozen-interface observability controls and teacher-gap capacity curves."""

from .capacity import CapacityPoint, TeacherGapCapacityCurve, fit_capacity_curve
from .probe import FrozenReadProbe, LayerwiseObservabilityReport, ObservabilityResult, audit_layers

__all__ = [
    "FrozenReadProbe",
    "ObservabilityResult",
    "LayerwiseObservabilityReport",
    "audit_layers",
    "CapacityPoint",
    "TeacherGapCapacityCurve",
    "fit_capacity_curve",
]
