from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Callable, Sequence

from torch import Tensor

from .probe import FrozenReadProbe, ObservabilityResult


@dataclass
class CapacityPoint:
    capacity: int
    result: ObservabilityResult

    def to_dict(self) -> dict[str, object]:
        return {"capacity": self.capacity, "result": self.result.to_dict()}


@dataclass
class TeacherGapCapacityCurve:
    points: list[CapacityPoint]

    def minimum_capacity_for(self, gap_closure: float) -> int | None:
        eligible = [
            point.capacity
            for point in self.points
            if point.result.teacher_gap_closure >= gap_closure
        ]
        return min(eligible) if eligible else None

    def to_dict(self) -> dict[str, object]:
        return {"points": [point.to_dict() for point in self.points]}


def fit_capacity_curve(
    capacities: Sequence[int],
    *,
    probe_factory: Callable[[int], FrozenReadProbe],
    train_features: Tensor,
    train_base_logits: Tensor,
    train_teacher_logits: Tensor,
    validation_features: Tensor,
    validation_base_logits: Tensor,
    validation_teacher_logits: Tensor,
) -> TeacherGapCapacityCurve:
    points: list[CapacityPoint] = []
    for capacity in capacities:
        probe = probe_factory(int(capacity))
        result = probe.fit(
            train_features,
            train_base_logits,
            train_teacher_logits,
            validation_features,
            validation_base_logits,
            validation_teacher_logits,
            name=f"capacity_{capacity}",
        )
        points.append(CapacityPoint(capacity=int(capacity), result=result))
    return TeacherGapCapacityCurve(points)
