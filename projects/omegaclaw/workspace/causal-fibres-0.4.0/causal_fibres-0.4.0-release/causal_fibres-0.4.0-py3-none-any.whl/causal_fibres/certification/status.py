from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any


class ModuleStatus(str, Enum):
    CANDIDATE = "candidate"
    FUNCTIONAL = "functional"
    INTERVENTION_ALIGNED = "intervention_aligned"
    CAUSALLY_IDENTIFIED = "causally_identified"
    CONSOLIDATED = "consolidated"
    UNDERIDENTIFIED = "underidentified"


@dataclass
class CertificationEvidence:
    unique_ablation_value: float | None = None
    intervention_selectivity: float | None = None
    intervention_repeatability: float | None = None
    routing_precision: float | None = None
    routing_recall: float | None = None
    off_support_mass: float | None = None
    fingerprint_condition: float | None = None
    finite_order_distance: float | None = None
    context_stability: float | None = None
    retention_score: float | None = None
    semantic_stability: float | None = None
    underidentified: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class CertificationThresholds:
    minimum_ablation_value: float = 1e-4
    minimum_selectivity: float = 2.0
    minimum_repeatability: float = 0.8
    minimum_routing_precision: float = 0.8
    minimum_routing_recall: float = 0.8
    maximum_off_support_mass: float = 0.1
    minimum_fingerprint_condition: float = 1e-3
    maximum_finite_order_distance: float = 0.05
    minimum_context_stability: float = 0.8
    minimum_retention_score: float = 0.8
    minimum_semantic_stability: float = 0.8


@dataclass
class CertificationResult:
    status: ModuleStatus
    passed_levels: list[ModuleStatus]
    reasons: list[str]
    evidence: CertificationEvidence

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status.value,
            "passed_levels": [status.value for status in self.passed_levels],
            "reasons": list(self.reasons),
            "evidence": asdict(self.evidence),
        }


class ModuleCertifier:
    """Conservative evidence ladder for claims about learned modules."""

    def __init__(self, thresholds: CertificationThresholds | None = None) -> None:
        self.thresholds = thresholds or CertificationThresholds()

    def certify(self, evidence: CertificationEvidence) -> CertificationResult:
        if evidence.underidentified:
            return CertificationResult(
                status=ModuleStatus.UNDERIDENTIFIED,
                passed_levels=[ModuleStatus.CANDIDATE],
                reasons=[
                    "The operator or intervention family does not identify this module uniquely."
                ],
                evidence=evidence,
            )
        passed = [ModuleStatus.CANDIDATE]
        reasons: list[str] = []
        if (
            evidence.unique_ablation_value is None
            or evidence.unique_ablation_value < self.thresholds.minimum_ablation_value
        ):
            reasons.append("No sufficiently large unique functional ablation effect was established.")
            return CertificationResult(ModuleStatus.CANDIDATE, passed, reasons, evidence)
        passed.append(ModuleStatus.FUNCTIONAL)
        if not (
            evidence.intervention_selectivity is not None
            and evidence.intervention_selectivity >= self.thresholds.minimum_selectivity
            and evidence.intervention_repeatability is not None
            and evidence.intervention_repeatability >= self.thresholds.minimum_repeatability
        ):
            reasons.append("Interventions are not yet selective and repeatable enough.")
            return CertificationResult(ModuleStatus.FUNCTIONAL, passed, reasons, evidence)
        passed.append(ModuleStatus.INTERVENTION_ALIGNED)
        identified = all(
            (
                evidence.routing_precision is not None,
                evidence.routing_recall is not None,
                evidence.off_support_mass is not None,
                evidence.fingerprint_condition is not None,
            )
        )
        if identified:
            identified = bool(
                evidence.routing_precision >= self.thresholds.minimum_routing_precision
                and evidence.routing_recall >= self.thresholds.minimum_routing_recall
                and evidence.off_support_mass <= self.thresholds.maximum_off_support_mass
                and evidence.fingerprint_condition >= self.thresholds.minimum_fingerprint_condition
            )
        if not identified:
            reasons.append("Support routing or fingerprint conditioning is insufficient for causal identification.")
            return CertificationResult(ModuleStatus.INTERVENTION_ALIGNED, passed, reasons, evidence)
        passed.append(ModuleStatus.CAUSALLY_IDENTIFIED)
        consolidated = all(
            (
                evidence.finite_order_distance is not None,
                evidence.context_stability is not None,
                evidence.retention_score is not None,
            )
        )
        if consolidated:
            consolidated = bool(
                evidence.finite_order_distance <= self.thresholds.maximum_finite_order_distance
                and evidence.context_stability >= self.thresholds.minimum_context_stability
                and evidence.retention_score >= self.thresholds.minimum_retention_score
                and (
                    evidence.semantic_stability is None
                    or evidence.semantic_stability >= self.thresholds.minimum_semantic_stability
                )
            )
        if not consolidated:
            reasons.append("The module is identified but not yet stable across contexts and finite curricula.")
            return CertificationResult(ModuleStatus.CAUSALLY_IDENTIFIED, passed, reasons, evidence)
        passed.append(ModuleStatus.CONSOLIDATED)
        reasons.append("All configured functional, interventional, causal, and stability gates passed.")
        return CertificationResult(ModuleStatus.CONSOLIDATED, passed, reasons, evidence)
