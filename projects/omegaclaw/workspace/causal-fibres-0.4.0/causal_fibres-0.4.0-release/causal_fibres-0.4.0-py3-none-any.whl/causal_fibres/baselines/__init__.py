"""Mandatory dense, LoRA, SAE, replay, and isolation baselines."""

from .continual import ParameterIsolationBaseline, ReplayBuffer
from .dense import DenseAdapterBaseline
from .lora import LoRALinear, inject_lora, iter_lora_modules, lora_parameters, merge_lora_
from .sae_steering import SAEFeatureSteering

__all__ = [
    "DenseAdapterBaseline",
    "LoRALinear",
    "inject_lora",
    "iter_lora_modules",
    "lora_parameters",
    "merge_lora_",
    "SAEFeatureSteering",
    "ReplayBuffer",
    "ParameterIsolationBaseline",
]
