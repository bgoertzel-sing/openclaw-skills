from __future__ import annotations

from collections.abc import Callable, Iterable

import torch
from torch import Tensor, nn


class LoRALinear(nn.Module):
    """Minimal dependency-free LoRA wrapper for ``nn.Linear``."""

    def __init__(
        self,
        base: nn.Linear,
        rank: int,
        *,
        alpha: float | None = None,
        dropout: float = 0.0,
        freeze_base: bool = True,
    ) -> None:
        super().__init__()
        if rank <= 0:
            raise ValueError("rank must be positive")
        if not 0 <= dropout < 1:
            raise ValueError("dropout must lie in [0, 1)")
        self.base = base
        self.rank = rank
        self.alpha = float(alpha if alpha is not None else rank)
        self.scaling = self.alpha / rank
        self.dropout = nn.Dropout(dropout)
        self.lora_a = nn.Linear(base.in_features, rank, bias=False)
        self.lora_b = nn.Linear(rank, base.out_features, bias=False)
        nn.init.kaiming_uniform_(self.lora_a.weight, a=5**0.5)
        nn.init.zeros_(self.lora_b.weight)
        if freeze_base:
            for parameter in self.base.parameters():
                parameter.requires_grad_(False)

    def forward(self, inputs: Tensor) -> Tensor:
        return self.base(inputs) + self.scaling * self.lora_b(self.lora_a(self.dropout(inputs)))

    @property
    def delta_weight(self) -> Tensor:
        return self.scaling * (self.lora_b.weight @ self.lora_a.weight)

    def merged_linear(self) -> nn.Linear:
        merged = nn.Linear(
            self.base.in_features,
            self.base.out_features,
            bias=self.base.bias is not None,
            device=self.base.weight.device,
            dtype=self.base.weight.dtype,
        )
        with torch.no_grad():
            merged.weight.copy_(self.base.weight + self.delta_weight.to(self.base.weight))
            if self.base.bias is not None and merged.bias is not None:
                merged.bias.copy_(self.base.bias)
        return merged


def _resolve_parent(root: nn.Module, path: str) -> tuple[nn.Module, str]:
    parts = path.split(".")
    parent = root
    for part in parts[:-1]:
        if part.isdigit() and isinstance(parent, (nn.Sequential, nn.ModuleList)):
            parent = parent[int(part)]
        else:
            parent = getattr(parent, part)
    return parent, parts[-1]


def inject_lora(
    model: nn.Module,
    *,
    rank: int,
    module_names: Iterable[str] | None = None,
    predicate: Callable[[str, nn.Linear], bool] | None = None,
    alpha: float | None = None,
    dropout: float = 0.0,
    freeze_base: bool = True,
) -> list[str]:
    """Replace selected linear modules with :class:`LoRALinear` wrappers."""

    requested = None if module_names is None else set(module_names)
    candidates = [
        (name, module)
        for name, module in model.named_modules()
        if name and isinstance(module, nn.Linear)
    ]
    replaced: list[str] = []
    for name, module in candidates:
        selected = requested is None and predicate is None
        if requested is not None and name in requested:
            selected = True
        if predicate is not None and predicate(name, module):
            selected = True
        if not selected:
            continue
        parent, attribute = _resolve_parent(model, name)
        wrapper = LoRALinear(
            module,
            rank,
            alpha=alpha,
            dropout=dropout,
            freeze_base=freeze_base,
        )
        if attribute.isdigit() and isinstance(parent, (nn.Sequential, nn.ModuleList)):
            parent[int(attribute)] = wrapper
        else:
            setattr(parent, attribute, wrapper)
        replaced.append(name)
    if requested is not None:
        missing = requested - set(replaced)
        if missing:
            raise KeyError(f"Requested LoRA modules not found: {sorted(missing)}")
    return replaced


def iter_lora_modules(model: nn.Module):
    for name, module in model.named_modules():
        if isinstance(module, LoRALinear):
            yield name, module


def lora_parameters(model: nn.Module):
    for _, module in iter_lora_modules(model):
        yield from module.lora_a.parameters()
        yield from module.lora_b.parameters()


def merge_lora_(model: nn.Module) -> list[str]:
    replaced: list[str] = []
    candidates = [(name, module) for name, module in model.named_modules() if isinstance(module, LoRALinear)]
    for name, module in candidates:
        parent, attribute = _resolve_parent(model, name)
        merged = module.merged_linear()
        if attribute.isdigit() and isinstance(parent, (nn.Sequential, nn.ModuleList)):
            parent[int(attribute)] = merged
        else:
            setattr(parent, attribute, merged)
        replaced.append(name)
    return replaced
