from __future__ import annotations

from collections.abc import Sequence

import torch
from torch import Tensor, nn

from causal_fibres.representations import SparseAutoencoder


class SAEFeatureSteering(nn.Module):
    """Use SAE features as an explicit steering or residual-prediction baseline."""

    def __init__(
        self,
        sae: SparseAutoencoder,
        output_dim: int,
        *,
        freeze_sae: bool = True,
        bias: bool = True,
    ) -> None:
        super().__init__()
        if output_dim <= 0:
            raise ValueError("output_dim must be positive")
        self.sae = sae
        self.output_dim = output_dim
        self.steering = nn.Linear(sae.dictionary_size, output_dim, bias=bias)
        if freeze_sae:
            for parameter in self.sae.parameters():
                parameter.requires_grad_(False)

    def forward(self, hidden: Tensor) -> Tensor:
        code = self.sae.encode(hidden)
        return self.steering(code)

    def selected_feature_effect(
        self,
        feature_indices: Sequence[int],
        *,
        values: Tensor | float = 1.0,
    ) -> Tensor:
        indices = torch.as_tensor(feature_indices, device=self.steering.weight.device, dtype=torch.long)
        weights = self.steering.weight[:, indices]
        value = torch.as_tensor(values, device=weights.device, dtype=weights.dtype)
        if value.ndim == 0:
            return weights.sum(dim=-1) * value
        return weights @ value

    def feature_contributions(self, hidden: Tensor) -> Tensor:
        code = self.sae.encode(hidden)
        return code.unsqueeze(-1) * self.steering.weight.transpose(0, 1)
