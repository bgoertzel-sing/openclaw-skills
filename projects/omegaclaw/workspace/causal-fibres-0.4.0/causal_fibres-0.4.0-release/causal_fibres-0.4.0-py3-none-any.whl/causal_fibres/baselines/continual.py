from __future__ import annotations

import random
from collections import deque
from collections.abc import Mapping, Sequence
from typing import Any

import torch
from torch import Tensor, nn


def _detach_cpu(value: Any) -> Any:
    if isinstance(value, Tensor):
        return value.detach().cpu()
    if isinstance(value, Mapping):
        return {key: _detach_cpu(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return tuple(_detach_cpu(item) for item in value)
    if isinstance(value, list):
        return [_detach_cpu(item) for item in value]
    return value


def _stack(values: Sequence[Any]) -> Any:
    first = values[0]
    if isinstance(first, Tensor):
        return torch.stack(list(values))
    if isinstance(first, Mapping):
        return {key: _stack([value[key] for value in values]) for key in first}
    if isinstance(first, tuple):
        return tuple(_stack([value[index] for value in values]) for index in range(len(first)))
    return list(values)


class ReplayBuffer:
    """Small architecture-neutral FIFO or reservoir replay buffer."""

    def __init__(self, capacity: int, *, strategy: str = "reservoir", seed: int = 0) -> None:
        if capacity <= 0:
            raise ValueError("capacity must be positive")
        if strategy not in {"reservoir", "fifo"}:
            raise ValueError("strategy must be reservoir or fifo")
        self.capacity = capacity
        self.strategy = strategy
        self._rng = random.Random(seed)
        self._seen = 0
        self._items: deque[Any] = deque(maxlen=capacity)

    def __len__(self) -> int:
        return len(self._items)

    def add(self, item: Any) -> None:
        value = _detach_cpu(item)
        self._seen += 1
        if self.strategy == "fifo" or len(self._items) < self.capacity:
            self._items.append(value)
            return
        position = self._rng.randrange(self._seen)
        if position < self.capacity:
            items = list(self._items)
            items[position] = value
            self._items = deque(items, maxlen=self.capacity)

    def sample(self, batch_size: int) -> Any:
        if batch_size <= 0:
            raise ValueError("batch_size must be positive")
        if not self._items:
            raise RuntimeError("Cannot sample from an empty replay buffer")
        count = min(batch_size, len(self._items))
        chosen = self._rng.sample(list(self._items), count)
        return _stack(chosen)


class ParameterIsolationBaseline:
    """Apply supplied context masks to parameter gradients.

    Masks are keyed by exact parameter name and may be scalar or tensor-valued.
    This is an explicit baseline for comparing causal support estimates against
    ordinary parameter isolation.
    """

    def __init__(self, masks_by_context: Mapping[Any, Mapping[str, Tensor | float]]) -> None:
        self.masks_by_context = {
            context: dict(masks) for context, masks in masks_by_context.items()
        }

    def apply(self, model: nn.Module, context: Any) -> dict[str, float]:
        masks = self.masks_by_context.get(context)
        if masks is None:
            raise KeyError(f"No parameter-isolation mask for context {context!r}")
        kept = 0.0
        total = 0.0
        for name, parameter in model.named_parameters():
            if parameter.grad is None:
                continue
            total += float(parameter.grad.norm())
            mask = masks.get(name, 0.0)
            mask_tensor = torch.as_tensor(mask, device=parameter.grad.device, dtype=parameter.grad.dtype)
            parameter.grad.mul_(mask_tensor)
            kept += float(parameter.grad.norm())
        return {
            "gradient_norm_before_mask": total,
            "gradient_norm_after_mask": kept,
            "gradient_retained_fraction": kept / max(total, 1e-12),
        }
