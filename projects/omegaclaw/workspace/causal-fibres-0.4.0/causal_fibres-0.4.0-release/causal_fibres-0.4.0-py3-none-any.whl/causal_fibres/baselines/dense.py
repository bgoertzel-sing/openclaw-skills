from __future__ import annotations

from torch import Tensor, nn


class DenseAdapterBaseline(nn.Module):
    """Ordinary feed-forward adapter baseline."""

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        *,
        bottleneck_dim: int,
        residual: bool = False,
    ) -> None:
        super().__init__()
        if min(input_dim, output_dim, bottleneck_dim) <= 0:
            raise ValueError("dimensions must be positive")
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.residual = residual
        if residual and input_dim != output_dim:
            raise ValueError("residual=True requires input_dim == output_dim")
        self.network = nn.Sequential(
            nn.LayerNorm(input_dim),
            nn.Linear(input_dim, bottleneck_dim),
            nn.GELU(),
            nn.Linear(bottleneck_dim, output_dim),
        )

    def forward(self, inputs: Tensor) -> Tensor:
        value = self.network(inputs)
        return inputs + value if self.residual else value
