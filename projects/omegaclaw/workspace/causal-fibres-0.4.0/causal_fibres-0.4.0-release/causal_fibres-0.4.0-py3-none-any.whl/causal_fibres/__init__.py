"""Causal Fibres: modular causal credit and PC residual tooling."""

from .core import (
    CFEConfig,
    CheckpointManager,
    CreditPacket,
    FibreState,
    RepresentationConfig,
    SubstrateConfig,
    EvaluationConfig,
    ForwardRecord,
    SiteSpec,
    SolveResult,
    StepContext,
    seed_everything,
)
from .fibres import (
    FibrePlasticityController,
    ResponsibilityGradientGate,
    IndependentFibrePredictor,
    LinearFibreBank,
    MultiSiteFibrePredictor,
    TerminalFibreSidecar,
)
from .solvers import (
    GradientPCSolver,
    LevenbergMarquardtPCSolver,
    NoOpStateSolver,
    PreconditionedPCSolver,
)

from .representations import (
    ContextualFibreBundle,
    DenseResidualRepresentation,
    GroupedSparseDictionary,
    OrthogonalFibreRepresentation,
    RepresentationContest,
    SparseAutoencoder,
)
from .observability import FrozenReadProbe, TeacherGapCapacityCurve
from .evaluation import (
    FiniteCurriculumLoopEvaluator,
    FreeSettlementEvaluator,
    MatchedComputeEvaluator,
    NovelContextRoutingEvaluator,
)
from .certification import ModuleCertifier, ModuleStatus

__all__ = [
    "CFEConfig",
    "CheckpointManager",
    "CreditPacket",
    "FibreState",
    "RepresentationConfig",
    "SubstrateConfig",
    "EvaluationConfig",
    "ForwardRecord",
    "SiteSpec",
    "SolveResult",
    "StepContext",
    "seed_everything",
    "FibrePlasticityController",
    "ResponsibilityGradientGate",
    "IndependentFibrePredictor",
    "LinearFibreBank",
    "MultiSiteFibrePredictor",
    "TerminalFibreSidecar",
    "NoOpStateSolver",
    "GradientPCSolver",
    "LevenbergMarquardtPCSolver",
    "PreconditionedPCSolver",
    "DenseResidualRepresentation",
    "OrthogonalFibreRepresentation",
    "SparseAutoencoder",
    "GroupedSparseDictionary",
    "ContextualFibreBundle",
    "RepresentationContest",
    "FrozenReadProbe",
    "TeacherGapCapacityCurve",
    "FreeSettlementEvaluator",
    "MatchedComputeEvaluator",
    "FiniteCurriculumLoopEvaluator",
    "NovelContextRoutingEvaluator",
    "ModuleCertifier",
    "ModuleStatus",
]

__version__ = "0.4.0"
