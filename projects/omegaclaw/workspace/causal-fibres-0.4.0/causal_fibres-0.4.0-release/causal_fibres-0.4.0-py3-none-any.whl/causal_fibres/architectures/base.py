from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Mapping, Sequence

from torch import Tensor

from causal_fibres.core.types import ForwardRecord, SiteSpec


class BaseArchitectureAdapter(ABC):
    @property
    @abstractmethod
    def site_specs(self) -> Sequence[SiteSpec]:
        raise NotImplementedError

    @abstractmethod
    def forward_base(self, batch: Any) -> ForwardRecord:
        raise NotImplementedError

    def forward_with_writes(self, batch: Any, writes: Mapping[str, Tensor]) -> ForwardRecord:
        raise NotImplementedError(
            f"{type(self).__name__} does not support intermediate writes; "
            "use a terminal sidecar or an intervenable adapter"
        )
