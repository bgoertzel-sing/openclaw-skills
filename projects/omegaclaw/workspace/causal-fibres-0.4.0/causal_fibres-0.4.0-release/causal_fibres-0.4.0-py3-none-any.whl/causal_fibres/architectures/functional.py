from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from typing import Any

from torch import Tensor

from causal_fibres.core.types import ForwardRecord, SiteSpec

from .base import BaseArchitectureAdapter


class FunctionalAdapter(BaseArchitectureAdapter):
    """Adapter backed by user-supplied callables.

    This is useful for non-standard learning systems and tests. ``forward_fn``
    may return a ``ForwardRecord`` directly or an output tensor; when it returns
    a tensor, ``site_fn`` must provide the site mapping.
    """

    def __init__(
        self,
        site_specs: Sequence[SiteSpec],
        forward_fn: Callable[[Any], ForwardRecord | Tensor],
        *,
        site_fn: Callable[[Any, Tensor], Mapping[str, Tensor]] | None = None,
        write_fn: Callable[[Any, Mapping[str, Tensor]], ForwardRecord] | None = None,
    ) -> None:
        self._site_specs = tuple(site_specs)
        self.forward_fn = forward_fn
        self.site_fn = site_fn
        self.write_fn = write_fn

    @property
    def site_specs(self) -> Sequence[SiteSpec]:
        return self._site_specs

    def forward_base(self, batch: Any) -> ForwardRecord:
        value = self.forward_fn(batch)
        if isinstance(value, ForwardRecord):
            return value
        if self.site_fn is None:
            raise TypeError("site_fn is required when forward_fn returns a Tensor")
        return ForwardRecord(output=value, sites=dict(self.site_fn(batch, value)))

    def forward_with_writes(self, batch: Any, writes: Mapping[str, Tensor]) -> ForwardRecord:
        if self.write_fn is None:
            return super().forward_with_writes(batch, writes)
        return self.write_fn(batch, writes)
