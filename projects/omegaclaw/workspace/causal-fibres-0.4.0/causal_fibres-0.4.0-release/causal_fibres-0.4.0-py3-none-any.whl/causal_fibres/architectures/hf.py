from __future__ import annotations

from typing import Any, Mapping, Sequence

import torch
from torch import Tensor, nn

from causal_fibres.core.types import ForwardRecord, SiteSpec

from .base import BaseArchitectureAdapter


def _infer_hidden_width(model: nn.Module) -> int:
    config = getattr(model, "config", None)
    for name in ("hidden_size", "n_embd", "d_model"):
        value = getattr(config, name, None)
        if isinstance(value, int) and value > 0:
            return value
    raise ValueError("Could not infer hidden width; pass widths explicitly")


class HFHiddenStatesAdapter(BaseArchitectureAdapter):
    """Terminal-sidecar adapter for Hugging Face-style causal language models.

    The adapter deliberately avoids importing ``transformers``. It works with
    any module whose forward method accepts ``output_hidden_states=True`` and
    returns an object with ``logits`` and ``hidden_states`` attributes.

    ``layers`` maps a site name to an index in the returned hidden-state tuple.
    In standard HF causal LMs, index 0 is the embedding output and index ``i+1``
    is the output of Transformer block ``i``.
    """

    def __init__(
        self,
        model: nn.Module,
        layers: Mapping[str, int],
        *,
        widths: Mapping[str, int] | None = None,
        freeze: bool = True,
        no_grad: bool = True,
        forward_kwargs: Mapping[str, Any] | None = None,
        remove_batch_keys: Sequence[str] = (),
    ) -> None:
        if not layers:
            raise ValueError("At least one hidden-state layer is required")
        self.model = model
        self.layers = dict(layers)
        width = _infer_hidden_width(model)
        self.widths = {name: width for name in self.layers}
        if widths is not None:
            self.widths.update(widths)
        self.no_grad = no_grad
        self.forward_kwargs = dict(forward_kwargs or {})
        self.remove_batch_keys = tuple(remove_batch_keys)
        if freeze:
            model.eval()
            for parameter in model.parameters():
                parameter.requires_grad_(False)

    @property
    def site_specs(self) -> Sequence[SiteSpec]:
        return [
            SiteSpec(name, self.widths[name], metadata={"hidden_state_index": index})
            for name, index in self.layers.items()
        ]

    def forward_base(self, batch: Any) -> ForwardRecord:
        if not isinstance(batch, Mapping):
            raise TypeError("HFHiddenStatesAdapter expects a mapping batch")
        kwargs = {key: value for key, value in batch.items() if key not in self.remove_batch_keys}
        kwargs.update(self.forward_kwargs)
        kwargs["output_hidden_states"] = True
        kwargs.setdefault("return_dict", True)
        kwargs.setdefault("use_cache", False)
        context = torch.no_grad() if self.no_grad else torch.enable_grad()
        with context:
            raw = self.model(**kwargs)
        logits = getattr(raw, "logits", None)
        hidden_states = getattr(raw, "hidden_states", None)
        if not isinstance(logits, Tensor):
            raise TypeError("HF model output must expose Tensor .logits")
        if hidden_states is None:
            raise TypeError("HF model output must expose .hidden_states")
        sites: dict[str, Tensor] = {}
        for name, index in self.layers.items():
            try:
                sites[name] = hidden_states[index]
            except IndexError as exc:
                raise IndexError(
                    f"Hidden-state index {index} for site {name!r} is unavailable; "
                    f"model returned {len(hidden_states)} states"
                ) from exc
        aux = {
            "raw_output": raw,
            "attention_mask": batch.get("attention_mask"),
            "labels": batch.get("labels"),
            "input_ids": batch.get("input_ids"),
        }
        return ForwardRecord(output=logits, sites=sites, aux=aux)
