"""Architecture adapters."""

from .base import BaseArchitectureAdapter
from .functional import FunctionalAdapter
from .hf import HFHiddenStatesAdapter
from .hooked import HookedModuleAdapter

__all__ = [
    "BaseArchitectureAdapter",
    "FunctionalAdapter",
    "HFHiddenStatesAdapter",
    "HookedModuleAdapter",
]
