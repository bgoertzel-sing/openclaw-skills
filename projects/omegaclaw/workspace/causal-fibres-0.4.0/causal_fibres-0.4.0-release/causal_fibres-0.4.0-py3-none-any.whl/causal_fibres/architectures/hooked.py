from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Callable, Mapping, Sequence

import torch
from torch import Tensor, nn

from causal_fibres.core.types import ForwardRecord, SiteSpec

from .base import BaseArchitectureAdapter

TensorSelector = Callable[[Any], Tensor]
OutputReplacer = Callable[[Any, Tensor, str], Any]


def default_output_selector(output: Any) -> Tensor:
    if isinstance(output, Tensor):
        return output
    logits = getattr(output, "logits", None)
    if isinstance(logits, Tensor):
        return logits
    if isinstance(output, (tuple, list)) and output and isinstance(output[0], Tensor):
        return output[0]
    raise TypeError("Could not select a tensor output; supply output_selector")


def default_site_selector(output: Any) -> Tensor:
    if isinstance(output, Tensor):
        return output
    if isinstance(output, (tuple, list)) and output and isinstance(output[0], Tensor):
        return output[0]
    hidden = getattr(output, "last_hidden_state", None)
    if isinstance(hidden, Tensor):
        return hidden
    raise TypeError("Could not select site tensor; supply a per-site selector")


def default_output_replacer(output: Any, write: Tensor, mode: str) -> Any:
    def combine(value: Tensor) -> Tensor:
        if value.shape != write.shape:
            raise ValueError(
                f"Write shape {tuple(write.shape)} does not match module output "
                f"{tuple(value.shape)}"
            )
        if mode == "add":
            return value + write
        if mode == "replace":
            return write
        if mode == "read_only":
            return value
        raise ValueError(f"Unsupported write mode: {mode}")

    if isinstance(output, Tensor):
        return combine(output)
    if isinstance(output, tuple) and output and isinstance(output[0], Tensor):
        return (combine(output[0]), *output[1:])
    if isinstance(output, list) and output and isinstance(output[0], Tensor):
        return [combine(output[0]), *output[1:]]
    raise TypeError("Could not replace module output; supply a site_output_replacer")


class HookedModuleAdapter(BaseArchitectureAdapter):
    """Capture named modules from an arbitrary ``torch.nn.Module``.

    This adapter is intended for quick experiments. It supports explicit
    additive/replacement writes through forward hooks, but model-family-native
    adapters remain preferable when suffix recomputation or cache semantics are
    important.
    """

    def __init__(
        self,
        model: nn.Module,
        sites: Mapping[str, str],
        widths: Mapping[str, int],
        *,
        output_selector: TensorSelector = default_output_selector,
        site_selectors: Mapping[str, TensorSelector] | None = None,
        site_write_modes: Mapping[str, str] | None = None,
        site_output_replacers: Mapping[str, OutputReplacer] | None = None,
        freeze: bool = True,
        no_grad: bool = True,
    ) -> None:
        self.model = model
        self._sites = dict(sites)
        self._widths = dict(widths)
        self.output_selector = output_selector
        self.site_selectors = dict(site_selectors or {})
        self.site_write_modes = {
            name: (site_write_modes or {}).get(name, "add") for name in self._sites
        }
        self.site_output_replacers = dict(site_output_replacers or {})
        self.no_grad = no_grad
        if set(self._sites) != set(self._widths):
            raise ValueError("sites and widths must have the same keys")
        modules = dict(model.named_modules())
        missing = [path for path in self._sites.values() if path not in modules]
        if missing:
            raise KeyError(f"Unknown module paths: {missing}")
        self._module_lookup = modules
        if freeze:
            model.eval()
            for parameter in model.parameters():
                parameter.requires_grad_(False)

    @property
    def site_specs(self) -> Sequence[SiteSpec]:
        return [
            SiteSpec(
                name,
                self._widths[name],
                write_mode=self.site_write_modes[name],
                metadata={"module_path": self._sites[name]},
            )
            for name in self._sites
        ]

    @contextmanager
    def _capture(self, writes: Mapping[str, Tensor] | None = None):
        captured: dict[str, Tensor] = {}
        handles = []
        writes = dict(writes or {})
        unknown = set(writes) - set(self._sites)
        if unknown:
            raise KeyError(f"Writes supplied for unknown sites: {sorted(unknown)}")
        for site_name, module_path in self._sites.items():
            module = self._module_lookup[module_path]
            selector = self.site_selectors.get(site_name, default_site_selector)
            replacer = self.site_output_replacers.get(site_name, default_output_replacer)
            mode = self.site_write_modes[site_name]

            def hook(_module, _inputs, output, *, name=site_name, pick=selector, put=replacer, m=mode):
                selected = pick(output)
                captured[name] = selected
                if name in writes:
                    return put(output, writes[name].to(selected), m)
                return None

            handles.append(module.register_forward_hook(hook))
        try:
            yield captured
        finally:
            for handle in handles:
                handle.remove()

    def _call_model(self, batch: Any) -> Any:
        if isinstance(batch, Mapping):
            return self.model(**batch)
        if isinstance(batch, tuple):
            return self.model(*batch)
        return self.model(batch)

    def _forward(self, batch: Any, writes: Mapping[str, Tensor] | None = None) -> ForwardRecord:
        grad_context = torch.no_grad() if self.no_grad else torch.enable_grad()
        with self._capture(writes) as sites, grad_context:
            raw_output = self._call_model(batch)
            output = self.output_selector(raw_output)
        return ForwardRecord(output=output, sites=dict(sites), aux={"raw_output": raw_output})

    def forward_base(self, batch: Any) -> ForwardRecord:
        return self._forward(batch)

    def forward_with_writes(self, batch: Any, writes: Mapping[str, Tensor]) -> ForwardRecord:
        return self._forward(batch, writes)
