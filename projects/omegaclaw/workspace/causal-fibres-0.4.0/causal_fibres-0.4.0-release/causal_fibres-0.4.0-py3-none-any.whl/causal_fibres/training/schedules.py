from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass
class LinearSchedule:
    start: float
    end: float
    steps: int

    def __call__(self, step: int) -> float:
        if self.steps <= 0:
            return self.end
        fraction = min(max(step / self.steps, 0.0), 1.0)
        return self.start + fraction * (self.end - self.start)


@dataclass
class CosineSchedule:
    start: float
    end: float
    steps: int

    def __call__(self, step: int) -> float:
        if self.steps <= 0:
            return self.end
        fraction = min(max(step / self.steps, 0.0), 1.0)
        weight = 0.5 * (1.0 - math.cos(math.pi * fraction))
        return self.start + weight * (self.end - self.start)


class PiecewiseSchedule:
    def __init__(self, points: list[tuple[int, float]]) -> None:
        if not points:
            raise ValueError("At least one schedule point is required")
        self.points = sorted((int(step), float(value)) for step, value in points)

    def __call__(self, step: int) -> float:
        value = self.points[0][1]
        for point_step, point_value in self.points:
            if step < point_step:
                break
            value = point_value
        return value
