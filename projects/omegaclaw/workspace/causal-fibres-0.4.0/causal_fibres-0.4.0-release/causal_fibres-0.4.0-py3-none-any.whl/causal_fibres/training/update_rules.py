from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import Any

import torch
from torch import nn

from causal_fibres.core.types import StepContext


class AutogradUpdateRule:
    """Persistent-parameter update using a standard PyTorch optimizer."""

    def __init__(
        self,
        optimizer: torch.optim.Optimizer,
        parameters: Callable[[], Any],
        *,
        loss_key: str = "loss_total",
        gradient_clip: float | None = None,
    ) -> None:
        self.optimizer = optimizer
        self.parameters = parameters
        self.loss_key = loss_key
        self.gradient_clip = gradient_clip

    def step(self, ctx: StepContext) -> Mapping[str, float]:
        if self.loss_key not in ctx.losses:
            raise KeyError(f"Missing loss {self.loss_key!r}")
        self.optimizer.zero_grad(set_to_none=True)
        ctx.losses[self.loss_key].backward()
        grad_norm = 0.0
        if self.gradient_clip is not None:
            norm = nn.utils.clip_grad_norm_(self.parameters(), self.gradient_clip)
            grad_norm = float(norm)
        self.optimizer.step()
        return {"outer_grad_norm": grad_norm}


class CallableUpdateRule:
    """Adapter for local, Hebbian, evolutionary, or custom update algorithms."""

    def __init__(self, fn: Callable[[StepContext], Mapping[str, float]]) -> None:
        self.fn = fn

    def step(self, ctx: StepContext) -> Mapping[str, float]:
        return self.fn(ctx)
