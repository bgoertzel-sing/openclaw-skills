from __future__ import annotations

from contextlib import nullcontext
from dataclasses import dataclass
from typing import Any, Callable, Iterable, Mapping, Sequence

import torch
from torch import Tensor, nn

from causal_fibres.core.protocols import ArchitectureAdapter, StateSolver
from causal_fibres.core.types import FibreState, StepContext
from causal_fibres.fibres.gauge import (
    covariance_gauge_loss,
    function_space_balance_loss,
    write_norm_gauge_loss,
)
from causal_fibres.fibres.sidecar import TerminalFibreSidecar

from .callbacks import Callback
from .losses import (
    absolute_state_energy,
    masked_cross_entropy,
    predictor_amortization_loss,
    predictor_prior_energy,
    temperature_kl,
)

TeacherFn = Callable[[Any], Tensor | Any]
SupportFn = Callable[[Any], Tensor | None]
ContextFn = Callable[[Any], Any]
MaskFn = Callable[[Any], Tensor | None]
LabelsFn = Callable[[Any], Tensor | None]
ExtraEnergyFn = Callable[[Tensor, StepContext], Tensor]
ExtraOuterLossFn = Callable[[StepContext], Mapping[str, Tensor]]
PostBackwardFn = Callable[[StepContext], Mapping[str, float] | None]


@dataclass
class DistillationWeights:
    deploy_kd: float = 1.0
    settled_kd: float = 0.25
    cross_entropy: float = 0.0
    amortization: float = 1.0
    predictor_prior: float = 0.1
    absolute_state: float = 0.01
    gauge: float = 0.0
    function_balance: float = 0.0
    write_norm: float = 0.0
    anchor_kl: float = 0.0


class PartialDistillationTrainer:
    """Frozen-backbone partial distillation into a PC/ePC fibre sidecar.

    Predictor-only deployment and teacher-clamped settlement are tracked as
    separate modes. The base adapter remains architecture independent, so this
    trainer works for Transformers, CNNs, RNNs, GNNs, and other terminal-output
    systems.
    """

    def __init__(
        self,
        adapter: ArchitectureAdapter,
        sidecar: TerminalFibreSidecar,
        teacher: TeacherFn,
        solver: StateSolver,
        optimizer: torch.optim.Optimizer,
        *,
        weights: DistillationWeights | None = None,
        temperature: float = 2.0,
        support_fn: SupportFn | None = None,
        context_fn: ContextFn | None = None,
        mask_fn: MaskFn | None = None,
        labels_fn: LabelsFn | None = None,
        extra_energy_fn: ExtraEnergyFn | None = None,
        extra_outer_loss_fn: ExtraOuterLossFn | None = None,
        post_backward_fns: Sequence[PostBackwardFn] = (),
        callbacks: Sequence[Callback] = (),
        gradient_clip: float | None = 1.0,
        gradient_accumulation_steps: int = 1,
        scheduler: Any = None,
        amp: bool = False,
        amp_dtype: torch.dtype = torch.bfloat16,
        gauge_projection_norm: float | None = 1.0,
        ignore_index: int = -100,
        causal_lm_shift: bool = False,
    ) -> None:
        if gradient_accumulation_steps <= 0:
            raise ValueError("gradient_accumulation_steps must be positive")
        self.adapter = adapter
        self.sidecar = sidecar
        self.teacher = teacher
        self.solver = solver
        self.optimizer = optimizer
        self.weights = weights or DistillationWeights()
        self.temperature = temperature
        self.support_fn = support_fn
        self.context_fn = context_fn
        self.mask_fn = mask_fn
        self.labels_fn = labels_fn
        self.extra_energy_fn = extra_energy_fn
        self.extra_outer_loss_fn = extra_outer_loss_fn
        self.post_backward_fns = tuple(post_backward_fns)
        self.callbacks = tuple(callbacks)
        self.gradient_clip = gradient_clip
        self.gradient_accumulation_steps = gradient_accumulation_steps
        self.scheduler = scheduler
        self.amp = amp
        self.amp_dtype = amp_dtype
        self.gauge_projection_norm = gauge_projection_norm
        self.ignore_index = ignore_index
        self.causal_lm_shift = causal_lm_shift
        self.step_index = 0
        self._accumulation_index = 0

    @staticmethod
    def _select_output(output: Any) -> Tensor:
        if isinstance(output, Tensor):
            return output
        logits = getattr(output, "logits", None)
        if isinstance(logits, Tensor):
            return logits
        if isinstance(output, (tuple, list)) and output and isinstance(output[0], Tensor):
            return output[0]
        raise TypeError("Teacher callable must return a Tensor or object with .logits")

    def _teacher_output(self, batch: Any) -> Tensor:
        with torch.no_grad():
            output = self.teacher(batch)
        return self._select_output(output)

    def _context(self, batch: Any, context_id: Any) -> Any:
        if self.context_fn is not None:
            value = self.context_fn(batch)
            if context_id is None:
                context_id = value
        if isinstance(context_id, Mapping):
            return context_id
        return context_id

    def _mask(self, batch: Any, record: Any) -> Tensor | None:
        if self.mask_fn is not None:
            return self.mask_fn(batch)
        mask = record.aux.get("attention_mask") if hasattr(record, "aux") else None
        return mask if isinstance(mask, Tensor) else None

    def _labels(self, batch: Any, record: Any) -> Tensor | None:
        if self.labels_fn is not None:
            return self.labels_fn(batch)
        labels = record.aux.get("labels") if hasattr(record, "aux") else None
        if isinstance(labels, Tensor):
            return labels
        if isinstance(batch, Mapping) and isinstance(batch.get("labels"), Tensor):
            return batch["labels"]
        return None

    def _autocast_context(self, tensor: Tensor):
        if not self.amp or tensor.device.type not in {"cuda", "cpu"}:
            return nullcontext()
        return torch.autocast(device_type=tensor.device.type, dtype=self.amp_dtype)

    def _build_step(
        self,
        batch: Any,
        *,
        context_id: Any = None,
        settle: bool = True,
    ) -> StepContext:
        record = self.adapter.forward_base(batch)
        teacher_output = self._teacher_output(batch).to(record.output)
        context = self._context(batch, context_id)
        known_support = None if self.support_fn is None else self.support_fn(batch)
        if known_support is not None:
            known_support = known_support.to(record.output.device)
        mask = self._mask(batch, record)
        if mask is not None:
            mask = mask.to(record.output.device)
        predicted = self.sidecar.predict(
            record,
            context=context,
            known_support=known_support,
        )
        ctx = StepContext(
            batch=batch,
            context_id=context_id,
            forward=record,
            predicted=predicted,
            step_index=self.step_index,
            teacher_output=teacher_output,
            cache={
                "known_support": known_support,
                "loss_mask": mask,
                "context": context,
            },
        )
        if settle:
            gate = predicted.gate
            prior = predicted.value
            initial = prior.detach().requires_grad_(True)

            def state_energy(state: Tensor) -> Tensor:
                output = self.sidecar.compose(record, state, gate)
                kd = temperature_kl(
                    output,
                    teacher_output,
                    temperature=self.temperature,
                    mask=mask,
                )
                energy = (
                    kd
                    + predictor_prior_energy(
                        state,
                        prior.detach(),
                        self.weights.predictor_prior,
                    )
                    + absolute_state_energy(state, self.weights.absolute_state)
                )
                if self.extra_energy_fn is not None:
                    energy = energy + self.extra_energy_fn(state, ctx)
                return energy

            solve = self.solver.solve(initial, state_energy, create_graph=False)
            ctx.settled = FibreState(
                value=solve.state.detach(),
                gate=predicted.gate,
                prior=predicted.prior,
                write_permission=predicted.write_permission,
                metadata={"solve": solve},
            )
            ctx.cache["solve"] = solve
        return ctx

    def _outer_losses(self, ctx: StepContext) -> Tensor:
        teacher_output = ctx.teacher_output
        assert teacher_output is not None
        mask = ctx.cache.get("loss_mask")
        deploy_output = self.sidecar.compose(ctx.forward, ctx.predicted)
        ctx.output = deploy_output
        deploy_kd = temperature_kl(
            deploy_output,
            teacher_output,
            temperature=self.temperature,
            mask=mask,
        )
        if ctx.settled is None:
            settled_output = deploy_output
            settled_kd = deploy_kd.detach()
            amortization = deploy_output.new_zeros(())
        else:
            settled_output = self.sidecar.compose(ctx.forward, ctx.settled)
            settled_kd = temperature_kl(
                settled_output,
                teacher_output,
                temperature=self.temperature,
                mask=mask,
            )
            amortization = predictor_amortization_loss(
                ctx.predicted.value,
                ctx.settled.value,
            )
        labels = self._labels(ctx.batch, ctx.forward)
        if labels is not None and self.weights.cross_entropy:
            labels = labels.to(deploy_output.device)
            ce_logits = deploy_output
            ce_mask = mask
            if self.causal_lm_shift:
                if deploy_output.ndim < 3 or labels.ndim < 2:
                    raise ValueError("causal_lm_shift requires sequence logits and labels")
                ce_logits = deploy_output[..., :-1, :]
                labels = labels[..., 1:]
                if ce_mask is not None:
                    ce_mask = ce_mask[..., 1:]
            ce = masked_cross_entropy(
                ce_logits,
                labels,
                mask=ce_mask,
                ignore_index=self.ignore_index,
            )
        else:
            ce = deploy_output.new_zeros(())
        gauge = (
            covariance_gauge_loss(ctx.predicted.value)
            if self.weights.gauge
            else deploy_output.new_zeros(())
        )
        contributions = self.sidecar.writer.fibre_contributions(
            ctx.predicted.value,
            ctx.predicted.gate,
        )
        balance = (
            function_space_balance_loss(contributions)
            if self.weights.function_balance
            else deploy_output.new_zeros(())
        )
        write_norm = (
            write_norm_gauge_loss(self.sidecar.writer.weight)
            if self.weights.write_norm
            else deploy_output.new_zeros(())
        )
        anchor = (
            temperature_kl(
                deploy_output,
                ctx.forward.output.detach(),
                temperature=1.0,
                mask=mask,
            )
            if self.weights.anchor_kl
            else deploy_output.new_zeros(())
        )
        total = (
            self.weights.deploy_kd * deploy_kd
            + self.weights.settled_kd * settled_kd
            + self.weights.cross_entropy * ce
            + self.weights.amortization * amortization
            + self.weights.gauge * gauge
            + self.weights.function_balance * balance
            + self.weights.write_norm * write_norm
            + self.weights.anchor_kl * anchor
        )
        ctx.losses.update(
            {
                "loss_deploy_kd": deploy_kd,
                "loss_settled_kd": settled_kd,
                "loss_cross_entropy": ce,
                "loss_amortization": amortization,
                "loss_gauge": gauge,
                "loss_function_balance": balance,
                "loss_write_norm": write_norm,
                "loss_anchor_kl": anchor,
            }
        )
        if self.extra_outer_loss_fn is not None:
            extras = dict(self.extra_outer_loss_fn(ctx))
            for name, value in extras.items():
                if not isinstance(value, Tensor) or value.numel() != 1:
                    raise TypeError(f"Extra loss {name!r} must be a scalar Tensor")
                ctx.losses[name] = value
                total = total + value
        ctx.losses["loss_total"] = total
        return total

    def train_step(self, batch: Any, *, context_id: Any = None) -> StepContext:
        self.sidecar.train()
        ctx = self._build_step(batch, context_id=context_id, settle=True)
        with self._autocast_context(ctx.forward.output):
            total = self._outer_losses(ctx)
        if self._accumulation_index == 0:
            self.optimizer.zero_grad(set_to_none=True)
        scaled_total = total / self.gradient_accumulation_steps
        scaled_total.backward()
        self._accumulation_index += 1
        if self._accumulation_index >= self.gradient_accumulation_steps:
            for fn in self.post_backward_fns:
                values = fn(ctx)
                if values:
                    ctx.metrics.update({key: float(value) for key, value in values.items()})
            if self.gradient_clip is not None:
                norm = nn.utils.clip_grad_norm_(self.sidecar.parameters(), self.gradient_clip)
                ctx.metrics["outer_grad_norm"] = float(norm)
            self.optimizer.step()
            self.optimizer.zero_grad(set_to_none=True)
            if self.scheduler is not None:
                self.scheduler.step()
            self.sidecar.project_gauge(self.gauge_projection_norm)
            self._accumulation_index = 0
        solve = ctx.cache.get("solve")
        if solve is not None:
            ctx.metrics.update(
                {
                    "solve_steps": float(solve.steps),
                    "solve_backtracks": float(solve.diagnostics.get("backtracks", 0)),
                    "energy_initial": solve.energies[0],
                    "energy_final": solve.energies[-1],
                    "energy_drop": solve.energy_drop,
                }
            )
        ctx.metrics["amortization_gap"] = float(
            (ctx.losses["loss_deploy_kd"] - ctx.losses["loss_settled_kd"]).detach()
        )
        ctx.metrics["residual_scale"] = float(self.sidecar.residual_scale.detach())
        if ctx.predicted.gate is not None:
            ctx.metrics["mean_active_fibres"] = float(
                (ctx.predicted.gate > 1e-3).to(ctx.predicted.gate).sum(dim=-1).mean()
            )
        for callback in self.callbacks:
            callback.on_step_end(self.step_index, ctx)
        self.step_index += 1
        return ctx

    @torch.no_grad()
    def evaluate_step(
        self,
        batch: Any,
        *,
        context_id: Any = None,
        settle: bool = True,
    ) -> StepContext:
        self.sidecar.eval()
        # State settlement requires gradients with respect to state, so build it
        # outside no_grad when requested.
        if settle:
            with torch.enable_grad():
                ctx = self._build_step(batch, context_id=context_id, settle=True)
            ctx.predicted = ctx.predicted.detached()
            if ctx.settled is not None:
                ctx.settled = ctx.settled.detached()
        else:
            ctx = self._build_step(batch, context_id=context_id, settle=False)
        with torch.no_grad():
            self._outer_losses(ctx)
        solve = ctx.cache.get("solve")
        if solve is not None:
            ctx.metrics.update(
                {
                    "solve_steps": float(solve.steps),
                    "energy_initial": solve.energies[0],
                    "energy_final": solve.energies[-1],
                }
            )
        ctx.metrics["amortization_gap"] = float(
            ctx.losses["loss_deploy_kd"] - ctx.losses["loss_settled_kd"]
        )
        return ctx

    def fit(self, batches: Iterable[Any], *, max_steps: int | None = None) -> list[StepContext]:
        records: list[StepContext] = []
        self.optimizer.zero_grad(set_to_none=True)
        for batch in batches:
            if max_steps is not None and len(records) >= max_steps:
                break
            records.append(self.train_step(batch))
        return records
