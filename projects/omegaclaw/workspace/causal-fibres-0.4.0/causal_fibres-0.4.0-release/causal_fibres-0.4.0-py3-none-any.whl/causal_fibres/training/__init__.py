"""Training engines, losses, callbacks, schedules, and continual-learning tools."""

from .callbacks import (
    CSVLogger,
    Callback,
    FunctionCallback,
    HistoryCallback,
    JsonlLogger,
    NaNGuard,
    ProgressPrinter,
)
from .continual import (
    ContinualLearningRunner,
    RetentionRecord,
    forgetting_from_records,
    function_space_update_commutator,
)
from .distill import DistillationWeights, PartialDistillationTrainer
from .engine import AuditSchedule, CFEEngine, LearningPhase
from .losses import (
    credit_alignment_loss,
    masked_cross_entropy,
    off_support_gradient_fraction,
    predictor_amortization_loss,
    responsibility_cross_entropy,
    router_budget_loss,
    router_entropy,
    symmetric_kl,
    temperature_kl,
)
from .schedules import CosineSchedule, LinearSchedule, PiecewiseSchedule
from .update_rules import AutogradUpdateRule, CallableUpdateRule

__all__ = [
    "Callback",
    "HistoryCallback",
    "JsonlLogger",
    "CSVLogger",
    "ProgressPrinter",
    "NaNGuard",
    "FunctionCallback",
    "ContinualLearningRunner",
    "RetentionRecord",
    "forgetting_from_records",
    "function_space_update_commutator",
    "DistillationWeights",
    "PartialDistillationTrainer",
    "AuditSchedule",
    "CFEEngine",
    "LearningPhase",
    "temperature_kl",
    "symmetric_kl",
    "masked_cross_entropy",
    "predictor_amortization_loss",
    "off_support_gradient_fraction",
    "responsibility_cross_entropy",
    "router_budget_loss",
    "router_entropy",
    "credit_alignment_loss",
    "LinearSchedule",
    "CosineSchedule",
    "PiecewiseSchedule",
    "AutogradUpdateRule",
    "CallableUpdateRule",
]
