from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable, Iterable, Mapping, Sequence

from causal_fibres.core.types import StepContext

from .callbacks import Callback


class LearningPhase(str, Enum):
    OBSERVABILITY = "observability"
    COMPETENCE = "competence"
    SETTLEMENT = "settlement"
    INSTRUMENTATION = "instrumentation"
    SPECIALIZATION = "specialization"
    SPARSIFICATION = "sparsification"
    CONTINUAL = "continual"
    SYMBOLIC = "symbolic"


@dataclass
class AuditSchedule:
    intervention_interval: int = 200
    operator_interval: int = 500
    structure_interval: int = 2000


AuditFn = Callable[[StepContext], Mapping[str, float]]
StepFn = Callable[[Any, LearningPhase], StepContext]


class CFEEngine:
    """Architecture- and learning-rule-independent orchestration shell."""

    def __init__(
        self,
        step_fn: StepFn,
        *,
        phase: LearningPhase = LearningPhase.COMPETENCE,
        schedule: AuditSchedule | None = None,
        intervention_audit: AuditFn | None = None,
        operator_audit: AuditFn | None = None,
        structure_audit: AuditFn | None = None,
        callbacks: Sequence[Callback] = (),
    ) -> None:
        self.step_fn = step_fn
        self.phase = phase
        self.schedule = schedule or AuditSchedule()
        self.intervention_audit = intervention_audit
        self.operator_audit = operator_audit
        self.structure_audit = structure_audit
        self.callbacks = tuple(callbacks)
        self.step_index = 0

    def set_phase(self, phase: LearningPhase) -> None:
        self.phase = phase

    def step(self, batch: Any) -> StepContext:
        ctx = self.step_fn(batch, self.phase)
        ctx.step_index = self.step_index
        ctx.phase = self.phase.value
        step = self.step_index
        if (
            self.intervention_audit is not None
            and self.schedule.intervention_interval > 0
            and step % self.schedule.intervention_interval == 0
        ):
            ctx.metrics.update(self.intervention_audit(ctx))
        if (
            self.operator_audit is not None
            and self.schedule.operator_interval > 0
            and step % self.schedule.operator_interval == 0
        ):
            ctx.metrics.update(self.operator_audit(ctx))
        if (
            self.structure_audit is not None
            and self.schedule.structure_interval > 0
            and step % self.schedule.structure_interval == 0
        ):
            ctx.metrics.update(self.structure_audit(ctx))
        for callback in self.callbacks:
            callback.on_step_end(step, ctx)
        self.step_index += 1
        return ctx

    def run(self, batches: Iterable[Any], *, max_steps: int | None = None) -> list[StepContext]:
        history: list[StepContext] = []
        for batch in batches:
            if max_steps is not None and len(history) >= max_steps:
                break
            history.append(self.step(batch))
        return history
