from __future__ import annotations

import copy
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Mapping

import torch
from torch import nn


@dataclass
class RetentionRecord:
    after_context: str
    losses: dict[str, float]
    metrics: dict[str, float] = field(default_factory=dict)


class ContinualLearningRunner:
    """Small general runner for sequential context experiments."""

    def __init__(
        self,
        train_context: Callable[[str, Iterable[Any]], None],
        evaluate_context: Callable[[str], float],
    ) -> None:
        self.train_context = train_context
        self.evaluate_context = evaluate_context

    def run(self, streams: Mapping[str, Iterable[Any]]) -> list[RetentionRecord]:
        seen: list[str] = []
        records: list[RetentionRecord] = []
        for context_name, batches in streams.items():
            self.train_context(context_name, batches)
            seen.append(context_name)
            losses = {name: float(self.evaluate_context(name)) for name in seen}
            records.append(RetentionRecord(context_name, losses))
        return records


def forgetting_from_records(records: list[RetentionRecord]) -> dict[str, float]:
    best: dict[str, float] = {}
    final: dict[str, float] = {}
    for record in records:
        for context, loss in record.losses.items():
            best[context] = min(best.get(context, float("inf")), loss)
            final[context] = loss
    return {context: final[context] - best[context] for context in final}


def function_space_update_commutator(
    model: nn.Module,
    update_a: Callable[[nn.Module], None],
    update_b: Callable[[nn.Module], None],
    evaluate: Callable[[nn.Module], torch.Tensor],
    distance: Callable[[torch.Tensor, torch.Tensor], torch.Tensor],
) -> float:
    """Measure ``U_B U_A`` versus ``U_A U_B`` without mutating ``model``."""

    model_ab = copy.deepcopy(model)
    model_ba = copy.deepcopy(model)
    update_a(model_ab)
    update_b(model_ab)
    update_b(model_ba)
    update_a(model_ba)
    with torch.no_grad():
        output_ab = evaluate(model_ab)
        output_ba = evaluate(model_ba)
        return float(distance(output_ab, output_ba))
