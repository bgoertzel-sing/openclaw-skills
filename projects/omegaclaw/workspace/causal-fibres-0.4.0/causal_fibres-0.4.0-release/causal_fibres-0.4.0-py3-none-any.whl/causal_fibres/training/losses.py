from __future__ import annotations

import torch
from torch import Tensor
import torch.nn.functional as F


def _masked_mean(values: Tensor, mask: Tensor | None, eps: float = 1e-12) -> Tensor:
    if mask is None:
        return values.mean()
    mask = mask.to(device=values.device, dtype=values.dtype)
    while mask.ndim < values.ndim:
        mask = mask.unsqueeze(-1)
    weighted = values * mask
    return weighted.sum() / mask.expand_as(values).sum().clamp_min(eps)


def temperature_kl(
    student_logits: Tensor,
    teacher_logits: Tensor,
    *,
    temperature: float = 1.0,
    reduction: str = "batchmean",
    mask: Tensor | None = None,
) -> Tensor:
    """Teacher-to-student KL with optional sample/token mask.

    When ``mask`` is supplied, the function computes a per-position KL over the
    final logit dimension and averages only over active positions. Without a
    mask it preserves the historical ``torch.nn.functional.kl_div`` behavior.
    """

    if student_logits.shape != teacher_logits.shape:
        raise ValueError("Student and teacher logits must have identical shape")
    temp = max(float(temperature), 1e-6)
    student = F.log_softmax(student_logits / temp, dim=-1)
    teacher = F.softmax(teacher_logits / temp, dim=-1)
    if mask is None:
        return F.kl_div(student, teacher, reduction=reduction) * temp * temp
    per_position = (teacher * (teacher.clamp_min(1e-12).log() - student)).sum(dim=-1)
    return _masked_mean(per_position, mask) * temp * temp


def symmetric_kl(
    first_logits: Tensor,
    second_logits: Tensor,
    *,
    temperature: float = 1.0,
    mask: Tensor | None = None,
) -> Tensor:
    return 0.5 * (
        temperature_kl(
            first_logits,
            second_logits,
            temperature=temperature,
            mask=mask,
        )
        + temperature_kl(
            second_logits,
            first_logits,
            temperature=temperature,
            mask=mask,
        )
    )


def masked_cross_entropy(
    logits: Tensor,
    labels: Tensor,
    *,
    mask: Tensor | None = None,
    ignore_index: int = -100,
) -> Tensor:
    if logits.shape[:-1] != labels.shape:
        raise ValueError("labels must match logits leading dimensions")
    flat_loss = F.cross_entropy(
        logits.reshape(-1, logits.shape[-1]),
        labels.reshape(-1),
        reduction="none",
        ignore_index=ignore_index,
    ).reshape_as(labels)
    valid = labels.ne(ignore_index)
    if mask is not None:
        valid = valid & mask.to(dtype=torch.bool, device=labels.device)
    if not bool(valid.any()):
        return logits.new_zeros(())
    return flat_loss[valid].mean()


def predictor_amortization_loss(
    predicted: Tensor,
    settled: Tensor,
    *,
    precision: Tensor | float = 1.0,
) -> Tensor:
    difference = predicted - settled.detach()
    if isinstance(precision, Tensor):
        difference = difference * precision.sqrt()
    else:
        difference = difference * float(precision) ** 0.5
    return 0.5 * difference.square().mean()


def absolute_state_energy(state: Tensor, weight: float) -> Tensor:
    return 0.5 * weight * state.square().mean()


def predictor_prior_energy(state: Tensor, prior: Tensor, weight: float) -> Tensor:
    return 0.5 * weight * (state - prior).square().mean()


def off_support_gradient_fraction(
    gradients: Tensor,
    support: Tensor,
    eps: float = 1e-12,
) -> Tensor:
    """Return absolute gradient mass outside the supplied fibre support."""

    if gradients.ndim < 2:
        raise ValueError("gradients must include a fibre axis")
    support = support.to(device=gradients.device, dtype=gradients.dtype)
    while support.ndim < gradients.ndim:
        support = support.unsqueeze(-1)
    outside = gradients.abs() * (1.0 - support)
    return outside.sum() / (gradients.abs().sum() + eps)


def responsibility_cross_entropy(predicted: Tensor, target: Tensor, eps: float = 1e-12) -> Tensor:
    if predicted.shape != target.shape:
        raise ValueError("responsibility tensors must have identical shape")
    target = target / target.sum(dim=-1, keepdim=True).clamp_min(eps)
    return -(target * predicted.clamp_min(eps).log()).sum(dim=-1).mean()


def router_budget_loss(gates: Tensor, target_active: float) -> Tensor:
    return (gates.sum(dim=-1) - target_active).square().mean()


def router_entropy(gates: Tensor, eps: float = 1e-12) -> Tensor:
    return -(gates * gates.clamp_min(eps).log()).sum(dim=-1).mean()


def credit_alignment_loss(
    predicted: Tensor,
    oracle: Tensor,
    *,
    metric: Tensor | None = None,
    cosine_weight: float = 1.0,
) -> Tensor:
    if predicted.shape != oracle.shape:
        raise ValueError("predicted and oracle credit must have identical shape")
    difference = predicted - oracle.detach()
    if metric is not None:
        flat = difference.reshape(-1, difference.shape[-1])
        difference_energy = torch.einsum("nd,dd,nd->n", flat, metric, flat).mean()
    else:
        difference_energy = difference.square().mean()
    pred_flat = predicted.reshape(predicted.shape[0], -1) if predicted.ndim > 1 else predicted[None]
    oracle_flat = oracle.detach().reshape(oracle.shape[0], -1) if oracle.ndim > 1 else oracle.detach()[None]
    cosine = F.cosine_similarity(pred_flat, oracle_flat, dim=-1).mean()
    return difference_energy + cosine_weight * (1.0 - cosine)


def contrastive_template_loss(
    queries: Tensor,
    positive_keys: Tensor,
    negative_keys: Tensor,
    *,
    temperature: float = 0.1,
) -> Tensor:
    """InfoNCE loss for one positive and a set of negatives per query."""

    query = F.normalize(queries, dim=-1)
    positive = F.normalize(positive_keys.to(query), dim=-1)
    negative = F.normalize(negative_keys.to(query), dim=-1)
    positive_score = (query * positive).sum(dim=-1, keepdim=True)
    negative_scores = torch.einsum("...d,...nd->...n", query, negative)
    logits = torch.cat([positive_score, negative_scores], dim=-1) / max(temperature, 1e-6)
    labels = torch.zeros(logits.shape[:-1], dtype=torch.long, device=logits.device)
    return F.cross_entropy(logits.reshape(-1, logits.shape[-1]), labels.reshape(-1))
