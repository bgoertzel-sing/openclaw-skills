from __future__ import annotations

import csv
import json
import math
from pathlib import Path
from typing import Any, Callable, Protocol

from causal_fibres.core.types import StepContext


class Callback(Protocol):
    def on_step_end(self, step: int, ctx: StepContext) -> None: ...


class HistoryCallback:
    def __init__(self) -> None:
        self.history: list[dict[str, Any]] = []

    def on_step_end(self, step: int, ctx: StepContext) -> None:
        row: dict[str, Any] = {"step": step, "phase": ctx.phase, "context_id": ctx.context_id}
        row.update(ctx.metrics)
        row.update(ctx.scalar_losses())
        self.history.append(row)


class JsonlLogger:
    def __init__(self, path: str | Path, *, flush: bool = True) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.flush = flush

    def on_step_end(self, step: int, ctx: StepContext) -> None:
        row: dict[str, Any] = {"step": step, "phase": ctx.phase, "context_id": ctx.context_id}
        row.update(ctx.metrics)
        row.update(ctx.scalar_losses())
        with open(self.path, "a", encoding="utf-8") as handle:
            handle.write(json.dumps(row, default=str, sort_keys=True) + "\n")
            if self.flush:
                handle.flush()


class CSVLogger:
    """Append scalar training rows to CSV.

    The first row determines the column order. Later unseen keys are ignored;
    JSONL is preferable when metrics change dynamically across phases.
    """

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.fieldnames: list[str] | None = None

    def on_step_end(self, step: int, ctx: StepContext) -> None:
        row: dict[str, Any] = {"step": step, "phase": ctx.phase, "context_id": ctx.context_id}
        row.update(ctx.metrics)
        row.update(ctx.scalar_losses())
        if self.fieldnames is None:
            self.fieldnames = list(row)
            with open(self.path, "w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=self.fieldnames)
                writer.writeheader()
                writer.writerow({key: row.get(key) for key in self.fieldnames})
        else:
            with open(self.path, "a", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=self.fieldnames)
                writer.writerow({key: row.get(key) for key in self.fieldnames})


class ProgressPrinter:
    def __init__(self, every: int = 50, keys: tuple[str, ...] = ("loss_total",)) -> None:
        self.every = every
        self.keys = keys

    def on_step_end(self, step: int, ctx: StepContext) -> None:
        if self.every <= 0 or step % self.every:
            return
        values: list[str] = []
        scalar_losses = ctx.scalar_losses()
        for key in self.keys:
            if key in ctx.metrics:
                values.append(f"{key}={ctx.metrics[key]:.5g}")
            elif key in scalar_losses:
                values.append(f"{key}={scalar_losses[key]:.5g}")
        print(f"[causal-fibres step={step}] " + " ".join(values), flush=True)


class NaNGuard:
    def on_step_end(self, step: int, ctx: StepContext) -> None:
        values = {**ctx.metrics, **ctx.scalar_losses()}
        nonfinite = {key: value for key, value in values.items() if not math.isfinite(float(value))}
        if nonfinite:
            raise FloatingPointError(f"Non-finite metrics at step {step}: {nonfinite}")


class FunctionCallback:
    def __init__(self, fn: Callable[[int, StepContext], None]) -> None:
        self.fn = fn

    def on_step_end(self, step: int, ctx: StepContext) -> None:
        self.fn(step, ctx)
