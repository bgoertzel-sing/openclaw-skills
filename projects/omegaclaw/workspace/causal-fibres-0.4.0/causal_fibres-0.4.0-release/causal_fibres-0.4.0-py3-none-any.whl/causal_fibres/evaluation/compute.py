from __future__ import annotations

import time
from collections.abc import Callable, Mapping
from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class ComputePoint:
    step: int
    elapsed_seconds: float
    metrics: dict[str, float]


@dataclass
class MatchedComputeRun:
    name: str
    points: list[ComputePoint]
    steps_completed: int
    elapsed_seconds: float
    final_metrics: dict[str, float]

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "points": [asdict(point) for point in self.points],
            "steps_completed": self.steps_completed,
            "elapsed_seconds": self.elapsed_seconds,
            "final_metrics": dict(self.final_metrics),
        }


class MatchedComputeEvaluator:
    """Run methods under matched update or wall-clock budgets."""

    def __init__(self, *, log_interval: int = 10) -> None:
        if log_interval <= 0:
            raise ValueError("log_interval must be positive")
        self.log_interval = log_interval

    def run(
        self,
        name: str,
        *,
        step_fn: Callable[[int], Mapping[str, float] | None],
        evaluate_fn: Callable[[], Mapping[str, float]],
        max_steps: int,
        wall_clock_seconds: float | None = None,
    ) -> MatchedComputeRun:
        if max_steps <= 0:
            raise ValueError("max_steps must be positive")
        if wall_clock_seconds is not None and wall_clock_seconds <= 0:
            raise ValueError("wall_clock_seconds must be positive")
        start = time.perf_counter()
        points: list[ComputePoint] = []
        completed = 0
        for step in range(1, max_steps + 1):
            step_fn(step)
            completed = step
            elapsed = time.perf_counter() - start
            if step % self.log_interval == 0 or step == max_steps:
                points.append(
                    ComputePoint(
                        step=step,
                        elapsed_seconds=elapsed,
                        metrics={key: float(value) for key, value in evaluate_fn().items()},
                    )
                )
            if wall_clock_seconds is not None and elapsed >= wall_clock_seconds:
                break
        elapsed = time.perf_counter() - start
        final = {key: float(value) for key, value in evaluate_fn().items()}
        if not points or points[-1].step != completed:
            points.append(ComputePoint(completed, elapsed, final))
        return MatchedComputeRun(name, points, completed, elapsed, final)

    def compare(
        self,
        methods: Mapping[
            str,
            tuple[
                Callable[[int], Mapping[str, float] | None],
                Callable[[], Mapping[str, float]],
            ],
        ],
        *,
        max_steps: int,
        wall_clock_seconds: float | None = None,
    ) -> dict[str, MatchedComputeRun]:
        return {
            name: self.run(
                name,
                step_fn=step_fn,
                evaluate_fn=evaluate_fn,
                max_steps=max_steps,
                wall_clock_seconds=wall_clock_seconds,
            )
            for name, (step_fn, evaluate_fn) in methods.items()
        }
