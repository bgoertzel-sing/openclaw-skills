from __future__ import annotations

from dataclasses import asdict, dataclass

import torch
from torch import Tensor


@dataclass
class RoutingMetrics:
    precision: float
    recall: float
    f1: float
    exact_support_accuracy: float
    off_support_mass: float
    support_mass: float

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


@dataclass
class NovelContextRoutingReport:
    training: RoutingMetrics
    held_out: RoutingMetrics

    @property
    def f1_generalization_gap(self) -> float:
        return self.training.f1 - self.held_out.f1

    def to_dict(self) -> dict[str, object]:
        return {
            "training": self.training.to_dict(),
            "held_out": self.held_out.to_dict(),
            "f1_generalization_gap": self.f1_generalization_gap,
        }


def routing_metrics(
    responsibility: Tensor,
    true_support: Tensor,
    *,
    top_k: int | None = None,
    threshold: float = 0.5,
) -> RoutingMetrics:
    if responsibility.shape != true_support.shape:
        raise ValueError("responsibility and true_support must have the same shape")
    support = true_support.to(dtype=torch.bool, device=responsibility.device)
    if top_k is None:
        predicted = responsibility >= threshold
    else:
        if not 0 < top_k <= responsibility.shape[-1]:
            raise ValueError("invalid top_k")
        indices = torch.topk(responsibility, k=top_k, dim=-1).indices
        predicted = torch.zeros_like(responsibility, dtype=torch.bool)
        predicted.scatter_(-1, indices, True)
    true_positive = (predicted & support).sum().to(torch.float32)
    false_positive = (predicted & ~support).sum().to(torch.float32)
    false_negative = (~predicted & support).sum().to(torch.float32)
    precision = true_positive / (true_positive + false_positive).clamp_min(1.0)
    recall = true_positive / (true_positive + false_negative).clamp_min(1.0)
    f1 = 2 * precision * recall / (precision + recall).clamp_min(1e-12)
    exact = (predicted == support).all(dim=-1).to(torch.float32).mean()
    total_mass = responsibility.abs().sum().clamp_min(1e-12)
    off_mass = (responsibility.abs() * (~support).to(responsibility)).sum() / total_mass
    on_mass = (responsibility.abs() * support.to(responsibility)).sum() / total_mass
    return RoutingMetrics(
        precision=float(precision),
        recall=float(recall),
        f1=float(f1),
        exact_support_accuracy=float(exact),
        off_support_mass=float(off_mass),
        support_mass=float(on_mass),
    )


class NovelContextRoutingEvaluator:
    def evaluate(
        self,
        *,
        training_responsibility: Tensor,
        training_support: Tensor,
        held_out_responsibility: Tensor,
        held_out_support: Tensor,
        top_k: int | None = None,
        threshold: float = 0.5,
    ) -> NovelContextRoutingReport:
        return NovelContextRoutingReport(
            training=routing_metrics(
                training_responsibility,
                training_support,
                top_k=top_k,
                threshold=threshold,
            ),
            held_out=routing_metrics(
                held_out_responsibility,
                held_out_support,
                top_k=top_k,
                threshold=threshold,
            ),
        )
