from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import asdict, dataclass
from enum import Enum
from typing import Any

from torch import Tensor


class SettlementMode(str, Enum):
    PREDICTOR = "predictor_only"
    FREE = "free_settlement"
    CONSTRAINED = "constrained_settlement"
    CLAMPED = "teacher_clamped_diagnostic"


@dataclass
class SettlementEvaluation:
    losses: dict[str, float]
    predictor_to_free_gain: float | None
    predictor_to_constrained_gain: float | None
    amortization_gap: float | None
    metadata: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class FreeSettlementEvaluator:
    """Keep deployment, free inference, constrained inference, and oracle clamping distinct."""

    def __init__(self, loss_fn: Callable[[Tensor], Tensor]) -> None:
        self.loss_fn = loss_fn

    def evaluate(
        self,
        *,
        predictor_fn: Callable[[], Tensor],
        free_fn: Callable[[], Tensor] | None = None,
        constrained_fn: Callable[[], Tensor] | None = None,
        clamped_fn: Callable[[], Tensor] | None = None,
        metadata: Mapping[str, Any] | None = None,
    ) -> SettlementEvaluation:
        outputs: dict[SettlementMode, Tensor] = {SettlementMode.PREDICTOR: predictor_fn()}
        if free_fn is not None:
            outputs[SettlementMode.FREE] = free_fn()
        if constrained_fn is not None:
            outputs[SettlementMode.CONSTRAINED] = constrained_fn()
        if clamped_fn is not None:
            outputs[SettlementMode.CLAMPED] = clamped_fn()
        losses = {
            mode.value: float(self.loss_fn(output).detach())
            for mode, output in outputs.items()
        }
        predictor_loss = losses[SettlementMode.PREDICTOR.value]
        free_loss = losses.get(SettlementMode.FREE.value)
        constrained_loss = losses.get(SettlementMode.CONSTRAINED.value)
        clamped_loss = losses.get(SettlementMode.CLAMPED.value)
        return SettlementEvaluation(
            losses=losses,
            predictor_to_free_gain=(
                None if free_loss is None else predictor_loss - free_loss
            ),
            predictor_to_constrained_gain=(
                None if constrained_loss is None else predictor_loss - constrained_loss
            ),
            amortization_gap=(
                None if clamped_loss is None else predictor_loss - clamped_loss
            ),
            metadata={
                **dict(metadata or {}),
                "warning": (
                    "teacher_clamped_diagnostic is an oracle diagnostic and must not be "
                    "reported as deployment performance"
                ),
            },
        )
