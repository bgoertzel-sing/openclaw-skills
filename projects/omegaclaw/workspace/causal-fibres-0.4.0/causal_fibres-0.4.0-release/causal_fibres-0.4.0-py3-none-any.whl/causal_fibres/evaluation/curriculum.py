from __future__ import annotations

import copy
from collections.abc import Callable, Hashable, Mapping, Sequence
from dataclasses import asdict, dataclass
from typing import Any

import torch
from torch import Tensor, nn

from causal_fibres.training.losses import symmetric_kl


@dataclass
class CurriculumOutput:
    sequence: tuple[Hashable, ...]
    output: Tensor
    metrics: dict[str, float]


@dataclass
class FiniteCurriculumReport:
    outputs: dict[str, CurriculumOutput]
    pairwise_distances: dict[str, float]
    maximum_order_distance: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "outputs": {
                name: {
                    "sequence": list(value.sequence),
                    "metrics": dict(value.metrics),
                }
                for name, value in self.outputs.items()
            },
            "pairwise_distances": dict(self.pairwise_distances),
            "maximum_order_distance": self.maximum_order_distance,
        }


class FiniteCurriculumLoopEvaluator:
    """Measure actual finite order dependence over complete update sequences.

    This complements local Hessian or Lie-bracket diagnostics.  By default only
    model state is snapshotted; callers with persistent optimizer state should
    supply custom ``snapshot_fn`` and ``restore_fn``.
    """

    def __init__(
        self,
        model: nn.Module,
        *,
        update_fn: Callable[[nn.Module, Hashable], Mapping[str, float] | None],
        output_fn: Callable[[nn.Module], Tensor],
        distance_fn: Callable[[Tensor, Tensor], Tensor] | None = None,
        snapshot_fn: Callable[[], Any] | None = None,
        restore_fn: Callable[[Any], None] | None = None,
    ) -> None:
        self.model = model
        self.update_fn = update_fn
        self.output_fn = output_fn
        self.distance_fn = distance_fn or (lambda first, second: symmetric_kl(first, second))
        self.snapshot_fn = snapshot_fn or self._default_snapshot
        self.restore_fn = restore_fn or self._default_restore

    def _default_snapshot(self) -> dict[str, Tensor]:
        return {name: tensor.detach().clone() for name, tensor in self.model.state_dict().items()}

    def _default_restore(self, state: Mapping[str, Tensor]) -> None:
        self.model.load_state_dict(state)

    def evaluate(
        self,
        sequences: Mapping[str, Sequence[Hashable]],
    ) -> FiniteCurriculumReport:
        if len(sequences) < 2:
            raise ValueError("At least two curriculum sequences are required")
        initial = self.snapshot_fn()
        outputs: dict[str, CurriculumOutput] = {}
        try:
            for name, sequence in sequences.items():
                self.restore_fn(copy.deepcopy(initial))
                metrics: dict[str, float] = {}
                for position, context in enumerate(sequence):
                    values = self.update_fn(self.model, context)
                    if values:
                        metrics.update(
                            {f"step_{position}/{key}": float(value) for key, value in values.items()}
                        )
                with torch.no_grad():
                    output = self.output_fn(self.model).detach().clone()
                outputs[name] = CurriculumOutput(tuple(sequence), output, metrics)
        finally:
            self.restore_fn(initial)
        names = list(outputs)
        distances: dict[str, float] = {}
        maximum = 0.0
        for first_index, first_name in enumerate(names):
            for second_name in names[first_index + 1 :]:
                distance = float(
                    self.distance_fn(outputs[first_name].output, outputs[second_name].output).detach()
                )
                key = f"{first_name}__vs__{second_name}"
                distances[key] = distance
                maximum = max(maximum, distance)
        return FiniteCurriculumReport(outputs, distances, maximum)
