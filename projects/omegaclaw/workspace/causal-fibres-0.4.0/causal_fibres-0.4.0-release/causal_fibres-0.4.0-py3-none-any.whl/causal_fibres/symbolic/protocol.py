from __future__ import annotations

from typing import Any, Protocol

from torch import Tensor


class TemplateStore(Protocol):
    def query(self, keys: Tensor, top_k: int) -> tuple[Tensor, Tensor, Tensor]:
        """Return scores, selected template keys, and selected values."""
        ...

    def metadata(self, indices: Tensor) -> Any:
        """Optional metadata lookup. Implementations may raise NotImplementedError."""
        ...
