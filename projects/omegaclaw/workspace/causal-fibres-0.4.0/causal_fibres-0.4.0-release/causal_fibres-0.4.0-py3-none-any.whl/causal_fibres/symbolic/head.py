from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import Tensor, nn
import torch.nn.functional as F

from .protocol import TemplateStore


@dataclass
class SymbolicHeadOutput:
    queries: Tensor
    attention: Tensor
    summary: Tensor
    feedback: Tensor
    scores: Tensor | None = None


class SymbolicFibreHead(nn.Module):
    """Project canonical fibre states into a template key space."""

    def __init__(
        self,
        n_fibres: int,
        fibre_dim: int,
        key_dim: int,
        value_dim: int,
        *,
        top_k: int = 4,
        temperature: float = 1.0,
        feedback_scale: float = 1.0,
    ) -> None:
        super().__init__()
        self.n_fibres = n_fibres
        self.fibre_dim = fibre_dim
        self.key_dim = key_dim
        self.value_dim = value_dim
        self.top_k = top_k
        self.temperature = temperature
        self.feedback_scale = feedback_scale
        self.query_weight = nn.Parameter(torch.empty(n_fibres, fibre_dim, key_dim))
        self.query_bias = nn.Parameter(torch.zeros(n_fibres, key_dim))
        self.value_to_fibre = nn.Parameter(torch.empty(n_fibres, value_dim, fibre_dim))
        nn.init.normal_(self.query_weight, std=fibre_dim**-0.5)
        nn.init.normal_(self.value_to_fibre, std=value_dim**-0.5)

    def queries(self, state: Tensor) -> Tensor:
        if state.shape[-2:] != (self.n_fibres, self.fibre_dim):
            raise ValueError("Unexpected fibre state shape")
        return torch.einsum("...qr,qrk->...qk", state, self.query_weight) + self.query_bias

    def retrieve(self, state: Tensor, store: TemplateStore) -> SymbolicHeadOutput:
        query = self.queries(state)
        scores, _keys, values = store.query(query, self.top_k)
        attention = torch.softmax(scores / max(self.temperature, 1e-6), dim=-1)
        summary = torch.einsum("...qm,...qmv->...qv", attention, values)
        feedback = self.feedback_scale * torch.einsum(
            "...qv,qvr->...qr", summary, self.value_to_fibre
        )
        return SymbolicHeadOutput(query, attention, summary, feedback, scores=scores)

    def supervised_key_loss(self, state: Tensor, target_keys: Tensor, mask: Tensor | None = None) -> Tensor:
        query = F.normalize(self.queries(state), dim=-1)
        target = F.normalize(target_keys.to(query), dim=-1)
        loss = 1.0 - (query * target).sum(dim=-1)
        if mask is None:
            return loss.mean()
        mask = mask.to(loss)
        return (loss * mask).sum() / mask.sum().clamp_min(1.0)

    def contrastive_loss(
        self,
        state: Tensor,
        positive_keys: Tensor,
        negative_keys: Tensor,
        *,
        temperature: float = 0.1,
    ) -> Tensor:
        query = F.normalize(self.queries(state), dim=-1)
        positive = F.normalize(positive_keys.to(query), dim=-1)
        negative = F.normalize(negative_keys.to(query), dim=-1)
        positive_score = (query * positive).sum(dim=-1, keepdim=True)
        negative_scores = torch.einsum("...qd,...qnd->...qn", query, negative)
        logits = torch.cat([positive_score, negative_scores], dim=-1) / max(temperature, 1e-6)
        labels = torch.zeros(logits.shape[:-1], dtype=torch.long, device=logits.device)
        return F.cross_entropy(logits.reshape(-1, logits.shape[-1]), labels.reshape(-1))
