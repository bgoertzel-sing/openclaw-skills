from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any

import torch
from torch import Tensor
import torch.nn.functional as F


class StaticTemplateStore:
    """In-memory dense template store for tests and first GPU experiments."""

    def __init__(
        self,
        keys: Tensor,
        values: Tensor,
        *,
        normalize: bool = True,
        records: Iterable[Mapping[str, Any]] | None = None,
    ) -> None:
        if keys.ndim != 2 or values.ndim != 2 or keys.shape[0] != values.shape[0]:
            raise ValueError("keys and values must be [templates, dim] with equal template count")
        self.keys = F.normalize(keys, dim=-1) if normalize else keys
        self.values = values
        self.normalize = normalize
        self.records = list(records or ({"template_id": index} for index in range(keys.shape[0])))
        if len(self.records) != keys.shape[0]:
            raise ValueError("records must match template count")

    @property
    def size(self) -> int:
        return int(self.keys.shape[0])

    def query_with_indices(self, keys: Tensor, top_k: int) -> tuple[Tensor, Tensor, Tensor, Tensor]:
        if self.size == 0:
            raise RuntimeError("Template store is empty")
        query = F.normalize(keys, dim=-1) if self.normalize else keys
        scores = torch.einsum("...d,nd->...n", query, self.keys.to(query))
        top_k = min(top_k, self.keys.shape[0])
        selected_scores, indices = torch.topk(scores, top_k, dim=-1)
        selected_keys = self.keys.to(query)[indices]
        selected_values = self.values.to(query)[indices]
        return selected_scores, selected_keys, selected_values, indices

    def query(self, keys: Tensor, top_k: int) -> tuple[Tensor, Tensor, Tensor]:
        scores, selected_keys, selected_values, _ = self.query_with_indices(keys, top_k)
        return scores, selected_keys, selected_values

    def metadata(self, indices: Tensor) -> Any:
        flat = indices.detach().cpu().reshape(-1).tolist()
        selected = [self.records[int(index)] for index in flat]
        shape = tuple(indices.shape)
        if not shape:
            return selected[0]
        # Metadata remains a nested Python list rather than a tensor.
        result: Any = selected
        for axis in reversed(shape[1:]):
            result = [result[i : i + axis] for i in range(0, len(result), axis)]
        return result

    def to(self, device: torch.device | str, dtype: torch.dtype | None = None) -> "StaticTemplateStore":
        self.keys = self.keys.to(device=device, dtype=dtype or self.keys.dtype)
        self.values = self.values.to(device=device, dtype=dtype or self.values.dtype)
        return self


class MutableTemplateStore(StaticTemplateStore):
    """Dense store that supports controlled online additions."""

    @torch.no_grad()
    def add(
        self,
        keys: Tensor,
        values: Tensor,
        records: Iterable[Mapping[str, Any]] | None = None,
    ) -> list[int]:
        if keys.ndim == 1:
            keys = keys.unsqueeze(0)
        if values.ndim == 1:
            values = values.unsqueeze(0)
        if keys.ndim != 2 or values.ndim != 2 or keys.shape[0] != values.shape[0]:
            raise ValueError("new keys and values must be [templates, dim]")
        if keys.shape[1] != self.keys.shape[1] or values.shape[1] != self.values.shape[1]:
            raise ValueError("new template dimensions must match the store")
        start = self.size
        new_keys = F.normalize(keys.to(self.keys), dim=-1) if self.normalize else keys.to(self.keys)
        self.keys = torch.cat([self.keys, new_keys], dim=0)
        self.values = torch.cat([self.values, values.to(self.values)], dim=0)
        supplied = list(records or ())
        if supplied and len(supplied) != keys.shape[0]:
            raise ValueError("records must match the number of new templates")
        if not supplied:
            supplied = [{"template_id": start + i} for i in range(keys.shape[0])]
        self.records.extend(supplied)
        return list(range(start, self.size))
