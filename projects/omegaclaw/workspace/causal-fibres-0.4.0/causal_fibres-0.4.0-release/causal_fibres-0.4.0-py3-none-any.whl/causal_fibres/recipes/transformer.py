from __future__ import annotations

from collections.abc import Mapping

import torch
from torch import Tensor, nn

from causal_fibres.core.config import CFEConfig
from causal_fibres.credit.router import KnownSupportRouter, SoftTopKRouter
from causal_fibres.fibres.bank import IndependentFibrePredictor, LinearFibreBank, MultiSiteFibrePredictor
from causal_fibres.fibres.pooling import IdentityPooler
from causal_fibres.fibres.sidecar import TerminalFibreSidecar
from causal_fibres.solvers import (
    GradientPCSolver,
    LevenbergMarquardtPCSolver,
    NoOpStateSolver,
    PreconditionedPCSolver,
)


def build_router(
    kind: str,
    n_fibres: int,
    fibre_dim: int,
    *,
    top_k: int | None = 2,
    temperature: float = 2.0,
    straight_through: bool = False,
) -> nn.Module | None:
    if kind == "none":
        return None
    if kind == "known_support":
        return KnownSupportRouter(normalize=False)
    if kind == "soft_topk":
        return SoftTopKRouter(
            n_fibres,
            fibre_dim,
            top_k=top_k,
            temperature=temperature,
            straight_through=straight_through,
        )
    raise ValueError(f"Router kind {kind!r} requires application-specific inputs")


def build_solver(config: CFEConfig):
    solver = config.solver
    if solver.kind == "none":
        return NoOpStateSolver()
    if solver.kind == "gradient_pc":
        return GradientPCSolver(
            steps=solver.steps,
            step_size=solver.step_size,
            tolerance=solver.tolerance,
            backtracking=solver.backtracking,
            max_backtracks=solver.max_backtracks,
        )
    if solver.kind == "preconditioned_pc":
        return PreconditionedPCSolver(
            steps=solver.steps,
            step_size=solver.step_size,
            tolerance=solver.tolerance,
            max_backtracks=solver.max_backtracks,
        )
    if solver.kind == "lm_pc":
        return LevenbergMarquardtPCSolver(
            steps=solver.steps,
            damping=solver.damping,
            tolerance=solver.tolerance,
            cg_max_iter=solver.cg_max_iter,
            max_attempts=solver.max_backtracks,
        )
    raise ValueError(f"Unknown solver kind: {solver.kind}")


def build_terminal_transformer_sidecar(
    site_widths: Mapping[str, int],
    output_dim: int,
    *,
    n_fibres: int = 8,
    fibre_dim: int = 16,
    predictor_hidden_dim: int | None = 128,
    predictor_fusion: str = "weighted_sum",
    site_poolers: Mapping[str, nn.Module] | None = None,
    top_k: int | None = 2,
    router_temperature: float = 2.0,
    residual_scale: float = 0.0,
    trainable_scale: bool = True,
    fixed_weight: Tensor | None = None,
    output_mask: Tensor | None = None,
    router_kind: str = "soft_topk",
) -> TerminalFibreSidecar:
    """Build a conservative frozen-Transformer terminal sidecar."""

    predictor = MultiSiteFibrePredictor(
        site_widths,
        n_fibres,
        fibre_dim,
        hidden_dim=predictor_hidden_dim,
        fusion=predictor_fusion,
        site_poolers=site_poolers or {name: IdentityPooler() for name in site_widths},
    )
    writer = LinearFibreBank(
        n_fibres,
        fibre_dim,
        output_dim,
        fixed_weight=fixed_weight,
        output_mask=output_mask,
    )
    router = build_router(
        router_kind,
        n_fibres,
        fibre_dim,
        top_k=top_k,
        temperature=router_temperature,
    )
    return TerminalFibreSidecar(
        predictor,
        writer,
        router,
        residual_scale=residual_scale,
        trainable_scale=trainable_scale,
    )


def build_terminal_sidecar_from_config(
    site_widths: Mapping[str, int],
    output_dim: int,
    config: CFEConfig,
    *,
    site_poolers: Mapping[str, nn.Module] | None = None,
) -> TerminalFibreSidecar:
    config.validate()
    return build_terminal_transformer_sidecar(
        site_widths,
        output_dim,
        n_fibres=config.fibre.n_fibres,
        fibre_dim=config.fibre.fibre_dim,
        predictor_hidden_dim=config.fibre.predictor_hidden_dim,
        predictor_fusion=config.fibre.predictor_fusion,
        site_poolers=site_poolers,
        top_k=config.router.top_k,
        router_temperature=config.router.temperature,
        residual_scale=config.fibre.residual_scale,
        trainable_scale=config.fibre.trainable_scale,
        router_kind=config.router.kind,
    )


def canonical_binary_factor_write(
    n_factors: int,
    *,
    negative_scale: float = -0.5,
    positive_scale: float = 0.5,
    device: torch.device | str | None = None,
    dtype: torch.dtype = torch.float32,
) -> Tensor:
    """Create fixed one-dimensional writes for independent binary factors.

    The output layout is ``[factor0_class0, factor0_class1, factor1_class0, ...]``.
    """

    weight = torch.zeros(n_factors, 1, 2 * n_factors, device=device, dtype=dtype)
    for factor in range(n_factors):
        weight[factor, 0, 2 * factor] = negative_scale
        weight[factor, 0, 2 * factor + 1] = positive_scale
    return weight


def build_canonical_binary_factor_sidecar(
    site_widths: Mapping[str, int],
    n_factors: int,
    *,
    predictor_hidden_dim: int | None = 128,
    site_poolers: Mapping[str, nn.Module] | None = None,
    residual_scale: float = 1.0,
    known_support: bool = True,
) -> TerminalFibreSidecar:
    fixed_weight = canonical_binary_factor_write(n_factors)
    predictor = IndependentFibrePredictor(
        site_widths,
        n_factors,
        1,
        hidden_dim=predictor_hidden_dim,
        site_poolers=site_poolers,
    )
    writer = LinearFibreBank(
        n_factors,
        1,
        2 * n_factors,
        fixed_weight=fixed_weight,
    )
    router = KnownSupportRouter(normalize=False) if known_support else None
    return TerminalFibreSidecar(
        predictor,
        writer,
        router,
        residual_scale=residual_scale,
        trainable_scale=False,
    )
