from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Sequence

from torch import nn

from causal_fibres.core import CFEConfig, RepresentationConfig
from causal_fibres.representations import (
    ContextualFibreBundle,
    DenseResidualRepresentation,
    GroupedSparseDictionary,
    OrthogonalFibreRepresentation,
    SparseAutoencoder,
)


class StructuralStage(str, Enum):
    OBSERVABILITY = "observability"
    REPRESENTATION_CONTEST = "representation_contest"
    GATED_PLASTICITY = "gated_plasticity"
    SUBSTRATE_COADAPTATION = "substrate_coadaptation"
    PC_CONSTRAINTS = "pc_constraints"
    LEARNED_HIGHWAY = "learned_highway"
    SYMBOLIC_CAP = "symbolic_cap"


@dataclass
class StageGate:
    allowed: bool
    reasons: list[str]


def default_groups(dictionary_size: int, group_count: int, *, overlap: int = 0) -> list[list[int]]:
    if dictionary_size <= 0 or group_count <= 0:
        raise ValueError("dictionary_size and group_count must be positive")
    groups: list[list[int]] = []
    base = max(1, dictionary_size // group_count)
    for group in range(group_count):
        start = group * base
        end = dictionary_size if group == group_count - 1 else min(dictionary_size, (group + 1) * base)
        indices = list(range(max(0, start - overlap), min(dictionary_size, end + overlap)))
        groups.append(indices)
    return groups


def build_representation(
    config: RepresentationConfig,
    *,
    input_dim: int,
    n_fibres: int = 8,
    fibre_dim: int = 4,
    groups: Sequence[Sequence[int]] | None = None,
) -> nn.Module:
    config.validate()
    if config.kind == "dense":
        return DenseResidualRepresentation(input_dim, config.code_dim)
    if config.kind == "sae":
        return SparseAutoencoder(
            input_dim,
            config.dictionary_size,
            top_k=config.top_k,
            sparsity_weight=config.sparsity_weight,
        )
    if config.kind == "grouped_sae":
        return GroupedSparseDictionary(
            input_dim,
            config.dictionary_size,
            groups or default_groups(config.dictionary_size, config.group_count, overlap=1),
            top_k=config.top_k,
            sparsity_weight=config.sparsity_weight,
            group_sparsity_weight=config.group_sparsity_weight,
        )
    if config.kind == "orthogonal":
        return OrthogonalFibreRepresentation(input_dim, n_fibres, fibre_dim)
    if config.kind == "contextual_bundle":
        if config.context_dim is None:
            raise ValueError("contextual_bundle requires representation.context_dim")
        return ContextualFibreBundle(
            input_dim,
            n_fibres,
            fibre_dim,
            config.context_dim,
            transport_strength=config.transport_strength,
        )
    raise AssertionError("unreachable")


def stage_gate(
    stage: StructuralStage,
    *,
    observability_gap_closure: float | None = None,
    representation_has_winner: bool | None = None,
    learned_support_f1: float | None = None,
    constrained_settlement_gain: float | None = None,
    exact_gradient_is_bottleneck: bool = False,
) -> StageGate:
    reasons: list[str] = []
    if stage != StructuralStage.OBSERVABILITY:
        if observability_gap_closure is None or observability_gap_closure < 0.5:
            reasons.append("The frozen-read observability control has not closed at least 50% of the teacher gap.")
    if stage in {
        StructuralStage.GATED_PLASTICITY,
        StructuralStage.SUBSTRATE_COADAPTATION,
        StructuralStage.PC_CONSTRAINTS,
        StructuralStage.LEARNED_HIGHWAY,
        StructuralStage.SYMBOLIC_CAP,
    } and not representation_has_winner:
        reasons.append("No structured representation has survived the matched-budget representation contest.")
    if stage in {
        StructuralStage.PC_CONSTRAINTS,
        StructuralStage.LEARNED_HIGHWAY,
        StructuralStage.SYMBOLIC_CAP,
    } and (learned_support_f1 is None or learned_support_f1 < 0.7):
        reasons.append("Learned support routing has not generalized sufficiently to held-out contexts.")
    if stage == StructuralStage.LEARNED_HIGHWAY and not exact_gradient_is_bottleneck:
        reasons.append("A learned highway is not justified while exact residual credit remains cheap and available.")
    if stage == StructuralStage.SYMBOLIC_CAP and (
        constrained_settlement_gain is None or constrained_settlement_gain <= 0
    ):
        reasons.append("No deployment-time gain from additional constraints or retrieval has been established.")
    return StageGate(allowed=not reasons, reasons=reasons)


def recommended_stage(config: CFEConfig) -> StructuralStage:
    if config.substrate.kind == "low_rank":
        return StructuralStage.SUBSTRATE_COADAPTATION
    if config.solver.kind != "none":
        return StructuralStage.PC_CONSTRAINTS
    if config.credit.kind in {"causal_highway", "blend"}:
        return StructuralStage.LEARNED_HIGHWAY
    return StructuralStage.REPRESENTATION_CONTEST
