"""Reference builders and experiment recipes."""

from .transformer import (
    build_canonical_binary_factor_sidecar,
    build_router,
    build_solver,
    build_terminal_sidecar_from_config,
    build_terminal_transformer_sidecar,
    canonical_binary_factor_write,
)

__all__ = [
    "build_router",
    "build_solver",
    "build_terminal_transformer_sidecar",
    "build_terminal_sidecar_from_config",
    "canonical_binary_factor_write",
    "build_canonical_binary_factor_sidecar",
]

from .structural import (
    StageGate,
    StructuralStage,
    build_representation,
    default_groups,
    recommended_stage,
    stage_gate,
)

__all__ += [
    "StructuralStage",
    "StageGate",
    "default_groups",
    "build_representation",
    "stage_gate",
    "recommended_stage",
]
