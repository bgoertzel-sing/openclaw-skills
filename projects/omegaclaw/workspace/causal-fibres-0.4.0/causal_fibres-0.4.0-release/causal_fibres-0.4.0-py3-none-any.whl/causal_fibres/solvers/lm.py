from __future__ import annotations

import math

import torch
from torch import Tensor

from causal_fibres.core.types import SolveResult

from .base import BaseStateSolver, EnergyFn
from .preconditioned import CGInfo, conjugate_gradient


class LevenbergMarquardtPCSolver(BaseStateSolver):
    """Adaptive damped second-order PC settlement.

    The solver uses Hessian-vector products and conjugate gradient, so it is
    matrix-free. It behaves like a trust-region Levenberg--Marquardt method:
    unsuccessful quadratic steps increase damping, while accurate steps reduce
    it. For non-convex state energies the damping also protects CG from
    non-positive curvature.
    """

    def __init__(
        self,
        *,
        steps: int = 4,
        damping: float = 0.1,
        minimum_damping: float = 1e-6,
        maximum_damping: float = 1e6,
        damping_increase: float = 4.0,
        damping_decrease: float = 0.5,
        acceptance_threshold: float = 1e-4,
        good_step_threshold: float = 0.75,
        poor_step_threshold: float = 0.25,
        tolerance: float = 1e-5,
        cg_max_iter: int = 32,
        cg_tolerance: float = 1e-6,
        max_attempts: int = 6,
        fallback_step_size: float = 1e-2,
    ) -> None:
        self.steps = steps
        self.damping = damping
        self.minimum_damping = minimum_damping
        self.maximum_damping = maximum_damping
        self.damping_increase = damping_increase
        self.damping_decrease = damping_decrease
        self.acceptance_threshold = acceptance_threshold
        self.good_step_threshold = good_step_threshold
        self.poor_step_threshold = poor_step_threshold
        self.tolerance = tolerance
        self.cg_max_iter = cg_max_iter
        self.cg_tolerance = cg_tolerance
        self.max_attempts = max_attempts
        self.fallback_step_size = fallback_step_size

    def solve(
        self,
        initial: Tensor,
        energy_fn: EnergyFn,
        *,
        create_graph: bool = False,
    ) -> SolveResult:
        if create_graph:
            raise NotImplementedError(
                "LevenbergMarquardtPCSolver is intended for detached state settlement"
            )
        state = initial.detach().requires_grad_(True)
        damping = float(self.damping)
        energies: list[float] = []
        damping_history: list[float] = []
        rho_history: list[float] = []
        gradient_norms: list[float] = []
        cg_history: list[dict[str, float | int | bool]] = []
        rejected = 0
        converged = False

        for _ in range(self.steps):
            energy = energy_fn(state)
            if energy.ndim:
                energy = energy.mean()
            current = float(energy.detach())
            energies.append(current)
            gradient = torch.autograd.grad(energy, state, create_graph=True)[0]
            gradient_detached = gradient.detach()
            grad_norm = float(gradient_detached.norm())
            gradient_norms.append(grad_norm)
            if not math.isfinite(grad_norm):
                raise FloatingPointError("Non-finite LM state gradient")
            if grad_norm <= self.tolerance:
                converged = True
                break

            def raw_hvp(vector: Tensor) -> Tensor:
                product = (gradient * vector).sum()
                value = torch.autograd.grad(product, state, retain_graph=True)[0]
                return value.detach()

            accepted = False
            chosen_candidate = state
            chosen_rho = float("nan")
            chosen_info = CGInfo(0, grad_norm, False)
            for _attempt in range(self.max_attempts):
                current_damping = damping

                def matvec(vector: Tensor) -> Tensor:
                    return raw_hvp(vector) + current_damping * vector

                direction, info = conjugate_gradient(
                    matvec,
                    gradient_detached,
                    max_iter=self.cg_max_iter,
                    tolerance=self.cg_tolerance,
                    return_info=True,
                )
                assert isinstance(info, CGInfo)
                if info.nonpositive_curvature or not torch.isfinite(direction).all():
                    direction = self.fallback_step_size * gradient_detached
                candidate = state - direction
                candidate_energy = energy_fn(candidate)
                if candidate_energy.ndim:
                    candidate_energy = candidate_energy.mean()
                actual_reduction = current - float(candidate_energy.detach())
                raw_curvature = raw_hvp(direction)
                predicted_reduction = float(
                    (gradient_detached * direction).sum()
                    - 0.5 * (direction * raw_curvature).sum()
                )
                rho = (
                    actual_reduction / predicted_reduction
                    if predicted_reduction > 1e-12
                    else float("-inf")
                )
                chosen_rho = rho
                chosen_info = info
                if actual_reduction > 0 and rho >= self.acceptance_threshold:
                    chosen_candidate = candidate
                    accepted = True
                    if rho >= self.good_step_threshold:
                        damping = max(self.minimum_damping, damping * self.damping_decrease)
                    elif rho < self.poor_step_threshold:
                        damping = min(self.maximum_damping, damping * self.damping_increase)
                    break
                damping = min(self.maximum_damping, damping * self.damping_increase)
                rejected += 1

            damping_history.append(damping)
            rho_history.append(chosen_rho)
            cg_history.append(
                {
                    "iterations": chosen_info.iterations,
                    "residual_norm": chosen_info.residual_norm,
                    "converged": chosen_info.converged,
                    "nonpositive_curvature": chosen_info.nonpositive_curvature,
                }
            )
            if not accepted:
                # A conservative first-order fallback still guarantees progress
                # only when it lowers the actual energy.
                fallback = state - self.fallback_step_size * gradient_detached
                fallback_energy = energy_fn(fallback)
                if fallback_energy.ndim:
                    fallback_energy = fallback_energy.mean()
                if float(fallback_energy.detach()) < current:
                    chosen_candidate = fallback
                else:
                    chosen_candidate = state
            state = chosen_candidate.detach().requires_grad_(True)

        final = energy_fn(state)
        if final.ndim:
            final = final.mean()
        energies.append(float(final.detach()))
        self.damping = damping
        return SolveResult(
            state=state,
            energies=energies,
            steps=min(self.steps, len(energies) - 1),
            converged=converged,
            diagnostics={
                "solver": "lm_pc",
                "damping": damping,
                "damping_history": damping_history,
                "rho_history": rho_history,
                "gradient_norms": gradient_norms,
                "cg_history": cg_history,
                "rejected_steps": rejected,
            },
        )
