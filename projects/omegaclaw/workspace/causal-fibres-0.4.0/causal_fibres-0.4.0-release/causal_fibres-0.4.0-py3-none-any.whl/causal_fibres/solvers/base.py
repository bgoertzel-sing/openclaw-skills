from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable

from torch import Tensor

from causal_fibres.core.types import SolveResult

EnergyFn = Callable[[Tensor], Tensor]


class BaseStateSolver(ABC):
    @abstractmethod
    def solve(
        self,
        initial: Tensor,
        energy_fn: EnergyFn,
        *,
        create_graph: bool = False,
    ) -> SolveResult:
        raise NotImplementedError


class NoOpStateSolver(BaseStateSolver):
    """Return the amortized state without iterative settlement."""

    def solve(
        self,
        initial: Tensor,
        energy_fn: EnergyFn,
        *,
        create_graph: bool = False,
    ) -> SolveResult:
        del create_graph
        energy = energy_fn(initial)
        if energy.ndim:
            energy = energy.mean()
        return SolveResult(
            state=initial,
            energies=[float(energy.detach())],
            steps=0,
            converged=True,
            diagnostics={"solver": "none"},
        )
