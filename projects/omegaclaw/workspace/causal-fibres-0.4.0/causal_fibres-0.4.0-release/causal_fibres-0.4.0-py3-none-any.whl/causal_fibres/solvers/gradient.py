from __future__ import annotations

import math

import torch
from torch import Tensor

from causal_fibres.core.types import SolveResult

from .base import BaseStateSolver, EnergyFn


class GradientPCSolver(BaseStateSolver):
    """Predictive-coding state descent with optional backtracking."""

    def __init__(
        self,
        steps: int = 4,
        step_size: float = 0.2,
        *,
        tolerance: float = 1e-5,
        backtracking: bool = True,
        backtrack_factor: float = 0.5,
        max_backtracks: int = 8,
        min_step_size: float = 1e-7,
        armijo: float = 0.0,
    ) -> None:
        if steps < 0:
            raise ValueError("steps must be non-negative")
        if step_size <= 0:
            raise ValueError("step_size must be positive")
        self.steps = steps
        self.step_size = step_size
        self.tolerance = tolerance
        self.backtracking = backtracking
        self.backtrack_factor = backtrack_factor
        self.max_backtracks = max_backtracks
        self.min_step_size = min_step_size
        self.armijo = armijo

    def solve(
        self,
        initial: Tensor,
        energy_fn: EnergyFn,
        *,
        create_graph: bool = False,
    ) -> SolveResult:
        state = initial if initial.requires_grad else initial.detach().requires_grad_(True)
        energies: list[float] = []
        gradient_norms: list[float] = []
        accepted_step_sizes: list[float] = []
        total_backtracks = 0
        converged = False
        for _ in range(self.steps):
            energy = energy_fn(state)
            if energy.ndim != 0:
                energy = energy.mean()
            energy_value = float(energy.detach())
            energies.append(energy_value)
            gradient = torch.autograd.grad(
                energy,
                state,
                create_graph=create_graph,
                retain_graph=create_graph,
            )[0]
            grad_norm = float(gradient.detach().norm())
            gradient_norms.append(grad_norm)
            if not math.isfinite(grad_norm):
                raise FloatingPointError("Non-finite PC state gradient")
            if grad_norm <= self.tolerance:
                converged = True
                break
            step_size = self.step_size
            candidate = state - step_size * gradient
            accepted = not self.backtracking
            if self.backtracking:
                slope = float(gradient.detach().square().sum())
                for _ in range(self.max_backtracks + 1):
                    candidate_energy = energy_fn(candidate)
                    if candidate_energy.ndim != 0:
                        candidate_energy = candidate_energy.mean()
                    threshold = energy_value - self.armijo * step_size * slope
                    if float(candidate_energy.detach()) <= threshold:
                        accepted = True
                        break
                    total_backtracks += 1
                    step_size *= self.backtrack_factor
                    if step_size < self.min_step_size:
                        break
                    candidate = state - step_size * gradient
            if not accepted:
                candidate = state
                step_size = 0.0
            accepted_step_sizes.append(step_size)
            state = candidate if create_graph else candidate.detach().requires_grad_(True)
        final_energy = energy_fn(state)
        if final_energy.ndim != 0:
            final_energy = final_energy.mean()
        energies.append(float(final_energy.detach()))
        return SolveResult(
            state=state,
            energies=energies,
            steps=min(self.steps, len(energies) - 1),
            converged=converged,
            diagnostics={
                "solver": "gradient_pc",
                "backtracks": total_backtracks,
                "gradient_norms": gradient_norms,
                "step_sizes": accepted_step_sizes,
            },
        )
