from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

import torch
from torch import Tensor

from causal_fibres.core.types import SolveResult

from .base import BaseStateSolver, EnergyFn

Preconditioner = Callable[[Tensor, Tensor, EnergyFn], Tensor]


@dataclass
class CGInfo:
    iterations: int
    residual_norm: float
    converged: bool
    nonpositive_curvature: bool = False


def conjugate_gradient(
    matvec: Callable[[Tensor], Tensor],
    rhs: Tensor,
    *,
    max_iter: int = 32,
    tolerance: float = 1e-6,
    return_info: bool = False,
) -> Tensor | tuple[Tensor, CGInfo]:
    """Matrix-free conjugate gradient on a symmetric positive system."""

    x = torch.zeros_like(rhs)
    r = rhs - matvec(x)
    p = r.clone()
    rr = torch.dot(r.reshape(-1), r.reshape(-1))
    initial = float(rr.sqrt())
    if initial <= tolerance:
        info = CGInfo(0, initial, True)
        return (x, info) if return_info else x
    nonpositive = False
    iterations = 0
    for iteration in range(max_iter):
        ap = matvec(p)
        denom = torch.dot(p.reshape(-1), ap.reshape(-1))
        if float(denom) <= 1e-12:
            nonpositive = True
            break
        alpha = rr / denom
        x = x + alpha * p
        r = r - alpha * ap
        rr_new = torch.dot(r.reshape(-1), r.reshape(-1))
        iterations = iteration + 1
        if float(rr_new.sqrt()) <= tolerance:
            rr = rr_new
            break
        beta = rr_new / rr.clamp_min(1e-12)
        p = r + beta * p
        rr = rr_new
    residual = float(rr.sqrt())
    info = CGInfo(
        iterations=iterations,
        residual_norm=residual,
        converged=residual <= tolerance,
        nonpositive_curvature=nonpositive,
    )
    return (x, info) if return_info else x


def identity_preconditioner(state: Tensor, gradient: Tensor, energy_fn: EnergyFn) -> Tensor:
    del state, energy_fn
    return gradient


class ExplicitDampedHessianPreconditioner:
    """Exact small-state LM/Newton preconditioner for debugging."""

    def __init__(self, damping: float = 0.1) -> None:
        self.damping = damping

    def __call__(self, state: Tensor, gradient: Tensor, energy_fn: EnergyFn) -> Tensor:
        shape = state.shape
        base = state.detach().reshape(-1).requires_grad_(True)

        def flat_energy(vector: Tensor) -> Tensor:
            value = energy_fn(vector.reshape(shape))
            return value.mean() if value.ndim else value

        hessian = torch.autograd.functional.hessian(flat_energy, base, create_graph=False)
        eye = torch.eye(hessian.shape[0], device=hessian.device, dtype=hessian.dtype)
        matrix = hessian + self.damping * eye
        try:
            solution = torch.linalg.solve(matrix, gradient.detach().reshape(-1))
        except RuntimeError:
            solution = torch.linalg.pinv(matrix) @ gradient.detach().reshape(-1)
        return solution.reshape(shape)


class PreconditionedPCSolver(BaseStateSolver):
    """PC state descent using a supplied approximate inverse metric."""

    def __init__(
        self,
        preconditioner: Preconditioner = identity_preconditioner,
        *,
        steps: int = 4,
        step_size: float = 1.0,
        tolerance: float = 1e-5,
        backtrack_factor: float = 0.5,
        max_backtracks: int = 8,
    ) -> None:
        self.preconditioner = preconditioner
        self.steps = steps
        self.step_size = step_size
        self.tolerance = tolerance
        self.backtrack_factor = backtrack_factor
        self.max_backtracks = max_backtracks

    def solve(
        self,
        initial: Tensor,
        energy_fn: EnergyFn,
        *,
        create_graph: bool = False,
    ) -> SolveResult:
        state = initial if initial.requires_grad else initial.detach().requires_grad_(True)
        energies: list[float] = []
        gradient_norms: list[float] = []
        step_sizes: list[float] = []
        total_backtracks = 0
        converged = False
        for _ in range(self.steps):
            energy = energy_fn(state)
            if energy.ndim:
                energy = energy.mean()
            current = float(energy.detach())
            energies.append(current)
            gradient = torch.autograd.grad(
                energy,
                state,
                create_graph=create_graph,
                retain_graph=create_graph,
            )[0]
            gradient_norm = float(gradient.detach().norm())
            gradient_norms.append(gradient_norm)
            if gradient_norm <= self.tolerance:
                converged = True
                break
            direction = self.preconditioner(state, gradient, energy_fn)
            step_size = self.step_size
            accepted = False
            candidate = state - step_size * direction
            for _ in range(self.max_backtracks + 1):
                candidate_energy = energy_fn(candidate)
                if candidate_energy.ndim:
                    candidate_energy = candidate_energy.mean()
                if float(candidate_energy.detach()) <= current:
                    accepted = True
                    break
                total_backtracks += 1
                step_size *= self.backtrack_factor
                candidate = state - step_size * direction
            if not accepted:
                candidate = state
                step_size = 0.0
            step_sizes.append(step_size)
            state = candidate if create_graph else candidate.detach().requires_grad_(True)
        final = energy_fn(state)
        if final.ndim:
            final = final.mean()
        energies.append(float(final.detach()))
        return SolveResult(
            state=state,
            energies=energies,
            steps=min(self.steps, len(energies) - 1),
            converged=converged,
            diagnostics={
                "solver": "preconditioned_pc",
                "backtracks": total_backtracks,
                "gradient_norms": gradient_norms,
                "step_sizes": step_sizes,
            },
        )
