from __future__ import annotations

from typing import Any

import torch
from torch import Tensor, nn


class IdentityPooler(nn.Module):
    def forward(self, tensor: Tensor, mask: Tensor | None = None, **_: Any) -> Tensor:
        del mask
        return tensor


class LastTokenPooler(nn.Module):
    """Select the final valid token from ``[batch, token, feature]`` tensors."""

    def forward(self, tensor: Tensor, mask: Tensor | None = None, **_: Any) -> Tensor:
        if tensor.ndim != 3:
            raise ValueError("LastTokenPooler expects [batch, token, feature]")
        if mask is None:
            return tensor[:, -1]
        if mask.shape != tensor.shape[:2]:
            raise ValueError("mask must match [batch, token]")
        indices = mask.to(dtype=torch.long).sum(dim=-1).clamp_min(1) - 1
        batch_indices = torch.arange(tensor.shape[0], device=tensor.device)
        return tensor[batch_indices, indices]


class MaskedMeanPooler(nn.Module):
    def forward(self, tensor: Tensor, mask: Tensor | None = None, **_: Any) -> Tensor:
        if tensor.ndim != 3:
            raise ValueError("MaskedMeanPooler expects [batch, token, feature]")
        if mask is None:
            return tensor.mean(dim=1)
        if mask.shape != tensor.shape[:2]:
            raise ValueError("mask must match [batch, token]")
        weights = mask.to(tensor).unsqueeze(-1)
        return (tensor * weights).sum(dim=1) / weights.sum(dim=1).clamp_min(1.0)


class AttentionPooler(nn.Module):
    """Learned query pooling over a sequence axis."""

    def __init__(self, width: int) -> None:
        super().__init__()
        self.query = nn.Parameter(torch.empty(width))
        nn.init.normal_(self.query, std=width**-0.5)

    def forward(self, tensor: Tensor, mask: Tensor | None = None, **_: Any) -> Tensor:
        if tensor.ndim != 3:
            raise ValueError("AttentionPooler expects [batch, token, feature]")
        scores = torch.einsum("btd,d->bt", tensor, self.query) / max(1, tensor.shape[-1]) ** 0.5
        if mask is not None:
            if mask.shape != tensor.shape[:2]:
                raise ValueError("mask must match [batch, token]")
            scores = scores.masked_fill(~mask.to(dtype=torch.bool), float("-inf"))
        attention = torch.softmax(scores, dim=-1)
        return torch.einsum("bt,btd->bd", attention, tensor)
