from __future__ import annotations

from collections.abc import Iterable

import torch
from torch import Tensor, nn

from .bank import IndependentFibrePredictor, LinearFibreBank


class FibrePlasticityController:
    """Mask persistent gradients by fibre without changing forward activation.

    This is distinct from an activation router. It is most exact when the
    predictor has independent per-fibre branches. For entangled predictors the
    controller can still mask grouped writer gradients, but it cannot assign
    shared predictor parameters cleanly to one fibre.
    """

    def __init__(
        self,
        n_fibres: int,
        *,
        predictor: nn.Module | None = None,
        writer: LinearFibreBank | None = None,
        mask: Tensor | None = None,
    ) -> None:
        self.n_fibres = n_fibres
        self.predictor = predictor
        self.writer = writer
        self.mask = (
            torch.ones(n_fibres, dtype=torch.bool)
            if mask is None
            else mask.to(dtype=torch.bool).clone()
        )
        if self.mask.shape != (n_fibres,):
            raise ValueError("plasticity mask must have shape [n_fibres]")

    def set_mask(self, mask: Tensor | Iterable[bool]) -> None:
        value = torch.as_tensor(mask, dtype=torch.bool)
        if value.shape != (self.n_fibres,):
            raise ValueError("plasticity mask must have shape [n_fibres]")
        self.mask = value.clone()

    def apply(self) -> dict[str, float]:
        active = self.mask
        masked_parameters = 0
        total_parameters = 0
        if isinstance(self.predictor, IndependentFibrePredictor):
            for index, branch in enumerate(self.predictor.branches):
                for parameter in branch.parameters():
                    if parameter.grad is None:
                        continue
                    total_parameters += parameter.numel()
                    if not bool(active[index]):
                        parameter.grad.zero_()
                        masked_parameters += parameter.numel()
        if self.writer is not None:
            if isinstance(self.writer.weight, Tensor) and self.writer.weight.grad is not None:
                total_parameters += self.writer.weight.numel()
                inactive = ~active.to(device=self.writer.weight.grad.device)
                masked_parameters += int(self.writer.weight.grad[inactive].numel())
                self.writer.weight.grad[inactive] = 0
            scale = self.writer.fibre_scale
            if isinstance(scale, nn.Parameter) and scale.grad is not None:
                total_parameters += scale.numel()
                inactive = ~active.to(device=scale.grad.device)
                masked_parameters += int(scale.grad[inactive].numel())
                scale.grad[inactive] = 0
        return {
            "plasticity_active_fibres": float(active.sum()),
            "plasticity_masked_fraction": (
                masked_parameters / total_parameters if total_parameters else 0.0
            ),
        }


class ResponsibilityGradientGate:
    """Scale exact autograd gradients with learned or supplied responsibilities.

    This is the conservative continual-learning mechanism promoted ahead of a
    learned credit highway. Parameter groups must be disjoint so that routing
    controls plasticity without redefining the task gradient itself.
    """

    def __init__(
        self,
        parameter_groups: Iterable[Iterable[nn.Parameter]],
        *,
        minimum_gate: float = 0.0,
        power: float = 1.0,
    ) -> None:
        self.parameter_groups = [list(group) for group in parameter_groups]
        if not self.parameter_groups:
            raise ValueError("At least one parameter group is required")
        if minimum_gate < 0 or power <= 0:
            raise ValueError("minimum_gate must be non-negative and power positive")
        identifiers = [id(parameter) for group in self.parameter_groups for parameter in group]
        if len(identifiers) != len(set(identifiers)):
            raise ValueError("ResponsibilityGradientGate requires disjoint parameter groups")
        self.minimum_gate = float(minimum_gate)
        self.power = float(power)

    @property
    def n_groups(self) -> int:
        return len(self.parameter_groups)

    def apply(self, responsibility: Tensor) -> dict[str, float]:
        if responsibility.ndim > 1:
            reduce_axes = tuple(range(responsibility.ndim - 1))
            responsibility = responsibility.mean(dim=reduce_axes)
        if responsibility.shape != (self.n_groups,):
            raise ValueError("responsibility must reduce to shape [n_groups]")
        gates = responsibility.detach().clamp_min(0).pow(self.power)
        gates = torch.maximum(gates, torch.full_like(gates, self.minimum_gate))
        before = 0.0
        after = 0.0
        for index, group in enumerate(self.parameter_groups):
            gate = gates[index]
            for parameter in group:
                if parameter.grad is None:
                    continue
                before += float(parameter.grad.norm())
                parameter.grad.mul_(gate.to(parameter.grad))
                after += float(parameter.grad.norm())
        return {
            "plasticity_mean_gate": float(gates.mean()),
            "plasticity_min_gate": float(gates.min()),
            "plasticity_max_gate": float(gates.max()),
            "gradient_norm_before_gate": before,
            "gradient_norm_after_gate": after,
            "gradient_retained_fraction": after / max(before, 1e-12),
        }
