from __future__ import annotations

import torch
from torch import Tensor


def covariance_gauge_loss(state: Tensor, eps: float = 1e-5) -> Tensor:
    """Encourage unit within-fibre covariance without coupling distinct fibres."""

    flat = state.reshape(-1, state.shape[-2], state.shape[-1])
    centered = flat - flat.mean(dim=0, keepdim=True)
    denom = max(1, centered.shape[0] - 1)
    cov = torch.einsum("nqr,nqs->qrs", centered, centered) / denom
    identity = torch.eye(state.shape[-1], device=state.device, dtype=state.dtype)
    return (cov - identity.unsqueeze(0)).square().mean() + eps * state.square().mean()


def cross_fibre_covariance_loss(state: Tensor) -> Tensor:
    flat = state.reshape(-1, state.shape[-2], state.shape[-1])
    centered = flat - flat.mean(dim=0, keepdim=True)
    fibre_vectors = centered.transpose(0, 1).reshape(state.shape[-2], -1)
    gram = fibre_vectors @ fibre_vectors.T / max(1, fibre_vectors.shape[-1])
    offdiag = gram - torch.diag_embed(torch.diagonal(gram))
    return offdiag.square().mean()


def write_norm_gauge_loss(weight: Tensor, target_norm: float = 1.0) -> Tensor:
    norms = weight.norm(dim=(-2, -1))
    return (norms - target_norm).square().mean()


def function_space_balance_loss(contributions: Tensor, eps: float = 1e-8) -> Tensor:
    """Discourage one fibre from dominating solely through scale.

    ``contributions`` is ``[..., fibre, output]``. The loss operates on the
    log-RMS contribution so it remains insensitive to the global residual scale.
    """

    reduce_dims = tuple(range(contributions.ndim - 2)) + (-1,)
    rms = contributions.square().mean(dim=reduce_dims).sqrt().clamp_min(eps)
    log_rms = rms.log()
    return (log_rms - log_rms.mean()).square().mean()
