from __future__ import annotations

import torch
from torch import Tensor, nn

from causal_fibres.core.types import FibreState, ForwardRecord

from .bank import LinearFibreBank, MultiSiteFibrePredictor


class TerminalFibreSidecar(nn.Module):
    """Frozen-backbone sidecar that adds a correction to the backbone output."""

    def __init__(
        self,
        predictor: MultiSiteFibrePredictor,
        writer: LinearFibreBank,
        router: nn.Module | None = None,
        *,
        residual_scale: float = 1.0,
        trainable_scale: bool = False,
        active_mask: Tensor | None = None,
    ) -> None:
        super().__init__()
        self.predictor = predictor
        self.writer = writer
        self.router = router
        initial = Tensor([float(residual_scale)])
        if trainable_scale:
            self.residual_scale = nn.Parameter(initial)
        else:
            self.register_buffer("residual_scale", initial)
        if active_mask is None:
            active_mask = torch.ones(writer.n_fibres, dtype=torch.bool)
        if active_mask.shape != (writer.n_fibres,):
            raise ValueError("active_mask must have shape [n_fibres]")
        self.register_buffer("active_mask", active_mask.to(dtype=torch.bool))

    @property
    def n_fibres(self) -> int:
        return self.writer.n_fibres

    @property
    def fibre_dim(self) -> int:
        return self.writer.fibre_dim

    def predict(
        self,
        record: ForwardRecord,
        *,
        context=None,
        known_support: Tensor | None = None,
        write_permission: Tensor | None = None,
    ) -> FibreState:
        prior = self.predictor(record.sites, context)
        if self.router is None:
            gate = None
        else:
            gate = self.router(prior, context=context, known_support=known_support)
        active = self.active_mask.to(device=prior.device)
        if not bool(active.all()):
            view_shape = (1,) * (prior.ndim - 2) + (self.n_fibres,)
            active_gate = active.to(prior).view(view_shape).expand(prior.shape[:-1])
            if gate is None:
                gate = active_gate
            else:
                gate = gate * active_gate
                gate = gate / gate.sum(dim=-1, keepdim=True).clamp_min(1e-8)
        return FibreState(
            value=prior,
            gate=gate,
            prior=prior,
            write_permission=write_permission,
        )

    def correction(self, state: FibreState | Tensor, gate: Tensor | None = None) -> Tensor:
        write_permission = None
        if isinstance(state, FibreState):
            gate = state.gate if gate is None else gate
            write_permission = state.write_permission
            value = state.value
        else:
            value = state
        return self.residual_scale.to(value) * self.writer(
            value, gate, write_permission=write_permission
        )

    def compose(
        self,
        record: ForwardRecord,
        state: FibreState | Tensor,
        gate: Tensor | None = None,
    ) -> Tensor:
        correction = self.correction(state, gate)
        if record.output.shape != correction.shape:
            raise ValueError(
                f"Backbone output {tuple(record.output.shape)} and correction "
                f"{tuple(correction.shape)} must match for terminal addition"
            )
        return record.output + correction

    @torch.no_grad()
    def set_residual_scale(self, value: float) -> None:
        if value < 0:
            raise ValueError("residual scale must be non-negative")
        self.residual_scale.fill_(float(value))


    @torch.no_grad()
    def set_active_fibres(self, mask: Tensor) -> None:
        if mask.shape != self.active_mask.shape:
            raise ValueError("mask must match active_mask shape")
        self.active_mask.copy_(mask.to(device=self.active_mask.device, dtype=torch.bool))

    @torch.no_grad()
    def activate_fibre(self, index: int) -> None:
        self.active_mask[index] = True

    @torch.no_grad()
    def deactivate_fibre(self, index: int) -> None:
        self.active_mask[index] = False

    @torch.no_grad()
    def project_gauge(self, target_write_norm: float | None = 1.0) -> None:
        if target_write_norm is not None:
            self.writer.normalize_write_norms(target_write_norm)
