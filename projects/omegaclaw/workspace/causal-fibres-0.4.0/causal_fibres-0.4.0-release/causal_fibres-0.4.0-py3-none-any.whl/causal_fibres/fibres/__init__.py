"""Fibre banks, predictors, pooling, gauge controls, and sidecars."""

from .bank import IndependentFibrePredictor, LinearFibreBank, MultiSiteFibrePredictor
from .gauge import (
    covariance_gauge_loss,
    cross_fibre_covariance_loss,
    function_space_balance_loss,
    write_norm_gauge_loss,
)
from .plasticity import FibrePlasticityController, ResponsibilityGradientGate
from .pooling import AttentionPooler, IdentityPooler, LastTokenPooler, MaskedMeanPooler
from .sidecar import TerminalFibreSidecar

__all__ = [
    "IndependentFibrePredictor",
    "LinearFibreBank",
    "MultiSiteFibrePredictor",
    "TerminalFibreSidecar",
    "FibrePlasticityController",
    "ResponsibilityGradientGate",
    "IdentityPooler",
    "LastTokenPooler",
    "MaskedMeanPooler",
    "AttentionPooler",
    "covariance_gauge_loss",
    "cross_fibre_covariance_loss",
    "function_space_balance_loss",
    "write_norm_gauge_loss",
]
