from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import torch
from torch import Tensor, nn

from .pooling import IdentityPooler


def _context_tensor(context: Any) -> Tensor | None:
    if isinstance(context, Tensor):
        return context
    if isinstance(context, Mapping):
        value = context.get("context_features")
        return value if isinstance(value, Tensor) else None
    return None


def _site_mask(context: Any, site_name: str) -> Tensor | None:
    if not isinstance(context, Mapping):
        return None
    masks = context.get("site_masks")
    if isinstance(masks, Mapping) and isinstance(masks.get(site_name), Tensor):
        return masks[site_name]
    mask = context.get("attention_mask")
    return mask if isinstance(mask, Tensor) else None


class MultiSiteFibrePredictor(nn.Module):
    """Project several architectural sites into one canonical fibre state.

    Site tensors may be tokenwise or pooled. Per-site poolers can align them to
    a common sample layout. ``weighted_sum`` learns one scalar mixture weight
    per site; ``concat`` concatenates aligned site features before an MLP.
    """

    def __init__(
        self,
        site_widths: Mapping[str, int],
        n_fibres: int,
        fibre_dim: int,
        *,
        hidden_dim: int | None = None,
        normalize_inputs: bool = True,
        fusion: str = "weighted_sum",
        site_poolers: Mapping[str, nn.Module] | None = None,
        context_dim: int | None = None,
    ) -> None:
        super().__init__()
        if not site_widths:
            raise ValueError("At least one site is required")
        if n_fibres <= 0 or fibre_dim <= 0:
            raise ValueError("n_fibres and fibre_dim must be positive")
        if fusion not in {"weighted_sum", "concat"}:
            raise ValueError("fusion must be 'weighted_sum' or 'concat'")
        self.site_names = tuple(site_widths)
        self.n_fibres = n_fibres
        self.fibre_dim = fibre_dim
        self.normalize_inputs = normalize_inputs
        self.fusion = fusion
        self.context_dim = context_dim
        output_dim = n_fibres * fibre_dim
        self.norms = nn.ModuleDict(
            {name: nn.LayerNorm(width) for name, width in site_widths.items()}
        )
        poolers = site_poolers or {}
        self.poolers = nn.ModuleDict(
            {name: poolers.get(name, IdentityPooler()) for name in self.site_names}
        )
        if fusion == "weighted_sum":
            self.projections = nn.ModuleDict(
                {
                    name: self._projection(width, output_dim, hidden_dim)
                    for name, width in site_widths.items()
                }
            )
            self.site_logits = nn.Parameter(torch.zeros(len(self.site_names)))
            self.concat_network = None
            if context_dim is not None:
                self.context_projection = nn.Linear(context_dim, output_dim)
            else:
                self.context_projection = None
        else:
            self.projections = nn.ModuleDict()
            self.register_parameter("site_logits", None)
            input_dim = sum(site_widths.values()) + (context_dim or 0)
            self.concat_network = self._projection(input_dim, output_dim, hidden_dim)
            self.context_projection = None

    @staticmethod
    def _projection(input_dim: int, output_dim: int, hidden_dim: int | None) -> nn.Module:
        if hidden_dim is None:
            return nn.Linear(input_dim, output_dim)
        return nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, output_dim),
        )

    def _aligned_sites(self, sites: Mapping[str, Tensor], context: Any) -> list[Tensor]:
        values: list[Tensor] = []
        leading_shape = None
        for name in self.site_names:
            if name not in sites:
                raise KeyError(f"Missing site {name!r}")
            tensor = sites[name]
            if tensor.shape[-1] != self.norms[name].normalized_shape[0]:
                raise ValueError(f"Unexpected feature width for site {name!r}")
            if self.normalize_inputs:
                tensor = self.norms[name](tensor)
            tensor = self.poolers[name](tensor, mask=_site_mask(context, name), site_name=name)
            if leading_shape is None:
                leading_shape = tensor.shape[:-1]
            elif tensor.shape[:-1] != leading_shape:
                raise ValueError(
                    "Poolers must align all sites to the same leading sample axes; "
                    f"{name} has {tensor.shape[:-1]} versus {leading_shape}"
                )
            values.append(tensor)
        return values

    def forward(self, sites: Mapping[str, Tensor], context: Any = None) -> Tensor:
        values = self._aligned_sites(sites, context)
        if self.fusion == "weighted_sum":
            projected: list[Tensor] = []
            for name, tensor in zip(self.site_names, values, strict=True):
                value = self.projections[name](tensor)
                projected.append(
                    value.reshape(*tensor.shape[:-1], self.n_fibres, self.fibre_dim)
                )
            weights = torch.softmax(self.site_logits, dim=0)
            stacked = torch.stack(projected, dim=-3)  # [..., site, fibre, dim]
            view_shape = (1,) * (stacked.ndim - 3) + (len(projected), 1, 1)
            result = (stacked * weights.view(view_shape)).sum(dim=-3)
            context_features = _context_tensor(context)
            if self.context_projection is not None:
                if context_features is None:
                    raise ValueError("context_features are required by this predictor")
                context_value = self.context_projection(context_features.to(result))
                result = result + context_value.reshape(
                    *context_value.shape[:-1], self.n_fibres, self.fibre_dim
                )
            return result

        context_features = _context_tensor(context)
        concatenated = list(values)
        if self.context_dim is not None:
            if context_features is None:
                raise ValueError("context_features are required by this predictor")
            if context_features.shape[:-1] != values[0].shape[:-1]:
                raise ValueError("context_features leading axes must match pooled sites")
            concatenated.append(context_features.to(values[0]))
        combined = torch.cat(concatenated, dim=-1)
        assert self.concat_network is not None
        output = self.concat_network(combined)
        return output.reshape(*combined.shape[:-1], self.n_fibres, self.fibre_dim)


class LinearFibreBank(nn.Module):
    """Grouped linear writes from canonical fibres into an output space."""

    def __init__(
        self,
        n_fibres: int,
        fibre_dim: int,
        output_dim: int,
        *,
        bias: bool = False,
        fixed_weight: Tensor | None = None,
        output_mask: Tensor | None = None,
        per_fibre_scale: bool = False,
    ) -> None:
        super().__init__()
        self.n_fibres = n_fibres
        self.fibre_dim = fibre_dim
        self.output_dim = output_dim
        if fixed_weight is not None:
            expected = (n_fibres, fibre_dim, output_dim)
            if tuple(fixed_weight.shape) != expected:
                raise ValueError(f"fixed_weight shape must be {expected}")
            self.register_buffer("weight", fixed_weight.clone())
            self._weight_trainable = False
        else:
            self.weight = nn.Parameter(torch.empty(n_fibres, fibre_dim, output_dim))
            nn.init.normal_(self.weight, std=1.0 / max(1, fibre_dim) ** 0.5)
            self._weight_trainable = True
        if output_mask is not None:
            if output_mask.shape not in {
                torch.Size((n_fibres, output_dim)),
                torch.Size((n_fibres, fibre_dim, output_dim)),
            }:
                raise ValueError("output_mask must be [fibre, output] or [fibre, dim, output]")
            if output_mask.ndim == 2:
                output_mask = output_mask[:, None, :]
            self.register_buffer("output_mask", output_mask.to(dtype=torch.float32))
        else:
            self.register_buffer("output_mask", None)
        if per_fibre_scale:
            self.fibre_scale = nn.Parameter(torch.ones(n_fibres))
        else:
            self.register_buffer("fibre_scale", torch.ones(n_fibres))
        if bias:
            self.bias = nn.Parameter(torch.zeros(output_dim))
        else:
            self.register_parameter("bias", None)

    def effective_weight(self) -> Tensor:
        weight = self.weight
        if self.output_mask is not None:
            weight = weight * self.output_mask.to(weight)
        return weight * self.fibre_scale.to(weight)[:, None, None]

    def forward(
        self,
        state: Tensor,
        gate: Tensor | None = None,
        write_permission: Tensor | None = None,
    ) -> Tensor:
        if state.shape[-2:] != (self.n_fibres, self.fibre_dim):
            raise ValueError(
                f"Expected trailing shape {(self.n_fibres, self.fibre_dim)}, "
                f"got {tuple(state.shape[-2:])}"
            )
        effective_gate = gate
        if write_permission is not None:
            effective_gate = (
                write_permission
                if effective_gate is None
                else effective_gate * write_permission.to(effective_gate)
            )
        if effective_gate is not None:
            if effective_gate.shape != state.shape[:-1]:
                raise ValueError(
                    f"Gate shape {tuple(effective_gate.shape)} must equal "
                    f"{tuple(state.shape[:-1])}"
                )
            state = state * effective_gate.unsqueeze(-1)
        output = torch.einsum("...qr,qro->...o", state, self.effective_weight())
        if self.bias is not None:
            output = output + self.bias
        return output

    @torch.no_grad()
    def normalize_write_norms(self, target_norm: float = 1.0, eps: float = 1e-8) -> None:
        if not self._weight_trainable:
            return
        norms = self.weight.norm(dim=(-2, -1), keepdim=True).clamp_min(eps)
        self.weight.mul_(target_norm / norms)

    def fibre_contributions(self, state: Tensor, gate: Tensor | None = None) -> Tensor:
        local = torch.einsum("...qr,qro->...qo", state, self.effective_weight())
        if gate is not None:
            local = local * gate.unsqueeze(-1)
        return local

    def contribution_rms(self, state: Tensor, gate: Tensor | None = None) -> Tensor:
        local = self.fibre_contributions(state, gate)
        reduce_dims = tuple(range(local.ndim - 2)) + (-1,)
        return local.square().mean(dim=reduce_dims).sqrt()


class IndependentFibrePredictor(nn.Module):
    """Separate predictor branch per fibre.

    This predictor is useful for strict continual-learning controls because an
    optimizer can update one fibre branch without changing the others. Sites
    are normalized, optionally pooled, concatenated, and passed through
    independent MLPs.
    """

    def __init__(
        self,
        site_widths: Mapping[str, int],
        n_fibres: int,
        fibre_dim: int,
        *,
        hidden_dim: int | None = 64,
        normalize_inputs: bool = True,
        site_poolers: Mapping[str, nn.Module] | None = None,
    ) -> None:
        super().__init__()
        if not site_widths:
            raise ValueError("At least one site is required")
        self.site_names = tuple(site_widths)
        self.n_fibres = n_fibres
        self.fibre_dim = fibre_dim
        self.normalize_inputs = normalize_inputs
        self.norms = nn.ModuleDict(
            {name: nn.LayerNorm(width) for name, width in site_widths.items()}
        )
        poolers = site_poolers or {}
        self.poolers = nn.ModuleDict(
            {name: poolers.get(name, IdentityPooler()) for name in self.site_names}
        )
        input_dim = sum(site_widths.values())
        branches: list[nn.Module] = []
        for _ in range(n_fibres):
            if hidden_dim is None:
                branches.append(nn.Linear(input_dim, fibre_dim))
            else:
                branches.append(
                    nn.Sequential(
                        nn.Linear(input_dim, hidden_dim),
                        nn.GELU(),
                        nn.Linear(hidden_dim, fibre_dim),
                    )
                )
        self.branches = nn.ModuleList(branches)

    def forward(self, sites: Mapping[str, Tensor], context: Any = None) -> Tensor:
        aligned: list[Tensor] = []
        leading = None
        for name in self.site_names:
            tensor = sites[name]
            if self.normalize_inputs:
                tensor = self.norms[name](tensor)
            tensor = self.poolers[name](tensor, mask=_site_mask(context, name), site_name=name)
            if leading is None:
                leading = tensor.shape[:-1]
            elif tensor.shape[:-1] != leading:
                raise ValueError("Poolers must align site sample axes")
            aligned.append(tensor)
        combined = torch.cat(aligned, dim=-1)
        return torch.stack([branch(combined) for branch in self.branches], dim=-2)

    def fibre_parameters(self, index: int):
        return self.branches[index].parameters()
