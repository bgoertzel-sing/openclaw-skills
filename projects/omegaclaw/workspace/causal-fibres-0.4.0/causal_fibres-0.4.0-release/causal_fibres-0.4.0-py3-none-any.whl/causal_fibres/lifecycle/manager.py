from __future__ import annotations

from .policy import FibreEvent, FibreEventType
from .registry import FibreRegistry, FibreStatus


class LifecycleManager:
    """Apply non-structural lifecycle events to a stable fibre registry.

    Tensor-resizing events such as spawn, split, and merge are returned to the
    caller because materializing them requires architecture- and optimizer-
    specific state migration. Status-only events are applied directly.
    """

    def __init__(self, registry: FibreRegistry) -> None:
        self.registry = registry

    def apply(self, events: list[FibreEvent]) -> list[FibreEvent]:
        pending: list[FibreEvent] = []
        for event in events:
            if event.kind == FibreEventType.PROMOTE:
                for index in event.fibres:
                    self.registry.update_status(index, FibreStatus.CONSOLIDATED)
            elif event.kind == FibreEventType.FREEZE:
                for index in event.fibres:
                    self.registry.update_status(index, FibreStatus.FROZEN)
            elif event.kind == FibreEventType.RETIRE:
                for index in event.fibres:
                    self.registry.update_status(index, FibreStatus.RETIRED)
            elif event.kind in {FibreEventType.SPAWN, FibreEventType.SPLIT, FibreEventType.MERGE}:
                pending.append(event)
        return pending
