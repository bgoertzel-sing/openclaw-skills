from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Mapping


class FibreEventType(str, Enum):
    SPAWN = "spawn"
    SPLIT = "split"
    MERGE = "merge"
    PROMOTE = "promote"
    FREEZE = "freeze"
    RETIRE = "retire"
    NONE = "none"


@dataclass(frozen=True)
class FibreEvent:
    kind: FibreEventType
    fibres: tuple[int, ...] = ()
    reason: str = ""
    score: float = 0.0


@dataclass
class ThresholdLifecyclePolicy:
    """Conservative structure policy driven by external audit metrics.

    This policy proposes events. Architecture-specific code decides how to
    materialize a split, merge, or spawn while preserving optimizer state.
    """

    spawn_unexplained: float = 0.25
    split_multimodality: float = 0.3
    merge_similarity: float = 0.97
    promote_stability: float = 0.95
    retire_unique_value: float = 1e-3

    def propose(self, metrics: Mapping[str, object]) -> list[FibreEvent]:
        events: list[FibreEvent] = []
        unexplained = float(metrics.get("unexplained_error_fraction", 0.0))
        reserve = int(metrics.get("reserve_fibres", 0))
        if unexplained >= self.spawn_unexplained and reserve > 0:
            events.append(
                FibreEvent(
                    FibreEventType.SPAWN,
                    reason="persistent unexplained causal error",
                    score=unexplained,
                )
            )

        multimodality = metrics.get("fingerprint_multimodality", {})
        if isinstance(multimodality, Mapping):
            for fibre, score in multimodality.items():
                if float(score) >= self.split_multimodality:
                    events.append(
                        FibreEvent(
                            FibreEventType.SPLIT,
                            fibres=(int(fibre),),
                            reason="multimodal causal fingerprint",
                            score=float(score),
                        )
                    )

        similarities = metrics.get("duplicate_similarity", {})
        if isinstance(similarities, Mapping):
            for pair, score in similarities.items():
                if float(score) >= self.merge_similarity:
                    q, r = pair
                    events.append(
                        FibreEvent(
                            FibreEventType.MERGE,
                            fibres=(int(q), int(r)),
                            reason="redundant read/write/fingerprint signature",
                            score=float(score),
                        )
                    )

        stability = metrics.get("fibre_stability", {})
        if isinstance(stability, Mapping):
            for fibre, score in stability.items():
                if float(score) >= self.promote_stability:
                    events.append(
                        FibreEvent(
                            FibreEventType.PROMOTE,
                            fibres=(int(fibre),),
                            reason="stable shared causal fingerprint",
                            score=float(score),
                        )
                    )

        unique_value = metrics.get("unique_ablation_value", {})
        if isinstance(unique_value, Mapping):
            for fibre, score in unique_value.items():
                if float(score) <= self.retire_unique_value:
                    events.append(
                        FibreEvent(
                            FibreEventType.RETIRE,
                            fibres=(int(fibre),),
                            reason="negligible unique functional value",
                            score=float(score),
                        )
                    )
        return events or [FibreEvent(FibreEventType.NONE)]
