from __future__ import annotations

import uuid
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Iterable, Mapping


class FibreStatus(str, Enum):
    RESERVE = "reserve"
    CANDIDATE = "candidate"
    FUNCTIONAL = "functional"
    INTERVENTION_ALIGNED = "intervention_aligned"
    CAUSALLY_IDENTIFIED = "causally_identified"
    CAUSAL = "causally_identified"  # backward-compatible alias
    UNDERIDENTIFIED = "underidentified"
    CONSOLIDATED = "consolidated"
    SHARED = "shared"
    MEDIATOR = "mediator"
    FROZEN = "frozen"
    RETIRED = "retired"


@dataclass
class FibreDescriptor:
    index: int
    uid: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str | None = None
    status: FibreStatus = FibreStatus.CANDIDATE
    parent_uids: tuple[str, ...] = ()
    context_support: tuple[str, ...] = ()
    symbolic_bindings: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["status"] = self.status.value
        return value

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "FibreDescriptor":
        data = dict(value)
        data["status"] = FibreStatus(data.get("status", FibreStatus.CANDIDATE.value))
        data["parent_uids"] = tuple(data.get("parent_uids", ()))
        data["context_support"] = tuple(data.get("context_support", ()))
        data["symbolic_bindings"] = tuple(data.get("symbolic_bindings", ()))
        return cls(**data)


class FibreRegistry:
    """Stable fibre identifiers and lifecycle metadata."""

    def __init__(self, descriptors: Iterable[FibreDescriptor]) -> None:
        self._items = {descriptor.uid: descriptor for descriptor in descriptors}
        indices = [descriptor.index for descriptor in self._items.values()]
        if len(indices) != len(set(indices)):
            raise ValueError("Fibre indices must be unique")

    @classmethod
    def create(cls, n_fibres: int, reserve_fraction: float = 0.25) -> "FibreRegistry":
        reserve_count = round(n_fibres * reserve_fraction)
        descriptors = []
        for index in range(n_fibres):
            status = FibreStatus.RESERVE if index >= n_fibres - reserve_count else FibreStatus.CANDIDATE
            descriptors.append(FibreDescriptor(index=index, name=f"fibre_{index}", status=status))
        return cls(descriptors)

    def descriptors(self) -> list[FibreDescriptor]:
        return sorted(self._items.values(), key=lambda item: item.index)

    def by_index(self, index: int) -> FibreDescriptor:
        for descriptor in self._items.values():
            if descriptor.index == index:
                return descriptor
        raise KeyError(index)

    def update_status(self, index: int, status: FibreStatus) -> None:
        self.by_index(index).status = status

    def to_dict(self) -> dict[str, Any]:
        return {"fibres": [descriptor.to_dict() for descriptor in self.descriptors()]}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "FibreRegistry":
        return cls(FibreDescriptor.from_dict(item) for item in value.get("fibres", []))
