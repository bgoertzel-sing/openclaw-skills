import importlib.util
import pathlib
import sys

import torch


SCRIPT = pathlib.Path(__file__).with_name("hdc_musicgen_structural.py")


def load_module():
    old = sys.argv[:]
    try:
        sys.argv = [str(SCRIPT), "stageS", "--device", "cpu"]
        spec = importlib.util.spec_from_file_location("hdc_structural", SCRIPT)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module
    finally:
        sys.argv = old


m = load_module()


def test_cosine_similarity_and_related_unrelated_classification():
    features = torch.tensor([
        [1.0, 0.0], [0.0, 1.0], [1.0, 0.0],
        [-1.0, 0.0], [1.0, 0.0],
    ])
    similarity = m.cosine_self_similarity(features)
    assert torch.isclose(similarity[0, 2], torch.tensor(1.0))
    spans = m.classify_structure_spans(features, window_blocks=1, spans_per_track=5)
    by_target = {span["target_block"]: span for span in spans}
    assert by_target[2]["stratum"] == "related"
    assert by_target[3]["stratum"] == "unrelated"
    assert by_target[4]["retrieved_block"] in (0, 2)


def test_stageA_has_four_conditions_length_control_and_aligned_eval_from():
    codes = torch.arange(2 * 60).reshape(2, 60)
    span = {
        "target_frame": 30, "retrieved_frame": 2, "random_frame": 10,
        "block_frames": 5,
    }
    conditions = m.make_stageA_conditions(codes, span, 10, 4)
    assert set(conditions) == {"window", "matched", "random", "full"}
    assert conditions["matched"][0].shape == conditions["random"][0].shape
    assert conditions["window"][1] == 10
    assert conditions["matched"][1] == conditions["random"][1] == 15
    for value, eval_from in conditions.values():
        assert value.shape[-1] - eval_from == 4


def test_relevance_gain_is_random_minus_matched():
    assert abs(m.relevance_gain({"random": 3.2, "matched": 3.0}) - 0.2) < 1e-9


def test_stageA_smoke_policy_bands_only_supported_strata_but_retains_bug_stop():
    summary = {
        "related": {"window": 4.0, "matched": 3.9, "random": 4.0, "full": 3.0,
                    "relevance_gain": 0.1, "n_spans": 4},
        "unrelated": {"window": 1.2, "matched": 1.2, "random": 1.2, "full": 1.2,
                      "relevance_gain": 0.0, "n_spans": 1},
    }
    gate = m.stageA_gate(summary)
    assert gate["nll_sanity_pass"]
    assert gate["nll_band_checked_strata"] == ["related"]
    assert gate["nll_support_insufficient_strata"] == ["unrelated"]
    summary["unrelated"]["window"] = 0.49
    assert not m.stageA_gate(summary)["nll_sanity_pass"]


def test_stageA_smoke_policy_fails_closed_on_nonfinite_sparse_nll():
    summary = {
        "related": {"window": 4.0, "matched": 3.9, "random": 4.0, "full": 3.0,
                    "relevance_gain": 0.1, "n_spans": 4},
        "unrelated": {"window": float("nan"), "matched": 1.2, "random": 1.2,
                      "full": 1.2, "relevance_gain": 0.0, "n_spans": 1},
    }
    gate = m.stageA_gate(summary)
    assert not gate["nll_sanity_pass"]
    assert gate["nll_nonfinite_stop"]


def test_stageA_policy_fails_closed_on_missing_aggregate_nll():
    summary = {
        "related": {"relevance_gain": 0.1, "n_spans": 4},
        "unrelated": {"window": 1.2, "matched": 1.2, "random": 1.2,
                      "full": 1.2, "relevance_gain": 0.0, "n_spans": 1},
    }
    gate = m.stageA_gate(summary)
    assert not gate["nll_sanity_pass"]
    assert gate["nll_missing_conditions_stop"]
    assert gate["nll_missing_conditions"]["related"] == [
        "full", "matched", "random", "window"
    ]


def test_masked_nll_ignores_audiocraft_nan_fill_positions():
    logits = torch.tensor([[[[2.0, 0.0], [float("nan"), float("nan")]]]])
    mask = torch.tensor([[[True, False]]])
    codes = torch.tensor([[[0, 1]]])
    value = m.masked_nll(logits, mask, codes, eval_from=0)
    assert torch.isfinite(value)
    assert torch.isclose(value, torch.log1p(torch.exp(torch.tensor(-2.0))))


def test_stageC_snr99_requires_both_cold_and_warm_near_one():
    assert m.noiseless_self_test({
        "snr99_cold": 1.0, "snr99_warm_prev": 0.9995
    })
    assert not m.noiseless_self_test({
        "snr99_cold": 0.99, "snr99_warm_prev": 1.0
    })


def test_stageD_summary_gain_and_fraction_of_oracle_recovered():
    metrics = {"window": 3.2, "summary": 3.1, "random": 3.3, "matched": 3.0}
    assert abs(m.summary_gain(metrics) - 0.1) < 1e-9
    assert abs(m.fraction_of_oracle_recovered(metrics) - 1 / 3) < 1e-9


def test_backbone_freeze_and_dropped_stageB_are_explicit():
    source = SCRIPT.read_text()
    assert 'choices=["stage0", "stageS", "stageA", "stageC", "stageD"]' in source


def test_full_run_has_restart_artifact_hooks():
    source = SCRIPT.read_text()
    for marker in (
        'stage0_codes_partial.pt', 'stageA_checkpoint.json',
        'stageD_adapter_checkpoint.pt', '--resume',
    ):
        assert marker in source
    assert "parameter.requires_grad_(False)" in source
    assert "def stageB" not in source
