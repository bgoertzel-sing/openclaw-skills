#!/usr/bin/env bash
set -euo pipefail
ROOT=/workspace/hdc-musicgen-full-r1
OUT=/workspace/hdc-musicgen-full-r1-results
AUDIO="$ROOT/audio"
mkdir -p "$OUT"
cd "$ROOT/code"
python hdc_musicgen_structural.py stage0 --audio_dir "$AUDIO" --out_dir "$OUT" --max_seconds 180 --resume --track_checkpoint_interval 5
python hdc_musicgen_structural.py stageS --out_dir "$OUT" --spans_per_track 6 --resume
python hdc_musicgen_structural.py stageA --out_dir "$OUT" --resume --track_checkpoint_interval 5
python hdc_musicgen_structural.py stageC --out_dir "$OUT" --resume
python hdc_musicgen_structural.py stageD --out_dir "$OUT" --adapter_steps 4000 --resume --checkpoint_interval 500
sha256sum "$OUT"/* > "$OUT/SHA256SUMS"
