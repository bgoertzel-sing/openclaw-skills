import importlib.util
import pathlib
import sys
from unittest import mock

import torch


SCRIPT = pathlib.Path(__file__).with_name("hdc_musicgen_experiments.py")


def load_module():
    old = sys.argv[:]
    try:
        sys.argv = [str(SCRIPT), "stageC", "--device", "cpu"]
        spec = importlib.util.spec_from_file_location("hdc_mg", SCRIPT)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module
    finally:
        sys.argv = old


m = load_module()


def test_delay_pattern_alignment_matches_next_pattern_step_and_mask():
    # Hidden s predicts delay-pattern sequence s+1, not ordinary frame t+1.
    hidden = torch.arange(5.0).view(1, 5, 1)
    sequence = torch.tensor([[
        [99, 10, 11, 12, 13, 99],
        [99, 99, 20, 21, 22, 23],
    ]])
    mask = sequence[0] != 99
    h, y = m.aligned_pattern_pairs(hidden, sequence, mask)
    assert h.squeeze(-1).tolist() == [1.0, 2.0, 3.0]
    assert y.tolist() == [[11, 20], [12, 21], [13, 22]]


def test_nll_is_cross_entropy_in_nats_per_token():
    targets = torch.tensor([[0, 1], [1, 0]])
    logits = [
        torch.tensor([[2.0, 0.0], [0.0, 2.0]]),
        torch.tensor([[0.0, 2.0], [2.0, 0.0]]),
    ]
    expected = torch.nn.functional.cross_entropy(logits[0], targets[:, 0])
    assert torch.allclose(m.logits_nll(logits, targets), expected)


def test_cuda_timing_sync_is_noop_on_cpu():
    with mock.patch.object(torch.cuda, "synchronize") as sync:
        m.cuda_sync("cpu")
        sync.assert_not_called()


def test_track_split_is_deterministic_disjoint_and_70_30():
    train, evaluate = m.split_track_indices(20, 7)
    assert len(train) == 14 and len(evaluate) == 6
    assert set(train).isdisjoint(evaluate)
    assert sorted(train + evaluate) == list(range(20))
    assert (train, evaluate) == m.split_track_indices(20, 7)


def test_codec_dimensions_pass_and_fail_loudly():
    class Obj:
        pass
    model = Obj()
    model.frame_rate = 50
    model.compression_model = Obj()
    model.compression_model.num_codebooks = 4
    model.lm = Obj()
    model.lm.card = 2048
    m.assert_codec_dimensions(model)
    model.lm.card = 1024
    try:
        m.assert_codec_dimensions(model)
    except AssertionError as exc:
        assert "cardinality" in str(exc)
    else:
        raise AssertionError("dimension mismatch did not fail")


def test_stage_c_includes_explicit_no_noise_condition():
    source = SCRIPT.read_text()
    assert "for snr_db in (None, 20, 10, 6, 3, 0)" in source
    assert '"inf"' in source
    assert 'initializers.append(("oracle_true", cur))' in source


def test_stage_d_divergence_gate_does_not_reject_worse_eval_nll():
    source = SCRIPT.read_text()
    assert "late_loss_consistently_increasing" in source
    assert "nll_ad" not in source[source.index("training_diagnostics"):
                                  source.index("track_split", source.index("training_diagnostics"))]
