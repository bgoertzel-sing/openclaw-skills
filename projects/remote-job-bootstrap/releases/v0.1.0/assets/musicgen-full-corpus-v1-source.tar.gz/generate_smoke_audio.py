"""Generate deterministic, license-clean synthetic smoke-test WAV fixtures."""
import math
import pathlib
import random
import struct
import wave

RATE = 16_000
SECONDS = 40
OUT = pathlib.Path(__file__).parents[1] / "artifacts" / "smoke-audio"
OUT.mkdir(parents=True, exist_ok=True)

for track in range(4):
    rng = random.Random(1000 + track)
    path = OUT / f"synthetic-{track + 1}.wav"
    with wave.open(str(path), "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(RATE)
        frames = bytearray()
        freqs = (110 + 37 * track, 220 + 23 * track, 330 + 19 * track)
        for i in range(RATE * SECONDS):
            t = i / RATE
            envelope = 0.55 + 0.35 * math.sin(2 * math.pi * 0.13 * t)
            signal = sum(math.sin(2 * math.pi * f * t) for f in freqs) / 3
            signal += 0.025 * rng.uniform(-1, 1)
            sample = max(-1.0, min(1.0, envelope * signal))
            frames.extend(struct.pack("<h", round(sample * 32767)))
        wav.writeframes(frames)
    print(path)
