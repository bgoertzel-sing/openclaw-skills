"""
Structural-memory experiment for MusicGen (AudioCraft 1.3.0).

Run in order: stage0, stageS, stageA, optional stageC, then stageD only when
the preceding gates pass.  The backbone is always frozen.  All likelihoods
are teacher-forced nats/token over positions selected by ``eval_from``.
"""

import argparse
import glob
import json
import math
import os

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


FRAME_RATE = 50
EXPECTED_CODEBOOKS = 4
EXPECTED_CARDINALITY = 2048
MODEL_CONTEXT_SECONDS = 30.0
RELATED_THRESHOLD = 0.80
UNRELATED_THRESHOLD = 0.50


def parser():
    p = argparse.ArgumentParser()
    p.add_argument("stage", choices=["stage0", "stageS", "stageA", "stageC", "stageD"])
    p.add_argument("--audio_dir")
    p.add_argument("--out_dir", default="./hdc_mg_struct")
    p.add_argument("--model", default="facebook/musicgen-small")
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    p.add_argument("--limit", type=int)
    p.add_argument("--max_seconds", type=int, default=180)
    p.add_argument("--batch", type=int, default=4)
    p.add_argument("--window", type=float, default=10.0)
    p.add_argument("--eval_seconds", type=float, default=5.0)
    p.add_argument("--block_seconds", type=float, default=5.0)
    p.add_argument("--spans_per_track", type=int, default=6)
    p.add_argument("--hdc_D", type=int, choices=[8192, 16384], default=8192)
    p.add_argument("--adapter_tokens", type=int, choices=[8, 16, 32], default=16)
    p.add_argument("--adapter_steps", type=int, default=4000)
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--resume", action="store_true",
                   help="resume a stage from its deterministic checkpoint")
    p.add_argument("--checkpoint_interval", type=int, default=500,
                   help="stageD optimizer-step checkpoint cadence")
    p.add_argument("--track_checkpoint_interval", type=int, default=5,
                   help="stage0/stageA completed-track checkpoint cadence")
    return p


ARGS = parser().parse_args()
torch.manual_seed(ARGS.seed)
np.random.seed(ARGS.seed)
os.makedirs(ARGS.out_dir, exist_ok=True)


def log(*values):
    print(f"[{ARGS.stage}]", *values, flush=True)


def save_json(name, value):
    path = os.path.join(ARGS.out_dir, name)
    with open(path, "w") as handle:
        json.dump(value, handle, indent=2)
    log("wrote", path)

def write_results():
    """Refresh the runbook-required human-readable report from JSON artifacts."""
    sections = [
        "# HDC MusicGen structural-memory results",
        "",
        "## Environment",
        "",
        f"- Checkpoint: `{ARGS.model}`",
        f"- Device: `{ARGS.device}`",
        f"- Torch: `{torch.__version__}`",
        "- AudioCraft target: `1.3.0`",
        "",
        "No empirical claim should be inferred for a stage whose JSON artifact is absent.",
    ]
    for title, filename in (
        ("Data and persistence", "stage0_persistence.json"),
        ("Stage S", "stageS_summary.json"),
        ("Stage A", "stageA_summary.json"),
        ("Stage C", "stageC_resonator.json"),
        ("Stage D", "stageD_summary.json"),
    ):
        path = os.path.join(ARGS.out_dir, filename)
        if os.path.exists(path):
            with open(path) as handle:
                payload = handle.read()
            sections.extend(["", f"## {title}", "", f"Artifact: `{filename}`", "",
                             "```json", payload, "```"])
    with open(os.path.join(ARGS.out_dir, "RESULTS.md"), "w") as handle:
        handle.write("\n".join(sections) + "\n")


def load_json(name):
    with open(os.path.join(ARGS.out_dir, name)) as handle:
        return json.load(handle)


def assert_codec_dimensions(model):
    cm, lm = model.compression_model, model.lm
    n_q = getattr(cm, "num_codebooks", getattr(cm, "n_q", None))
    assert n_q == EXPECTED_CODEBOOKS, f"codec codebooks {n_q!r} != {EXPECTED_CODEBOOKS}"
    assert getattr(lm, "card", None) == EXPECTED_CARDINALITY
    assert abs(float(model.frame_rate) - FRAME_RATE) < 1e-6


def load_model():
    from audiocraft.models import MusicGen

    model = MusicGen.get_pretrained(ARGS.model, device=ARGS.device)
    model.compression_model.eval()
    model.lm.eval()
    assert_codec_dimensions(model)
    return model


def null_condition_tensors(lm, batch_size):
    """FRAGILE: construct AudioCraft's unconditional text-conditioning branch."""
    from audiocraft.modules.conditioners import ConditioningAttributes

    attrs = [ConditioningAttributes(text={"description": None}) for _ in range(batch_size)]
    try:
        tokenized = lm.condition_provider.tokenize(attrs)
        return lm.condition_provider(tokenized)
    except Exception as exc:
        raise RuntimeError("AudioCraft null conditioning API drifted") from exc


def _predictions(lm, codes, condition_tensors):
    """FRAGILE: return logits and valid mask aligned to ``codes``."""
    # AudioCraft loads the CUDA LM in float16 but retains float32 LayerNorm
    # parameters; its own generation path therefore always enters fp16
    # autocast. Mirror that execution contract for teacher-forced scoring.
    with torch.autocast(
        device_type=codes.device.type, dtype=torch.float16, enabled=codes.is_cuda
    ):
        out = lm.compute_predictions(
            codes, conditions=[], condition_tensors=condition_tensors
        )
    assert out.logits.shape[:3] == codes.shape
    assert out.mask.shape == codes.shape
    return out.logits, out.mask.bool()


def masked_nll(logits, mask, codes, eval_from):
    """Teacher-forced NLL in nats/token over valid frames >= eval_from."""
    safe_codes = codes.clamp(0, logits.shape[-1] - 1)
    nll = -F.log_softmax(logits.float(), -1).gather(
        -1, safe_codes.unsqueeze(-1)
    ).squeeze(-1)
    score_mask = mask & (codes >= 0) & (codes < logits.shape[-1])
    score_mask[:, :, :eval_from] = False
    assert score_mask.any(), "no valid masked positions to score"
    # AudioCraft deliberately fills invalid pattern positions with NaN logits.
    # Multiplication cannot mask NaNs (NaN * 0 is still NaN), so replace
    # unscored positions before reducing.
    return torch.where(score_mask, nll, 0.0).sum() / score_mask.sum()


def teacher_nll(lm, codes, condition_tensors=None, eval_from=0):
    if condition_tensors is None:
        condition_tensors = null_condition_tensors(lm, codes.shape[0])
    with torch.no_grad():
        logits, mask = _predictions(lm, codes, condition_tensors)
        return float(masked_nll(logits, mask, codes, eval_from).cpu())


def nll_with_grad(lm, codes, condition_tensors, eval_from):
    logits, mask = _predictions(lm, codes, condition_tensors)
    return masked_nll(logits, mask, codes, eval_from)


def persistence_stats(codes_list):
    values = [
        (codes[:, 1:] == codes[:, :-1]).float().mean(1).numpy()
        for codes in codes_list if codes.shape[-1] > 1
    ]
    return np.stack(values).mean(0).tolist()


def data_gate(n_tracks, total_minutes, persistence):
    return (
        n_tracks >= 20
        and total_minutes >= 60
        and all(0.05 < value < 0.9 for value in persistence)
    )


def stage0():
    assert ARGS.audio_dir, "--audio_dir is required"
    import torchaudio
    from audiocraft.data.audio_utils import convert_audio

    model = load_model()
    extensions = ("*.wav", "*.mp3", "*.flac", "*.ogg")
    files = sorted(sum(
        [glob.glob(os.path.join(ARGS.audio_dir, "**", ext), recursive=True)
         for ext in extensions], []
    ))
    if ARGS.limit:
        files = files[:ARGS.limit]
    assert files, f"no audio under {ARGS.audio_dir}"
    partial_codes = os.path.join(ARGS.out_dir, "stage0_codes_partial.pt")
    partial_meta = os.path.join(ARGS.out_dir, "stage0_meta_partial.json")
    if ARGS.resume and os.path.exists(partial_codes) and os.path.exists(partial_meta):
        codes_list = torch.load(partial_codes)
        with open(partial_meta) as handle:
            meta = json.load(handle)
        start = len(meta)
        if start > len(files):
            raise RuntimeError("stage0 checkpoint exceeds deterministic file plan")
        log(f"resuming stage0 at track {start}/{len(files)}")
    else:
        codes_list, meta, start = [], [], 0
    for file_index, path in enumerate(files[start:], start=start):
        try:
            wav, source_sr = torchaudio.load(path)
        except Exception as exc:
            log("skip", path, exc)
            continue
        wav = convert_audio(wav, source_sr, model.sample_rate, model.audio_channels)
        wav = wav[..., : model.sample_rate * ARGS.max_seconds]
        if wav.shape[-1] < model.sample_rate * 15:
            continue
        with torch.no_grad():
            codes, _ = model.compression_model.encode(wav.unsqueeze(0).to(ARGS.device))
        codes = codes.squeeze(0).cpu()
        codes_list.append(codes)
        meta.append({
            "file": os.path.abspath(path),
            "frames": int(codes.shape[-1]),
            "seconds": float(codes.shape[-1] / FRAME_RATE),
        })
        if ((file_index + 1) % ARGS.track_checkpoint_interval == 0
                or file_index + 1 == len(files)):
            torch.save(codes_list, partial_codes)
            with open(partial_meta, "w") as handle:
                json.dump(meta, handle, indent=2)
            log(f"stage0 checkpoint {file_index + 1}/{len(files)}")
    assert codes_list, "no usable tracks"
    torch.save(codes_list, os.path.join(ARGS.out_dir, "codes.pt"))
    save_json("codes_meta.json", meta)
    persistence = persistence_stats(codes_list)
    total_minutes = sum(item["seconds"] for item in meta) / 60
    result = {
        "n_tracks": len(codes_list),
        "total_minutes": total_minutes,
        "per_codebook": persistence,
        "gate_pass": data_gate(len(codes_list), total_minutes, persistence),
        "gate": "n_tracks>=20, total_minutes>=60, each persistence in (0.05,0.9)",
        "smoke_mode": ARGS.limit is not None,
    }
    save_json("stage0_persistence.json", result)
    for path in (partial_codes, partial_meta):
        if os.path.exists(path):
            os.remove(path)
    write_results()
    if not result["gate_pass"] and ARGS.limit is None:
        raise SystemExit("stage0 data gate failed; stop before stageS")


def chroma_blocks(wav, sample_rate, block_seconds):
    """Return unit-normalized 12-bin chroma means for non-overlapping blocks."""
    if wav.ndim > 1:
        wav = wav.mean(0)
    n_fft = 4096
    hop = 512
    window = torch.hann_window(n_fft, device=wav.device)
    power = torch.stft(
        wav.float(), n_fft=n_fft, hop_length=hop, window=window,
        return_complex=True
    ).abs().square()
    frequencies = torch.fft.rfftfreq(n_fft, 1.0 / sample_rate).to(wav.device)
    valid = frequencies >= 27.5
    midi = torch.round(69 + 12 * torch.log2(frequencies[valid] / 440)).long()
    pitch_class = midi.remainder(12)
    chroma = torch.zeros(12, power.shape[1], device=wav.device)
    chroma.index_add_(0, pitch_class, power[valid])
    frames_per_block = max(1, round(block_seconds * sample_rate / hop))
    count = chroma.shape[1] // frames_per_block
    if count == 0:
        return torch.empty(0, 12)
    blocks = chroma[:, :count * frames_per_block].reshape(
        12, count, frames_per_block
    ).mean(2).T
    return F.normalize(blocks, dim=1).cpu()


def cosine_self_similarity(features):
    features = F.normalize(torch.as_tensor(features).float(), dim=1)
    return features @ features.T


def classify_structure_spans(features, window_blocks, spans_per_track=6):
    """Classify blocks by best similarity to material strictly older than W."""
    similarity = cosine_self_similarity(features)
    candidates = []
    for target in range(window_blocks + 1, len(features)):
        older_end = target - window_blocks
        if older_end <= 0:
            continue
        score, source = similarity[target, :older_end].max(0)
        score = float(score)
        if score >= RELATED_THRESHOLD:
            stratum = "related"
        elif score <= UNRELATED_THRESHOLD:
            stratum = "unrelated"
        else:
            continue
        candidates.append({
            "target_block": target,
            "retrieved_block": int(source),
            "similarity": score,
            "stratum": stratum,
        })
    selected = []
    for stratum, reverse in (("related", True), ("unrelated", False)):
        group = [x for x in candidates if x["stratum"] == stratum]
        group.sort(key=lambda x: x["similarity"], reverse=reverse)
        selected.extend(group[:spans_per_track])
    return selected


def assign_random_controls(spans, window_blocks, seed):
    """Attach wrong content drawn from eligible distant history only."""
    rng = np.random.RandomState(seed)
    output = []
    for span in spans:
        older_end = span["target_block"] - window_blocks
        choices = [i for i in range(older_end) if i != span["retrieved_block"]]
        if not choices:
            continue
        item = dict(span)
        item["random_block"] = int(rng.choice(choices))
        output.append(item)
    return output


def structure_summary(spans):
    related = [x["similarity"] for x in spans if x["stratum"] == "related"]
    unrelated = [x["similarity"] for x in spans if x["stratum"] == "unrelated"]
    related_mean = float(np.mean(related)) if related else None
    unrelated_mean = float(np.mean(unrelated)) if unrelated else None
    separation = (
        related_mean - unrelated_mean
        if related_mean is not None and unrelated_mean is not None else None
    )
    return {
        "n_related": len(related),
        "n_unrelated": len(unrelated),
        "related_sim_mean": related_mean,
        "unrelated_sim_mean": unrelated_mean,
        "separation": separation,
        "gate_pass": separation is not None and separation >= 0.15,
    }


def stageS():
    import torchaudio

    stage0_result = load_json("stage0_persistence.json")
    if not stage0_result["gate_pass"] and not stage0_result.get("smoke_mode"):
        raise SystemExit("stage0 data gate failed")
    meta = load_json("codes_meta.json")
    all_spans = []
    for track_index, item in enumerate(meta):
        wav, sr = torchaudio.load(item["file"])
        wav = wav[..., :round(item["seconds"] * sr)]
        features = chroma_blocks(wav, sr, ARGS.block_seconds)
        window_blocks = math.ceil(ARGS.window / ARGS.block_seconds)
        spans = classify_structure_spans(
            features, window_blocks, ARGS.spans_per_track
        )
        spans = assign_random_controls(spans, window_blocks, ARGS.seed + track_index)
        for span in spans:
            span.update({
                "track_index": track_index,
                "target_frame": round(span["target_block"] * ARGS.block_seconds * FRAME_RATE),
                "retrieved_frame": round(span["retrieved_block"] * ARGS.block_seconds * FRAME_RATE),
                "random_frame": round(span["random_block"] * ARGS.block_seconds * FRAME_RATE),
                "block_frames": round(ARGS.block_seconds * FRAME_RATE),
            })
        all_spans.extend(spans)
    save_json("stageS_spans.json", all_spans)
    summary = structure_summary(all_spans)
    summary.update({
        "related_threshold": RELATED_THRESHOLD,
        "unrelated_threshold": UNRELATED_THRESHOLD,
        "window_seconds": ARGS.window,
        "block_seconds": ARGS.block_seconds,
    })
    save_json("stageS_summary.json", summary)
    write_results()
    if not summary["gate_pass"]:
        raise SystemExit("stageS separation gate failed; corpus lacks detectable structure")


def make_stageA_conditions(codes, span, window_frames, eval_frames):
    """Build all four frozen conditions and their exact evaluation offsets."""
    target = span["target_frame"]
    block = span["block_frames"]
    assert target >= window_frames
    evaluation = codes[:, target:target + eval_frames]
    window = codes[:, target - window_frames:target]
    retrieved = codes[:, span["retrieved_frame"]:span["retrieved_frame"] + block]
    random = codes[:, span["random_frame"]:span["random_frame"] + block]
    assert retrieved.shape[-1] == random.shape[-1] == block
    result = {
        "window": (torch.cat([window, evaluation], -1), window_frames),
        "matched": (torch.cat([retrieved, window, evaluation], -1), block + window_frames),
        "random": (torch.cat([random, window, evaluation], -1), block + window_frames),
    }
    if (target + eval_frames) / FRAME_RATE <= MODEL_CONTEXT_SECONDS:
        result["full"] = (codes[:, :target + eval_frames], target)
    return result


def relevance_gain(metrics):
    return float(metrics["random"] - metrics["matched"])


def aggregate_conditions(rows, conditions):
    output = {}
    for stratum in ("related", "unrelated"):
        selected = [row for row in rows if row["stratum"] == stratum]
        means = {
            condition: float(np.mean([
                row["nll"][condition] for row in selected if condition in row["nll"]
            ]))
            for condition in conditions
            if any(condition in row["nll"] for row in selected)
        }
        means["relevance_gain"] = relevance_gain(means)
        means["n_spans"] = len(selected)
        output[stratum] = means
    return output


def stageA_gate(summary):
    rel = summary["related"]["relevance_gain"]
    unrel = summary["unrelated"]["relevance_gain"]
    # smoke-r2 amendment (Ben, 2026-07-27): apply the ordinary 1.5--6.0
    # band only to strata with at least four spans.  Sparse strata remain
    # diagnostic-only, but an alignment-like (<0.5) or clearly broken (>8)
    # value still fails closed at any support level.
    nll_keys = {"window", "matched", "random", "full"}
    nll_by_stratum = {
        name: [value for key, value in group.items() if key in nll_keys]
        for name, group in summary.items()
    }
    # A missing aggregate is not evidence that its NLL is sane.  In
    # particular, ``all([])`` would otherwise let a supported stratum pass the
    # ordinary band without any scored conditions.
    missing_nll_conditions = {
        name: sorted(nll_keys - set(group))
        for name, group in summary.items()
        if nll_keys - set(group)
    }
    nonfinite_nll = any(
        not math.isfinite(float(value))
        for values in nll_by_stratum.values() for value in values
    )
    catastrophic_nll = any(
        value < 0.5 or value > 8.0
        for values in nll_by_stratum.values() for value in values
    )
    band_checked_strata = [
        name for name, group in summary.items() if group["n_spans"] >= 4
    ]
    band_pass = all(
        all(1.5 <= value <= 6.0 for value in nll_by_stratum[name])
        for name in band_checked_strata
    )
    return {
        "gate_pass": rel > 0.02 and rel - unrel >= 0.01,
        "related_relevance_gain": rel,
        "unrelated_relevance_gain": unrel,
        "nll_sanity_pass": (
            bool(nll_by_stratum) and band_pass and not nonfinite_nll
            and not catastrophic_nll and not missing_nll_conditions
        ),
        "nll_band_min_spans": 4,
        "nll_band_checked_strata": band_checked_strata,
        "nll_support_insufficient_strata": [
            name for name, group in summary.items() if group["n_spans"] < 4
        ],
        "nll_nonfinite_stop": nonfinite_nll,
        "nll_missing_conditions_stop": bool(missing_nll_conditions),
        "nll_missing_conditions": missing_nll_conditions,
        "nll_alignment_bug_stop": catastrophic_nll,
    }


def stageA():
    model = load_model()
    codes_list = torch.load(os.path.join(ARGS.out_dir, "codes.pt"))
    spans = load_json("stageS_spans.json")
    if not load_json("stageS_summary.json")["gate_pass"]:
        raise SystemExit("stageS gate failed")
    window_frames = round(ARGS.window * FRAME_RATE)
    eval_frames = round(ARGS.eval_seconds * FRAME_RATE)
    checkpoint = os.path.join(ARGS.out_dir, "stageA_checkpoint.json")
    if ARGS.resume and os.path.exists(checkpoint):
        with open(checkpoint) as handle:
            saved = json.load(handle)
        rows, start = saved["rows"], int(saved["next_span"])
        if start > len(spans):
            raise RuntimeError("stageA checkpoint exceeds frozen span plan")
        log(f"resuming stageA at span {start}/{len(spans)}")
    else:
        rows, start = [], 0
    for index, span in enumerate(spans[start:], start=start):
        codes = codes_list[span["track_index"]]
        conditions = make_stageA_conditions(codes, span, window_frames, eval_frames)
        nll = {
            name: teacher_nll(
                model.lm, value.unsqueeze(0).to(ARGS.device), eval_from=eval_from
            )
            for name, (value, eval_from) in conditions.items()
        }
        rows.append({"span": span, "stratum": span["stratum"], "nll": nll})
        if ((index + 1) % ARGS.track_checkpoint_interval == 0
                or index + 1 == len(spans)):
            with open(checkpoint, "w") as handle:
                json.dump({"next_span": index + 1, "rows": rows}, handle)
            log(f"stageA checkpoint {index + 1}/{len(spans)}")
    save_json("stageA_spans.json", rows)
    summary = aggregate_conditions(rows, ("window", "matched", "random", "full"))
    summary["gate"] = stageA_gate(summary)
    save_json("stageA_summary.json", summary)
    if os.path.exists(checkpoint):
        os.remove(checkpoint)
    write_results()
    if not summary["gate"]["nll_sanity_pass"]:
        raise SystemExit("stageA NLL sanity band failed; inspect fragile plumbing")
    if not summary["gate"]["gate_pass"]:
        raise SystemExit("stageA relevance gate failed; do not run stageD")


def noiseless_self_test(results, tolerance=1e-3):
    return (
        abs(results.get("snr99_cold", -1) - 1.0) <= tolerance
        and abs(results.get("snr99_warm_prev", -1) - 1.0) <= tolerance
    )


def resonator_decode(Hn, atoms, initializer, iterations=16):
    n, dimensions = Hn.shape
    factors = [
        atoms[k].mean(0).expand(n, dimensions).clone()
        if initializer is None else atoms[k][initializer[:, k]].clone()
        for k in range(len(atoms))
    ]
    for _ in range(iterations):
        for factor in range(len(atoms)):
            unbound = Hn.clone()
            for other in range(len(atoms)):
                if other != factor:
                    unbound *= torch.sign(factors[other] + 1e-9)
            factors[factor] = (unbound @ atoms[factor].T) @ atoms[factor]
    return torch.stack([
        (torch.sign(factors[k]) @ atoms[k].T).argmax(-1)
        for k in range(len(atoms))
    ], 1)


def stageC():
    codes_list = torch.load(os.path.join(ARGS.out_dir, "codes.pt"))
    generator = torch.Generator().manual_seed(2)
    atoms = [
        torch.randint(0, 2, (EXPECTED_CARDINALITY, ARGS.hdc_D), generator=generator)
        .float().mul_(2).sub_(1).to(ARGS.device)
        for _ in range(EXPECTED_CODEBOOKS)
    ]
    pairs = []
    for codes in codes_list:
        choices = np.arange(1, codes.shape[-1])
        for t in np.random.choice(choices, min(200, len(choices)), replace=False):
            pairs.append((codes[:, t - 1].numpy(), codes[:, t].numpy()))
    pairs = pairs[:2000]
    previous = torch.tensor(np.array([x for x, _ in pairs]), device=ARGS.device)
    current = torch.tensor(np.array([x for _, x in pairs]), device=ARGS.device)
    product = torch.ones(len(current), ARGS.hdc_D, device=ARGS.device)
    for k in range(EXPECTED_CODEBOOKS):
        product *= atoms[k][current[:, k]]
    results = {}
    for snr in (99, 20, 10, 6, 3, 0):
        # snr99 is explicitly noiseless, not merely very-low numerical noise.
        noisy = product if snr == 99 else product + (
            F.normalize(torch.randn_like(product), dim=1)
            * product.norm(dim=1, keepdim=True) * 10 ** (-snr / 20)
        )
        # At snr99, true-state seeding verifies coding/cleanup for both named
        # paths. Lower SNR retains the actual cold and previous-frame starts.
        initializers = {"cold": None, "warm_prev": previous}
        for name, initializer in initializers.items():
            prediction = resonator_decode(noisy, atoms, initializer)
            results[f"snr{snr}_{name}"] = float(
                (prediction == current).all(1).float().mean()
            )
    output = {
        "D": ARGS.hdc_D,
        "results": results,
        "noiseless_self_test_pass": noiseless_self_test(results),
        "note": "feasibility footnote only; snr99 is a coding self-test",
    }
    save_json("stageC_resonator.json", output)
    write_results()
    if not output["noiseless_self_test_pass"]:
        raise SystemExit("stageC snr99 self-test failed")


class SummaryAdapter(nn.Module):
    def __init__(self, dimensions, model_dim, tokens):
        super().__init__()
        self.tokens = tokens
        self.model_dim = model_dim
        self.net = nn.Sequential(
            nn.Linear(dimensions, 2048), nn.GELU(),
            nn.Linear(2048, model_dim * tokens),
        )

    def forward(self, summary):
        return self.net(summary).view(-1, self.tokens, self.model_dim)


def build_summary(codes, upto, dimensions, atoms, roles):
    if upto <= 0:
        return torch.zeros(dimensions)
    position = torch.arange(upto, dtype=torch.float)
    relative = 1 - position / max(upto, 1)
    bucket = torch.clamp(
        (torch.log2(relative * upto + 1) / math.log2(upto + 1)
         * (len(roles) - 1)).long(), 0, len(roles) - 1
    )
    return torch.sign((roles[bucket] * atoms[codes[0, :upto]]).sum(0) + 1e-9)


def split_track_indices(n_tracks, seed, train_fraction=0.7):
    ids = list(range(n_tracks))
    np.random.RandomState(seed).shuffle(ids)
    cut = min(max(1, int(n_tracks * train_fraction)), n_tracks - 1)
    return ids[:cut], ids[cut:]


def summary_gain(metrics):
    return float(metrics["window"] - metrics["summary"])


def fraction_of_oracle_recovered(metrics):
    oracle = relevance_gain(metrics)
    return summary_gain(metrics) / oracle if oracle > 1e-9 else None


def stageD_metrics(rows):
    result = aggregate_conditions(rows, ("window", "summary", "matched", "random"))
    for stratum in ("related", "unrelated"):
        result[stratum]["summary_gain"] = summary_gain(result[stratum])
        result[stratum]["fraction_of_oracle_recovered"] = (
            fraction_of_oracle_recovered(result[stratum])
        )
    result["related_minus_unrelated_summary_gain"] = (
        result["related"]["summary_gain"] - result["unrelated"]["summary_gain"]
    )
    return result


def stageD():
    stage_a = load_json("stageA_summary.json")
    if not stage_a["gate"]["gate_pass"] or not stage_a["gate"]["nll_sanity_pass"]:
        raise SystemExit("stageA gate did not pass; stageD is forbidden")
    model = load_model()
    lm = model.lm
    for parameter in lm.parameters():
        parameter.requires_grad_(False)
    assert not any(parameter.requires_grad for parameter in lm.parameters())
    codes_list = torch.load(os.path.join(ARGS.out_dir, "codes.pt"))
    spans = load_json("stageS_spans.json")
    train_ids, eval_ids = split_track_indices(len(codes_list), ARGS.seed)
    train_spans = [x for x in spans if x["track_index"] in train_ids and x["stratum"] == "related"]
    eval_spans = [x for x in spans if x["track_index"] in eval_ids]
    assert train_spans and eval_spans
    assert {x["stratum"] for x in eval_spans} == {"related", "unrelated"}, (
        "Stage D evaluation requires both structural strata"
    )
    generator = torch.Generator().manual_seed(3)
    atoms = torch.randint(
        0, 2, (EXPECTED_CARDINALITY, ARGS.hdc_D), generator=generator
    ).float().mul_(2).sub_(1)
    roles = torch.randint(0, 2, (12, ARGS.hdc_D), generator=generator).float().mul_(2).sub_(1)
    model_dim = getattr(lm.condition_provider, "output_dim", 1024)
    window_frames = round(ARGS.window * FRAME_RATE)
    eval_frames = round(ARGS.eval_seconds * FRAME_RATE)

    def train_once(learning_rate):
        adapter = SummaryAdapter(
            ARGS.hdc_D, model_dim, ARGS.adapter_tokens
        ).to(ARGS.device)
        optimizer = torch.optim.Adam(adapter.parameters(), lr=learning_rate)

        def cond_from(summaries):
            """FRAGILE: inject adapter output into text cross-attention."""
            embedding = adapter(summaries)
            mask = torch.ones(
                embedding.shape[:2], dtype=torch.bool, device=embedding.device
            )
            return {"description": (embedding, mask)}

        checkpoint = os.path.join(ARGS.out_dir, "stageD_adapter_checkpoint.pt")
        start, losses = 0, []
        if ARGS.resume and os.path.exists(checkpoint):
            saved = torch.load(checkpoint, map_location=ARGS.device)
            adapter.load_state_dict(saved["adapter"])
            optimizer.load_state_dict(saved["optimizer"])
            start, losses = int(saved["step"]), list(saved["losses"])
            np.random.set_state(saved["numpy_rng"])
            torch.set_rng_state(saved["torch_rng"])
            if torch.cuda.is_available() and saved.get("cuda_rng") is not None:
                torch.cuda.set_rng_state_all(saved["cuda_rng"])
            log(f"resuming stageD at step {start}/{ARGS.adapter_steps}")
        for step in range(start, ARGS.adapter_steps):
            chosen = np.random.choice(len(train_spans), ARGS.batch, replace=True)
            segments, summaries = [], []
            for index in chosen:
                span = train_spans[index]
                codes = codes_list[span["track_index"]]
                target = span["target_frame"]
                segments.append(codes[:, target-window_frames:target+eval_frames])
                summaries.append(build_summary(
                    codes, target-window_frames, ARGS.hdc_D, atoms, roles
                ))
            segments = torch.stack(segments).to(ARGS.device)
            summaries = torch.stack(summaries).to(ARGS.device)
            loss = nll_with_grad(lm, segments, cond_from(summaries), window_frames)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            losses.append(float(loss.detach().cpu()))
            if ((step + 1) % ARGS.checkpoint_interval == 0
                    or step + 1 == ARGS.adapter_steps):
                torch.save({
                    "adapter": adapter.state_dict(), "optimizer": optimizer.state_dict(),
                    "step": step + 1, "losses": losses,
                    "numpy_rng": np.random.get_state(),
                    "torch_rng": torch.get_rng_state(),
                    "cuda_rng": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
                }, checkpoint)
                log(f"stageD checkpoint {step + 1}/{ARGS.adapter_steps}")

        rows = []
        for span in eval_spans:
            codes = codes_list[span["track_index"]]
            base = make_stageA_conditions(codes, span, window_frames, eval_frames)
            target = span["target_frame"]
            summary = build_summary(
                codes, target-window_frames, ARGS.hdc_D, atoms, roles
            ).unsqueeze(0).to(ARGS.device)
            nll = {
                name: teacher_nll(lm, value.unsqueeze(0).to(ARGS.device), eval_from=offset)
                for name, (value, offset) in base.items() if name != "full"
            }
            window_value, window_offset = base["window"]
            nll["summary"] = teacher_nll(
                lm, window_value.unsqueeze(0).to(ARGS.device),
                cond_from(summary), window_offset
            )
            rows.append({"span": span, "stratum": span["stratum"], "nll": nll})
        return adapter, rows, losses

    learning_rate = ARGS.lr
    adapter, rows, losses = train_once(learning_rate)
    metrics = stageD_metrics(rows)
    reran = False
    if any(
        metrics[stratum]["summary"] - metrics[stratum]["window"] > 0.02
        for stratum in ("related", "unrelated")
    ):
        learning_rate /= 2
        reran = True
        adapter, rows, losses = train_once(learning_rate)
        metrics = stageD_metrics(rows)
    torch.save(adapter.state_dict(), os.path.join(ARGS.out_dir, "stageD_adapter.pt"))
    checkpoint = os.path.join(ARGS.out_dir, "stageD_adapter_checkpoint.pt")
    if os.path.exists(checkpoint):
        os.remove(checkpoint)
    save_json("stageD_spans.json", rows)
    metrics.update({
        "learning_rate": learning_rate,
        "reran_after_divergence": reran,
        "adapter_steps": ARGS.adapter_steps,
        "train_track_indices": train_ids,
        "eval_track_indices": eval_ids,
        "final_train_nll": losses[-1] if losses else None,
        "backbone_frozen": True,
    })
    save_json("stageD_summary.json", metrics)
    write_results()


if __name__ == "__main__":
    {
        "stage0": stage0,
        "stageS": stageS,
        "stageA": stageA,
        "stageC": stageC,
        "stageD": stageD,
    }[ARGS.stage]()
