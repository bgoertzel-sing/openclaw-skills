# Matched-state ePC Tiny Shakespeare distillation gate

Status: frozen protocol, 2026-07-15.

## Question

Does block-state predictive-coding relaxation improve Tiny Shakespeare student
distillation relative to both ordinary backpropagation and ordinary knowledge
distillation when initialization, data order, teacher logits, optimizer, dropout,
and evaluation batches are matched?

## Arms and fixed state

- Pretrain one backprop teacher per seed, then freeze it.
- Cache the exact training minibatches and teacher logits once per seed.
- Initialize every student arm from the same state dictionary. Each arm gets a
  fresh AdamW optimizer with identical hyperparameters. Dropout is exactly zero.
- Compare one BP arm, ordinary KD at `lambda={0.001,0.01,0.05}`, and ePC at the
  same lambda values with activity-inference depth `T={1,2,4,8}`. The BP arm is
  the `lambda=0` endpoint. Distillation softmax temperature is separately fixed
  at 2.0 so it is not conflated with ePC inference depth.
- `T=1` must be exactly ordinary KD under autograd. For `T>1`, residual-block
  activities are relaxed under a declared local prediction energy, then
  detached before the local weight objective is differentiated.

## Measurements and invariants

- Held-out perplexity on fixed evaluation batches.
- Per-block ordinary-KD/ePC gradient norm, norm ratio, and mean parameter-wise
  cosine on the first fixed training batch.
- Every activity-energy value and a monotonicity flag.
- Wall time, process high-water RSS, RSS delta, and CUDA peak allocation when
  applicable.
- Exact corpus SHA-256, configuration, seeds, and all raw arm rows in JSON.

The run fails closed if an energy trace rises, a gradient diagnostic is
non-finite, fewer than two seeds complete, or no genuine `T>1` arm has lower
held-out perplexity than both its matched ordinary-KD arm and BP in every seed.
Failure blocks longer ePC training and all crown/head stages; it does not justify
tuning on held-out results and reusing the same run as confirmatory evidence.

## Research rules

Rules 1, 2, 3, 5, and 7 are central: validate the ePC estimator and endpoint,
freeze this software-level contract, retain PyTorch transformer primitives,
record reproducible evidence, and keep teacher/data/ePC/reporting seams modular.

## Post-run normalization correction

The first execution at commit `941b8b3` failed promotion and revealed that
hidden local squared errors were averaged over batch, sequence, and feature
dimensions while PyTorch KD `batchmean` sums sequence/vocabulary terms and
averages only over batch. This suppressed local block credit by approximately
`seq_len*d_model`. The subsequent correction sums each hidden error tensor per
example and averages only over batch. It is a mechanistic correction derived
from gradient diagnostics, not evidence from a successful outcome. Any corpus
rerun using it requires a new frozen run record and cannot be pooled with the
first gate.
