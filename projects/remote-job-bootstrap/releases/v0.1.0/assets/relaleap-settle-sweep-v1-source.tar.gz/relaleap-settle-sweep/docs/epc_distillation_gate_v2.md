# Corrected-normalization ePC distillation gate v2

Frozen 2026-07-15 before execution at commit `cbe4c08`.

This is a new confirmatory diagnostic after the first gate exposed a mechanistic
normalization defect. It does not pool results with v1 and uses untouched seeds
`{73,89,107}`. The only scientific change is batch-consistent hidden local-error
normalization, already validated on the synthetic nonzero-credit invariant.

All other controls and the fail-closed rule remain fixed: dropout zero; cached
minibatches and teacher logits; identical student state and fresh identical
AdamW optimizers; BP, ordinary KD, and ePC with
`lambda={0,.001,.01,.05}`, inference depth `T={1,2,4,8}`, and separately fixed
softmax temperature 2.0. The diagnostic-scale model/data schedule remains
`seq_len=32`, batch 4, teacher/student widths 32/16, two blocks, 12 teacher
steps, six student steps, and four fixed evaluation batches.

Promotion requires at least one genuine `T>1`/positive-lambda candidate to have
lower held-out perplexity than both BP and its matched KD arm in every seed,
with monotone energy and finite block-gradient diagnostics. Otherwise longer
training and every columnar/crown/SLT-guided head stage remain blocked.
