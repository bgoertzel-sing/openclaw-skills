# Draft scalable ePC outcome experiment

Status: design draft only; not an authorization or remote-job record.

## Scientific contrast

Train fresh, matched BP+CE, BP+KD, and ePC+KD GPT-2-small student arms from one
initial state per seed. Preserve every final checkpoint. The teacher, student
architecture, source batches, soft targets, optimizer family, update count, and
evaluation batches are matched. The existing corrected runner commit ancestry
is required; July 17 protocol-drift artifacts are excluded.

Use a pinned WikiText-103 source domain and a pinned, genuinely shifted public
text target (candidate: TinyStories). Dataset revisions, preprocessing code,
token indices, and hashes must be fixed during preflight; no unpinned download
is acceptable.

## Primary functional probe

Freeze each trained backbone and attach the same zero-initialized low-rank
adapter at the same residual locations. Adapt only this common adapter on target
data. This tests whether the learned backbone supports cheaper adaptation while
holding the post-training update mechanism fixed.

Report per seed and jointly:

- target-domain validation-loss area under the adaptation curve;
- target-domain gain at the frozen final adaptation step;
- source-domain forgetting at the same checkpoints;
- adaptation wall time and peak memory.

As a secondary functional probe, run a short common full-model CE fine-tune to
test whether the result depends on freezing the backbone.

## Secondary structural probes

- layerwise linear CKA on exact shared source and target probe tokens;
- effective rank and participation ratio by layer;
- residual-block skip/noise sensitivity;
- fixed token-corruption and target-domain perplexity;
- optional calibrated linear probes only if a label-bearing target is frozen
  before outcome inspection.

## Design and decision rule to freeze before launch

- at least three seeds;
- exact train and adaptation updates plus checkpoint cadence;
- source/target evaluation indices and SHA-256 hashes;
- a pre-adaptation loss-parity tolerance;
- a joint seed-and-batch bootstrap interval;
- ePC must improve target adaptation AUC against both controls without exceeding
  the frozen source-forgetting tolerance;
- structural divergence alone cannot promote ePC;
- missing arms, hash drift, non-finite metrics, or unequal budgets fail closed.

The local v1 effect sizes must not be used to tune thresholds: its chronological
Tiny Shakespeare split was demonstrably too weak.

## Provisional execution shape

One 80 GB A100-class GPU is the conservative starting point because the prior
runner used an A100 PCIe 80 GB successfully at the systems level. Use ephemeral
storage only unless checkpoint size or retry policy justifies a bounded volume.
Upload only the pinned source tree and frozen configs; retrieve checkpoints,
JSON metrics, logs, environment summary, and hashes before termination.

Before provisioning, create a replacement experiment/remote-job record with
the actual RunPod account context, live region/price, immutable image digest,
storage, expected runtime, maximum time/cost, stop/terminate behavior, and
artifact return path. Obtain Ben's fresh explicit approval for exactly that
envelope. The autonomous spend budget is zero.
