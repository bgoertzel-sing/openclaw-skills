# GPT-2-small ePC distillation pilot protocol

Frozen before outcome inspection on 2026-07-16. The machine-readable contract is
`configs/gpt2_small_epc_pilot.json`; disagreement is an error and the JSON wins.

## Scientific question and claim boundary

On a corpus large enough to exercise GPT-2-scale representations, does the
current local ePC relaxation objective improve a six-layer GPT-2 student over
ordinary BP+KD under both equal optimizer updates and equal elapsed training
time? A pass promotes only a larger confirmatory run. It is not evidence for
causal columns, SLT guidance, or general ePC superiority. A failure is a null
result for this exact schedule, not evidence that predictive coding cannot work.

## Frozen model and data

The teacher is `openai-community/gpt2` at git revision
`607a30d783dfa663caf39e06633721c8d4cfcd7e`: 124,439,808 parameters,
`d_model=768`, 12 blocks and 12 heads. The safetensors LFS object is SHA-256
`248dfc3911869ec493c76e65bf2fcf7f615828b0254c12b473182f0f81d3a707`.
The GPT-2 BPE tokenizer comes from the same revision; its vocab and merges
hashes are recorded in JSON. The student has the same width, heads, vocabulary,
positions, and tied embeddings, but six randomly initialized blocks.

Training and evaluation use `Salesforce/wikitext`,
`wikitext-103-raw-v1`, revision
`b08601e04326c79dfdd32d625aee71d232d685c3`. Exact parquet LFS hashes are
recorded in JSON. Tiny Shakespeare must not be substituted.

## Arms and schedule

All arms start from the identical per-seed student state and consume the same
ordered token batches with dropout disabled. The primary arms are BP+CE,
ordinary BP+KD, and ePC+KD. The ordinary loss is
`0.5 * CE + 0.5 * T^2 * KL(teacher/T || student/T)` with `T=2`.

The ePC arm uses four activity states counting the feed-forward state, activity
step size 0.2 with at most 12 monotone backtracks, and output-clamp/KD energy
weight `lambda=0.05`. The hidden-state MSE arm is explicitly exploratory and
separate: it maps student blocks 0--5 to teacher blocks 1,3,5,7,9,11 at weight
0.1 and cannot satisfy the primary promotion criterion.

Each update-matched arm receives 1,000 optimizer updates, context 256,
microbatch 4, accumulation 8, AdamW at `1e-4`, weight decay 0.01, 50-update
warmup, gradient clipping 1.0, and BF16. In addition, ordinary BP+KD runs until
the measured ePC elapsed-time budget for that seed is exhausted. It may finish
an update already started but may not start another after the bound. Report
both update count and elapsed seconds; do not collapse the two controls.

## Deterministic evaluation and diagnostics

Seeds are exactly 1729, 3253, and 6421. The validation token stream is split
into non-overlapping 257-token chunks. For each seed, chunks are ordered by
`SHA256(decimal_seed || ':' || decimal_chunk_index)` and the first 256 are the
fixed eval set. Save chosen indices and their aggregate SHA-256 before training.

Every arm emits JSON containing configuration hash, source commit, seed, arm,
update count, elapsed seconds, student and teacher validation loss/perplexity,
KD gap in nats, and per-block credit diagnostics (gradient norm, ratio to
ordinary KD, cosine, finiteness). ePC also emits every activity-energy trace,
accepted step size and backtrack count. JSON-schema or finiteness failure blocks
promotion.

## Promotion rule

The primary ePC arm promotes only if all invariants pass and all of the following
were written before the run: three distinct seeds; mean validation-loss gain of
at least 0.005 nats over update-matched BP+KD; no seed regresses by more than
0.002 nats; mean gain of at least 0.002 nats over wall-clock-matched BP+KD;
monotone activity energy; finite metrics; and nonzero credit in all six student
blocks. Perplexity and KD-gap are reported but validation loss is decisive.

## CPU dry-run gate

Before GPU approval, a two-layer CPU stub must use the same arm/objective,
batch-order, metric-serialization and promotion-evaluator interfaces. It must
complete all three seeds, reproduce identical JSON on repeat apart from declared
timing fields, preserve exact depth-one KD, exercise genuine relaxation, reject
malformed configs/metrics, and pass the complete local test suite. This is
implementation evidence only; toy outcomes never satisfy scientific promotion.
