# REMOTE_JOB: GPT-2-small ePC distillation pilot

Status: **retired after aborted attempt; fresh approval required; do not provision**.
Provider: RunPod, Ben's account.
Resource name: `relaleap-gpt2-small-epc-pilot-20260716`.

This draft was approved by Ben in Telegram message 8487 ("Yes run the relaleap
test on runpod thx") and consumed by the aborted 2026-07-17 attempt. That
attempt changed images/source and retried outside the frozen ledger, so this
record no longer authorizes provisioning. See experiment
`20260717T003032Z-gpt2-small-runpod-pilot`. A replacement job must pin the
corrected runner commit `d400c15`, a reviewed image, new bounds, and receive
fresh explicit approval.

## Requested bound

- GPU: one A100 PCIe 80 GB at $1.39/hr (Community Cloud, verified 2026-07-17 00:12 UTC).
  A100 SXM 80GB at $1.49/hr is acceptable. L40S 48GB at $0.99/hr is a fallback
  only after a successful memory smoke.
- Region: any RunPod Community Cloud region offering A100 PCIe at or below $1.49/hr.
- Image: `pytorch/pytorch:2.4.0-cuda12.4-cudnn9-runtime`
  Dependency lock: `requirements-gpu.lock.txt` (pinned transformers, tokenizers,
  safetensors, huggingface-hub, datasets, pytest).
- Source: local branch `agent/tinyshakespeare-hdpc`, reviewed production GPU
  runner commit `e4f2f58` (includes runner
  `scripts/run_gpt2_pilot_gpu.py`, direct dependency
  lock, launch script `launch_runpod.sh`, adapter `0cdc70a`, CPU gate `c310230`,
  frozen protocol `886acdc`).
- Storage: 40 GB ephemeral container disk plus 80 GB encrypted pod volume. No
  public endpoint; SSH only. Upload only the clean source archive, frozen JSON,
  and launch script. Dataset/model are public. Privacy class: public research
  code and public corpus only; no secrets, OpenClaw state, or unrelated files.

## Price and cap

Live RunPod pricing verified 2026-07-17 00:12 UTC from https://www.runpod.io/pricing:
- A100 PCIe 80GB: $1.39/hr (Community Cloud)
- A100 SXM 80GB: $1.49/hr (Community Cloud)
- L40S 48GB: $0.99/hr (Community Cloud)

Selected: A100 PCIe 80GB at $1.39/hr.
Estimated runtime: 3-4 GPU-hours for 3 seeds × 3 arms + wall-clock-matched controls.
Hard cap: 6 elapsed hours and USD $10.00 total (6h × $1.39 = $8.34, plus storage buffer).
If the console quote exceeds $1.49/hr or the $10 cap, do not provision — request a new bound.

## Execution and return

Run `runpodctl doctor` locally first. On the pod, verify GPU, CUDA, image digest,
source commit, dependency lock, model/tokenizer/dataset hashes, and a one-update
smoke before starting. Use named tmux session `relaleap-gpt2-epc-20260716`.
Write logs and structured JSON after every arm/seed under
`results/gpt2_small_epc_pilot/<run-id>/`; sync them after each seed to local
`projects/relaleap/experiments/<run-id>/artifacts/`.

Stop immediately on hash/config mismatch, CUDA/OOM after the allowed batch-size
preserving accumulation adjustment, non-finite metric, non-monotone energy,
artifact-write failure, six hours, or USD $10 observed/projected spend.

## Stop, terminate, and cleanup

Stopping is allowed only for the few minutes needed to retrieve and hash
artifacts. After local JSON validation and SHA-256 inventory, terminate the pod
and delete the volume, endpoint, and snapshot. Query RunPod again and record
resource absence and final observed cost in the experiment `RUN.md`. Never
leave a stopped volume billable while drafting the summary.

## Approval status

The earlier unsupported 17:03 PDT approval claim was correctly withdrawn. Ben
later explicitly approved the then-frozen attempt in Telegram message 8487.
That approval was consumed by the aborted run and does not cover the corrected
source or another pod. Do not provision until a new reviewed job record is
explicitly approved.

Filled gaps:
- Production GPU runner and promotion evaluator: reviewed at `e4f2f58`
- Direct dependency pins: `requirements-gpu.lock.txt`; the fully resolved
  environment will be captured on-pod as `environment.freeze.txt`
- Pod-side launch script: verifies the archive commit marker and pinned public
  model/tokenizer/dataset hashes before any training
- Live RunPod pricing: verified 2026-07-17 00:12 UTC (A100 PCIe $1.39/hr)
- Final clean launch source commit: `e4f2f58`

Remaining pre-flight steps (on-pod, before training):
- Verify immutable image digest of `pytorch/pytorch:2.4.0-cuda12.4-cudnn9-runtime`
- Run one-update GPU smoke to measure actual per-update runtime
- Confirm total estimated runtime stays within 6h / $10 cap

The two-layer CPU interface gate passed at `c310230` with 118 tests; see
experiment `20260716T201500Z-gpt2-pilot-cpu-dry-run`. The production block-state
adapter passed separately at `0cdc70a` with 121 full tests; see
`20260716T221908Z-gpt2-production-adapter`. All 11 protocol/dry-run/adapter tests
re-verified at commit `e24dbc8`.
