# ePC outcome probe: local instrument gate and scalable follow-up

## Question

When BP, ordinary KD, and ePC distillation reach similar held-out loss, does ePC
produce a network with a reproducible functional or structural advantage?

This protocol tests properties of the trained networks. It does not reinterpret
small perplexity differences as efficacy evidence.

## Stage 1: Pop!_OS local instrument gate

Train matched two-block character transformers from the same initialization and
fixed batches on domain A of Tiny Shakespeare. Arms are BP+CE, BP+KD, and
ePC+KD. The teacher, soft targets, optimizer family, update count, and evaluation
batches are matched. Domain B is a disjoint chronological corpus slice.

Primary endpoint: apply the same ordinary-CE adaptation procedure to every
trained arm on domain B. Report adaptation gain on B and forgetting on A. This
isolates whether the learned starting networks differ in plasticity; it does not
claim that the common CE adaptation rule is the best deployment rule for ePC.

Secondary endpoints:

1. layerwise linear CKA between arms on identical domain-A observations;
2. layerwise effective rank and participation ratio;
3. loss increase when each residual block is replaced by the identity map;
4. loss increase under a fixed 10% token-corruption mask.

Instrument controls must pass before interpreting outcomes: identical and
orthogonally rotated representations have CKA 1; known-rank activations recover
the expected spectral scale; corruption is seed-deterministic; all metrics are
finite; repeated runs are identical outside timing fields.

The local run is an instrumentation and effect-size pilot, not a promotion
test. Two seeds are deliberately too few for a scientific advantage claim.

## Stage 2: scalable GPT-2-small/WikiText follow-up

Proceed only after Stage 1 produces complete deterministic records and the
probe controls pass. Retrain a fresh matched BP/KD/ePC checkpoint trio from one
pinned source commit and protocol; the aborted July 17 artifacts are ineligible.
Run at least three frozen seeds and preserve checkpoints plus exact probe-set
indices and hashes.

Primary comparison is ePC versus both BP and KD on common-rule adaptation:

- domain-B adaptation area under the loss curve;
- domain-A forgetting after a fixed adaptation budget;
- a joint bootstrap confidence interval over seeds and evaluation batches.

CKA, spectral summaries, block-skip sensitivity, and corruption/OOD robustness
remain secondary. A structural difference without functional improvement is a
descriptive result, not promotion. Promotion requires ePC to improve the
preregistered adaptation/forgetting tradeoff against both controls without a
material pre-adaptation loss regression. Exact thresholds, domain split,
checkpoint cadence, GPU type, runtime, and cost must be frozen in a new remote
job record before provisioning. Paid execution requires fresh explicit approval.

## Fail-closed conditions

- source, config, data, checkpoint, or probe-set hash mismatch;
- missing arm/seed/checkpoint or non-finite metric;
- unequal initialization, batches, adaptation rule, or adaptation budget;
- nondeterministic local records outside declared timing fields;
- post-hoc domain, seed, threshold, or horizon extension.
