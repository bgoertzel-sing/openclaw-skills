#!/usr/bin/env bash
set -euo pipefail

# RelaLeap GPT-2-small ePC pilot — RunPod launch script
#
# Usage: bash launch_runpod.sh <source-archive> <output-dir>
#
# This script runs on the RunPod pod after environment setup.
# It does NOT provision anything. It assumes the pod is already
# running with the correct image and GPU.

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SOURCE_ARCHIVE="${1:?source archive required}"
OUTPUT_DIR="${2:?output directory required}"
SOURCE_COMMIT="${3:?source commit hash required}"

echo "=== RelaLeap GPT-2-small ePC pilot launch ==="
echo "Source archive: $SOURCE_ARCHIVE"
echo "Output dir: $OUTPUT_DIR"
echo "Source commit: $SOURCE_COMMIT"
echo "Time: $(date -u +%Y-%m-%dT%H:%M:%SZ)"

# Verify GPU
python3 -c "import torch; assert torch.cuda.is_available(); print(f'CUDA: {torch.cuda.get_device_name(0)}'); print(f'PyTorch: {torch.__version__}')"

# Extract source
echo "=== Extracting source ==="
mkdir -p /workspace/relaleap
tar xzf "$SOURCE_ARCHIVE" -C /workspace/relaleap
cd /workspace/relaleap

# Verify source commit
test -f SOURCE_COMMIT
ARCHIVE_COMMIT=$(tr -d '[:space:]' < SOURCE_COMMIT)
test "$ARCHIVE_COMMIT" = "$SOURCE_COMMIT"
echo "Source archive commit: $ARCHIVE_COMMIT"

# Install the frozen direct dependencies. Capture the fully resolved
# environment below because this pilot file does not pin transitive wheels.
echo "=== Installing dependencies ==="
pip install -r requirements-gpu.lock.txt 2>&1 | tail -10
python3 -m pip freeze --all | sort > environment.freeze.txt

# Pre-flight: download and hash model/tokenizer/dataset
echo "=== Pre-flight: downloading pinned model and dataset ==="
python3 -c "
from pathlib import Path
from transformers import AutoModelForCausalLM, AutoTokenizer
from datasets import load_dataset
from huggingface_hub import hf_hub_download
import hashlib, json

protocol = json.loads(Path('configs/gpt2_small_epc_pilot.json').read_text())

def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def require_hash(path, expected, label):
    observed = sha256(path)
    if observed != expected:
        raise RuntimeError(f'{label} hash mismatch: {observed} != {expected}')
    print(f'{label} sha256: {observed}')

# Download and verify teacher
teacher = protocol['teacher']
weights = hf_hub_download(teacher['model_id'], 'model.safetensors', revision=teacher['revision'])
require_hash(weights, teacher['weights_sha256'], 'teacher weights')
model = AutoModelForCausalLM.from_pretrained(teacher['model_id'], revision=teacher['revision'], use_safetensors=True)
print(f'Teacher params: {sum(p.numel() for p in model.parameters()):,}')
if sum(p.numel() for p in model.parameters()) != teacher['parameter_count']:
    raise RuntimeError('teacher parameter-count mismatch')

# Download and verify tokenizer
tokenizer = protocol['tokenizer']
vocab = hf_hub_download(tokenizer['model_id'], 'vocab.json', revision=tokenizer['revision'])
merges = hf_hub_download(tokenizer['model_id'], 'merges.txt', revision=tokenizer['revision'])
require_hash(vocab, tokenizer['vocab_sha256'], 'tokenizer vocab')
require_hash(merges, tokenizer['merges_sha256'], 'tokenizer merges')
tok = AutoTokenizer.from_pretrained(tokenizer['model_id'], revision=tokenizer['revision'])
print(f'Vocab size: {tok.vocab_size}')
if tok.vocab_size != tokenizer['vocab_size']:
    raise RuntimeError('tokenizer vocabulary-size mismatch')

# Download and verify the pinned source parquet files before materialization
dataset = protocol['dataset']
train_files = [
    'wikitext-103-raw-v1/train-00000-of-00002.parquet',
    'wikitext-103-raw-v1/train-00001-of-00002.parquet',
]
validation_files = ['wikitext-103-raw-v1/validation-00000-of-00001.parquet']
train_hashes = sorted(sha256(hf_hub_download(
    dataset['id'], name, revision=dataset['revision'], repo_type='dataset'
)) for name in train_files)
validation_hashes = sorted(sha256(hf_hub_download(
    dataset['id'], name, revision=dataset['revision'], repo_type='dataset'
)) for name in validation_files)
if train_hashes != sorted(dataset['train_lfs_sha256']):
    raise RuntimeError(f'train dataset hash mismatch: {train_hashes}')
if validation_hashes != [dataset['validation_lfs_sha256']]:
    raise RuntimeError(f'validation dataset hash mismatch: {validation_hashes}')
ds = load_dataset(dataset['id'], dataset['subset'], revision=dataset['revision'])
print(f'Train samples: {len(ds[\"train\"])}')
print(f'Val samples: {len(ds[\"validation\"])}')
print(f'Train cache sha256: {train_hashes}')
print(f'Validation cache sha256: {validation_hashes}')
print('Pre-flight complete')
"

# Run the pilot
echo "=== Running pilot ==="
mkdir -p "$OUTPUT_DIR"
HF_HUB_OFFLINE=1 HF_DATASETS_OFFLINE=1 python3 scripts/run_gpt2_pilot_gpu.py \
  --protocol configs/gpt2_small_epc_pilot.json \
  --output "$OUTPUT_DIR" \
  --device cuda \
  --source-commit "$SOURCE_COMMIT"

echo "=== Pilot complete ==="
echo "Results in: $OUTPUT_DIR"
echo "Time: $(date -u +%Y-%m-%dT%H:%M:%SZ)"

# Hash all output files
echo "=== Output hashes ==="
cd "$OUTPUT_DIR"
for f in *.json; do
  echo "$(sha256sum "$f")"
done
