from __future__ import annotations

from .calibration_benchmarks import (
    AnalyticCalibrationBenchmark,
    BenchmarkFamily,
    InteractionSign,
    TrueTargets,
    crossing_singularity,
    cusp_singularity,
    independent_composition,
    nonzero_product_ridge,
    overparameterized_mixture,
    product_singularity,
    rank_deficient_linear,
    redundant_composition,
    regular_linear_gaussian,
    synergistic_composition,
)

AnalyticBenchmark = AnalyticCalibrationBenchmark
AnalyticTarget = TrueTargets


def registry() -> dict[str, AnalyticBenchmark]:
    """Return the pre-registered analytic SLT calibration benchmark suite."""

    benchmarks = [
        regular_linear_gaussian(),
        rank_deficient_linear(),
        product_singularity(),
        nonzero_product_ridge(),
        cusp_singularity(),
        crossing_singularity(),
        overparameterized_mixture(),
        independent_composition(),
        redundant_composition(),
        synergistic_composition(),
    ]
    return {bench.benchmark_id: bench for bench in benchmarks}


def list_benchmarks() -> list[str]:
    return sorted(registry())


def get_benchmark(name: str) -> AnalyticBenchmark:
    try:
        return registry()[name]
    except KeyError as exc:
        known = ", ".join(list_benchmarks())
        raise KeyError(f"unknown analytic benchmark {name!r}; known benchmarks: {known}") from exc


__all__ = [
    "AnalyticBenchmark",
    "AnalyticTarget",
    "BenchmarkFamily",
    "InteractionSign",
    "TrueTargets",
    "crossing_singularity",
    "cusp_singularity",
    "get_benchmark",
    "independent_composition",
    "list_benchmarks",
    "nonzero_product_ridge",
    "overparameterized_mixture",
    "product_singularity",
    "rank_deficient_linear",
    "redundant_composition",
    "regular_linear_gaussian",
    "registry",
    "synergistic_composition",
]
