"""Deterministic multi-step execution for the clean-room PCStep adapter.

This is deliberately a KD-only engineering experiment: it compares the T=1
endpoint with the same update sequence using activity settlement. It makes no
claim to implement Mesto's unpublished transformer-local update rule.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Mapping

import torch

from .pcstep_adapter import PCStepBatch, PCStepSnapshot, capture_snapshot, model_digest, pc_step, restore_snapshot, snapshot_bytes


@dataclass(frozen=True)
class ArmResult:
    arm: str
    objectives: tuple[float, ...]
    final_snapshot: PCStepSnapshot
    final_snapshot_bytes: bytes
    final_model_digest: str


BatchProvider = Callable[[int], PCStepBatch]


def run_arm(
    model: Any,
    optimizer: torch.optim.Optimizer,
    initial: PCStepSnapshot,
    batches: BatchProvider,
    *,
    arm: str,
    updates: int,
    settle_steps: int,
    temperature: float,
    gate: Mapping[int, bool],
) -> ArmResult:
    """Run a fixed batch plan from a restored snapshot and capture final state."""
    if arm not in {"t1_kd", "settled_epc"}:
        raise ValueError("unknown arm")
    if updates <= 0 or settle_steps < 1:
        raise ValueError("updates must be positive and settle_steps at least one")
    restore_snapshot(model, optimizer, initial)
    objectives: list[float] = []
    steps = 1 if arm == "t1_kd" else settle_steps
    for update in range(updates):
        batch = batches(update)
        result = pc_step(
            model, optimizer, batch, gate=gate, steps=steps,
            temperature=temperature, outer_step=update,
        )
        objectives.append(result.objective)
    final = capture_snapshot(model, optimizer, outer_step=updates, batch_cursor=updates)
    return ArmResult(
        arm=arm,
        objectives=tuple(objectives),
        final_snapshot=final,
        final_snapshot_bytes=snapshot_bytes(final),
        final_model_digest=model_digest(model),
    )


def replay_is_exact(
    model: Any,
    optimizer: torch.optim.Optimizer,
    initial: PCStepSnapshot,
    batches: BatchProvider,
    **kwargs: Any,
) -> bool:
    """Run the same arm twice and require identical objectives and snapshot."""
    first = run_arm(model, optimizer, initial, batches, **kwargs)
    second = run_arm(model, optimizer, initial, batches, **kwargs)
    return first.objectives == second.objectives and first.final_snapshot_bytes == second.final_snapshot_bytes
