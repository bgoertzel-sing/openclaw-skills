from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Literal
import json, time

EventType = Literal["column_growth", "split", "merge", "transfer", "kill"]

@dataclass(frozen=True)
class StructuralEvent:
    event_type: EventType
    step: int
    columns: list[int]
    reason: str
    metrics: dict[str, float]
    accepted: bool
    seed: int | None = None
    timestamp: float = 0.0
    extra: dict[str, Any] | None = None

class EventLog:
    def __init__(self) -> None:
        self.events: list[StructuralEvent] = []
    def append(self, event_type: EventType, step: int, columns: list[int], reason: str, metrics: dict[str, float] | None = None, accepted: bool = False, seed: int | None = None, extra: dict[str, Any] | None = None) -> StructuralEvent:
        event = StructuralEvent(event_type, step, columns, reason, metrics or {}, accepted, seed, time.time(), extra)
        self.events.append(event)
        return event
    def to_rows(self) -> list[dict[str, Any]]:
        return [asdict(e) for e in self.events]
    def write_jsonl(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as f:
            for row in self.to_rows():
                f.write(json.dumps(row, sort_keys=True) + "\n")
