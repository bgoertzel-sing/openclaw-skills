from __future__ import annotations

from dataclasses import dataclass

import torch

from relaleap.arms import RankOneColumnLearner
from relaleap.slt.gauge import GaugePolicy, GaugeReport, canonicalize_rank_one_atoms


@dataclass(frozen=True)
class RankOneAtomSnapshot:
    read: torch.Tensor
    write: torch.Tensor
    amplitude: torch.Tensor
    membership_atoms_by_column: torch.Tensor
    report: GaugeReport | None = None


def rank_one_atom_snapshot(arm: RankOneColumnLearner) -> RankOneAtomSnapshot:
    """Extract rank-one atom coordinates from a RelaLeap rank-one learner.

    ``membership_atoms_by_column`` is softmax-normalized and shaped
    ``[num_atoms, num_columns]`` so it can be permuted with atoms for reports.
    """

    return RankOneAtomSnapshot(
        read=arm.a.detach().clone(),
        write=arm.b.detach().clone(),
        amplitude=arm.beta.detach().clone(),
        membership_atoms_by_column=torch.softmax(arm.q_logits.detach(), dim=0).T.contiguous(),
    )


def canonical_rank_one_atom_snapshot(
    arm: RankOneColumnLearner,
    *,
    usage: torch.Tensor | None = None,
    policy: GaugePolicy | None = None,
) -> RankOneAtomSnapshot:
    """Return a canonical reporting snapshot for a rank-one learner.

    The current train-time arm uses tanh atoms, so this helper is for reporting
    and SLT-coordinate accounting rather than in-place model rewriting; nonlinear
    scale changes are not applied to the live module.
    """

    snap = rank_one_atom_snapshot(arm)
    read, write, amp, membership, report = canonicalize_rank_one_atoms(
        snap.read,
        snap.write,
        snap.amplitude,
        usage=usage,
        membership=snap.membership_atoms_by_column,
        policy=policy,
    )
    assert membership is not None
    return RankOneAtomSnapshot(read=read, write=write, amplitude=amp, membership_atoms_by_column=membership, report=report)
