"""Common post-training probes for matched BP, KD, and ePC networks."""
from __future__ import annotations

import copy
import math
from typing import Iterable

import torch
from torch import nn

from .tinyshakespeare import CausalCharTransformerLM, cross_entropy_for_logits


def _matrix(values: torch.Tensor) -> torch.Tensor:
    if values.ndim < 2:
        raise ValueError("probe activations must have at least two dimensions")
    return values.detach().to(dtype=torch.float64).reshape(-1, values.shape[-1])


def linear_cka(left: torch.Tensor, right: torch.Tensor) -> float:
    """Linear centered-kernel alignment over matched observations."""

    x, y = _matrix(left), _matrix(right)
    if x.shape[0] != y.shape[0]:
        raise ValueError("CKA inputs must contain the same number of observations")
    x = x - x.mean(dim=0, keepdim=True)
    y = y - y.mean(dim=0, keepdim=True)
    cross = torch.linalg.matrix_norm(x.T @ y) ** 2
    left_norm = torch.linalg.matrix_norm(x.T @ x)
    right_norm = torch.linalg.matrix_norm(y.T @ y)
    denominator = left_norm * right_norm
    if denominator <= 0:
        raise ValueError("CKA is undefined for constant activations")
    return float((cross / denominator).clamp(0.0, 1.0))


def spectral_summary(values: torch.Tensor) -> dict[str, float]:
    """Effective rank and participation ratio of centered activations."""

    x = _matrix(values)
    x = x - x.mean(dim=0, keepdim=True)
    eigenvalues = torch.linalg.svdvals(x).square()
    total = eigenvalues.sum()
    if total <= 0:
        raise ValueError("spectral summary is undefined for constant activations")
    probabilities = eigenvalues / total
    nonzero = probabilities[probabilities > 0]
    effective_rank = torch.exp(-(nonzero * nonzero.log()).sum())
    participation_ratio = total.square() / eigenvalues.square().sum()
    return {
        "effective_rank": float(effective_rank),
        "participation_ratio": float(participation_ratio),
    }


@torch.no_grad()
def collect_hidden_states(
    model: CausalCharTransformerLM,
    batches: Iterable[tuple[torch.Tensor, torch.Tensor]],
) -> tuple[torch.Tensor, ...]:
    model.eval()
    collected: list[list[torch.Tensor]] = []
    for tokens, _ in batches:
        states = model.forward_states(tokens)[:-1]
        if not collected:
            collected = [[] for _ in states]
        if len(states) != len(collected):
            raise ValueError("model returned an inconsistent number of hidden states")
        for target, state in zip(collected, states):
            target.append(state.detach().cpu())
    if not collected:
        raise ValueError("at least one probe batch is required")
    return tuple(torch.cat(layer, dim=0) for layer in collected)


@torch.no_grad()
def mean_loss(
    model: nn.Module,
    batches: Iterable[tuple[torch.Tensor, torch.Tensor]],
) -> float:
    model.eval()
    losses = [float(cross_entropy_for_logits(model(x), y)) for x, y in batches]
    if not losses:
        raise ValueError("at least one evaluation batch is required")
    return sum(losses) / len(losses)


@torch.no_grad()
def block_skip_losses(
    model: CausalCharTransformerLM,
    batches: Iterable[tuple[torch.Tensor, torch.Tensor]],
) -> list[float]:
    """Evaluate each residual block by replacing it with the identity map."""

    model.eval()
    per_block: list[list[float]] = [[] for _ in model.blocks]
    for tokens, targets in batches:
        _, seq_len = tokens.shape
        positions = torch.arange(seq_len, device=tokens.device)
        initial = model.token_embedding(tokens) + model.position_embedding(positions)[None, :, :]
        causal_mask = torch.triu(
            torch.ones(seq_len, seq_len, dtype=torch.bool, device=tokens.device), diagonal=1
        )
        for skipped in range(len(model.blocks)):
            state = initial
            for index, block in enumerate(model.blocks):
                if index != skipped:
                    state = block(state, causal_mask)
            logits = model.lm_head(model.ln_f(state))
            per_block[skipped].append(float(cross_entropy_for_logits(logits, targets)))
    return [sum(values) / len(values) for values in per_block]


def corrupt_batches(
    batches: Iterable[tuple[torch.Tensor, torch.Tensor]],
    *,
    vocab_size: int,
    probability: float,
    seed: int,
) -> tuple[tuple[torch.Tensor, torch.Tensor], ...]:
    if not 0.0 <= probability <= 1.0:
        raise ValueError("corruption probability must be in [0, 1]")
    generator = torch.Generator().manual_seed(seed)
    corrupted = []
    for tokens, targets in batches:
        mask = torch.rand(tokens.shape, generator=generator) < probability
        replacements = torch.randint(vocab_size, tokens.shape, generator=generator)
        corrupted.append((torch.where(mask.to(tokens.device), replacements.to(tokens.device), tokens), targets))
    return tuple(corrupted)


def common_ce_adaptation(
    model: CausalCharTransformerLM,
    adaptation_batches: Iterable[tuple[torch.Tensor, torch.Tensor]],
    *,
    learning_rate: float,
) -> CausalCharTransformerLM:
    """Apply the same ordinary-CE adaptation rule to every trained arm."""

    adapted = copy.deepcopy(model)
    adapted.train()
    optimizer = torch.optim.AdamW(adapted.parameters(), lr=learning_rate)
    count = 0
    for tokens, targets in adaptation_batches:
        optimizer.zero_grad(set_to_none=True)
        loss = cross_entropy_for_logits(adapted(tokens), targets)
        if not math.isfinite(float(loss.detach())):
            raise ValueError("non-finite adaptation loss")
        loss.backward()
        optimizer.step()
        count += 1
    if count == 0:
        raise ValueError("at least one adaptation batch is required")
    return adapted
