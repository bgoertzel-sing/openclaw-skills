from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from .ci_gates import evaluate_ci_gates
from .reports import CalibrationReport, EstimatorRunReport, SamplerDiagnostics


@dataclass(frozen=True)
class DecisionReport:
    slt_evidence_status: str
    estimator_type: str
    estimated_parameter_blocks: list[str]
    wbic_temperature: float
    wbic_n: int
    chain_count: int
    total_steps_per_chain: int
    ess_per_chain: list[float]
    seed_cv: float
    calibration_benchmarks_passed: bool
    calibration_benchmark_details: dict[str, Any]
    null_normalized_margin: float
    null_normalized_ci: tuple[float, float]
    regime_discriminability: str
    finite_sample_caveat: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def make_decision_report(estimator_results: list[Any], parameter_blocks: list[Any], calibration_report: CalibrationReport, sampler_diagnostics: SamplerDiagnostics) -> DecisionReport:
    first = estimator_results[0] if estimator_results else None
    lam = float(getattr(first, "lambda_hat", getattr(first, "lambda_single_n", 0.0))) if first is not None else 0.0
    se = float(getattr(first, "lambda_se", getattr(first, "lambda_stderr", 0.0))) if first is not None else 0.0
    blocks = [str(getattr(b, "block_id", getattr(getattr(b, "block", None), "name", getattr(b, "name", b)))) for b in parameter_blocks]
    return DecisionReport(
        slt_evidence_status="allow_releap_evidence" if calibration_report.status == "pass" and lam >= 0 else "block_releap_evidence",
        estimator_type=str(getattr(first, "estimator_kind", "finite_sample_wbic_sgld_proxy_not_exact_rlct")),
        estimated_parameter_blocks=blocks,
        wbic_temperature=float(getattr(sampler_diagnostics, "wbic_temperature", getattr(first, "beta_total_energy", 0.0))),
        wbic_n=int(getattr(first, "n_data", 0)) if first is not None else 0,
        chain_count=int(getattr(sampler_diagnostics, "chains", getattr(first, "num_chains", 0))),
        total_steps_per_chain=int(getattr(first, "num_steps", 0)) if first is not None else 0,
        ess_per_chain=[float(getattr(sampler_diagnostics, "effective_sample_size", 0.0))],
        seed_cv=float(getattr(sampler_diagnostics, "monte_carlo_cv", 0.0)),
        calibration_benchmarks_passed=calibration_report.status == "pass",
        calibration_benchmark_details={"status": calibration_report.status, "benchmarks": list(calibration_report.benchmarks), "expected_lambda": dict(calibration_report.expected_lambda), "observed_lambda": dict(calibration_report.observed_lambda), "tolerance": calibration_report.tolerance, "notes": calibration_report.notes},
        null_normalized_margin=lam,
        null_normalized_ci=(lam - 1.96 * se, lam + 1.96 * se),
        regime_discriminability="calibrated_stable" if calibration_report.status == "pass" and lam >= 0 else "not_decision_usable",
        finite_sample_caveat="Finite-sample WBIC/SGLD proxy only: not an exact RLCT claim.",
    )


def validate_decision_report(report: DecisionReport) -> list[str]:
    errors: list[str] = []
    for field_name in DecisionReport.__dataclass_fields__:
        value = getattr(report, field_name)
        if value is None or value == "" or value == [] or value == {}:
            errors.append(f"{field_name} is required")
    if report.chain_count < 4:
        errors.append("chain_count must be at least 4")
    if report.wbic_n <= 0:
        errors.append("wbic_n must be positive")
    if report.total_steps_per_chain <= 0:
        errors.append("total_steps_per_chain must be positive")
    if len(report.null_normalized_ci) != 2 or report.null_normalized_ci[0] > report.null_normalized_ci[1]:
        errors.append("null_normalized_ci must be an ordered pair")
    caveat = report.finite_sample_caveat.lower()
    if "finite-sample" not in caveat or "not an exact rlct" not in caveat:
        errors.append("finite_sample_caveat must preserve finite-sample/not-exact-RLCT wording")
    return errors


def decision_summary(report: EstimatorRunReport) -> dict[str, object]:
    gates = evaluate_ci_gates(report)
    allowed = all(gate.passed for gate in gates) and report.scientific_decision_usable
    return {
        "releap_slt_evidence_allowed": allowed,
        "promotion_allowed": allowed,
        "scientific_decision_usable": allowed,
        "decision": "allow_releap_evidence" if allowed else "block_promotion",
        "finite_sample_wording": report.finite_sample_wording,
        "gates": [asdict(gate) for gate in gates],
    }


def build_decision_markdown(report: EstimatorRunReport) -> str:
    summary = decision_summary(report)
    lines = [
        "# RelaLeap SLT Estimator Decision Report", "", "## Decision",
        f"- decision: {summary['decision']}",
        f"- releap_slt_evidence_allowed: {summary['releap_slt_evidence_allowed']}",
        f"- promotion_allowed: {summary['promotion_allowed']}",
        f"- finite_sample_wording: {summary['finite_sample_wording']}", "", "## CI gates",
    ]
    for gate in summary["gates"]:  # type: ignore[index]
        lines.append(f"- {gate['gate_name']}: {'pass' if gate['passed'] else 'fail'} -- {gate['reason']}")
    lines.extend(["", "## Validation plan", report.validation_plan_text, "", "## Coverage and budget", f"- input_sample_size: {report.input_sample_size}", f"- input_coverage_report: {report.input_coverage_report}", f"- inference_budget_report: {report.inference_budget_report}", "", "## Lambda estimates"])
    for estimate in report.lambda_estimates:
        lines.append(f"- {estimate.target}: lambda_hat={estimate.lambda_hat}, se={estimate.standard_error}, null_normalized_margin={estimate.null_normalized_margin}; {estimate.interpretation}")
    lines.append("")
    return "\n".join(lines)


def write_decision_report(report: EstimatorRunReport, out_dir: str | Path) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / "slt_estimator_report.json").write_text(json.dumps(report.to_dict(), indent=2, sort_keys=True), encoding="utf-8")
    (out / "slt_estimator_decision.md").write_text(build_decision_markdown(report), encoding="utf-8")
