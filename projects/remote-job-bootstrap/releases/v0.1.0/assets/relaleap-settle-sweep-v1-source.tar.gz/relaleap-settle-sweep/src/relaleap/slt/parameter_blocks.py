from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

BlockRole = Literal["atoms", "dictionary", "router", "membership", "shared_core", "joint", "other"]


@dataclass(frozen=True)
class ParameterBlock:
    """Declared live parameter block sampled by an SLT estimator.

    The block name is the stable join key used by benchmark, estimator, gauge,
    and report artifacts.  `trainable=True` is required for decision-grade SLT
    evidence; frozen proxy blocks must remain diagnostic-only.
    """

    name: str
    role: BlockRole
    size: int
    trainable: bool = True
    parent: str | None = None
    mask_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("ParameterBlock.name must be non-empty")
        if self.size <= 0:
            raise ValueError("ParameterBlock.size must be positive")


@dataclass(frozen=True)
class ParameterBlockReport:
    """Report-side summary for one estimated parameter block."""

    block: ParameterBlock
    theta_hat_status: str
    gauge_policy_id: str
    prior_family: str
    prior_scale: float
    n_parameters_sampled: int
    live_parameter_fraction: float
    notes: str = ""

    def __post_init__(self) -> None:
        if self.n_parameters_sampled <= 0:
            raise ValueError("n_parameters_sampled must be positive")
        if not 0.0 <= self.live_parameter_fraction <= 1.0:
            raise ValueError("live_parameter_fraction must be in [0, 1]")
