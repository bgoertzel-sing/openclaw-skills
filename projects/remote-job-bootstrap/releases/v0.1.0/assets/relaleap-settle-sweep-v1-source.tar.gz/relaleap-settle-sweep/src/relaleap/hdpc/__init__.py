"""CPU-first predictive-coding primitives for the HDPC prototype.

This package intentionally starts with a tiny MLP reference implementation.
It establishes endpoint and identity invariants before any transformer trainer
or Tiny Shakespeare data path is added.
"""

from .crown import IdentityPCCrown
from .gpt2_epc import GPT2BlockStateAdapter, GPT2ForwardStates, gpt2_epc_objective
from .pcstep_adapter import (
    PCStepBatch,
    PCStepResult,
    PCStepSnapshot,
    capture_snapshot,
    model_digest,
    pc_step,
    restore_snapshot,
    snapshot_bytes,
)
from .mlp import PCInferenceTrace, PredictiveCodingMLP
from .transformer_epc import TransformerEPCTrace, transformer_epc_objective
from .tinyshakespeare import (
    CausalCharTransformerLM,
    HDPCTinyShakespeareStudent,
    HDPCTrainingConfig,
    TinyCharTransformerConfig,
    TinyShakespeareTokenizer,
    compare_bp_and_pc_gradients,
    cross_entropy_for_logits,
    get_batch,
    kd_loss,
    prepare_tinyshakespeare_data,
    run_homotopy_kd_training,
)

__all__ = [
    "CausalCharTransformerLM",
    "HDPCTrainingConfig",
    "GPT2BlockStateAdapter",
    "GPT2ForwardStates",
    "PCStepBatch",
    "PCStepResult",
    "PCStepSnapshot",
    "capture_snapshot",
    "model_digest",
    "pc_step",
    "restore_snapshot",
    "snapshot_bytes",
    "HDPCTinyShakespeareStudent",
    "IdentityPCCrown",
    "PCInferenceTrace",
    "PredictiveCodingMLP",
    "TinyCharTransformerConfig",
    "TinyShakespeareTokenizer",
    "TransformerEPCTrace",
    "compare_bp_and_pc_gradients",
    "cross_entropy_for_logits",
    "get_batch",
    "gpt2_epc_objective",
    "kd_loss",
    "prepare_tinyshakespeare_data",
    "run_homotopy_kd_training",
    "transformer_epc_objective",
]
