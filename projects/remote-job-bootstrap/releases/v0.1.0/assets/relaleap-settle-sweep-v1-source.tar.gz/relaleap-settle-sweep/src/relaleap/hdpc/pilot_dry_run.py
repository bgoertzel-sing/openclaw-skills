"""Deterministic two-layer execution gate for the GPT-2 pilot interfaces."""
from __future__ import annotations

import copy
import hashlib
import json
import math
from pathlib import Path
import time
from typing import Any

import torch

from .pilot_protocol import validate_pilot_protocol
from .tinyshakespeare import (
    CausalCharTransformerLM,
    TinyCharTransformerConfig,
    compare_bp_and_pc_gradients,
    cross_entropy_for_logits,
    kd_loss,
)
from .transformer_epc import transformer_epc_objective

SCHEMA = "relaleap.gpt2_epc_metrics.v1"
TIMING_FIELDS = {"elapsed_seconds"}


def _canonical_hash(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def _fixed_batches(seed: int, count: int, *, vocab: int, length: int):
    generator = torch.Generator().manual_seed(seed)
    return tuple(
        (
            torch.randint(vocab, (2, length), generator=generator),
            torch.randint(vocab, (2, length), generator=generator),
        )
        for _ in range(count)
    )


def _block_credit(model, ordinary, predictive) -> list[dict[str, Any]]:
    rows = compare_bp_and_pc_gradients(model, ordinary, predictive)
    grouped: dict[str, list[Any]] = {}
    for row in rows:
        if row.name.startswith("blocks."):
            grouped.setdefault(".".join(row.name.split(".")[:2]), []).append(row)
    result = []
    for block, members in sorted(grouped.items()):
        bp = math.sqrt(sum(item.bp_norm**2 for item in members))
        epc = math.sqrt(sum(item.pc_norm**2 for item in members))
        cosines = [item.cosine for item in members if item.cosine is not None]
        result.append({
            "block": block,
            "ordinary_kd_norm": bp,
            "epc_norm": epc,
            "norm_ratio": None if bp == 0 else epc / bp,
            "mean_cosine": None if not cosines else sum(cosines) / len(cosines),
            "finite": math.isfinite(bp) and math.isfinite(epc),
        })
    return result


@torch.no_grad()
def _evaluate(model, teacher, batches):
    student_losses, teacher_losses, kd_values = [], [], []
    model.eval()
    for x, y in batches:
        teacher_logits = teacher(x)
        student_logits = model(x)
        student_losses.append(float(cross_entropy_for_logits(student_logits, y)))
        teacher_losses.append(float(cross_entropy_for_logits(teacher_logits, y)))
        kd_values.append(float(kd_loss(student_logits, teacher_logits, temperature=2.0)))
    model.train()
    student_loss = sum(student_losses) / len(student_losses)
    teacher_loss = sum(teacher_losses) / len(teacher_losses)
    return student_loss, teacher_loss, sum(kd_values) / len(kd_values)


def _run_arm(protocol, seed, arm, initial_state, teacher, train_batches, eval_batches):
    config = teacher.config
    model = CausalCharTransformerLM(config)
    model.load_state_dict(initial_state)
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4)
    energy_traces: list[list[float]] = []
    accepted_step_sizes: list[list[float]] = []
    backtrack_counts: list[list[int]] = []
    credit: list[dict[str, Any]] = []
    started = time.perf_counter()
    for index, (x, y) in enumerate(train_batches):
        with torch.no_grad():
            anchor = teacher(x)
        optimizer.zero_grad(set_to_none=True)
        logits = model(x)
        ce = cross_entropy_for_logits(logits, y)
        ordinary = kd_loss(logits, anchor, temperature=protocol["training"]["kd_temperature"])
        if arm == "bp_ce":
            loss = ce
        elif arm == "bp_kd":
            loss = 0.5 * ce + 0.5 * ordinary
        else:
            predictive, trace = transformer_epc_objective(
                model, x, anchor,
                steps=protocol["epc"]["state_count_including_feedforward"],
                temperature=protocol["training"]["kd_temperature"],
                relaxation_lr=protocol["epc"]["activity_step_size"],
                max_backtracks=protocol["epc"]["max_backtracks"],
                output_weight=protocol["epc"]["lambda_output"],
            )
            loss = 0.5 * ce + 0.5 * predictive
            energy_traces.append(list(trace.energy_history))
            accepted_step_sizes.append(list(trace.accepted_step_sizes))
            backtrack_counts.append(list(trace.backtrack_counts))
            if index == 0:
                credit = _block_credit(model, ordinary, predictive)
        loss.backward()
        optimizer.step()
    elapsed = time.perf_counter() - started
    student_loss, teacher_loss, kd_value = _evaluate(model, teacher, eval_batches)
    record = {
        "schema": SCHEMA,
        "mode": "cpu_two_layer_stub",
        "protocol_sha256": _canonical_hash(protocol),
        "seed": seed,
        "arm": arm,
        "update_count": len(train_batches),
        "elapsed_seconds": elapsed,
        "student_val_loss": student_loss,
        "student_val_perplexity": math.exp(student_loss),
        "teacher_val_loss": teacher_loss,
        "teacher_val_perplexity": math.exp(teacher_loss),
        "kd_gap_nats": kd_value,
        "credit_assignment": credit,
        "activity_energy_traces": energy_traces,
        "accepted_step_sizes": accepted_step_sizes,
        "backtrack_counts": backtrack_counts,
        "activity_energy_monotone": all(
            all(after <= before + 1e-9 * max(1.0, abs(before))
                for before, after in zip(trace, trace[1:]))
            for trace in energy_traces
        ),
        "eval_set_sha256": _canonical_hash([
            [x.tolist(), y.tolist()] for x, y in eval_batches
        ]),
    }
    validate_metric_record(record)
    return record


def validate_metric_record(record: dict[str, Any]) -> None:
    required = {
        "schema", "mode", "protocol_sha256", "seed", "arm", "update_count",
        "elapsed_seconds", "student_val_loss", "student_val_perplexity",
        "teacher_val_loss", "teacher_val_perplexity", "kd_gap_nats",
        "credit_assignment", "activity_energy_traces",
        "accepted_step_sizes", "backtrack_counts",
        "activity_energy_monotone", "eval_set_sha256",
    }
    missing = required - record.keys()
    if missing:
        raise ValueError(f"metric record missing fields: {sorted(missing)}")
    if record["schema"] != SCHEMA or record["arm"] not in {"bp_ce", "bp_kd", "epc_kd"}:
        raise ValueError("invalid metric schema or arm")
    numeric = [record[key] for key in (
        "elapsed_seconds", "student_val_loss", "student_val_perplexity",
        "teacher_val_loss", "teacher_val_perplexity", "kd_gap_nats",
    )]
    if not all(isinstance(value, (int, float)) and math.isfinite(value) for value in numeric):
        raise ValueError("all scalar metrics must be finite")
    if record["arm"] == "epc_kd":
        if not record["activity_energy_traces"] or not record["credit_assignment"]:
            raise ValueError("ePC metrics require energy and credit diagnostics")
        if not record["activity_energy_monotone"]:
            raise ValueError("non-monotone ePC record")
        if not record["accepted_step_sizes"] or not record["backtrack_counts"]:
            raise ValueError("ePC metrics require relaxation acceptance diagnostics")


def comparable_payload(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [{key: value for key, value in row.items() if key not in TIMING_FIELDS} for row in records]


def run_cpu_dry_run(protocol: dict[str, Any]) -> list[dict[str, Any]]:
    validate_pilot_protocol(protocol)
    records = []
    for seed in protocol["evaluation"]["seeds"]:
        torch.manual_seed(seed)
        config = TinyCharTransformerConfig(
            vocab_size=23, seq_len=8, d_model=8, nhead=2, d_ff=16,
            num_layers=2, dropout=0.0,
        )
        teacher = CausalCharTransformerLM(config)
        teacher.eval()
        torch.manual_seed(seed + 1)
        template = CausalCharTransformerLM(config)
        initial_state = copy.deepcopy(template.state_dict())
        train_batches = _fixed_batches(seed + 2, 2, vocab=23, length=8)
        eval_batches = _fixed_batches(seed + 3, 2, vocab=23, length=8)
        for arm in protocol["controls"]["primary"]:
            records.append(_run_arm(
                protocol, seed, arm, initial_state, teacher, train_batches, eval_batches
            ))
    return records


def write_metrics(path: str | Path, records: list[dict[str, Any]]) -> None:
    for record in records:
        validate_metric_record(record)
    Path(path).write_text(json.dumps(records, indent=2, sort_keys=True) + "\n", encoding="utf-8")
