from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Callable, Iterable, Literal, Protocol, Sequence

import torch

from .energy import EnergyModel
from .priors import Prior

SensitivityStatus = Literal["ranking_stable", "diagnostic_only"]


class _EstimatorLike(Protocol):
    lambda_hat: float
    status: str


@dataclass(frozen=True)
class PriorSensitivityCandidate:
    arm_id: str
    theta: torch.Tensor
    data_score: float


@dataclass(frozen=True)
class PriorSensitivityReport:
    scales: list[float]
    lambda_hats: list[float | dict[str, float]]
    rankings: list[list[str]]
    stable: bool
    notes: str
    status: SensitivityStatus = "ranking_stable"
    prior_family: str = "unknown"
    result_statuses: list[str] | None = None
    scores_by_scale: list[dict[str, float]] | None = None
    top_arm_by_scale: list[str] | None = None
    ranking_flipped: bool = False

    # Backward-compatible aliases for earlier report naming.
    @property
    def prior_scales(self) -> list[float]:
        return self.scales

    @property
    def rankings_by_scale(self) -> list[list[str]]:
        return self.rankings

    @property
    def caveat(self) -> str:
        return self.notes

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def _lambda_and_status(result: object) -> tuple[float, str]:
    if isinstance(result, dict):
        lambda_value = result.get("lambda_hat", result.get("lambda_single_n"))
        status = result.get("status", result.get("estimator_status", "unknown"))
    else:
        lambda_value = getattr(result, "lambda_hat", getattr(result, "lambda_single_n", None))
        status = getattr(result, "status", getattr(result, "estimator_status", "unknown"))
    if lambda_value is None:
        raise ValueError("estimator_fn result must expose lambda_hat or lambda_single_n")
    return float(lambda_value), str(status)


def _rank_lambda_row(row: float | dict[str, float]) -> list[str]:
    if isinstance(row, dict):
        return sorted(row, key=lambda arm: (row[arm], arm))
    return ["lambda_hat"]


def _rankings_stable(rankings: Sequence[Sequence[str]]) -> bool:
    if not rankings:
        return True
    first = list(rankings[0])
    return all(list(ranking) == first for ranking in rankings[1:])


def prior_sensitivity_sweep(
    energy_model: EnergyModel,
    prior_family: Callable[[float], Prior],
    scale_grid: Iterable[float],
    estimator_fn: Callable[..., object],
) -> PriorSensitivityReport:
    """Run an estimator across prior scales and flag ranking instability.

    The estimator may accept ``(energy_model, prior)`` or ``(energy_model, prior,
    scale)`` and may return a scalar-like single lambda estimate, an
    EstimatorResult-like object, or a mapping with per-arm lambda estimates. Arm
    ranking uses ascending lambda values and is diagnostic-only if rankings flip
    under the sweep.
    """

    scales = [float(scale) for scale in scale_grid]
    if not scales:
        raise ValueError("at least one prior scale is required")

    lambda_hats: list[float | dict[str, float]] = []
    rankings: list[list[str]] = []
    result_statuses: list[str] = []
    prior_family_name = "unknown"

    for scale in scales:
        prior = prior_family(scale)
        prior_family_name = prior.family_name
        try:
            result = estimator_fn(energy_model, prior, scale)
        except TypeError:
            result = estimator_fn(energy_model, prior)

        if isinstance(result, dict) and result and all(isinstance(v, (int, float)) for v in result.values()):
            row = {str(k): float(v) for k, v in result.items()}
            status = "ok"
        else:
            row, status = _lambda_and_status(result)
        lambda_hats.append(row)
        rankings.append(_rank_lambda_row(row))
        result_statuses.append(status)

    stable = _rankings_stable(rankings)
    status: SensitivityStatus = "ranking_stable" if stable else "diagnostic_only"
    notes = (
        "ranking stable under prior-scale sweep; still finite-sample diagnostic evidence only"
        if stable
        else "diagnostic_only: arm rankings flip under modest prior-scale changes"
    )
    return PriorSensitivityReport(
        scales=scales,
        lambda_hats=lambda_hats,
        rankings=rankings,
        stable=stable,
        notes=notes,
        status=status,
        prior_family=prior_family_name,
        result_statuses=result_statuses,
        top_arm_by_scale=[ranking[0] for ranking in rankings],
        ranking_flipped=not stable,
    )


def prior_sensitivity_report(
    candidates: Iterable[PriorSensitivityCandidate],
    prior_factory: Callable[[float], Prior],
    scales: Iterable[float],
) -> PriorSensitivityReport:
    """Evaluate whether arm rankings are stable under declared prior-scale changes.

    Lower score is better. If the top arm changes under the sweep, the run is
    diagnostic-only because modest prior choices can alter model selection.
    """

    candidate_list = list(candidates)
    scale_list = [float(s) for s in scales]
    if len(candidate_list) < 2:
        raise ValueError("at least two candidates are required for prior sensitivity")
    if not scale_list:
        raise ValueError("at least one prior scale is required")

    rankings: list[list[str]] = []
    score_rows: list[dict[str, float]] = []
    prior_family_name = prior_factory(scale_list[0]).family_name
    for scale in scale_list:
        prior = prior_factory(scale)
        if prior.family_name != prior_family_name:
            raise ValueError("prior_factory must return a consistent prior family")
        scores = {c.arm_id: float(c.data_score - prior.log_density(c.theta).detach().cpu()) for c in candidate_list}
        ranking = sorted(scores, key=lambda k: (scores[k], k))
        rankings.append(ranking)
        score_rows.append(scores)

    stable = _rankings_stable(rankings)
    flipped = not stable
    top = [r[0] for r in rankings]
    return PriorSensitivityReport(
        scales=scale_list,
        lambda_hats=score_rows,
        rankings=rankings,
        stable=stable,
        notes=(
            "diagnostic-only: arm rankings flip under the declared prior-scale sweep"
            if flipped
            else "ranking stable under the declared prior-scale sweep; still finite-sample diagnostic evidence only"
        ),
        status="diagnostic_only" if flipped else "ranking_stable",
        prior_family=prior_family_name,
        result_statuses=["score_only"] * len(scale_list),
        scores_by_scale=score_rows,
        top_arm_by_scale=top,
        ranking_flipped=flipped,
    )
