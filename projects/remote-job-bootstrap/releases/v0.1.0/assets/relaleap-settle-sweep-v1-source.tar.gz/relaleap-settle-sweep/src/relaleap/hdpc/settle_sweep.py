"""Validation and aggregation for the preregistered settlement-depth sweep."""
from __future__ import annotations

import math
from typing import Any, Iterable, Mapping


FROZEN_DEPTHS = (1, 2, 4, 8)


def _average_ranks(values: list[float]) -> list[float]:
    order = sorted(range(len(values)), key=values.__getitem__)
    ranks = [0.0] * len(values)
    start = 0
    while start < len(order):
        stop = start + 1
        while stop < len(order) and values[order[stop]] == values[order[start]]:
            stop += 1
        rank = (start + 1 + stop) / 2.0
        for index in order[start:stop]:
            ranks[index] = rank
        start = stop
    return ranks


def _spearman(left: list[float], right: list[float]) -> float:
    left_ranks = _average_ranks(left)
    right_ranks = _average_ranks(right)
    left_mean = sum(left_ranks) / len(left_ranks)
    right_mean = sum(right_ranks) / len(right_ranks)
    numerator = sum(
        (x - left_mean) * (y - right_mean)
        for x, y in zip(left_ranks, right_ranks)
    )
    left_scale = sum((x - left_mean) ** 2 for x in left_ranks)
    right_scale = sum((y - right_mean) ** 2 for y in right_ranks)
    if left_scale == 0.0 or right_scale == 0.0:
        return 0.0
    return numerator / math.sqrt(left_scale * right_scale)


def validate_arm_record(depth: int, arm: Any) -> None:
    """Validate one restartable arm artifact."""
    if depth not in FROZEN_DEPTHS or not isinstance(arm, Mapping):
        raise ValueError(f"missing or unexpected arm T={depth}")
    if arm.get("settle_steps") != depth:
        raise ValueError(f"settle-depth mismatch at T={depth}")
    if arm.get("replay_exact") is not True:
        raise ValueError(f"replay mismatch at T={depth}")
    kd = arm.get("held_out_kd_nats")
    objectives = arm.get("objectives")
    if not isinstance(kd, (int, float)) or not math.isfinite(float(kd)):
        raise ValueError(f"non-finite held-out KD at T={depth}")
    if not isinstance(objectives, list) or not objectives:
        raise ValueError(f"missing objectives at T={depth}")
    if not all(isinstance(x, (int, float)) and math.isfinite(float(x)) for x in objectives):
        raise ValueError(f"non-finite objective at T={depth}")


def validate_seed_record(record: Mapping[str, Any]) -> None:
    """Fail closed unless one seed contains every finite, replay-exact arm."""
    if record.get("status") != "passed":
        raise ValueError("seed record did not pass")
    arms = record.get("arms")
    if not isinstance(arms, Mapping):
        raise ValueError("missing arms")
    if tuple(sorted(int(key) for key in arms)) != FROZEN_DEPTHS:
        raise ValueError("missing or unexpected settle depth")
    for depth in FROZEN_DEPTHS:
        validate_arm_record(depth, arms.get(str(depth)))


def aggregate_seed_records(records: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
    """Aggregate fixed-depth seed records without changing the frozen criteria."""
    records = list(records)
    if not records:
        raise ValueError("no seed records")
    for record in records:
        validate_seed_record(record)
    seeds = [int(record["seed"]) for record in records]
    baseline = {
        int(record["seed"]): float(record["arms"]["1"]["held_out_kd_nats"])
        for record in records
    }
    gains = {
        str(depth): [
            baseline[int(record["seed"])] - float(record["arms"][str(depth)]["held_out_kd_nats"])
            for record in records
        ]
        for depth in FROZEN_DEPTHS
    }
    means = {depth: sum(values) / len(values) for depth, values in gains.items()}
    depth_values = [float(depth) for depth in FROZEN_DEPTHS]
    per_seed_spearman = {
        str(record["seed"]): _spearman(
            depth_values,
            [
                baseline[int(record["seed"])]
                - float(record["arms"][str(depth)]["held_out_kd_nats"])
                for depth in FROZEN_DEPTHS
            ],
        )
        for record in records
    }
    return {
        "schema": "relaleap.clean_room_transformer_epc_settle_sweep_summary.v1",
        "status": "completed",
        "seeds": seeds,
        "settle_steps": list(FROZEN_DEPTHS),
        "mean_gain_vs_t1_nats": means,
        "per_seed_gain_vs_t1_nats": gains,
        "positive_gain_fraction": {
            depth: sum(value > 0.0 for value in values) / len(values)
            for depth, values in gains.items()
            if depth != "1"
        },
        "per_seed_depth_gain_spearman": per_seed_spearman,
        "mean_depth_gain_spearman": sum(per_seed_spearman.values()) / len(records),
        "mean_gain_nondecreasing": all(
            means[str(left)] <= means[str(right)]
            for left, right in zip(FROZEN_DEPTHS, FROZEN_DEPTHS[1:])
        ),
        "all_replays_exact": True,
    }
