from __future__ import annotations
from dataclasses import dataclass
import itertools
import torch
import torch.nn.functional as F

@dataclass
class FrozenLinearSuffix:
    weight: torch.Tensor
    bias: torch.Tensor | None = None
    def __call__(self, h: torch.Tensor) -> torch.Tensor:
        return h @ self.weight + (self.bias if self.bias is not None else 0)

def _ce(logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
    return F.cross_entropy(logits, targets, reduction="mean")

class ExactAblationAuditor:
    def __init__(self, suffix, targets: torch.Tensor):
        self.suffix = suffix
        self.targets = targets

    def exact_support_loss(self, hidden_states: torch.Tensor, column_residuals: torch.Tensor, support: list[int] | tuple[int, ...]) -> torch.Tensor:
        if len(support) == 0:
            r = torch.zeros_like(hidden_states)
        else:
            r = column_residuals[:, list(support), :].sum(dim=1)
        return _ce(self.suffix(hidden_states + r), self.targets)

    def singleton_gain(self, hidden_states: torch.Tensor, column_residuals: torch.Tensor, column: int) -> torch.Tensor:
        base = self.exact_support_loss(hidden_states, column_residuals, [])
        one = self.exact_support_loss(hidden_states, column_residuals, [column])
        return base - one

    def pair_synergy(self, hidden_states: torch.Tensor, column_residuals: torch.Tensor, a: int, b: int) -> torch.Tensor:
        base = self.exact_support_loss(hidden_states, column_residuals, [])
        pair = self.exact_support_loss(hidden_states, column_residuals, [a, b])
        return (base - pair) - self.singleton_gain(hidden_states, column_residuals, a) - self.singleton_gain(hidden_states, column_residuals, b)

    def one_swap_regret(self, hidden_states: torch.Tensor, column_residuals: torch.Tensor, support: list[int] | tuple[int, ...]) -> torch.Tensor:
        support = tuple(sorted(set(support)))
        k = column_residuals.shape[1]
        current = self.exact_support_loss(hidden_states, column_residuals, support)
        best = current
        for old in support:
            for new in range(k):
                if new not in support:
                    candidate = tuple(sorted((set(support) - {old}) | {new}))
                    best = torch.minimum(best, self.exact_support_loss(hidden_states, column_residuals, candidate))
        return torch.clamp(current - best, min=0)
