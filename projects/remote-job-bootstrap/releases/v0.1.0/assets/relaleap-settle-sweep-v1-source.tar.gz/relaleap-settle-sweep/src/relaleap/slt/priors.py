from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

import torch


@dataclass(frozen=True)
class PriorReport:
    prior_family: str
    prior_scale: float
    finite_sample_caveat: str = "Priors are part of finite-sample WBIC/SGLD proxy diagnostics, not exact RLCT evidence."


class Prior(Protocol):
    """Autograd-free prior interface used by SLT finite-sample diagnostics."""

    family_name: str
    scale: float

    def log_density(self, theta: torch.Tensor) -> torch.Tensor: ...

    def grad_log_density(self, theta: torch.Tensor) -> torch.Tensor: ...

    def with_scale(self, scale: float) -> "Prior": ...

    def report(self) -> PriorReport: ...

    @property
    def family(self) -> str: ...

    def negative_log_prob(self, theta: torch.Tensor) -> torch.Tensor: ...

    def grad(self, theta: torch.Tensor) -> torch.Tensor: ...


def _validate_scale(scale: float) -> float:
    scale = float(scale)
    if not scale > 0:
        raise ValueError("prior scale must be positive")
    return scale


def _as_tensor_like(value: torch.Tensor | float | int, theta: torch.Tensor) -> torch.Tensor:
    return torch.as_tensor(value, dtype=theta.dtype, device=theta.device)


@dataclass(frozen=True, init=False)
class GaussianPrior:
    """Diagonal Gaussian prior, omitting constants independent of theta.

    log π(θ) = -0.5 * sum(((θ - μ) / σ)^2) + const.
    """

    mean: torch.Tensor | float = 0.0
    scale: float = 1.0
    family_name: str = "gaussian_l2"

    def __init__(
        self,
        mean: torch.Tensor | float = 0.0,
        scale: float = 1.0,
        family_name: str = "gaussian_l2",
    ) -> None:
        object.__setattr__(self, "mean", mean)
        object.__setattr__(self, "scale", _validate_scale(scale))
        object.__setattr__(self, "family_name", family_name)

    @property
    def family(self) -> str:
        return self.family_name

    def _mean_like(self, theta: torch.Tensor) -> torch.Tensor:
        return _as_tensor_like(self.mean, theta)

    def log_density(self, theta: torch.Tensor) -> torch.Tensor:
        residual = theta - self._mean_like(theta)
        return -0.5 * torch.sum((residual / self.scale) ** 2)

    def grad_log_density(self, theta: torch.Tensor) -> torch.Tensor:
        residual = theta - self._mean_like(theta)
        return -residual / (self.scale**2)

    # Backward-compatible aliases used by earlier validation scaffolding.
    def negative_log_prob(self, theta: torch.Tensor) -> torch.Tensor:
        return -self.log_density(theta)

    def grad(self, theta: torch.Tensor) -> torch.Tensor:
        return -self.grad_log_density(theta)

    def with_scale(self, scale: float) -> "GaussianPrior":
        return GaussianPrior(mean=self.mean, scale=scale, family_name=self.family_name)

    def report(self) -> PriorReport:
        return PriorReport(self.family_name, self.scale)


@dataclass(frozen=True)
class LaplacePrior:
    """Zero-mean isotropic Laplace prior, omitting constants independent of theta."""

    scale: float = 1.0
    family_name: str = "laplace_l1"

    def __post_init__(self) -> None:
        object.__setattr__(self, "scale", _validate_scale(self.scale))

    @property
    def family(self) -> str:
        return self.family_name

    def log_density(self, theta: torch.Tensor) -> torch.Tensor:
        return -torch.sum(torch.abs(theta)) / self.scale

    def grad_log_density(self, theta: torch.Tensor) -> torch.Tensor:
        # Subgradient convention at zero is 0; tests avoid the nondifferentiable point.
        return -torch.sign(theta) / self.scale

    def negative_log_prob(self, theta: torch.Tensor) -> torch.Tensor:
        return -self.log_density(theta)

    def grad(self, theta: torch.Tensor) -> torch.Tensor:
        return -self.grad_log_density(theta)

    def with_scale(self, scale: float) -> "LaplacePrior":
        return LaplacePrior(scale=scale, family_name=self.family_name)

    def report(self) -> PriorReport:
        return PriorReport(self.family_name, self.scale)


@dataclass(frozen=True)
class ImproperUniform:
    """Flat improper prior for tests and null diagnostics."""

    scale: float = float("inf")
    family_name: str = "improper_uniform"

    @property
    def family(self) -> str:
        return self.family_name

    def log_density(self, theta: torch.Tensor) -> torch.Tensor:
        return torch.zeros((), dtype=theta.dtype, device=theta.device)

    def grad_log_density(self, theta: torch.Tensor) -> torch.Tensor:
        return torch.zeros_like(theta)

    def negative_log_prob(self, theta: torch.Tensor) -> torch.Tensor:
        return -self.log_density(theta)

    def grad(self, theta: torch.Tensor) -> torch.Tensor:
        return -self.grad_log_density(theta)

    def with_scale(self, scale: float) -> "ImproperUniform":
        _ = scale
        return ImproperUniform()

    def report(self) -> PriorReport:
        return PriorReport(self.family_name, self.scale)


def finite_difference_grad(fn, theta: torch.Tensor, eps: float = 1e-5) -> torch.Tensor:
    """Central finite-difference gradient for small validation tensors."""

    if eps <= 0:
        raise ValueError("eps must be positive")
    original = theta.detach()
    flat = original.clone().reshape(-1).to(dtype=torch.float64)
    grad = torch.empty_like(flat)
    for i in range(flat.numel()):
        plus = flat.clone()
        plus[i] += eps
        minus = flat.clone()
        minus[i] -= eps
        plus_theta = plus.reshape_as(original).to(dtype=original.dtype, device=original.device)
        minus_theta = minus.reshape_as(original).to(dtype=original.dtype, device=original.device)
        grad[i] = (fn(plus_theta).detach().to(torch.float64) - fn(minus_theta).detach().to(torch.float64)) / (2 * eps)
    return grad.reshape_as(original).to(dtype=original.dtype, device=original.device)
