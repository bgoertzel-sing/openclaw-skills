from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal
import numpy as np
import torch

RegimeName = Literal[
    "exact_factorized",
    "shared_core_redundant",
    "synergistic_pair",
    "low_rank_trap",
    "oblique_dictionary",
    "random_null",
]

@dataclass(frozen=True)
class SyntheticRegimeData:
    hidden_states: torch.Tensor
    context_features: torch.Tensor
    true_supports: torch.Tensor
    ground_truth_residuals: torch.Tensor
    targets: torch.Tensor
    metadata: dict[str, Any]


def _rng(seed: int) -> tuple[np.random.Generator, torch.Generator]:
    return np.random.default_rng(seed), torch.Generator().manual_seed(seed)


def _make_context(h: torch.Tensor, token_ids: torch.Tensor, positions: torch.Tensor, c_dim: int) -> torch.Tensor:
    n = h.shape[0]
    ctx = torch.zeros(n, c_dim, dtype=h.dtype)
    if c_dim > 0:
        ctx[:, 0] = (token_ids.float() % 7) / 3.0 - 1.0
    if c_dim > 1:
        ctx[:, 1] = torch.sin(positions.float() / 5.0)
    if c_dim > 2:
        ctx[:, 2] = torch.cos(positions.float() / 7.0)
    if c_dim > 3:
        take = min(c_dim - 3, h.shape[1])
        ctx[:, 3 : 3 + take] = h[:, :take]
    return ctx


def _topk_support(scores: torch.Tensor, k: int) -> torch.Tensor:
    return torch.topk(scores, k=k, dim=1).indices.sort(dim=1).values


def _rank_one_columns(d: int, c: int, gen: torch.Generator, *, oblique: bool = False) -> tuple[torch.Tensor, torch.Tensor]:
    a = torch.randn(c, d, generator=gen)
    b = torch.randn(c, d, generator=gen)
    if not oblique:
        qa, _ = torch.linalg.qr(a.T, mode="reduced")
        qb, _ = torch.linalg.qr(b.T, mode="reduced")
        a = qa.T[:c]
        b = qb.T[:c]
    else:
        shared = torch.randn(1, d, generator=gen)
        a = 0.65 * a + 0.35 * shared
        b = 0.55 * b + 0.45 * torch.roll(shared, shifts=1, dims=1)
    a = torch.nn.functional.normalize(a, dim=1)
    b = torch.nn.functional.normalize(b, dim=1)
    return a, b


def _residual_from_support(h: torch.Tensor, supports: torch.Tensor, a: torch.Tensor, b: torch.Tensor, amp: float = 1.0) -> torch.Tensor:
    r = torch.zeros_like(h)
    for row in range(h.shape[0]):
        for col in supports[row].tolist():
            gate = torch.tanh(h[row].dot(a[col]))
            r[row] += amp * gate * b[col]
    return r


def generate_regime(
    regime: RegimeName,
    *,
    seed: int = 0,
    n: int = 256,
    d_model: int = 16,
    c_dim: int = 6,
    num_columns: int = 6,
    support_size: int = 2,
    num_classes: int = 4,
    noise_std: float = 0.01,
) -> SyntheticRegimeData:
    """Generate deterministic Tier-A synthetic residual-layer data with known supports."""
    if num_columns > d_model and regime != "random_null":
        raise ValueError("num_columns must be <= d_model for non-null regimes")
    np_rng, gen = _rng(seed)
    h = torch.randn(n, d_model, generator=gen)
    token_ids = torch.tensor(np_rng.integers(0, 97, size=n), dtype=torch.long)
    positions = torch.arange(n, dtype=torch.long) % 128
    ctx = _make_context(h, token_ids, positions, c_dim)
    router_w = torch.randn(num_columns, d_model + c_dim, generator=gen)
    router_x = torch.cat([h, ctx], dim=1)
    scores = router_x @ router_w.T
    supports = _topk_support(scores, min(support_size, num_columns))
    a, b = _rank_one_columns(d_model, num_columns, gen, oblique=(regime == "oblique_dictionary"))
    shared_core = None
    interactions: dict[str, Any] = {}

    if regime == "exact_factorized":
        r = _residual_from_support(h, supports, a, b, amp=1.0)
    elif regime == "shared_core_redundant":
        r = _residual_from_support(h, supports, a, b, amp=0.7)
        shared_core = torch.nn.functional.normalize(torch.randn(d_model, generator=gen), dim=0)
        active01 = ((supports == 0).any(1) | (supports == 1).any(1)).float().unsqueeze(1)
        core_signal = torch.tanh(h @ shared_core).unsqueeze(1) * shared_core.unsqueeze(0)
        r = r + 0.9 * active01 * core_signal
        interactions["shared_core_columns"] = [0, 1]
    elif regime == "synergistic_pair":
        r = _residual_from_support(h, supports, a, b, amp=0.65)
        pair_active = ((supports == 0).any(1) & (supports == 1).any(1)).float().unsqueeze(1)
        syn_vec = torch.nn.functional.normalize(b[0] + torch.roll(b[1], 1), dim=0)
        syn_signal = torch.tanh((h @ a[0]) * (h @ a[1])).unsqueeze(1) * syn_vec.unsqueeze(0)
        r = r + 1.25 * pair_active * syn_signal
        interactions["synergistic_pairs"] = [[0, 1]]
    elif regime == "low_rank_trap":
        rank = max(1, min(3, d_model, num_columns))
        u = torch.randn(d_model, rank, generator=gen)
        v = torch.randn(d_model, rank, generator=gen)
        coeff = h @ u
        r = coeff @ v.T / np.sqrt(rank)
        # Supports are deliberately incidental, not causal.
        interactions["low_rank"] = rank
    elif regime == "oblique_dictionary":
        r = _residual_from_support(h, supports, a, b, amp=1.0)
        mix = torch.randn(num_columns, num_columns, generator=gen) * 0.15 + torch.eye(num_columns)
        r = r + 0.25 * _residual_from_support(h, supports, mix @ a, mix @ b, amp=1.0)
        interactions["oblique"] = True
    elif regime == "random_null":
        supports = torch.tensor(np_rng.integers(0, num_columns, size=(n, support_size)), dtype=torch.long).sort(dim=1).values
        r = noise_std * torch.randn(n, d_model, generator=gen)
    else:
        raise ValueError(f"unknown regime {regime}")

    if regime != "random_null" and noise_std:
        r = r + noise_std * torch.randn(n, d_model, generator=gen)
    target_w = torch.randn(d_model, num_classes, generator=gen)
    targets = torch.argmax((h + r) @ target_w, dim=1)
    metadata = {
        "known_regime": regime,
        "seed": seed,
        "true_columns": list(range(num_columns)),
        "true_basis": {"a": a, "b": b},
        "true_shared_core": shared_core,
        "true_interactions": interactions,
        "token_ids": token_ids,
        "position_index": positions,
        "config": {"n": n, "d_model": d_model, "c_dim": c_dim, "num_columns": num_columns, "support_size": support_size},
    }
    return SyntheticRegimeData(h, ctx, supports, r, targets, metadata)


def generate_all_regimes(seed: int = 0, **kwargs: Any) -> dict[str, SyntheticRegimeData]:
    names: list[RegimeName] = ["exact_factorized", "shared_core_redundant", "synergistic_pair", "low_rank_trap", "oblique_dictionary", "random_null"]
    return {name: generate_regime(name, seed=seed + i * 1009, **kwargs) for i, name in enumerate(names)}
