from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

import torch

SortKey = Literal["usage", "amplitude", "norm", "none"]


@dataclass(frozen=True)
class GaugePolicy:
    """Canonicalization policy for finite-sample SLT reporting.

    The default matches the validation-plan policy for rank-one atoms:
    normalize read/write vectors, absorb scale into amplitudes, use a
    first-nonzero-positive sign convention, and sort atoms by stable usage or
    norm keys.  This is a coordinate/reporting gauge; it must not be used to
    claim exact RLCT invariance by itself.
    """

    policy_id: str = "rank_one_linear_v1"
    normalize_read_vectors: bool = True
    normalize_write_vectors: bool = True
    absorb_scale_into_amplitude: bool = True
    canonical_sign: str = "first_nonzero_positive"
    sort_atoms_by: SortKey = "usage"
    eps: float = 1e-12


@dataclass(frozen=True)
class GaugeReport:
    policy_id: str
    permutation: tuple[int, ...]
    read_scales: tuple[float, ...]
    write_scales: tuple[float, ...]
    sign_flips_read: tuple[int, ...]
    sign_flips_write: tuple[int, ...]
    residual_gauge_degrees: tuple[str, ...] = field(default_factory=tuple)


def _validate_rank_one_shapes(read: torch.Tensor, write: torch.Tensor, amplitude: torch.Tensor) -> None:
    if read.ndim != 2 or write.ndim != 2:
        raise ValueError("read and write must be rank-2 tensors shaped [num_atoms, dim]")
    if read.shape[0] != write.shape[0]:
        raise ValueError("read and write must have the same number of atoms")
    if amplitude.ndim != 1 or amplitude.shape[0] != read.shape[0]:
        raise ValueError("amplitude must be shaped [num_atoms]")


def _first_nonzero_sign(vec: torch.Tensor, eps: float) -> int:
    nz = torch.nonzero(vec.abs() > eps, as_tuple=False)
    if nz.numel() == 0:
        return 1
    return 1 if vec[nz[0, 0]].item() >= 0 else -1


def rank_one_function(read: torch.Tensor, write: torch.Tensor, amplitude: torch.Tensor, inputs: torch.Tensor) -> torch.Tensor:
    """Evaluate a linear rank-one dictionary sum.

    Computes sum_g amplitude[g] * write[g] * <read[g], input>.  This helper is
    intentionally linear; nonlinear atoms such as tanh adapters have less scale
    gauge freedom and should only use sign/permutation parts that preserve their
    activation semantics.
    """

    _validate_rank_one_shapes(read, write, amplitude)
    return (inputs @ read.T * amplitude) @ write


def canonicalize_rank_one_atoms(
    read: torch.Tensor,
    write: torch.Tensor,
    amplitude: torch.Tensor,
    *,
    usage: torch.Tensor | None = None,
    membership: torch.Tensor | None = None,
    policy: GaugePolicy | None = None,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor | None, GaugeReport]:
    """Canonicalize linear rank-one atoms without changing their function.

    Scale is absorbed into ``amplitude`` when vectors are normalized.  Sign flips
    use the first-nonzero-positive convention for read and write vectors, with
    the compensating sign absorbed into ``amplitude``.  Atoms are optionally
    sorted; ``membership`` tensors shaped with atom dimension first are permuted
    consistently and returned.
    """

    policy = policy or GaugePolicy()
    _validate_rank_one_shapes(read, write, amplitude)
    if usage is not None and (usage.ndim != 1 or usage.shape[0] != amplitude.shape[0]):
        raise ValueError("usage must be shaped [num_atoms]")
    if membership is not None and membership.shape[0] != amplitude.shape[0]:
        raise ValueError("membership must have atom dimension first")

    out_read = read.clone()
    out_write = write.clone()
    out_amp = amplitude.clone()
    n = amplitude.shape[0]

    read_scales = torch.ones(n, dtype=out_amp.dtype, device=out_amp.device)
    write_scales = torch.ones(n, dtype=out_amp.dtype, device=out_amp.device)

    if policy.normalize_read_vectors:
        read_scales = out_read.norm(dim=1).clamp_min(policy.eps)
        out_read = out_read / read_scales.unsqueeze(1)
        if policy.absorb_scale_into_amplitude:
            out_amp = out_amp * read_scales
    if policy.normalize_write_vectors:
        write_scales = out_write.norm(dim=1).clamp_min(policy.eps)
        out_write = out_write / write_scales.unsqueeze(1)
        if policy.absorb_scale_into_amplitude:
            out_amp = out_amp * write_scales

    read_signs = []
    write_signs = []
    if policy.canonical_sign == "first_nonzero_positive":
        for g in range(n):
            sr = _first_nonzero_sign(out_read[g], policy.eps)
            sw = _first_nonzero_sign(out_write[g], policy.eps)
            out_read[g] = out_read[g] * sr
            out_write[g] = out_write[g] * sw
            out_amp[g] = out_amp[g] * sr * sw
            read_signs.append(sr)
            write_signs.append(sw)
    elif policy.canonical_sign in {"none", ""}:
        read_signs = [1] * n
        write_signs = [1] * n
    else:
        raise ValueError(f"unknown canonical_sign policy: {policy.canonical_sign}")

    if policy.sort_atoms_by == "usage" and usage is not None:
        primary = usage.detach().to(out_amp.device, out_amp.dtype)
    elif policy.sort_atoms_by == "amplitude":
        primary = out_amp.detach().abs()
    elif policy.sort_atoms_by == "norm":
        primary = (read_scales * write_scales).detach()
    elif policy.sort_atoms_by in {"usage", "none"}:
        primary = None
    else:
        raise ValueError(f"unknown sort_atoms_by policy: {policy.sort_atoms_by}")

    if primary is None:
        perm = torch.arange(n, device=out_amp.device)
    else:
        # Stable descending sort via Python preserves original order for ties.
        order = sorted(range(n), key=lambda i: (-float(primary[i].item()), i))
        perm = torch.tensor(order, dtype=torch.long, device=out_amp.device)

    out_membership = membership.index_select(0, perm).clone() if membership is not None else None
    report = GaugeReport(
        policy_id=policy.policy_id,
        permutation=tuple(int(i) for i in perm.cpu().tolist()),
        read_scales=tuple(float(x) for x in read_scales.index_select(0, perm).detach().cpu().tolist()),
        write_scales=tuple(float(x) for x in write_scales.index_select(0, perm).detach().cpu().tolist()),
        sign_flips_read=tuple(int(read_signs[i]) for i in perm.cpu().tolist()),
        sign_flips_write=tuple(int(write_signs[i]) for i in perm.cpu().tolist()),
        residual_gauge_degrees=("permutation_ties", "zero_atoms") if primary is not None else ("permutation_symmetry", "zero_atoms"),
    )
    return out_read.index_select(0, perm), out_write.index_select(0, perm), out_amp.index_select(0, perm), out_membership, report


def dictionary_function(atoms: torch.Tensor, coefficients: torch.Tensor) -> torch.Tensor:
    """Evaluate a linear dictionary ``coefficients @ atoms``."""

    if atoms.ndim != 2 or coefficients.ndim != 2:
        raise ValueError("atoms and coefficients must be rank-2 tensors")
    if coefficients.shape[1] != atoms.shape[0]:
        raise ValueError("coefficients second dimension must match number of atoms")
    return coefficients @ atoms


def canonicalize_dictionary(
    atoms: torch.Tensor,
    coefficients: torch.Tensor | None = None,
    *,
    usage: torch.Tensor | None = None,
    policy: GaugePolicy | None = None,
) -> tuple[torch.Tensor, torch.Tensor | None, GaugeReport]:
    """Canonicalize a linear dictionary with optional compensating coefficients.

    Atoms are normalized and sign-canonicalized.  If ``coefficients`` are
    supplied, inverse scale/sign transformations and atom permutations are
    applied so that ``coefficients @ atoms`` is preserved.
    """

    policy = policy or GaugePolicy(policy_id="linear_dictionary_v1", sort_atoms_by="usage")
    if atoms.ndim != 2:
        raise ValueError("atoms must be shaped [num_atoms, dim]")
    if coefficients is not None and (coefficients.ndim != 2 or coefficients.shape[1] != atoms.shape[0]):
        raise ValueError("coefficients must be shaped [n, num_atoms]")
    n = atoms.shape[0]
    if usage is not None and (usage.ndim != 1 or usage.shape[0] != n):
        raise ValueError("usage must be shaped [num_atoms]")

    out_atoms = atoms.clone()
    out_coeff = coefficients.clone() if coefficients is not None else None
    scales = torch.ones(n, dtype=out_atoms.dtype, device=out_atoms.device)
    if policy.normalize_write_vectors:
        scales = out_atoms.norm(dim=1).clamp_min(policy.eps)
        out_atoms = out_atoms / scales.unsqueeze(1)
        if out_coeff is not None and policy.absorb_scale_into_amplitude:
            out_coeff = out_coeff * scales.unsqueeze(0)

    signs = []
    if policy.canonical_sign == "first_nonzero_positive":
        for g in range(n):
            s = _first_nonzero_sign(out_atoms[g], policy.eps)
            out_atoms[g] = out_atoms[g] * s
            if out_coeff is not None:
                out_coeff[:, g] = out_coeff[:, g] * s
            signs.append(s)
    elif policy.canonical_sign in {"none", ""}:
        signs = [1] * n
    else:
        raise ValueError(f"unknown canonical_sign policy: {policy.canonical_sign}")

    if policy.sort_atoms_by == "usage" and usage is not None:
        primary = usage.detach().to(out_atoms.device, out_atoms.dtype)
    elif policy.sort_atoms_by == "norm":
        primary = scales.detach()
    elif policy.sort_atoms_by == "amplitude" and out_coeff is not None:
        primary = out_coeff.detach().abs().mean(dim=0)
    elif policy.sort_atoms_by in {"usage", "none", "amplitude"}:
        primary = None
    else:
        raise ValueError(f"unknown sort_atoms_by policy: {policy.sort_atoms_by}")

    if primary is None:
        perm = torch.arange(n, device=out_atoms.device)
    else:
        perm = torch.tensor(sorted(range(n), key=lambda i: (-float(primary[i].item()), i)), dtype=torch.long, device=out_atoms.device)

    report = GaugeReport(
        policy_id=policy.policy_id,
        permutation=tuple(int(i) for i in perm.cpu().tolist()),
        read_scales=tuple(1.0 for _ in range(n)),
        write_scales=tuple(float(x) for x in scales.index_select(0, perm).detach().cpu().tolist()),
        sign_flips_read=tuple(1 for _ in range(n)),
        sign_flips_write=tuple(int(signs[i]) for i in perm.cpu().tolist()),
        residual_gauge_degrees=("orthogonal_rotations_within_degenerate_subspaces", "permutation_ties", "zero_atoms"),
    )
    out_atoms = out_atoms.index_select(0, perm)
    if out_coeff is not None:
        out_coeff = out_coeff.index_select(1, perm)
    return out_atoms, out_coeff, report
