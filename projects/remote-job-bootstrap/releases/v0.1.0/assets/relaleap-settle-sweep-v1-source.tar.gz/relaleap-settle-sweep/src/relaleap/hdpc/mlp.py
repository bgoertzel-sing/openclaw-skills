from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import torch
from torch import nn


@dataclass(frozen=True)
class PCInferenceTrace:
    """Auditable state and energy record from a predictive-coding objective."""

    states: tuple[torch.Tensor, ...]
    energy_history: tuple[float, ...]
    steps: int
    output_weight: float


class PredictiveCodingMLP(nn.Module):
    """Small reference MLP with local squared-error PC relaxation.

    ``steps=1`` is the feed-forward endpoint: intermediate states retain their
    ordinary autograd graph, so the output prediction error gives exactly the
    output-weight-scaled backpropagation gradient.  For ``steps>1``, hidden
    activities are relaxed against a clamped output target and then detached
    for local predictive-coding weight gradients.

    This is a test scaffold, not yet a transformer/ePC claim.  Backtracking is
    used during activity inference so every accepted inner step is
    non-increasing in the declared PC energy.
    """

    def __init__(self, widths: Sequence[int]) -> None:
        super().__init__()
        widths = tuple(int(width) for width in widths)
        if len(widths) < 2 or any(width <= 0 for width in widths):
            raise ValueError("widths must contain at least two positive dimensions")
        self.layers = nn.ModuleList(
            nn.Linear(input_width, output_width)
            for input_width, output_width in zip(widths[:-1], widths[1:])
        )

    def _predict(self, layer_index: int, state: torch.Tensor) -> torch.Tensor:
        prediction = self.layers[layer_index](state)
        if layer_index < len(self.layers) - 1:
            prediction = torch.tanh(prediction)
        return prediction

    def forward_states(self, inputs: torch.Tensor) -> tuple[torch.Tensor, ...]:
        states = [inputs]
        for layer_index in range(len(self.layers)):
            states.append(self._predict(layer_index, states[-1]))
        return tuple(states)

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        return self.forward_states(inputs)[-1]

    def energy_from_states(
        self,
        states: Sequence[torch.Tensor],
        output_target: torch.Tensor,
        *,
        output_weight: float,
    ) -> torch.Tensor:
        """Return mean half-squared local prediction energy.

        ``states`` contains the input and each hidden activity, but not the
        clamped output.  The final layer predicts ``output_target``.
        """

        if output_weight < 0:
            raise ValueError("output_weight must be non-negative")
        if len(states) != len(self.layers):
            raise ValueError("states must contain the input and every hidden activity")

        energy = output_target.new_zeros(())
        for layer_index in range(len(self.layers)):
            prediction = self._predict(layer_index, states[layer_index])
            observed = output_target if layer_index == len(self.layers) - 1 else states[layer_index + 1]
            weight = output_weight if layer_index == len(self.layers) - 1 else 1.0
            error = observed - prediction
            energy = energy + 0.5 * weight * error.square().sum(dim=-1).mean()
        return energy

    def _inference_energy(
        self,
        inputs: torch.Tensor,
        hidden_states: Sequence[torch.Tensor],
        output_target: torch.Tensor,
        output_weight: float,
    ) -> torch.Tensor:
        return self.energy_from_states(
            (inputs, *hidden_states), output_target, output_weight=output_weight
        )

    def static_state_gradients(
        self,
        states: Sequence[torch.Tensor],
        output_target: torch.Tensor,
        *,
        output_weight: float,
    ) -> tuple[torch.Tensor, ...]:
        """Compute hidden-state gradients by differentiating the static energy."""

        if len(states) != len(self.layers):
            raise ValueError("states must contain the input and every hidden activity")
        hidden = tuple(state.detach().requires_grad_(True) for state in states[1:])
        energy = self.energy_from_states(
            (states[0].detach(), *hidden), output_target.detach(), output_weight=output_weight
        )
        return tuple(gradient.detach() for gradient in torch.autograd.grad(energy, hidden))

    def error_state_gradients(
        self,
        states: Sequence[torch.Tensor],
        output_target: torch.Tensor,
        *,
        output_weight: float,
    ) -> tuple[torch.Tensor, ...]:
        """Compute the same gradients from adjacent prediction errors.

        This is the local error-based PC (ePC) form for the supported
        ``Linear``/``tanh`` toy network.  It is deliberately written without
        differentiating the global energy, providing an independent check
        against static-PC autograd before extending ePC to transformer blocks.
        """

        if output_weight < 0:
            raise ValueError("output_weight must be non-negative")
        if len(states) != len(self.layers):
            raise ValueError("states must contain the input and every hidden activity")

        gradients = []
        batch_size = states[0].shape[0]
        for hidden_index in range(1, len(states)):
            lower_prediction = self._predict(hidden_index - 1, states[hidden_index - 1])
            lower_error = states[hidden_index] - lower_prediction

            upper_layer_index = hidden_index
            upper_prediction = self._predict(upper_layer_index, states[hidden_index])
            upper_observed = (
                output_target
                if upper_layer_index == len(self.layers) - 1
                else states[hidden_index + 1]
            )
            upper_weight = output_weight if upper_layer_index == len(self.layers) - 1 else 1.0
            weighted_upper_error = upper_weight * (upper_observed - upper_prediction)

            if upper_layer_index < len(self.layers) - 1:
                weighted_upper_error = weighted_upper_error * (1.0 - upper_prediction.square())
            top_down = weighted_upper_error @ self.layers[upper_layer_index].weight
            gradients.append((lower_error - top_down) / float(batch_size))
        return tuple(gradients)

    def pc_objective(
        self,
        inputs: torch.Tensor,
        output_target: torch.Tensor,
        *,
        steps: int,
        output_weight: float = 0.05,
        relaxation_lr: float = 0.2,
        max_backtracks: int = 12,
    ) -> tuple[torch.Tensor, PCInferenceTrace]:
        """Construct a BP-endpoint or relaxed local PC training objective.

        The target is always detached: homotopy distillation must not update a
        teacher through the student objective.  ``steps`` includes the initial
        feed-forward state, so ``steps=1`` performs no activity relaxation.
        """

        if steps < 1:
            raise ValueError("steps must be at least one")
        if relaxation_lr <= 0:
            raise ValueError("relaxation_lr must be positive")
        if max_backtracks < 0:
            raise ValueError("max_backtracks must be non-negative")

        target = output_target.detach()
        feedforward = self.forward_states(inputs)
        initial_states = feedforward[:-1]
        initial_energy = self.energy_from_states(initial_states, target, output_weight=output_weight)

        if steps == 1 or len(self.layers) == 1:
            trace = PCInferenceTrace(
                states=tuple(state.detach() for state in initial_states),
                energy_history=(float(initial_energy.detach()),),
                steps=steps,
                output_weight=float(output_weight),
            )
            return initial_energy, trace

        inference_input = inputs.detach()
        hidden = [state.detach() for state in feedforward[1:-1]]
        energy_history = [
            float(
                self._inference_energy(inference_input, hidden, target, output_weight).detach()
            )
        ]

        for _ in range(steps - 1):
            energy = self._inference_energy(inference_input, hidden, target, output_weight)
            gradients = self.error_state_gradients(
                (inference_input, *hidden), target, output_weight=output_weight
            )
            old_energy = float(energy.detach())
            step_size = float(relaxation_lr)

            accepted: list[torch.Tensor] | None = None
            accepted_energy = old_energy
            with torch.no_grad():
                for _ in range(max_backtracks + 1):
                    proposal = [state - step_size * gradient for state, gradient in zip(hidden, gradients)]
                    proposal_energy = float(
                        self._inference_energy(inference_input, proposal, target, output_weight)
                    )
                    tolerance = 1e-12 * max(1.0, abs(old_energy))
                    if proposal_energy <= old_energy + tolerance:
                        accepted = proposal
                        accepted_energy = proposal_energy
                        break
                    step_size *= 0.5

            if accepted is None:
                accepted = [state.detach() for state in hidden]
            hidden = [state.detach() for state in accepted]
            energy_history.append(accepted_energy)

        local_states = (inference_input, *(state.detach() for state in hidden))
        objective = self.energy_from_states(local_states, target, output_weight=output_weight)
        trace = PCInferenceTrace(
            states=tuple(state.detach() for state in local_states),
            energy_history=tuple(energy_history),
            steps=steps,
            output_weight=float(output_weight),
        )
        return objective, trace
