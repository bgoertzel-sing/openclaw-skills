from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol
import torch
from torch import nn
import torch.nn.functional as F

@dataclass(frozen=True)
class ArmDependencyContract:
    uses_hidden: bool = True
    uses_context: bool = False
    uses_targets: bool = False
    uses_teacher_residuals: bool = False
    uses_base_logits: bool = False
    uses_gradients: bool = False
    uses_fisher_metric: bool = False
    uses_router_support: bool = False
    uses_token_position: bool = False

class ResidualArm(nn.Module):
    arm_id: str = "base"
    promotion_candidate: bool = False
    dependency_contract: ArmDependencyContract = ArmDependencyContract()

    def fit_basis(self, train_cache: Any, config: dict[str, Any]) -> None:  # pragma: no cover
        return None

    def fit_parameters(self, train_cache: Any, val_cache: Any | None, config: dict[str, Any]) -> None:  # pragma: no cover
        return None

    def forward_residual(self, hidden_states: torch.Tensor, context_features: torch.Tensor, return_aux: bool = False):
        raise NotImplementedError

    def parameter_blocks(self) -> dict[str, list[nn.Parameter]]:
        return {"all": [p for p in self.parameters() if p.requires_grad]}


def _hard_topk_st(scores: torch.Tensor, k: int) -> torch.Tensor:
    k = min(k, scores.shape[-1])
    probs = torch.softmax(scores, dim=-1)
    idx = torch.topk(probs, k=k, dim=-1).indices
    hard = torch.zeros_like(probs).scatter_(-1, idx, 1.0)
    return hard + probs - probs.detach()

class RankOneColumnLearner(ResidualArm):
    """Identity-initialized sparse residual column learner with rank-one atoms."""
    arm_id = "rank_one_atom_columns"
    promotion_candidate = True
    dependency_contract = ArmDependencyContract(uses_hidden=True, uses_context=True, uses_router_support=True)

    def __init__(self, d_model: int, context_dim: int, num_columns: int = 4, atoms_per_column: int = 2, top_k: int = 2):
        super().__init__()
        self.d_model = d_model
        self.context_dim = context_dim
        self.num_columns = num_columns
        self.num_atoms = num_columns * atoms_per_column
        self.top_k = top_k
        self.a = nn.Parameter(F.normalize(torch.randn(self.num_atoms, d_model) * 0.02, dim=1))
        self.b = nn.Parameter(F.normalize(torch.randn(self.num_atoms, d_model) * 0.02, dim=1))
        self.beta = nn.Parameter(torch.zeros(self.num_atoms))
        q = torch.full((num_columns, self.num_atoms), -6.0)
        for k in range(num_columns):
            q[k, k * atoms_per_column : (k + 1) * atoms_per_column] = 6.0
        self.q_logits = nn.Parameter(q)
        self.atom_context = nn.Linear(context_dim, self.num_atoms, bias=False) if context_dim else None
        self.router = nn.Linear(d_model + context_dim, num_columns)
        self.alpha = nn.Linear(d_model + context_dim, num_columns)
        nn.init.zeros_(self.router.bias)
        nn.init.zeros_(self.alpha.bias)

    def column_residuals(self, hidden_states: torch.Tensor, context_features: torch.Tensor) -> torch.Tensor:
        pre = hidden_states @ self.a.T
        if self.atom_context is not None:
            pre = pre + self.atom_context(context_features)
        z = torch.tanh(pre)
        atom_values = z.unsqueeze(-1) * self.beta.view(1, -1, 1) * self.b.unsqueeze(0)
        q = torch.softmax(self.q_logits, dim=0).T  # atoms x columns
        return torch.einsum("ngd,gk->nkd", atom_values, q)

    def forward_residual(self, hidden_states: torch.Tensor, context_features: torch.Tensor, return_aux: bool = False):
        x = torch.cat([hidden_states, context_features], dim=-1) if self.context_dim else hidden_states
        col = self.column_residuals(hidden_states, context_features)
        mask = _hard_topk_st(self.router(x), self.top_k)
        alpha = self.alpha(x)
        residual = (col * (mask * alpha).unsqueeze(-1)).sum(dim=1)
        aux = {"column_mask": mask.detach(), "column_alpha": alpha.detach(), "column_residuals": col.detach()}
        return (residual, aux) if return_aux else residual

    def parameter_blocks(self) -> dict[str, list[nn.Parameter]]:
        blocks = {
            "atom_input_directions": [self.a],
            "atom_output_directions": [self.b],
            "atom_amplitudes": [self.beta],
            "column_membership": [self.q_logits],
            "router": list(self.router.parameters()),
            "alpha": list(self.alpha.parameters()),
        }
        if self.atom_context is not None:
            blocks["atom_context"] = list(self.atom_context.parameters())
        for k in range(self.num_columns):
            blocks[f"column_{k}"] = [self.q_logits[k], *list(self.router.parameters()), *list(self.alpha.parameters())]
        return blocks

class FlatValueSameRouter(ResidualArm):
    arm_id = "flat_value_same_router"
    promotion_candidate = False
    dependency_contract = ArmDependencyContract(uses_hidden=True, uses_context=True, uses_router_support=True, uses_teacher_residuals=True)

    def __init__(self, d_model: int, context_dim: int, num_columns: int, top_k: int = 2, rank: int | None = None):
        super().__init__()
        self.d_model, self.context_dim, self.num_columns, self.top_k, self.rank = d_model, context_dim, num_columns, top_k, rank
        self.router = nn.Linear(d_model + context_dim, num_columns)
        self.alpha = nn.Linear(d_model + context_dim, num_columns)
        if rank is None:
            self.values = nn.Parameter(torch.randn(num_columns, d_model) * 0.02)
            self.left = self.right = None
        else:
            self.left = nn.Parameter(torch.randn(num_columns, rank) * 0.02)
            self.right = nn.Parameter(torch.randn(rank, d_model) * 0.02)
            self.values = None

    @property
    def value_matrix(self) -> torch.Tensor:
        return self.values if self.rank is None else self.left @ self.right

    def forward_residual(self, hidden_states: torch.Tensor, context_features: torch.Tensor, return_aux: bool = False):
        x = torch.cat([hidden_states, context_features], dim=-1) if self.context_dim else hidden_states
        mask = _hard_topk_st(self.router(x), self.top_k)
        coeff = mask * self.alpha(x)
        residual = coeff @ self.value_matrix
        aux = {"column_mask": mask.detach(), "coefficients": coeff.detach()}
        return (residual, aux) if return_aux else residual

    def parameter_blocks(self) -> dict[str, list[nn.Parameter]]:
        blocks = {"router": list(self.router.parameters()), "alpha": list(self.alpha.parameters())}
        blocks["values"] = [self.values] if self.rank is None else [self.left, self.right]
        return blocks

class SVDLowRankControl(ResidualArm):
    arm_id = "svd_lowrank_control"
    promotion_candidate = False
    dependency_contract = ArmDependencyContract(uses_hidden=True, uses_context=True, uses_teacher_residuals=True)

    def __init__(self, d_model: int, context_dim: int, rank: int = 4):
        super().__init__()
        self.d_model, self.context_dim, self.rank = d_model, context_dim, rank
        self.register_buffer("basis", torch.empty(d_model, rank))
        self.encoder = nn.Linear(d_model + context_dim, rank)
        self.basis_fitted = False

    def fit_basis_from_residuals(self, train_residuals: torch.Tensor) -> None:
        centered = train_residuals - train_residuals.mean(0, keepdim=True)
        _, _, vh = torch.linalg.svd(centered, full_matrices=False)
        q = min(self.rank, vh.shape[0])
        basis = torch.zeros(self.d_model, self.rank, dtype=train_residuals.dtype, device=train_residuals.device)
        basis[:, :q] = vh[:q].T
        self.basis = basis
        self.basis_fitted = True

    def forward_residual(self, hidden_states: torch.Tensor, context_features: torch.Tensor, return_aux: bool = False):
        if not self.basis_fitted:
            raise RuntimeError("SVD basis must be fit on train residuals before use")
        x = torch.cat([hidden_states, context_features], dim=-1) if self.context_dim else hidden_states
        z = self.encoder(x)
        residual = z @ self.basis.T
        aux = {"coefficients": z.detach(), "rank": self.rank}
        return (residual, aux) if return_aux else residual

    def parameter_blocks(self) -> dict[str, list[nn.Parameter]]:
        return {"encoder": list(self.encoder.parameters())}
