from __future__ import annotations

from dataclasses import dataclass
from math import erfc, sqrt
from typing import Sequence

import torch

Tensor = torch.Tensor


@dataclass(frozen=True)
class ChainDiagnostics:
    energy_ess_per_chain: list[float]
    rhat_energy: float | None
    trend_test: dict[str, float | bool | str]
    nan_or_divergence_count: int
    acceptance_rate: float | None = None


def effective_sample_size_1d(x: Tensor, max_lag: int | None = None) -> float:
    """Initial-positive-sequence ESS estimate for one scalar chain."""

    values = x.detach().double().flatten()
    values = values[torch.isfinite(values)]
    n = int(values.numel())
    if n < 3:
        return float(n)
    centered = values - values.mean()
    var = torch.mean(centered * centered)
    if var <= 0:
        return float(n)
    if max_lag is None:
        max_lag = min(n - 1, 1000)
    rho_sum = 0.0
    for lag in range(1, max_lag + 1):
        acov = torch.mean(centered[:-lag] * centered[lag:])
        rho = float(acov / var)
        if rho <= 0.0:
            break
        rho_sum += rho
    return max(1.0, float(n) / (1.0 + 2.0 * rho_sum))


def split_rhat(chains: Sequence[Tensor]) -> float | None:
    """Split-chain rank-normal-free R-hat for scalar chains."""

    split: list[Tensor] = []
    for chain in chains:
        finite = chain.detach().double().flatten()
        finite = finite[torch.isfinite(finite)]
        half = int(finite.numel()) // 2
        if half >= 2:
            split.extend([finite[:half], finite[-half:]])
    m = len(split)
    if m < 2:
        return None
    n = min(int(s.numel()) for s in split)
    if n < 2:
        return None
    y = torch.stack([s[:n] for s in split])
    chain_means = y.mean(dim=1)
    chain_vars = y.var(dim=1, unbiased=True)
    b = n * chain_means.var(unbiased=True)
    w = chain_vars.mean()
    if w <= 0:
        return 1.0 if b <= 0 else float("inf")
    var_hat = ((n - 1) / n) * w + b / n
    return float(torch.sqrt(var_hat / w))


def mann_kendall_trend_test(x: Tensor) -> dict[str, float | bool | str]:
    """Two-sided Mann-Kendall trend test using a normal approximation."""

    values = x.detach().double().flatten()
    values = values[torch.isfinite(values)]
    n = int(values.numel())
    if n < 8:
        return {"status": "not_run", "n": float(n), "tau": float("nan"), "z": float("nan"), "p_value": float("nan"), "has_trend": False}
    s = 0.0
    for k in range(n - 1):
        s += float(torch.sign(values[k + 1 :] - values[k]).sum())
    unique, counts = torch.unique(values, return_counts=True)
    _ = unique
    tie_term = float(torch.sum(counts.double() * (counts.double() - 1.0) * (2.0 * counts.double() + 5.0)))
    var_s = (n * (n - 1) * (2 * n + 5) - tie_term) / 18.0
    if var_s <= 0:
        z = 0.0
        p = 1.0
    else:
        z = (s - 1.0) / sqrt(var_s) if s > 0 else (s + 1.0) / sqrt(var_s) if s < 0 else 0.0
        p = erfc(abs(z) / sqrt(2.0))
    tau = s / (0.5 * n * (n - 1))
    return {"status": "pass" if p > 0.05 else "fail", "n": float(n), "tau": tau, "z": z, "p_value": p, "has_trend": p <= 0.05}


def diagnose_energy_chains(chains: Sequence[Tensor], *, acceptance_rates: Sequence[float] | None = None) -> ChainDiagnostics:
    finite_counts = [int(torch.isfinite(c).sum().item()) for c in chains]
    total_counts = [int(c.numel()) for c in chains]
    nan_count = sum(t - f for t, f in zip(total_counts, finite_counts))
    ess = [effective_sample_size_1d(c) for c in chains]
    rhat = split_rhat(chains)
    concatenated = torch.cat([c.detach().flatten() for c in chains]) if chains else torch.tensor([])
    trend = mann_kendall_trend_test(concatenated)
    acceptance_rate = None
    if acceptance_rates:
        finite_rates = [float(r) for r in acceptance_rates if torch.isfinite(torch.tensor(float(r)))]
        acceptance_rate = sum(finite_rates) / len(finite_rates) if finite_rates else None
    return ChainDiagnostics(
        energy_ess_per_chain=ess,
        rhat_energy=rhat,
        trend_test=trend,
        nan_or_divergence_count=nan_count,
        acceptance_rate=acceptance_rate,
    )
