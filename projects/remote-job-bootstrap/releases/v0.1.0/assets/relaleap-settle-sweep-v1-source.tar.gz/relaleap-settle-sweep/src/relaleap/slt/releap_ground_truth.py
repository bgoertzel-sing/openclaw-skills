from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

ExpectedSign = Literal["positive", "negative", "near_zero", "weakens_when_conditioned", "not_interpretable"]


@dataclass(frozen=True)
class RelaLeapGroundTruth:
    """Serializable ground-truth metadata for RelaLeap-shaped SLT benchmarks.

    These fields mirror the validation-plan contract for Subagent G. Tensor-valued
    arrays are stored in the generated benchmark metadata under ``true_basis`` or
    as dataset tensors; this dataclass keeps the small semantic contract stable.
    """

    benchmark_id: str
    known_regime: str
    true_support: list[list[int]]
    true_columns: list[int]
    true_basis: dict[str, Any]
    true_shared_core: dict[str, Any] | None = None
    true_mediators: list[dict[str, Any]] = field(default_factory=list)
    true_interactions: dict[str, Any] = field(default_factory=dict)
    expected_winner: str = "columnar_adapter"
    expected_I_lambda_signs: dict[str, ExpectedSign] = field(default_factory=dict)
    decision_notes: list[str] = field(default_factory=list)

    def to_metadata(self) -> dict[str, Any]:
        return {
            "benchmark_id": self.benchmark_id,
            "known_regime": self.known_regime,
            "true_support": self.true_support,
            "true_columns": self.true_columns,
            "true_basis": self.true_basis,
            "true_shared_core": self.true_shared_core,
            "true_mediators": self.true_mediators,
            "true_interactions": self.true_interactions,
            "expected_winner": self.expected_winner,
            "expected_I_lambda_signs": self.expected_I_lambda_signs,
            "decision_notes": self.decision_notes,
        }
