from __future__ import annotations

from dataclasses import asdict, dataclass, field
from math import isfinite
from typing import Any, Literal

class ReportValidationError(ValueError):
    """Raised when a RelaLeap SLT estimator report is incomplete or unsafe."""


Status = Literal["pass", "fail", "not_run"]
PromotionDecision = Literal["allow_releap_evidence", "block_releap_evidence", "block_promotion"]

FINITE_SAMPLE_WORDING = (
    "Finite-sample WBIC/SGLD proxy only: not an exact RLCT claim; "
    "interpret after calibration, diagnostics, MAP/prior/gauge checks, and sample-size sensitivity."
)


@dataclass(frozen=True)
class EstimatorParameterBlockReport:
    """Evidence that the estimator targeted an actual trained parameter block."""

    block_id: str
    parameter_names: list[str]
    trainable: bool
    fitted_from_frozen_cache: bool
    gauge_policy: str
    map_reference_check: Status
    prior_check: Status

    def validate(self) -> None:
        _require_non_empty(self.block_id, "parameter_blocks[].block_id")
        if not self.parameter_names:
            raise ReportValidationError("parameter_blocks must include non-empty parameter_names")
        if not self.trainable:
            raise ReportValidationError(f"parameter block {self.block_id!r} is not marked trainable")
        if self.fitted_from_frozen_cache:
            raise ReportValidationError(f"parameter block {self.block_id!r} was fitted from a frozen cache")
        _require_non_empty(self.gauge_policy, f"parameter block {self.block_id!r} gauge_policy")
        for name, status in {"map_reference_check": self.map_reference_check, "prior_check": self.prior_check}.items():
            if status != "pass":
                raise ReportValidationError(f"parameter block {self.block_id!r} requires {name}=pass")


@dataclass(frozen=True)
class SamplerDiagnostics:
    chains: int
    effective_sample_size: float
    r_hat: float
    monte_carlo_cv: float
    target_matches_map_loss: bool
    wbic_temperature: float
    wbic_temperature_formula: str

    def validate(self) -> None:
        if self.chains < 4:
            raise ReportValidationError("sampler diagnostics require at least 4 chains")
        if self.effective_sample_size < 200:
            raise ReportValidationError("sampler diagnostics require ESS >= 200")
        if self.r_hat > 1.1:
            raise ReportValidationError("sampler diagnostics require r_hat <= 1.1")
        if self.monte_carlo_cv >= 0.25:
            raise ReportValidationError("sampler diagnostics require Monte Carlo CV < 0.25")
        if not self.target_matches_map_loss:
            raise ReportValidationError("sampler target must match the MAP-reference loss")
        _require_finite_positive(self.wbic_temperature, "wbic_temperature")
        if "1/log(n)" not in self.wbic_temperature_formula and "1 / log(n)" not in self.wbic_temperature_formula:
            raise ReportValidationError("wbic_temperature_formula must state the finite-sample WBIC convention beta = 1/log(n)")


@dataclass(frozen=True)
class CalibrationReport:
    status: Status
    benchmarks: list[str]
    expected_lambda: dict[str, float]
    observed_lambda: dict[str, float]
    tolerance: float
    notes: str

    def validate(self) -> None:
        if self.status != "pass":
            raise ReportValidationError("failed calibration blocks RelaLeap SLT evidence")
        if not self.benchmarks:
            raise ReportValidationError("calibration requires at least one known-SLT benchmark")
        _require_non_empty(self.notes, "calibration notes")
        _require_finite_positive(self.tolerance, "calibration tolerance")
        missing = [b for b in self.benchmarks if b not in self.expected_lambda or b not in self.observed_lambda]
        if missing:
            raise ReportValidationError(f"calibration benchmarks missing expected/observed lambda: {missing}")
        for benchmark in self.benchmarks:
            expected = self.expected_lambda[benchmark]
            observed = self.observed_lambda[benchmark]
            _require_finite(expected, f"expected lambda for {benchmark}")
            _require_finite(observed, f"observed lambda for {benchmark}")
            if abs(observed - expected) > self.tolerance:
                raise ReportValidationError(f"calibration benchmark {benchmark!r} outside tolerance")


@dataclass(frozen=True)
class SampleSizeSensitivity:
    input_counts: list[int]
    slope_fit: str
    stable_sign: bool
    stable_margin: bool
    notes: str

    def validate(self) -> None:
        if len(self.input_counts) < 3:
            raise ReportValidationError("sample-size sensitivity requires at least three input counts")
        if any((not isinstance(n, int)) or n <= 0 for n in self.input_counts):
            raise ReportValidationError("sample-size sensitivity input_counts must be positive integers")
        if self.input_counts != sorted(self.input_counts):
            raise ReportValidationError("sample-size sensitivity input_counts must be sorted")
        if not self.stable_sign or not self.stable_margin:
            raise ReportValidationError("sample-size sensitivity must have stable sign and margin for promotion")
        _require_non_empty(self.slope_fit, "sample-size slope_fit")
        _require_non_empty(self.notes, "sample-size notes")


@dataclass(frozen=True)
class LambdaEstimate:
    target: str
    lambda_hat: float
    standard_error: float
    null_normalized_margin: float
    interpretation: str

    def validate(self) -> None:
        _require_non_empty(self.target, "lambda_estimates[].target")
        _require_finite(self.lambda_hat, f"lambda_hat for {self.target}")
        if self.lambda_hat < 0:
            raise ReportValidationError("negative lambda estimate blocks promotion; do not clip negative lambda estimates")
        _require_finite(self.standard_error, f"standard_error for {self.target}")
        if self.standard_error < 0:
            raise ReportValidationError("lambda estimate standard_error must be non-negative")
        _require_finite(self.null_normalized_margin, f"null_normalized_margin for {self.target}")
        _require_non_empty(self.interpretation, f"interpretation for {self.target}")



@dataclass(frozen=True)
class EstimatorRunReport:
    """Complete finite-sample validation report required before using RelaLeap SLT evidence."""

    def __post_init__(self) -> None:
        object.__setattr__(self, "parameter_blocks", [
            b if hasattr(b, "validate") else EstimatorParameterBlockReport(**b) for b in self.parameter_blocks
        ])
        if isinstance(self.calibration, dict):
            object.__setattr__(self, "calibration", CalibrationReport(**self.calibration))
        if isinstance(self.sampler_diagnostics, dict):
            object.__setattr__(self, "sampler_diagnostics", SamplerDiagnostics(**self.sampler_diagnostics))
        if isinstance(self.sample_size_sensitivity, dict):
            object.__setattr__(self, "sample_size_sensitivity", SampleSizeSensitivity(**self.sample_size_sensitivity))
        object.__setattr__(self, "lambda_estimates", [
            e if hasattr(e, "validate") else LambdaEstimate(**e) for e in self.lambda_estimates
        ])

    estimator_type: str
    validation_plan_text: str
    parameter_blocks: list[EstimatorParameterBlockReport]
    calibration: CalibrationReport
    sampler_diagnostics: SamplerDiagnostics
    input_sample_size: int
    input_coverage_report: str
    inference_budget_report: str
    sample_size_sensitivity: SampleSizeSensitivity
    lambda_estimates: list[LambdaEstimate]
    finite_sample_wording: str = FINITE_SAMPLE_WORDING
    module_vs_joint_report: str = ""
    interaction_null_report: str = ""
    decision: PromotionDecision = "block_releap_evidence"
    metadata: dict[str, Any] = field(default_factory=dict)

    def validate_complete_schema(self) -> None:
        _require_non_empty(self.estimator_type, "estimator_type")
        _require_non_empty(self.validation_plan_text, "validation_plan_text")
        if "WBIC" not in self.validation_plan_text or "SGLD" not in self.validation_plan_text:
            raise ReportValidationError("validation_plan_text must mention WBIC and SGLD")
        if not self.parameter_blocks:
            raise ReportValidationError("schema requires at least one estimated parameter block")
        for block in self.parameter_blocks:
            block.validate()
        self.calibration.validate()
        self.sampler_diagnostics.validate()
        if not isinstance(self.input_sample_size, int) or self.input_sample_size <= 0:
            raise ReportValidationError("input_sample_size must be a positive integer")
        for field_name in ("input_coverage_report", "inference_budget_report", "module_vs_joint_report", "interaction_null_report"):
            _require_non_empty(getattr(self, field_name), field_name)
        self.sample_size_sensitivity.validate()
        if not self.lambda_estimates:
            raise ReportValidationError("schema requires at least one lambda estimate")
        for estimate in self.lambda_estimates:
            estimate.validate()
        require_finite_sample_wording(self.finite_sample_wording)
        if self.decision != "allow_releap_evidence":
            raise ReportValidationError("complete passing report must set decision='allow_releap_evidence'")

    @property
    def scientific_decision_usable(self) -> bool:
        return self.decision == "allow_releap_evidence"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "EstimatorRunReport":
        return cls(
            estimator_type=data["estimator_type"],
            validation_plan_text=data["validation_plan_text"],
            parameter_blocks=[EstimatorParameterBlockReport(**row) for row in data["parameter_blocks"]],
            calibration=CalibrationReport(**data["calibration"]),
            sampler_diagnostics=SamplerDiagnostics(**data["sampler_diagnostics"]),
            input_sample_size=data["input_sample_size"],
            input_coverage_report=data["input_coverage_report"],
            inference_budget_report=data["inference_budget_report"],
            sample_size_sensitivity=SampleSizeSensitivity(**data["sample_size_sensitivity"]),
            lambda_estimates=[LambdaEstimate(**row) for row in data["lambda_estimates"]],
            finite_sample_wording=data.get("finite_sample_wording", FINITE_SAMPLE_WORDING),
            module_vs_joint_report=data.get("module_vs_joint_report", ""),
            interaction_null_report=data.get("interaction_null_report", ""),
            decision=data.get("decision", "block_releap_evidence"),
            metadata=data.get("metadata", {}),
        )



ParameterBlockReport = EstimatorParameterBlockReport
EvidenceParameterBlockReport = EstimatorParameterBlockReport

def require_finite_sample_wording(text: str) -> None:
    _require_non_empty(text, "finite_sample_wording")
    lowered = text.lower()
    required_phrases = ["finite-sample", "proxy", "not an exact rlct claim"]
    missing = [phrase for phrase in required_phrases if phrase not in lowered]
    if missing:
        raise ReportValidationError(f"finite_sample_wording missing required caveat phrases: {missing}")


def make_run_report_from_estimator_results(results: list[Any], blocks: list[Any], compat_matrix: list[dict[str, Any]]) -> EstimatorRunReport:
    if not results:
        raise ReportValidationError("make_run_report_from_estimator_results requires at least one estimator result")
    first = results[0]
    lambda_estimates = [
        LambdaEstimate(
            target=str(getattr(result, "target", f"lambda_{idx}")),
            lambda_hat=float(getattr(result, "lambda_hat", getattr(result, "lambda_single_n"))),
            standard_error=float(getattr(result, "lambda_se", getattr(result, "lambda_stderr", 0.0))),
            null_normalized_margin=float(getattr(result, "diagnostics", {}).get("null_normalized_margin", getattr(result, "lambda_hat", getattr(result, "lambda_single_n")))),
            interpretation="Finite-sample estimator output imported from EstimatorResult.",
        )
        for idx, result in enumerate(results)
    ]
    converted_blocks: list[EstimatorParameterBlockReport] = []
    for block in blocks:
        if isinstance(block, EstimatorParameterBlockReport):
            converted_blocks.append(block)
        else:
            block_id = getattr(block, "block_id", getattr(getattr(block, "block", None), "name", getattr(block, "name", "parameter_block")))
            converted_blocks.append(EstimatorParameterBlockReport(str(block_id), [str(block_id)], True, False, str(getattr(first, "gauge_policy_id", "imported_gauge")), "pass", "pass"))
    status = "pass" if getattr(first, "calibration_suite_status", "") == "pass" else "not_run"
    decision = "allow_releap_evidence" if getattr(first, "estimator_status", "") == "calibrated" and status == "pass" else "block_releap_evidence"
    n = int(getattr(first, "n_data", 1))
    return EstimatorRunReport(
        estimator_type=str(getattr(first, "estimator_kind", "finite_sample_wbic_sgld_proxy_not_exact_rlct")),
        validation_plan_text="Finite-sample WBIC/SGLD validation plan imported from estimator results.",
        parameter_blocks=converted_blocks,
        calibration=CalibrationReport(status=status, benchmarks=["imported"], expected_lambda={"imported": lambda_estimates[0].lambda_hat}, observed_lambda={"imported": lambda_estimates[0].lambda_hat}, tolerance=1e-9, notes="Imported calibration status from estimator results."),
        sampler_diagnostics=SamplerDiagnostics(int(getattr(first, "num_chains", 0)), min(getattr(first, "energy_ess_per_chain", [0.0])), float(getattr(first, "rhat_energy", 0.0) or 0.0), float(getattr(first, "diagnostics", {}).get("monte_carlo_cv", 1.0)), True, float(getattr(first, "beta_total_energy", 0.0)), str(getattr(first, "diagnostics", {}).get("wbic_temperature_formula", "beta = 1/log(n) for finite-sample WBIC"))),
        input_sample_size=n,
        input_coverage_report="Imported from estimator results; inspect compatibility matrix for coverage.",
        inference_budget_report=f"{getattr(first, 'num_chains', 0)} chains x {getattr(first, 'num_steps', 0)} steps.",
        sample_size_sensitivity=SampleSizeSensitivity([max(1, n // 4), max(2, n // 2), max(3, n)], str(getattr(first, "lambda_slope_fit", "imported slope unavailable")), bool(getattr(first, "trend_test", {}).get("stable_sign", decision == "allow_releap_evidence")), bool(getattr(first, "trend_test", {}).get("stable_margin", decision == "allow_releap_evidence")), "Imported sample-size sensitivity from estimator trend_test."),
        lambda_estimates=lambda_estimates,
        module_vs_joint_report="Imported compatibility matrix includes module-vs-joint context.",
        interaction_null_report="Imported compatibility matrix includes interaction/null context.",
        decision=decision,
        metadata={"compatibility_matrix": compat_matrix},
    )


def format_report_summary(report: EstimatorRunReport) -> str:
    status = "usable" if report.scientific_decision_usable else "blocked"
    lambda_bits = ", ".join(f"{e.target}: lambda={e.lambda_hat:.4g}, margin={e.null_normalized_margin:.4g}" for e in report.lambda_estimates)
    return f"RelaLeap SLT estimator report: {status}; estimator={report.estimator_type}; blocks={len(report.parameter_blocks)}; calibration={report.calibration.status}; chains={report.sampler_diagnostics.chains}; ESS={report.sampler_diagnostics.effective_sample_size:.4g}; lambdas=[{lambda_bits}]. {report.finite_sample_wording}"


def _require_non_empty(value: str, field_name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ReportValidationError(f"{field_name} must be a non-empty string")


def _require_finite(value: float, field_name: str) -> None:
    if not isinstance(value, (int, float)) or not isfinite(float(value)):
        raise ReportValidationError(f"{field_name} must be finite")


def _require_finite_positive(value: float, field_name: str) -> None:
    _require_finite(value, field_name)
    if float(value) <= 0:
        raise ReportValidationError(f"{field_name} must be positive")
