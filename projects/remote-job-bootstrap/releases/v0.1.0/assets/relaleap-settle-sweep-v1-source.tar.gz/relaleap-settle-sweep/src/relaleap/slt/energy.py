from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, Sequence

import torch

from .parameter_blocks import ParameterBlock

Tensor = torch.Tensor


class EnergyModel(Protocol):
    """Minimal energy interface shared by estimator and calibration agents."""

    def total_energy(self, theta: torch.Tensor, data: torch.Tensor) -> torch.Tensor: ...

    def mean_loss(self, theta: torch.Tensor, batch: torch.Tensor) -> torch.Tensor: ...

    def grad_total_energy(self, theta: torch.Tensor, batch: torch.Tensor) -> torch.Tensor: ...

    def theta_hat(self) -> torch.Tensor: ...

    def parameter_blocks(self) -> Sequence[ParameterBlock]: ...


class Prior(Protocol):
    prior_family: str
    prior_scale: float

    def negative_log_prior(self, theta: Tensor) -> Tensor:
        """Return U(theta) = -log pi(theta), up to an additive constant."""

    def grad_negative_log_prior(self, theta: Tensor) -> Tensor:
        """Return grad U(theta). Implementations may rely on autograd instead."""


@dataclass(frozen=True)
class GaussianPrior:
    """Zero-mean isotropic Gaussian prior U(theta)=||theta||^2/(2 scale^2)."""

    prior_scale: float = 1.0
    prior_family: str = "isotropic_gaussian"

    def __post_init__(self) -> None:
        if self.prior_scale <= 0:
            raise ValueError("prior_scale must be positive")

    def negative_log_prior(self, theta: Tensor) -> Tensor:
        return 0.5 * torch.sum(theta * theta) / (self.prior_scale**2)

    def grad_negative_log_prior(self, theta: Tensor) -> Tensor:
        return theta / (self.prior_scale**2)

    @property
    def precision(self) -> float:
        return 1.0 / (self.prior_scale**2)


@dataclass
class QuadraticEnergyModel:
    """Tiny deterministic mock model for smoke tests and downstream scaffolds."""

    reference: torch.Tensor
    blocks: Sequence[ParameterBlock]

    def total_energy(self, theta: torch.Tensor, data: torch.Tensor) -> torch.Tensor:
        residual = theta - self.reference.to(theta)
        return 0.5 * data.shape[0] * torch.sum(residual * residual)

    def mean_loss(self, theta: torch.Tensor, batch: torch.Tensor) -> torch.Tensor:
        residual = theta - self.reference.to(theta)
        return 0.5 * torch.sum(residual * residual)

    def grad_total_energy(self, theta: torch.Tensor, batch: torch.Tensor) -> torch.Tensor:
        return batch.shape[0] * (theta - self.reference.to(theta))

    def theta_hat(self) -> torch.Tensor:
        return self.reference.clone()

    def parameter_blocks(self) -> Sequence[ParameterBlock]:
        return tuple(self.blocks)


@dataclass
class GaussianQuadraticEnergyModel:
    """Quadratic total-energy model with exact tempered Gaussian posterior hooks.

    total_energy(theta, data) = 0.5 * (theta-center)^T H (theta-center) + offset,
    where H is the total-energy Hessian for the supplied data size.
    """

    hessian: Tensor
    center: Tensor
    n_data: int
    blocks: Sequence[ParameterBlock] = ()
    offset: float = 0.0

    def __post_init__(self) -> None:
        if self.hessian.ndim != 2 or self.hessian.shape[0] != self.hessian.shape[1]:
            raise ValueError("hessian must be a square matrix")
        if self.center.shape != (self.hessian.shape[0],):
            raise ValueError("center must be a vector matching hessian dimension")
        if self.n_data <= 1:
            raise ValueError("n_data must be greater than 1 for WBIC")

    def total_energy(self, theta: Tensor, data: Tensor) -> Tensor:
        _ = data
        delta = theta - self.center.to(theta.device, theta.dtype)
        hessian = self.hessian.to(theta.device, theta.dtype)
        return 0.5 * delta @ hessian @ delta + theta.new_tensor(float(self.offset))

    def mean_loss(self, theta: Tensor, batch: Tensor) -> Tensor:
        return self.total_energy(theta, batch) / float(self.n_data)

    def grad_total_energy(self, theta: Tensor, batch: Tensor) -> Tensor:
        _ = batch
        hessian = self.hessian.to(theta.device, theta.dtype)
        return hessian @ (theta - self.center.to(theta.device, theta.dtype))

    def theta_hat(self) -> Tensor:
        return self.center.detach().clone()

    def parameter_blocks(self) -> Sequence[ParameterBlock]:
        return tuple(self.blocks)


def potential_energy(
    model: EnergyModel,
    theta: Tensor,
    data: Tensor,
    *,
    beta_total_energy: float,
    prior: Prior | None = None,
) -> Tensor:
    """Return Phi(theta)=beta En(theta)+U(theta)."""

    phi = float(beta_total_energy) * model.total_energy(theta, data)
    if prior is not None:
        phi = phi + prior.negative_log_prior(theta)
    return phi


def grad_potential_energy(
    model: EnergyModel,
    theta: Tensor,
    batch: Tensor,
    *,
    beta_total_energy: float,
    n_data: int | None = None,
    prior: Prior | None = None,
) -> Tensor:
    """Return gradient of Phi using full-batch or unbiased minibatch scaling."""

    grad = model.grad_total_energy(theta, batch)
    if n_data is not None and batch.shape[0] != n_data:
        grad = grad * (float(n_data) / float(batch.shape[0]))
    grad = float(beta_total_energy) * grad
    if prior is not None:
        if hasattr(prior, "grad_negative_log_prior"):
            grad = grad + prior.grad_negative_log_prior(theta)  # type: ignore[attr-defined]
        else:
            theta_req = theta.detach().clone().requires_grad_(True)
            u = prior.negative_log_prior(theta_req)
            (prior_grad,) = torch.autograd.grad(u, theta_req)
            grad = grad + prior_grad.to(theta)
    return grad


def exact_gaussian_posterior_moments(
    model: GaussianQuadraticEnergyModel,
    *,
    beta_total_energy: float,
    prior: GaussianPrior | None = None,
) -> tuple[Tensor, Tensor]:
    """Analytic mean/covariance for a quadratic energy plus zero-mean Gaussian prior."""

    h = model.hessian.detach().double()
    center = model.center.detach().double()
    precision = float(beta_total_energy) * h
    rhs = float(beta_total_energy) * h @ center
    if prior is not None:
        precision = precision + torch.eye(h.shape[0], dtype=torch.double) * prior.precision
    covariance = torch.linalg.inv(precision)
    mean = covariance @ rhs
    return mean.to(model.center.dtype), covariance.to(model.center.dtype)
