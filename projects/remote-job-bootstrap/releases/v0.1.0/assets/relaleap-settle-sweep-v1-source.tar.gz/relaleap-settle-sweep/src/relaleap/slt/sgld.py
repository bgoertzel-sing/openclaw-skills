from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import torch

from .diagnostics import ChainDiagnostics, diagnose_energy_chains
from .energy import EnergyModel, Prior, grad_potential_energy

Tensor = torch.Tensor
Schedule = Callable[[int], float]


@dataclass(frozen=True)
class SGLDConfig:
    num_steps: int = 10_000
    step_size: float = 1e-3
    burn_in: int = 1_000
    thin: int = 10
    seed: int = 0
    init_noise: float = 0.0
    eval_interval: int = 1
    batch_size: int | None = None

    def __post_init__(self) -> None:
        if self.num_steps <= 0:
            raise ValueError("num_steps must be positive")
        if self.step_size <= 0:
            raise ValueError("step_size must be positive")
        if self.burn_in < 0 or self.burn_in >= self.num_steps:
            raise ValueError("burn_in must be nonnegative and less than num_steps")
        if self.thin <= 0 or self.eval_interval <= 0:
            raise ValueError("thin and eval_interval must be positive")
        if self.batch_size is not None and self.batch_size <= 0:
            raise ValueError("batch_size must be positive when supplied")


@dataclass
class SGLDResult:
    samples: Tensor
    energy_trace: Tensor
    diagnostics: ChainDiagnostics
    final_theta: Tensor
    beta_total_energy: float
    config: SGLDConfig
    n_data: int
    acceptance_rate: float | None = None


def _make_step_size(schedule_or_value: float | Schedule) -> Schedule:
    if callable(schedule_or_value):
        return schedule_or_value
    value = float(schedule_or_value)
    return lambda _t: value


def _sample_batch(data: Tensor, batch_size: int | None, generator: torch.Generator) -> Tensor:
    if batch_size is None or batch_size >= data.shape[0]:
        return data
    indices = torch.randint(data.shape[0], (batch_size,), generator=generator, device=data.device)
    return data.index_select(0, indices)


def run_sgld_chain(
    model: EnergyModel,
    data: Tensor,
    theta0: Tensor | None = None,
    *,
    beta_total_energy: float,
    prior: Prior | None = None,
    config: SGLDConfig | None = None,
    step_size: float | Schedule | None = None,
) -> SGLDResult:
    """Run SGLD for Phi=beta En+U.

    Uses the standard unadjusted Langevin convention
    theta <- theta - eta/2 grad Phi + sqrt(eta) N(0,I), with full-batch
    gradients by default and unbiased minibatch total-energy gradients when
    ``config.batch_size`` is set.
    """

    cfg = config or SGLDConfig()
    schedule = _make_step_size(cfg.step_size if step_size is None else step_size)
    generator = torch.Generator(device=data.device)
    generator.manual_seed(cfg.seed)
    theta = (model.theta_hat() if theta0 is None else theta0).detach().clone().to(data.device)
    if cfg.init_noise:
        theta = theta + cfg.init_noise * torch.randn(theta.shape, dtype=theta.dtype, device=theta.device, generator=generator)

    samples: list[Tensor] = []
    energies: list[Tensor] = []
    divergence_count = 0
    n_data = int(data.shape[0])
    for t in range(cfg.num_steps):
        batch = _sample_batch(data, cfg.batch_size, generator)
        grad = grad_potential_energy(
            model,
            theta,
            batch,
            beta_total_energy=beta_total_energy,
            n_data=n_data,
            prior=prior,
        )
        eta = float(schedule(t))
        if eta <= 0:
            raise ValueError("step-size schedule produced a non-positive value")
        with torch.no_grad():
            noise = torch.randn(theta.shape, dtype=theta.dtype, device=theta.device, generator=generator)
            theta = theta - 0.5 * eta * grad + eta**0.5 * noise
        if not torch.isfinite(theta).all():
            divergence_count += int(theta.numel() - torch.isfinite(theta).sum().item())

        if t % cfg.eval_interval == 0:
            with torch.no_grad():
                energies.append(model.total_energy(theta.detach(), data).detach().cpu())
        if t >= cfg.burn_in and ((t - cfg.burn_in) % cfg.thin == 0):
            samples.append(theta.detach().cpu().clone())

    sample_tensor = torch.stack(samples) if samples else torch.empty((0,) + tuple(theta.shape), dtype=theta.dtype)
    energy_trace = torch.stack(energies).flatten() if energies else torch.empty(0, dtype=theta.dtype)
    diagnostics = diagnose_energy_chains([energy_trace])
    if divergence_count:
        diagnostics = ChainDiagnostics(
            energy_ess_per_chain=diagnostics.energy_ess_per_chain,
            rhat_energy=diagnostics.rhat_energy,
            trend_test=diagnostics.trend_test,
            nan_or_divergence_count=diagnostics.nan_or_divergence_count + divergence_count,
            acceptance_rate=None,
        )
    return SGLDResult(
        samples=sample_tensor,
        energy_trace=energy_trace,
        diagnostics=diagnostics,
        final_theta=theta.detach().cpu(),
        beta_total_energy=float(beta_total_energy),
        config=cfg,
        n_data=n_data,
    )


def run_sgld_chains(
    model: EnergyModel,
    data: Tensor,
    theta0: Tensor | None = None,
    *,
    beta_total_energy: float,
    prior: Prior | None = None,
    config: SGLDConfig | None = None,
    num_chains: int = 4,
) -> list[SGLDResult]:
    if num_chains <= 0:
        raise ValueError("num_chains must be positive")
    base = config or SGLDConfig()
    results = []
    for chain in range(num_chains):
        cfg = SGLDConfig(
            num_steps=base.num_steps,
            step_size=base.step_size,
            burn_in=base.burn_in,
            thin=base.thin,
            seed=base.seed + chain,
            init_noise=base.init_noise,
            eval_interval=base.eval_interval,
            batch_size=base.batch_size,
        )
        results.append(run_sgld_chain(model, data, theta0, beta_total_energy=beta_total_energy, prior=prior, config=cfg))
    return results
