"""Hugging Face GPT-2 construction seam for the frozen pilot.

Imports are deliberately lazy: the CPU stub and unit suite do not require a
model download or the optional ``transformers`` package.
"""
from __future__ import annotations

from typing import Any


def build_hf_gpt2_models(protocol: dict[str, Any], *, local_files_only: bool = True):
    """Build the pinned teacher and random six-block student.

    The caller owns device placement. The pod preflight downloads and hashes
    the frozen files, so scientific execution defaults to local-only loading.
    """

    try:
        from transformers import AutoModelForCausalLM, GPT2Config, GPT2LMHeadModel
    except ImportError as exc:  # pragma: no cover - optional GPU dependency
        raise RuntimeError("install the frozen pilot environment with transformers") from exc

    teacher_spec = protocol["teacher"]
    teacher = AutoModelForCausalLM.from_pretrained(
        teacher_spec["model_id"],
        revision=teacher_spec["revision"],
        local_files_only=local_files_only,
        use_safetensors=True,
    )
    config = GPT2Config.from_pretrained(
        teacher_spec["model_id"],
        revision=teacher_spec["revision"],
        local_files_only=local_files_only,
    )
    student_spec = protocol["student"]
    config.n_layer = student_spec["num_layers"]
    config.n_embd = student_spec["d_model"]
    config.n_head = student_spec["num_heads"]
    config.n_inner = student_spec["d_ff"]
    config.resid_pdrop = config.embd_pdrop = config.attn_pdrop = 0.0
    config.use_cache = False
    student = GPT2LMHeadModel(config)
    student.tie_weights()
    teacher.eval()
    student.train()
    if len(teacher.transformer.h) != 12 or len(student.transformer.h) != 6:
        raise RuntimeError("constructed models do not match frozen layer counts")
    return teacher, student
