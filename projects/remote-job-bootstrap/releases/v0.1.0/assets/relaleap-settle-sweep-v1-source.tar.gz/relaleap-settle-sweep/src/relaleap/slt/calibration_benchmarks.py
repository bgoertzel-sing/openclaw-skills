from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Iterable, Protocol, Sequence

import torch

from .energy import EnergyModel, QuadraticEnergyModel
from .parameter_blocks import ParameterBlock


class BenchmarkFamily(str, Enum):
    """Analytic benchmark families from the SLT estimator validation plan."""

    REGULAR_LINEAR_GAUSSIAN = "regular_linear_gaussian"
    RANK_DEFICIENT_LINEAR = "rank_deficient_linear"
    PRODUCT_SINGULARITY = "product_singularity"
    NONZERO_PRODUCT_RIDGE = "nonzero_product_ridge"
    CUSP = "cusp"
    CROSSING = "crossing"
    OVERPARAMETERIZED_MIXTURE = "overparameterized_mixture"
    INDEPENDENT_COMPOSITION = "independent_composition"
    REDUNDANT_COMPOSITION = "redundant_composition"
    SYNERGISTIC_COMPOSITION = "synergistic_composition"


class InteractionSign(str, Enum):
    NEGATIVE = "negative"
    ZERO = "zero"
    POSITIVE = "positive"


@dataclass(frozen=True)
class TrueTargets:
    """Pre-registered analytic LLC/RLCT calibration target."""

    lambda_target: float | None
    tolerance: float | None = None
    interaction_sign: str | InteractionSign | None = None
    multiplicity: int | None = None
    notes: str = ""
    lambda_A: float | None = None
    lambda_B: float | None = None
    lambda_AB: float | None = None
    interaction: float | None = None

    @property
    def lambda_true(self) -> float | None:
        """Compatibility alias for earlier analytic-registry tests."""

        return self.lambda_target

    @property
    def multiplicity_true(self) -> int | None:
        """Compatibility alias for earlier analytic-registry tests."""

        return self.multiplicity

    def __post_init__(self) -> None:
        if isinstance(self.interaction_sign, str):
            object.__setattr__(self, "interaction_sign", InteractionSign(self.interaction_sign))
        if self.interaction is None and None not in (self.lambda_A, self.lambda_B, self.lambda_AB):
            object.__setattr__(self, "interaction", float(self.lambda_A + self.lambda_B - self.lambda_AB))
        if self.interaction_sign is None and self.interaction is not None and self.tolerance is not None:
            if self.interaction > self.tolerance:
                sign = InteractionSign.POSITIVE
            elif self.interaction < -self.tolerance:
                sign = InteractionSign.NEGATIVE
            else:
                sign = InteractionSign.ZERO
            object.__setattr__(self, "interaction_sign", sign)


class CalibrationBenchmark(Protocol):
    """Factory interface for known-SLT validation benchmarks."""

    benchmark_id: str

    def make_data(self, n: int, seed: int) -> torch.Tensor: ...

    def make_energy_model(self, data: torch.Tensor, cfg: dict[str, Any] | None = None) -> EnergyModel: ...

    def true_targets(self) -> TrueTargets: ...


@dataclass(frozen=True)
class FunctionalEnergyModel:
    """Deterministic EnergyModel backed by an analytic mean-loss function."""

    reference: torch.Tensor
    blocks: Sequence[ParameterBlock]
    mean_loss_fn: Callable[[torch.Tensor, torch.Tensor], torch.Tensor]

    def total_energy(self, theta: torch.Tensor, data: torch.Tensor) -> torch.Tensor:
        return data.shape[0] * self.mean_loss(theta, data)

    def mean_loss(self, theta: torch.Tensor, batch: torch.Tensor) -> torch.Tensor:
        return self.mean_loss_fn(theta.to(dtype=torch.float64), batch)

    def grad_total_energy(self, theta: torch.Tensor, batch: torch.Tensor) -> torch.Tensor:
        theta_var = theta.detach().clone().to(dtype=torch.float64).requires_grad_(True)
        energy = self.total_energy(theta_var, batch)
        (grad,) = torch.autograd.grad(energy, theta_var)
        return grad.to(theta)

    def theta_hat(self) -> torch.Tensor:
        return self.reference.clone()

    def parameter_blocks(self) -> Sequence[ParameterBlock]:
        return tuple(self.blocks)


@dataclass(frozen=True)
class MockCalibrationBenchmark:
    """Small regular quadratic benchmark used only for interface smoke tests."""

    benchmark_id: str = "mock_regular_quadratic"
    dim: int = 2
    target: TrueTargets = field(default_factory=lambda: TrueTargets(lambda_target=1.0, tolerance=0.1, multiplicity=1))

    def make_data(self, n: int, seed: int) -> torch.Tensor:
        generator = torch.Generator().manual_seed(seed)
        return torch.randn(n, self.dim, generator=generator)

    def make_energy_model(self, data: torch.Tensor, cfg: dict[str, Any] | None = None) -> EnergyModel:
        _ = data, cfg
        block = ParameterBlock(name="mock_theta", role="joint", size=self.dim, trainable=True)
        return QuadraticEnergyModel(reference=torch.zeros(self.dim, dtype=torch.float64), blocks=[block])

    def true_targets(self) -> TrueTargets:
        return self.target


@dataclass(frozen=True)
class AnalyticCalibrationBenchmark:
    """Base class for small analytic fixtures with pre-registered targets."""

    benchmark_id: str
    family: BenchmarkFamily
    target: TrueTargets
    dim: int
    blocks: tuple[ParameterBlock, ...]
    mean_loss_fn: Callable[[torch.Tensor, torch.Tensor], torch.Tensor]
    data_fn: Callable[[int, int], torch.Tensor]
    theta_star: torch.Tensor
    description: str = ""
    parameter_names: tuple[str, ...] = ()
    dimensions: dict[str, int | float] = field(default_factory=dict)

    @property
    def name(self) -> str:
        return self.benchmark_id

    @property
    def block_A(self) -> tuple[str, ...]:
        return tuple(block.name for block in self.blocks if block.name == "A")

    @property
    def block_B(self) -> tuple[str, ...]:
        return tuple(block.name for block in self.blocks if block.name == "B")

    def make_data(self, n: int, seed: int) -> torch.Tensor:
        if n <= 0:
            raise ValueError("n must be positive")
        return self.data_fn(n, seed).to(dtype=torch.float64)

    def make_energy_model(self, data: torch.Tensor, cfg: dict[str, Any] | None = None) -> EnergyModel:
        _ = cfg
        return FunctionalEnergyModel(reference=self.theta_star, blocks=self.blocks, mean_loss_fn=self.mean_loss_fn)

    def true_targets(self) -> TrueTargets:
        return self.target

    def loss(self, theta: torch.Tensor | Iterable[float]) -> torch.Tensor:
        if not isinstance(theta, torch.Tensor):
            theta = torch.tensor(list(theta), dtype=torch.float64)
        data = torch.zeros(1, 1, dtype=torch.float64)
        return self.mean_loss_fn(theta.to(dtype=torch.float64), data)


def _named_blocks(*specs: tuple[str, int]) -> tuple[ParameterBlock, ...]:
    return tuple(ParameterBlock(name=name, role="joint" if name == "AB" else "other", size=size, trainable=True) for name, size in specs)


def _noise_data(cols: int) -> Callable[[int, int], torch.Tensor]:
    def make(n: int, seed: int) -> torch.Tensor:
        generator = torch.Generator().manual_seed(seed)
        return torch.randn(n, cols, generator=generator, dtype=torch.float64)

    return make


def regular_linear_gaussian(d: int = 4, sigma: float = 1.0) -> AnalyticCalibrationBenchmark:
    if d <= 0:
        raise ValueError("d must be positive")
    w_star = torch.linspace(0.25, 0.25 * d, d, dtype=torch.float64)

    def make_data(n: int, seed: int) -> torch.Tensor:
        generator = torch.Generator().manual_seed(seed)
        x = torch.randn(n, d, generator=generator, dtype=torch.float64)
        eps = sigma * torch.randn(n, generator=generator, dtype=torch.float64)
        y = x @ w_star + eps
        return torch.cat([x, y[:, None]], dim=1)

    def mean_loss(theta: torch.Tensor, batch: torch.Tensor) -> torch.Tensor:
        if batch.shape[1] == d + 1:
            x, y = batch[:, :d], batch[:, d]
            residual = y - x @ theta
            # Drop constants; normalise so theta_star is the population optimum.
            return 0.5 * torch.mean((residual - (y - x @ w_star)) ** 2) / (sigma * sigma)
        delta = theta - w_star.to(theta)
        return 0.5 * torch.sum(delta * delta)

    return AnalyticCalibrationBenchmark(
        benchmark_id=f"regular_linear_gaussian_d{d}",
        family=BenchmarkFamily.REGULAR_LINEAR_GAUSSIAN,
        target=TrueTargets(lambda_target=d / 2.0, tolerance=0.10, multiplicity=1, notes="Regular identifiable Gaussian linear model; λ=d/2."),
        dim=d,
        blocks=_named_blocks(("AB", d)),
        mean_loss_fn=mean_loss,
        data_fn=make_data,
        theta_star=w_star,
        description="Identifiable d-dimensional linear Gaussian local quadratic.",
        parameter_names=tuple(f"w{i}" for i in range(d)),
        dimensions={"d": d, "sigma": float(sigma)},
    )


def rank_deficient_linear(d: int = 5, rank: int = 2) -> AnalyticCalibrationBenchmark:
    if not 0 < rank <= d:
        raise ValueError("rank must satisfy 0 < rank <= d")
    u_star = torch.linspace(0.3, 0.3 * rank, rank, dtype=torch.float64)

    def make_data(n: int, seed: int) -> torch.Tensor:
        generator = torch.Generator().manual_seed(seed)
        z = torch.randn(n, rank, generator=generator, dtype=torch.float64)
        x = torch.zeros(n, d, dtype=torch.float64)
        x[:, :rank] = z
        y = z @ u_star + 0.1 * torch.randn(n, generator=generator, dtype=torch.float64)
        return torch.cat([x, y[:, None]], dim=1)

    def mean_loss(theta: torch.Tensor, batch: torch.Tensor) -> torch.Tensor:
        _ = batch
        delta = theta[:rank] - u_star.to(theta)
        return 0.5 * torch.sum(delta * delta)

    theta_star = torch.zeros(d, dtype=torch.float64)
    theta_star[:rank] = u_star
    return AnalyticCalibrationBenchmark(
        benchmark_id=f"rank_deficient_linear_d{d}_r{rank}",
        family=BenchmarkFamily.RANK_DEFICIENT_LINEAR,
        target=TrueTargets(lambda_target=rank / 2.0, tolerance=0.15, multiplicity=1, notes="Only the rank-r subspace is identifiable; λ≈r/2."),
        dim=d,
        blocks=_named_blocks(("AB", d)),
        mean_loss_fn=mean_loss,
        data_fn=make_data,
        theta_star=theta_star,
        description="Rank-deficient linear regression catches parameter-count-over-two estimators.",
        parameter_names=tuple(f"w{i}" for i in range(d)),
        dimensions={"d": d, "rank": rank},
    )


def product_singularity() -> AnalyticCalibrationBenchmark:
    def mean_loss(theta: torch.Tensor, batch: torch.Tensor) -> torch.Tensor:
        _ = batch
        return (theta[0] * theta[1]) ** 2

    return AnalyticCalibrationBenchmark(
        benchmark_id="product_singularity_ab2",
        family=BenchmarkFamily.PRODUCT_SINGULARITY,
        target=TrueTargets(lambda_target=0.5, tolerance=0.10, multiplicity=1, lambda_A=0.0, lambda_B=0.0, lambda_AB=0.5, interaction_sign=InteractionSign.NEGATIVE, notes="K=(ab)^2: singleton blocks are flat, joint movement creates loss variation."),
        dim=2,
        blocks=_named_blocks(("A", 1), ("B", 1), ("AB", 2)),
        mean_loss_fn=mean_loss,
        data_fn=_noise_data(1),
        theta_star=torch.zeros(2, dtype=torch.float64),
        description="Product singularity with negative emergent interaction.",
        parameter_names=("a", "b"),
    )


def nonzero_product_ridge(c: float = 1.0) -> AnalyticCalibrationBenchmark:
    if c == 0:
        raise ValueError("c must be nonzero")
    root = float(abs(c) ** 0.5)
    b0 = float(c) / root

    def mean_loss(theta: torch.Tensor, batch: torch.Tensor) -> torch.Tensor:
        _ = batch
        a = root + theta[0]
        b = b0 + theta[1]
        return (a * b - float(c)) ** 2

    return AnalyticCalibrationBenchmark(
        benchmark_id=f"nonzero_product_ridge_c{c:g}",
        family=BenchmarkFamily.NONZERO_PRODUCT_RIDGE,
        target=TrueTargets(lambda_target=0.5, tolerance=0.10, multiplicity=1, lambda_A=0.5, lambda_B=0.5, lambda_AB=0.5, interaction_sign=InteractionSign.POSITIVE, notes="Freezing either block is regular; the joint model has a product-preserving ridge."),
        dim=2,
        blocks=_named_blocks(("A", 1), ("B", 1), ("AB", 2)),
        mean_loss_fn=mean_loss,
        data_fn=_noise_data(1),
        theta_star=torch.zeros(2, dtype=torch.float64),
        description="Nonzero product ridge K=(ab-c)^2 with redundant interaction.",
        parameter_names=("delta_a", "delta_b"),
        dimensions={"c": float(c)},
    )


def cusp_singularity() -> AnalyticCalibrationBenchmark:
    def mean_loss(theta: torch.Tensor, batch: torch.Tensor) -> torch.Tensor:
        _ = batch
        return (theta[0] ** 2 - theta[1] ** 2) ** 2

    return AnalyticCalibrationBenchmark(
        benchmark_id="cusp_a2_minus_b2_quartic",
        family=BenchmarkFamily.CUSP,
        target=TrueTargets(lambda_target=0.5, tolerance=0.20, multiplicity=1, notes="K=(a²-b²)² has crossing non-isolated minima along a=±b."),
        dim=2,
        blocks=_named_blocks(("A", 1), ("B", 1), ("AB", 2)),
        mean_loss_fn=mean_loss,
        data_fn=_noise_data(1),
        theta_star=torch.zeros(2, dtype=torch.float64),
        description="Cusp/crossed-ridge loss landscape fixture.",
        parameter_names=("a", "b"),
    )


def crossing_singularity() -> AnalyticCalibrationBenchmark:
    def mean_loss(theta: torch.Tensor, batch: torch.Tensor) -> torch.Tensor:
        _ = batch
        a, b, c = theta[0], theta[1], theta[2]
        return (a * b - c) ** 2 + c**2

    return AnalyticCalibrationBenchmark(
        benchmark_id="crossing_ab_minus_c_plus_c2",
        family=BenchmarkFamily.CROSSING,
        target=TrueTargets(lambda_target=0.75, tolerance=0.25, multiplicity=1, notes="K=(ab-c)^2+c^2 creates singular strata and a non-quadratic crossing landscape."),
        dim=3,
        blocks=_named_blocks(("A", 1), ("B", 1), ("C", 1), ("AB", 3)),
        mean_loss_fn=mean_loss,
        data_fn=_noise_data(1),
        theta_star=torch.zeros(3, dtype=torch.float64),
        description="Crossing singularity with auxiliary parameter c.",
        parameter_names=("a", "b", "c"),
    )


def overparameterized_mixture(sigma: float = 1.0) -> AnalyticCalibrationBenchmark:
    def make_data(n: int, seed: int) -> torch.Tensor:
        generator = torch.Generator().manual_seed(seed)
        return sigma * torch.randn(n, 1, generator=generator, dtype=torch.float64)

    def mean_loss(theta: torch.Tensor, batch: torch.Tensor) -> torch.Tensor:
        # Local analytic surrogate for the singular two-component mixture at α=1/2, μ1=μ2=0.
        alpha_logit, mu1, mu2 = theta[0], theta[1], theta[2]
        alpha = torch.sigmoid(alpha_logit)
        mean = alpha * mu1 + (1.0 - alpha) * mu2
        variance_excess = alpha * mu1**2 + (1.0 - alpha) * mu2**2 - mean**2
        return 0.5 * mean**2 + 0.25 * variance_excess**2

    return AnalyticCalibrationBenchmark(
        benchmark_id="overparameterized_two_component_gaussian_mixture",
        family=BenchmarkFamily.OVERPARAMETERIZED_MIXTURE,
        target=TrueTargets(lambda_target=0.75, tolerance=0.30, multiplicity=1, notes="Two-component 1D Gaussian mixture fit to one Gaussian; singular and λ < p/2 for p=3."),
        dim=3,
        blocks=_named_blocks(("mixture", 3), ("AB", 3)),
        mean_loss_fn=mean_loss,
        data_fn=make_data,
        theta_star=torch.zeros(3, dtype=torch.float64),
        description="Overparameterized Gaussian mixture surrogate with permutation/merging singularity.",
        parameter_names=("alpha_logit", "mu1", "mu2"),
        dimensions={"p": 3, "sigma": float(sigma)},
    )


def independent_composition(lambda_a: float = 0.5, lambda_b: float = 0.5) -> AnalyticCalibrationBenchmark:
    lambda_ab = float(lambda_a + lambda_b)

    def mean_loss(theta: torch.Tensor, batch: torch.Tensor) -> torch.Tensor:
        _ = batch
        return 0.5 * theta[0] ** 2 + 0.5 * theta[1] ** 2

    return AnalyticCalibrationBenchmark(
        benchmark_id="independent_composition_two_quadratics",
        family=BenchmarkFamily.INDEPENDENT_COMPOSITION,
        target=TrueTargets(lambda_target=lambda_ab, tolerance=0.10, multiplicity=1, lambda_A=float(lambda_a), lambda_B=float(lambda_b), lambda_AB=lambda_ab, interaction=0.0, interaction_sign=InteractionSign.ZERO, notes="Disjoint additive blocks; λ_AB≈λ_A+λ_B."),
        dim=2,
        blocks=_named_blocks(("A", 1), ("B", 1), ("AB", 2)),
        mean_loss_fn=mean_loss,
        data_fn=_noise_data(2),
        theta_star=torch.zeros(2, dtype=torch.float64),
        description="Independent composition benchmark with zero interaction.",
        parameter_names=("a", "b"),
    )


def redundant_composition() -> AnalyticCalibrationBenchmark:
    def mean_loss(theta: torch.Tensor, batch: torch.Tensor) -> torch.Tensor:
        _ = batch
        return 0.5 * (theta[0] + theta[1]) ** 2

    return AnalyticCalibrationBenchmark(
        benchmark_id="redundant_composition_shared_scalar",
        family=BenchmarkFamily.REDUNDANT_COMPOSITION,
        target=TrueTargets(lambda_target=0.5, tolerance=0.10, multiplicity=1, lambda_A=0.5, lambda_B=0.5, lambda_AB=0.5, interaction_sign=InteractionSign.POSITIVE, notes="Two blocks share one latent scalar direction; joint parameterization has a ridge."),
        dim=2,
        blocks=_named_blocks(("A", 1), ("B", 1), ("AB", 2)),
        mean_loss_fn=mean_loss,
        data_fn=_noise_data(2),
        theta_star=torch.zeros(2, dtype=torch.float64),
        description="Redundant shared-direction composition with positive interaction.",
        parameter_names=("alpha_a", "alpha_b"),
    )


def synergistic_composition() -> AnalyticCalibrationBenchmark:
    bench = product_singularity()
    return AnalyticCalibrationBenchmark(
        benchmark_id="synergistic_composition_gated_pair",
        family=BenchmarkFamily.SYNERGISTIC_COMPOSITION,
        target=bench.target,
        dim=bench.dim,
        blocks=bench.blocks,
        mean_loss_fn=bench.mean_loss_fn,
        data_fn=bench.data_fn,
        theta_star=bench.theta_star,
        description="Composition fixture using the zero-product gated pair; expected negative interaction.",
        parameter_names=bench.parameter_names,
    )


@dataclass(frozen=True)
class CalibrationEstimate:
    benchmark_name: str
    lambda_hat: float
    lambda_A: float | None = None
    lambda_B: float | None = None
    lambda_AB: float | None = None

    @property
    def interaction(self) -> float | None:
        if None in (self.lambda_A, self.lambda_B, self.lambda_AB):
            return None
        return float(self.lambda_A + self.lambda_B - self.lambda_AB)


@dataclass(frozen=True)
class CalibrationResult:
    benchmark_name: str
    status: str
    lambda_error: float
    expected_lambda: float | None
    observed_lambda: float
    expected_interaction_sign: InteractionSign | None
    observed_interaction: float | None
    message: str


class CalibrationEstimator(Protocol):
    def estimate(self, benchmark: AnalyticCalibrationBenchmark) -> CalibrationEstimate: ...


def interaction_sign(value: float, tolerance: float) -> InteractionSign:
    if value > tolerance:
        return InteractionSign.POSITIVE
    if value < -tolerance:
        return InteractionSign.NEGATIVE
    return InteractionSign.ZERO


def check_estimate(benchmark: AnalyticCalibrationBenchmark, estimate: CalibrationEstimate) -> CalibrationResult:
    target = benchmark.true_targets()
    expected = target.lambda_target
    lambda_error = float("inf") if expected is None else abs(float(estimate.lambda_hat) - expected)
    tolerance = 0.0 if target.tolerance is None else target.tolerance
    lambda_ok = expected is not None and lambda_error <= tolerance
    observed_interaction = estimate.interaction
    sign_ok = True
    expected_sign = target.interaction_sign
    if expected_sign is not None:
        sign_ok = observed_interaction is not None and interaction_sign(observed_interaction, tolerance) == expected_sign
    return CalibrationResult(
        benchmark_name=benchmark.benchmark_id,
        status="pass" if lambda_ok and sign_ok else "fail",
        lambda_error=lambda_error,
        expected_lambda=expected,
        observed_lambda=float(estimate.lambda_hat),
        expected_interaction_sign=expected_sign,
        observed_interaction=observed_interaction,
        message=f"λ_hat={estimate.lambda_hat:.6g}; λ_true={expected}; λ_error={lambda_error:.6g}",
    )


def run_calibration(estimator: CalibrationEstimator, benchmark_names: Iterable[str] | None = None) -> list[CalibrationResult]:
    from .analytic_registry import get_benchmark, registry

    benches = registry()
    names = list(benchmark_names) if benchmark_names is not None else sorted(benches)
    return [check_estimate(get_benchmark(name), estimator.estimate(get_benchmark(name))) for name in names]


class TargetMetadataEstimator:
    """Deterministic mock estimator returning pre-registered target metadata."""

    def estimate(self, benchmark: AnalyticCalibrationBenchmark) -> CalibrationEstimate:
        target = benchmark.true_targets()
        return CalibrationEstimate(
            benchmark_name=benchmark.benchmark_id,
            lambda_hat=0.0 if target.lambda_target is None else target.lambda_target,
            lambda_A=target.lambda_A,
            lambda_B=target.lambda_B,
            lambda_AB=target.lambda_AB,
        )
