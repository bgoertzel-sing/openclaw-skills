from __future__ import annotations

from dataclasses import replace
from typing import Any, Mapping, Sequence

import torch

from .parameter_blocks import ParameterBlock


def _generator(seed: int, *, device: torch.device | str | None = None) -> torch.Generator:
    gen_device = torch.device(device) if device is not None else torch.device("cpu")
    if gen_device.type == "meta":
        gen_device = torch.device("cpu")
    return torch.Generator(device=gen_device).manual_seed(int(seed))


def _randperm(n: int, seed: int, *, device: torch.device | str | None = None) -> torch.Tensor:
    dev = torch.device(device) if device is not None else torch.device("cpu")
    gen = _generator(seed, device=dev)
    return torch.randperm(n, generator=gen, device=dev)


def _shuffle_first_dim(x: torch.Tensor, seed: int) -> torch.Tensor:
    if x.ndim == 0:
        raise ValueError("cannot shuffle a scalar tensor")
    return x.index_select(0, _randperm(x.shape[0], seed, device=x.device))


def _as_mutable_mapping(data: Any) -> tuple[dict[str, Any], type[Any] | None]:
    if isinstance(data, Mapping):
        return dict(data), None
    if hasattr(data, "_asdict"):
        return dict(data._asdict()), type(data)
    if hasattr(data, "__dict__"):
        return dict(vars(data)), type(data)
    raise TypeError("data must be a mapping or object with attributes")


def _restore_mapping(values: dict[str, Any], original_type: type[Any] | None) -> Any:
    if original_type is None:
        return values
    try:
        return original_type(**values)
    except TypeError:
        return values


def _replace_first_present(data: Any, names: Sequence[str], seed: int) -> Any:
    values, original_type = _as_mutable_mapping(data)
    for name in names:
        if name in values:
            value = values[name]
            if not isinstance(value, torch.Tensor):
                raise TypeError(f"{name} must be a torch.Tensor")
            values[name] = _shuffle_first_dim(value, seed)
            return _restore_mapping(values, original_type)
    raise KeyError(f"data does not contain any of {tuple(names)}")


def target_shuffle_null(data: Any, seed: int) -> Any:
    """Return a copy of ``data`` with target labels shuffled along sample axis."""

    return _replace_first_present(data, ("y", "targets", "target", "labels"), seed)


def residual_shuffle_null(data: Any, seed: int) -> Any:
    """Return a copy of ``data`` with residual signals shuffled along sample axis."""

    return _replace_first_present(data, ("residuals", "residual", "teacher_residuals"), seed)


def block_assignment_shuffle_null(blocks: Sequence[ParameterBlock], seed: int) -> list[ParameterBlock]:
    """Shuffle parameter block role/parent/mask assignments while preserving block identities and sizes."""

    blocks = list(blocks)
    if not blocks:
        return []
    perm = _randperm(len(blocks), seed).cpu().tolist()
    source = [blocks[int(i)] for i in perm]
    shuffled: list[ParameterBlock] = []
    for block, src in zip(blocks, source):
        shuffled.append(
            replace(
                block,
                role=src.role,
                parent=src.parent,
                mask_id=src.mask_id,
                metadata={**block.metadata, "assignment_source": src.name},
            )
        )
    return shuffled


def router_support_shuffle_null(router_probs: torch.Tensor, seed: int) -> torch.Tensor:
    """Shuffle router support over rows, preserving each row distribution shape."""

    if router_probs.ndim < 1:
        raise ValueError("router_probs must have at least one dimension")
    return _shuffle_first_dim(router_probs, seed)


def shared_core_shuffle_null(shared_core_dirs: torch.Tensor, seed: int) -> torch.Tensor:
    """Shuffle shared-core directions across columns (dimension 1 for matrices)."""

    if shared_core_dirs.ndim == 0:
        raise ValueError("shared_core_dirs must not be scalar")
    if shared_core_dirs.ndim == 1:
        return shared_core_dirs.index_select(0, _randperm(shared_core_dirs.shape[0], seed, device=shared_core_dirs.device))
    perm = _randperm(shared_core_dirs.shape[1], seed, device=shared_core_dirs.device)
    return shared_core_dirs.index_select(1, perm)


def gauge_randomization_null(
    read: torch.Tensor,
    write: torch.Tensor,
    amplitude: torch.Tensor,
    seed: int,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Apply random sign, positive scale, and permutation gauge transforms.

    For the linear rank-one function ``sum_g amp[g] * write[g] * <read[g], x>``,
    this transform preserves outputs exactly up to floating-point roundoff.
    """

    if read.ndim != 2 or write.ndim != 2:
        raise ValueError("read and write must be rank-2 tensors shaped [num_atoms, dim]")
    if read.shape[0] != write.shape[0]:
        raise ValueError("read and write must have the same number of atoms")
    if amplitude.ndim != 1 or amplitude.shape[0] != read.shape[0]:
        raise ValueError("amplitude must be shaped [num_atoms]")

    n = read.shape[0]
    device = read.device
    gen = _generator(seed, device=device)
    perm = torch.randperm(n, generator=gen, device=device)
    dtype = read.dtype
    read_scale = torch.exp(torch.randn(n, generator=gen, device=device, dtype=dtype) * 0.5).clamp_min(1e-12)
    write_scale = torch.exp(torch.randn(n, generator=gen, device=device, dtype=dtype) * 0.5).clamp_min(1e-12)
    read_sign = torch.where(torch.rand(n, generator=gen, device=device) < 0.5, -1.0, 1.0).to(dtype)
    write_sign = torch.where(torch.rand(n, generator=gen, device=device) < 0.5, -1.0, 1.0).to(dtype)

    out_read = read * (read_scale * read_sign).unsqueeze(1)
    out_write = write * (write_scale * write_sign).unsqueeze(1)
    out_amp = amplitude.to(device=device) / (read_scale * write_scale) * read_sign * write_sign
    return out_read.index_select(0, perm), out_write.index_select(0, perm), out_amp.index_select(0, perm)


def mechanism_preserving_control(data: Any, seed: int) -> Any:
    """Preserve marginal mechanisms but break a declared cross-channel dependency.

    The default control shuffles an auxiliary/context channel when available,
    leaving targets and residuals intact.  This gives a deterministic local
    control for interaction claims without destroying the primary mechanism.
    """

    return _replace_first_present(data, ("dependency", "context", "router_support", "support", "x_aux"), seed)


def mechanism_violating_control(data: Any, seed: int) -> Any:
    """Break the mechanism entirely by shuffling the primary observed inputs."""

    return _replace_first_present(data, ("x", "inputs", "features", "hidden"), seed)
