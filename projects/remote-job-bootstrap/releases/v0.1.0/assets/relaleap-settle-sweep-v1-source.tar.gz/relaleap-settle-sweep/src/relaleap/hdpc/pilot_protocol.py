"""Validation and loading for the frozen GPT-2-small ePC pilot contract."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any


REQUIRED_METRICS = {
    "student_val_loss",
    "student_val_perplexity",
    "teacher_val_loss",
    "kd_gap_nats",
    "credit_assignment",
}


def load_pilot_protocol(path: str | Path) -> dict[str, Any]:
    protocol = json.loads(Path(path).read_text(encoding="utf-8"))
    validate_pilot_protocol(protocol)
    return protocol


def validate_pilot_protocol(protocol: dict[str, Any]) -> None:
    if protocol.get("status") != "frozen_pre_run":
        raise ValueError("pilot protocol must be frozen before execution")
    teacher = protocol["teacher"]
    expected_teacher = (768, 12, 12, 124439808)
    observed_teacher = (
        teacher["d_model"], teacher["num_layers"], teacher["num_heads"],
        teacher["parameter_count"],
    )
    if observed_teacher != expected_teacher:
        raise ValueError("teacher is not the pinned GPT-2-small architecture")
    for section, field in (("teacher", "revision"), ("tokenizer", "revision"), ("dataset", "revision")):
        value = protocol[section][field]
        if len(value) != 40 or any(c not in "0123456789abcdef" for c in value):
            raise ValueError(f"{section}.{field} must be a full git commit")
    training = protocol["training"]
    if abs(training["ce_weight"] + training["kd_weight"] - 1.0) > 1e-12:
        raise ValueError("CE and KD weights must sum to one")
    epc = protocol["epc"]
    if epc["state_count_including_feedforward"] <= 1:
        raise ValueError("primary ePC arm must perform genuine relaxation")
    if epc["activity_step_size"] <= 0 or epc["lambda_output"] <= 0:
        raise ValueError("ePC step size and lambda must be positive")
    controls = protocol["controls"]
    if not controls["update_matched"] or not controls["wall_clock_matched"]:
        raise ValueError("both update- and wall-clock-matched controls are required")
    evaluation = protocol["evaluation"]
    if len(evaluation["seeds"]) < 3 or len(set(evaluation["seeds"])) != len(evaluation["seeds"]):
        raise ValueError("at least three distinct evaluation seeds are required")
    if set(evaluation["metrics"]) != REQUIRED_METRICS:
        raise ValueError("structured metric contract is incomplete")
    promotion = protocol["promotion"]
    if promotion["required_seed_count"] != len(evaluation["seeds"]):
        raise ValueError("promotion seed count must match the frozen seeds")
    if not promotion["require_monotone_activity_energy"]:
        raise ValueError("promotion must fail closed on non-monotone relaxation")
