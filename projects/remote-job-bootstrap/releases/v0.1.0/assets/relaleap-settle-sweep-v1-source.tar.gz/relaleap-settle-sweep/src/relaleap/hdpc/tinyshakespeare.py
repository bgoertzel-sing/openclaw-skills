from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable
from urllib.request import urlretrieve

import torch
from torch import nn
from torch.nn import functional as F

from .crown import IdentityPCCrown

TINY_SHAKESPEARE_URL = "https://raw.githubusercontent.com/karpathy/char-rnn/master/data/tinyshakespeare/input.txt"


@dataclass(frozen=True)
class TinyShakespeareTokenizer:
    """Deterministic character tokenizer for the Tiny Shakespeare corpus."""

    chars: tuple[str, ...]

    @classmethod
    def from_text(cls, text: str) -> "TinyShakespeareTokenizer":
        if not text:
            raise ValueError("cannot build tokenizer from empty text")
        return cls(tuple(sorted(set(text))))

    @property
    def vocab_size(self) -> int:
        return len(self.chars)

    @property
    def stoi(self) -> dict[str, int]:
        return {ch: index for index, ch in enumerate(self.chars)}

    @property
    def itos(self) -> dict[int, str]:
        return {index: ch for index, ch in enumerate(self.chars)}

    def encode(self, text: str) -> torch.Tensor:
        stoi = self.stoi
        return torch.tensor([stoi[ch] for ch in text], dtype=torch.long)

    def decode(self, tokens: torch.Tensor | Iterable[int]) -> str:
        itos = self.itos
        if isinstance(tokens, torch.Tensor):
            values = tokens.detach().cpu().reshape(-1).tolist()
        else:
            values = list(tokens)
        return "".join(itos[int(token)] for token in values)


@dataclass(frozen=True)
class TinyShakespeareDataset:
    tokenizer: TinyShakespeareTokenizer
    train: torch.Tensor
    val: torch.Tensor
    source_path: Path

    @property
    def vocab_size(self) -> int:
        return self.tokenizer.vocab_size


def prepare_tinyshakespeare_data(
    data_dir: str | Path = "data/tinyshakespeare",
    *,
    url: str = TINY_SHAKESPEARE_URL,
    download: bool = True,
) -> TinyShakespeareDataset:
    """Load the canonical Tiny Shakespeare text, downloading it if needed."""

    root = Path(data_dir)
    root.mkdir(parents=True, exist_ok=True)
    text_path = root / "tinyshakespeare.txt"
    if not text_path.exists():
        if not download:
            raise FileNotFoundError(text_path)
        urlretrieve(url, text_path)

    text = text_path.read_text(encoding="utf-8")
    tokenizer = TinyShakespeareTokenizer.from_text(text)
    tokens = tokenizer.encode(text)
    split = int(0.9 * len(tokens))
    if split <= 0 or split >= len(tokens):
        raise ValueError("Tiny Shakespeare corpus is too small for a 90/10 train/val split")
    return TinyShakespeareDataset(
        tokenizer=tokenizer,
        train=tokens[:split],
        val=tokens[split:],
        source_path=text_path,
    )


def get_batch(
    tokens: torch.Tensor,
    *,
    batch_size: int,
    seq_len: int,
    device: torch.device | str,
    generator: torch.Generator | None = None,
) -> tuple[torch.Tensor, torch.Tensor]:
    if seq_len <= 0:
        raise ValueError("seq_len must be positive")
    if len(tokens) <= seq_len:
        raise ValueError("token stream must be longer than seq_len")
    starts = torch.randint(len(tokens) - seq_len, (batch_size,), generator=generator)
    x = torch.stack([tokens[start : start + seq_len] for start in starts])
    y = torch.stack([tokens[start + 1 : start + seq_len + 1] for start in starts])
    return x.to(device), y.to(device)


@dataclass(frozen=True)
class TinyCharTransformerConfig:
    vocab_size: int
    seq_len: int = 128
    d_model: int = 64
    nhead: int = 2
    d_ff: int = 256
    num_layers: int = 2
    dropout: float = 0.0


class TransformerBlock(nn.Module):
    def __init__(self, config: TinyCharTransformerConfig) -> None:
        super().__init__()
        self.ln1 = nn.LayerNorm(config.d_model)
        self.attn = nn.MultiheadAttention(
            config.d_model,
            config.nhead,
            dropout=config.dropout,
            batch_first=True,
        )
        self.ln2 = nn.LayerNorm(config.d_model)
        self.ff = nn.Sequential(
            nn.Linear(config.d_model, config.d_ff),
            nn.GELU(),
            nn.Linear(config.d_ff, config.d_model),
            nn.Dropout(config.dropout),
        )

    def forward(self, x: torch.Tensor, causal_mask: torch.Tensor) -> torch.Tensor:
        normalized = self.ln1(x)
        attended, _ = self.attn(
            normalized,
            normalized,
            normalized,
            attn_mask=causal_mask,
            need_weights=False,
        )
        x = x + attended
        return x + self.ff(self.ln2(x))


class CausalCharTransformerLM(nn.Module):
    """Small causal character transformer teacher/backbone."""

    def __init__(self, config: TinyCharTransformerConfig) -> None:
        super().__init__()
        self.config = config
        self.token_embedding = nn.Embedding(config.vocab_size, config.d_model)
        self.position_embedding = nn.Embedding(config.seq_len, config.d_model)
        self.blocks = nn.ModuleList(TransformerBlock(config) for _ in range(config.num_layers))
        self.ln_f = nn.LayerNorm(config.d_model)
        self.lm_head = nn.Linear(config.d_model, config.vocab_size)

    def forward_states(self, idx: torch.Tensor) -> tuple[torch.Tensor, ...]:
        """Return embedding state, every residual-block state, and logits."""

        batch, seq_len = idx.shape
        if seq_len > self.config.seq_len:
            raise ValueError(f"sequence length {seq_len} exceeds configured {self.config.seq_len}")
        positions = torch.arange(seq_len, device=idx.device)
        x = self.token_embedding(idx) + self.position_embedding(positions)[None, :, :]
        states = [x]
        causal_mask = torch.triu(
            torch.ones(seq_len, seq_len, dtype=torch.bool, device=idx.device), diagonal=1
        )
        for block in self.blocks:
            x = block(x, causal_mask)
            states.append(x)
        return (*states, self.lm_head(self.ln_f(x)))

    def forward(self, idx: torch.Tensor) -> torch.Tensor:
        return self.forward_states(idx)[-1]


class HDPCTinyShakespeareStudent(nn.Module):
    """Transformer student with an identity-initialized predictive-coding crown."""

    def __init__(self, config: TinyCharTransformerConfig, crown_hidden_width: int | None = None) -> None:
        super().__init__()
        self.backbone = CausalCharTransformerLM(config)
        self.crown = IdentityPCCrown(config.vocab_size, crown_hidden_width or config.vocab_size)

    def forward(self, idx: torch.Tensor, *, detached_crown: bool = True) -> torch.Tensor:
        logits = self.backbone(idx)
        crown_input = logits.detach() if detached_crown else logits
        return logits + self.crown.correction(crown_input)


def count_parameters(model: nn.Module) -> int:
    return sum(parameter.numel() for parameter in model.parameters())


def cross_entropy_for_logits(logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
    return F.cross_entropy(logits.reshape(-1, logits.size(-1)), targets.reshape(-1))


def kd_loss(
    student_logits: torch.Tensor,
    teacher_logits: torch.Tensor,
    *,
    temperature: float,
) -> torch.Tensor:
    if temperature <= 0:
        raise ValueError("temperature must be positive")
    teacher_probs = F.softmax(teacher_logits.detach() / temperature, dim=-1)
    student_log_probs = F.log_softmax(student_logits / temperature, dim=-1)
    return F.kl_div(student_log_probs, teacher_probs, reduction="batchmean") * (temperature**2)


@dataclass(frozen=True)
class GradientDiagnostic:
    name: str
    bp_norm: float
    pc_norm: float
    cosine: float | None
    shape: tuple[int, ...]


@dataclass(frozen=True)
class HDPCDiagnostics:
    gradients: tuple[GradientDiagnostic, ...]
    energy_profile: tuple[float, ...]
    update_sparsity_histogram: tuple[int, int, int, int]
    teacher_perplexity: float
    student_perplexity: float
    perplexity_delta: float


def _named_grads(model: nn.Module, loss: torch.Tensor) -> dict[str, torch.Tensor]:
    parameters = [(name, parameter) for name, parameter in model.named_parameters() if parameter.requires_grad]
    grads = torch.autograd.grad(
        loss,
        [parameter for _, parameter in parameters],
        retain_graph=True,
        allow_unused=True,
    )
    return {
        name: torch.zeros_like(parameter) if grad is None else grad.detach()
        for (name, parameter), grad in zip(parameters, grads)
    }


def compare_bp_and_pc_gradients(
    model: nn.Module,
    bp_loss: torch.Tensor,
    pc_loss: torch.Tensor,
) -> tuple[GradientDiagnostic, ...]:
    bp_grads = _named_grads(model, bp_loss)
    pc_grads = _named_grads(model, pc_loss)
    diagnostics: list[GradientDiagnostic] = []
    for name in bp_grads:
        bp = bp_grads[name].reshape(-1)
        pc = pc_grads[name].reshape(-1)
        bp_norm = float(bp.norm().detach())
        pc_norm = float(pc.norm().detach())
        cosine = None
        if bp_norm > 0 and pc_norm > 0:
            cosine = float(F.cosine_similarity(bp, pc, dim=0).detach())
        diagnostics.append(
            GradientDiagnostic(name, bp_norm, pc_norm, cosine, tuple(bp_grads[name].shape))
        )
    return tuple(diagnostics)


def update_sparsity_histogram(before: nn.Module, after: nn.Module) -> tuple[int, int, int, int]:
    """Histogram parameter updates into zero, tiny, small, and large buckets."""

    diffs = []
    for before_parameter, after_parameter in zip(before.parameters(), after.parameters()):
        diffs.append((after_parameter.detach() - before_parameter.detach()).abs().reshape(-1).cpu())
    if not diffs:
        return (0, 0, 0, 0)
    values = torch.cat(diffs)
    return (
        int((values == 0).sum()),
        int(((values > 0) & (values < 1e-7)).sum()),
        int(((values >= 1e-7) & (values < 1e-4)).sum()),
        int((values >= 1e-4).sum()),
    )


@torch.no_grad()
def estimate_perplexity(
    model: nn.Module,
    tokens: torch.Tensor,
    *,
    seq_len: int,
    batch_size: int,
    device: torch.device | str,
    steps: int = 8,
) -> float:
    model.eval()
    losses = []
    for _ in range(steps):
        x, y = get_batch(tokens, batch_size=batch_size, seq_len=seq_len, device=device)
        logits = model(x)
        losses.append(float(cross_entropy_for_logits(logits, y).detach()))
    model.train()
    return float(torch.exp(torch.tensor(losses).mean()))


@dataclass
class HDPCTrainingConfig:
    data_dir: Path = Path("data/tinyshakespeare")
    device: str = "cpu"
    epochs: int = 1
    seq_len: int = 128
    d_model: int = 64
    nhead: int = 2
    d_ff: int = 256
    num_layers: int = 2
    batch_size: int = 32
    learning_rate: float = 3e-4
    lambda_kd: float = 0.05
    temperatures: tuple[float, ...] = (1.0, 2.0, 4.0, 8.0)
    steps_per_epoch: int = 20
    eval_batches: int = 8
    seed: int = 1234
    download: bool = True
    artifact_dir: Path = Path("results/hdpc_tinyshakespeare")
    detached_crown: bool = True


@dataclass(frozen=True)
class HDPCTrainingResult:
    config: HDPCTrainingConfig
    model_config: TinyCharTransformerConfig
    teacher_parameters: int
    student_parameters: int
    diagnostics: HDPCDiagnostics
    artifact_path: Path
    source_path: Path


def run_homotopy_kd_training(config: HDPCTrainingConfig) -> HDPCTrainingResult:
    torch.manual_seed(config.seed)
    device = torch.device(config.device)
    dataset = prepare_tinyshakespeare_data(config.data_dir, download=config.download)
    model_config = TinyCharTransformerConfig(
        vocab_size=dataset.vocab_size,
        seq_len=config.seq_len,
        d_model=config.d_model,
        nhead=config.nhead,
        d_ff=config.d_ff,
        num_layers=config.num_layers,
    )
    teacher = CausalCharTransformerLM(model_config).to(device)
    student = HDPCTinyShakespeareStudent(model_config).to(device)
    student.backbone.load_state_dict(teacher.state_dict())

    teacher_optimizer = torch.optim.AdamW(teacher.parameters(), lr=config.learning_rate)
    student_optimizer = torch.optim.AdamW(student.parameters(), lr=config.learning_rate)
    generator = torch.Generator().manual_seed(config.seed)
    energy_profile: list[float] = []

    for _ in range(config.epochs):
        for temperature in config.temperatures:
            for _ in range(config.steps_per_epoch):
                x, y = get_batch(
                    dataset.train,
                    batch_size=config.batch_size,
                    seq_len=config.seq_len,
                    device=device,
                    generator=generator,
                )
                teacher_optimizer.zero_grad(set_to_none=True)
                teacher_logits = teacher(x)
                teacher_loss = cross_entropy_for_logits(teacher_logits, y)
                teacher_loss.backward()
                teacher_optimizer.step()

                student_optimizer.zero_grad(set_to_none=True)
                with torch.no_grad():
                    anchor = teacher(x).detach()
                student_logits = student(x, detached_crown=config.detached_crown)
                ce = cross_entropy_for_logits(student_logits, y)
                distill = kd_loss(student_logits, anchor, temperature=temperature)
                loss = (1.0 - config.lambda_kd) * ce + config.lambda_kd * distill
                loss.backward()
                student_optimizer.step()
                energy_profile.append(float(loss.detach()))

    # Capture diagnostics on one held-out batch with a detached KD anchor.
    x_val, y_val = get_batch(
        dataset.val,
        batch_size=min(config.batch_size, 16),
        seq_len=config.seq_len,
        device=device,
        generator=generator,
    )
    with torch.no_grad():
        anchor = teacher(x_val).detach()
    logits = student(x_val, detached_crown=config.detached_crown)
    bp_loss = cross_entropy_for_logits(logits, y_val)
    pc_loss = kd_loss(logits, anchor, temperature=config.temperatures[-1])
    gradients = compare_bp_and_pc_gradients(student, bp_loss, pc_loss)

    # One diagnostic update on a clone-free before/after parameter snapshot.
    before_tensors = [parameter.detach().clone() for parameter in student.parameters()]
    student_optimizer.zero_grad(set_to_none=True)
    ((1.0 - config.lambda_kd) * bp_loss + config.lambda_kd * pc_loss).backward()
    student_optimizer.step()
    after_proxy = nn.ModuleList([])
    # Reuse a tiny proxy object interface for histogram construction.
    class _Before(nn.Module):
        def __init__(self, tensors: list[torch.Tensor]) -> None:
            super().__init__()
            self.params = nn.ParameterList([nn.Parameter(tensor, requires_grad=False) for tensor in tensors])

    update_histogram = update_sparsity_histogram(_Before(before_tensors), student)
    del after_proxy

    teacher_ppl = estimate_perplexity(
        teacher,
        dataset.val,
        seq_len=config.seq_len,
        batch_size=min(config.batch_size, 16),
        device=device,
        steps=config.eval_batches,
    )
    student_ppl = estimate_perplexity(
        student,
        dataset.val,
        seq_len=config.seq_len,
        batch_size=min(config.batch_size, 16),
        device=device,
        steps=config.eval_batches,
    )

    diagnostics = HDPCDiagnostics(
        gradients=gradients,
        energy_profile=tuple(energy_profile),
        update_sparsity_histogram=update_histogram,
        teacher_perplexity=teacher_ppl,
        student_perplexity=student_ppl,
        perplexity_delta=student_ppl - teacher_ppl,
    )
    config.artifact_dir.mkdir(parents=True, exist_ok=True)
    artifact_path = config.artifact_dir / "hdpc_tinyshakespeare_smoke.pt"
    torch.save(
        {
            "model_config": model_config,
            "student_state_dict": student.state_dict(),
            "teacher_state_dict": teacher.state_dict(),
            "diagnostics": diagnostics,
        },
        artifact_path,
    )
    return HDPCTrainingResult(
        config=config,
        model_config=model_config,
        teacher_parameters=count_parameters(teacher),
        student_parameters=count_parameters(student),
        diagnostics=diagnostics,
        artifact_path=artifact_path,
        source_path=dataset.source_path,
    )
