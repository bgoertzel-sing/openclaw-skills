from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from .reports import EstimatorRunReport, ReportValidationError, require_finite_sample_wording


@dataclass(frozen=True)
class GateResult:
    gate_name: str
    passed: bool
    reason: str
    details: dict[str, Any] = field(default_factory=dict)

    @property
    def name(self) -> str:
        return self.gate_name


def _result(name: str, passed: bool, reason: str = "pass", **details: Any) -> GateResult:
    return GateResult(name, passed, reason, details)


def gate_sampler_correctness(result: EstimatorRunReport) -> GateResult:
    d = result.sampler_diagnostics
    details = {"ess": d.effective_sample_size, "rhat": d.r_hat, "cv": d.monte_carlo_cv, "chains": d.chains, "temperature_formula": d.wbic_temperature_formula}
    try:
        d.validate()
    except ReportValidationError as exc:
        return _result("sampler_correctness", False, str(exc), **details)
    return _result("sampler_correctness", True, **details)


def gate_analytic_calibration(result: EstimatorRunReport) -> GateResult:
    details = {"status": result.calibration.status, "benchmarks": list(result.calibration.benchmarks)}
    try:
        result.calibration.validate()
    except ReportValidationError as exc:
        return _result("analytic_calibration", False, str(exc), **details)
    return _result("analytic_calibration", True, **details)


def gate_sample_size_scaling(result: EstimatorRunReport) -> GateResult:
    s = result.sample_size_sensitivity
    details = {"slope_fit": s.slope_fit, "stable_sign": s.stable_sign, "stable_margin": s.stable_margin}
    try:
        s.validate()
    except ReportValidationError as exc:
        return _result("sample_size_scaling", False, str(exc), **details)
    return _result("sample_size_scaling", True, **details)


def gate_gauge_stability(result: EstimatorRunReport) -> GateResult:
    policies = [b.gauge_policy for b in result.parameter_blocks]
    details = {"gauge_policies": policies}
    if not policies or any(not policy.strip() for policy in policies):
        return _result("gauge_stability", False, "gauge policy ID must be non-empty", **details)
    return _result("gauge_stability", True, **details)


def gate_interaction_sanity(result: EstimatorRunReport) -> GateResult:
    details = {"module_vs_joint_report": result.module_vs_joint_report, "interaction_null_report": result.interaction_null_report}
    if not result.module_vs_joint_report.strip() or not result.interaction_null_report.strip():
        return _result("interaction_sanity", False, "interaction reports must exist", **details)
    if not result.lambda_estimates:
        return _result("interaction_sanity", False, "interaction reports require lambda estimates", **details)
    return _result("interaction_sanity", True, **details)


def gate_null_normalization(result: EstimatorRunReport) -> GateResult:
    details = {"decision": result.decision, "margins": [e.null_normalized_margin for e in result.lambda_estimates]}
    if result.decision != "allow_releap_evidence":
        return _result("null_normalization", True, "not promoted; null-normalized CI exclusion not required", **details)
    for estimate in result.lambda_estimates:
        ci = getattr(estimate, "null_normalized_ci", None)
        if ci is None:
            ci = (estimate.null_normalized_margin - 1.96 * estimate.standard_error, estimate.null_normalized_margin + 1.96 * estimate.standard_error)
        if len(ci) != 2 or ci[0] <= 0 <= ci[1]:
            return _result("null_normalization", False, "null-normalized margin CI must exclude zero for promoted estimates", target=estimate.target, ci=ci, **details)
    return _result("null_normalization", True, **details)


def gate_finite_sample_wording(result: EstimatorRunReport) -> GateResult:
    details = {"estimator_type": result.estimator_type, "finite_sample_wording": result.finite_sample_wording}
    if "finite_sample" not in result.estimator_type:
        return _result("finite_sample_wording", False, "estimator_kind must contain finite_sample and not_exact_rlct", **details)
    try:
        require_finite_sample_wording(result.finite_sample_wording)
    except ReportValidationError as exc:
        return _result("finite_sample_wording", False, str(exc), **details)
    return _result("finite_sample_wording", True, **details)


def gate_negative_lambda(result: EstimatorRunReport) -> GateResult:
    details = {"lambda_values": [e.lambda_hat for e in result.lambda_estimates], "clipped": result.metadata.get("lambda_clipped", False)}
    if details["clipped"]:
        return _result("negative_lambda", False, "lambda values must never be clipped", **details)
    for estimate in result.lambda_estimates:
        try:
            estimate.validate()
        except ReportValidationError as exc:
            return _result("negative_lambda", False, str(exc), **details)
    return _result("negative_lambda", True, **details)


def gate_releap_promotion(report: EstimatorRunReport) -> GateResult:
    components = [
        gate_sampler_correctness(report), gate_analytic_calibration(report), gate_sample_size_scaling(report),
        gate_gauge_stability(report), gate_interaction_sanity(report), gate_null_normalization(report),
        gate_finite_sample_wording(report), gate_negative_lambda(report),
    ]
    failed = [g.gate_name for g in components if not g.passed]
    details = {"component_gates_failed": failed, "scientific_decision_usable": report.scientific_decision_usable}
    if failed:
        return _result("releap_promotion", False, "one or more mandatory CI gates failed", **details)
    if not report.scientific_decision_usable:
        return _result("releap_promotion", False, "scientific_decision_usable is False", **details)
    return _result("releap_promotion", True, **details)


_GATE_FUNCTIONS: list[Callable[[EstimatorRunReport], GateResult]] = [
    gate_sampler_correctness, gate_analytic_calibration, gate_sample_size_scaling,
    gate_gauge_stability, gate_interaction_sanity, gate_null_normalization,
    gate_finite_sample_wording, gate_negative_lambda, gate_releap_promotion,
]


def evaluate_ci_gates(report: EstimatorRunReport) -> list[GateResult]:
    gates: list[GateResult] = []
    try:
        report.validate_complete_schema()
    except ReportValidationError as exc:
        gates.append(_result("complete_schema", False, str(exc)))
    else:
        gates.append(_result("complete_schema", True))
    gates.extend(func(report) for func in _GATE_FUNCTIONS)
    return gates


def assert_ci_gates(report: EstimatorRunReport) -> None:
    failures = [gate for gate in evaluate_ci_gates(report) if not gate.passed]
    if failures:
        detail = "; ".join(f"{gate.gate_name}: {gate.reason}" for gate in failures)
        raise ReportValidationError(f"SLT estimator CI gates failed: {detail}")
