from __future__ import annotations
from dataclasses import dataclass
import torch
from .arms import ArmDependencyContract

@dataclass(frozen=True)
class NullSpec:
    name: str
    perturbs: tuple[str, ...]
    applicable: bool = True

def dependency_aware_null_specs(contract: ArmDependencyContract) -> list[NullSpec]:
    specs: list[NullSpec] = []
    if contract.uses_targets: specs.append(NullSpec("target_shuffle", ("targets",)))
    if contract.uses_teacher_residuals: specs.append(NullSpec("teacher_residual_shuffle", ("teacher_residuals",)))
    if contract.uses_hidden: specs += [NullSpec("hidden_shuffle", ("hidden",)), NullSpec("hidden_residual_misalignment", ("hidden", "teacher_residuals"))]
    if contract.uses_context: specs.append(NullSpec("context_shuffle", ("context",)))
    if contract.uses_router_support: specs += [NullSpec("router_support_shuffle", ("router_support",)), NullSpec("support_frequency_matched_random", ("router_support",))]
    if contract.uses_gradients: specs += [NullSpec("gradient_shuffle", ("gradients",)), NullSpec("gradient_sign_flip", ("gradients",))]
    if contract.uses_fisher_metric: specs.append(NullSpec("fisher_metric_shuffle", ("fisher_metric",)))
    if contract.uses_token_position: specs += [NullSpec("position_shuffle", ("token_position",)), NullSpec("token_identity_shuffle", ("token_position",))]
    specs += [NullSpec("mechanism_preserving_control", tuple()), NullSpec("mechanism_violating_control", ("mechanism",))]
    return specs

def assert_null_adequacy(contract: ArmDependencyContract, specs: list[NullSpec]) -> None:
    required = []
    for field, channel in [
        ("uses_hidden", "hidden"), ("uses_context", "context"), ("uses_targets", "targets"),
        ("uses_teacher_residuals", "teacher_residuals"), ("uses_base_logits", "base_logits"),
        ("uses_gradients", "gradients"), ("uses_fisher_metric", "fisher_metric"),
        ("uses_router_support", "router_support"), ("uses_token_position", "token_position"),
    ]:
        if getattr(contract, field): required.append(channel)
    covered = {c for s in specs if s.applicable for c in s.perturbs}
    missing = [c for c in required if c not in covered]
    if missing:
        raise AssertionError(f"No destructive null for channels: {missing}")

def shuffle_tensor(x: torch.Tensor, seed: int) -> torch.Tensor:
    gen = torch.Generator(device=x.device).manual_seed(seed)
    return x[torch.randperm(x.shape[0], generator=gen, device=x.device)]
