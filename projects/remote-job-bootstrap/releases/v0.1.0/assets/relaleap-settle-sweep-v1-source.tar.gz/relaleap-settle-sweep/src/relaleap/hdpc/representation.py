"""Representation diagnostics with explicit centering and cross-checks."""

from __future__ import annotations

import math

import torch


def _matrix(features: torch.Tensor) -> torch.Tensor:
    # Float64 matters for the observed nearly rank-one ePC states: their Gram
    # matrices can otherwise lose enough precision for the two equivalent CKA
    # formulations to disagree materially.
    matrix = features.detach().double().reshape(-1, features.shape[-1])
    if matrix.shape[0] < 2:
        raise ValueError("representation diagnostics require at least two samples")
    if not torch.isfinite(matrix).all():
        raise ValueError("features must be finite")
    return matrix


def center_features(features: torch.Tensor) -> torch.Tensor:
    matrix = _matrix(features)
    return matrix - matrix.mean(dim=0, keepdim=True)


def linear_cka_feature(x: torch.Tensor, y: torch.Tensor) -> float:
    """Standard biased linear CKA computed in feature space."""

    x_centered = center_features(x)
    y_centered = center_features(y)
    if x_centered.shape[0] != y_centered.shape[0]:
        raise ValueError("CKA inputs must contain identical sample counts")
    cross = x_centered.T @ y_centered
    x_cov = x_centered.T @ x_centered
    y_cov = y_centered.T @ y_centered
    denominator = torch.linalg.norm(x_cov) * torch.linalg.norm(y_cov)
    if float(denominator) == 0.0:
        raise ValueError("CKA is undefined for a constant representation")
    return float(cross.square().sum() / denominator)


def _center_gram(gram: torch.Tensor) -> torch.Tensor:
    return (
        gram
        - gram.mean(dim=0, keepdim=True)
        - gram.mean(dim=1, keepdim=True)
        + gram.mean()
    )


def linear_cka_gram(x: torch.Tensor, y: torch.Tensor) -> float:
    """The same biased linear CKA computed from centered Gram matrices."""

    x_matrix = _matrix(x)
    y_matrix = _matrix(y)
    if x_matrix.shape[0] != y_matrix.shape[0]:
        raise ValueError("CKA inputs must contain identical sample counts")
    x_gram = _center_gram(x_matrix @ x_matrix.T)
    y_gram = _center_gram(y_matrix @ y_matrix.T)
    denominator = torch.linalg.norm(x_gram) * torch.linalg.norm(y_gram)
    if float(denominator) == 0.0:
        raise ValueError("CKA is undefined for a constant representation")
    return float((x_gram * y_gram).sum() / denominator)


def centered_rank_summary(features: torch.Tensor) -> dict[str, float]:
    """Entropy effective rank and participation ratio after feature centering."""

    singular_values = torch.linalg.svdvals(center_features(features))
    power = singular_values.square()
    total = power.sum()
    if float(total) == 0.0:
        return {"entropy_effective_rank": 0.0, "participation_ratio": 0.0}
    probabilities = power / total
    positive = probabilities[probabilities > 0]
    entropy_rank = torch.exp(-(positive * positive.log()).sum())
    participation = total.square() / power.square().sum()
    if not math.isfinite(float(entropy_rank)) or not math.isfinite(float(participation)):
        raise RuntimeError("non-finite centered rank diagnostic")
    return {
        "entropy_effective_rank": float(entropy_rank),
        "participation_ratio": float(participation),
    }
