"""Block-state predictive-coding distillation for the Tiny Shakespeare gate.

The implementation deliberately exposes the activity-energy trajectory.  A
single inference state (``steps=1``) is the ordinary KD/backprop endpoint.  At
larger depths, residual-block activities are relaxed and detached before the
same local prediction energy is differentiated with respect to weights.
"""
from __future__ import annotations

from dataclasses import dataclass

import torch

from .tinyshakespeare import CausalCharTransformerLM, kd_loss


@dataclass(frozen=True)
class TransformerEPCTrace:
    energy_history: tuple[float, ...]
    steps: int
    temperature: float
    accepted_step_sizes: tuple[float, ...] = ()
    backtrack_counts: tuple[int, ...] = ()

    @property
    def monotone(self) -> bool:
        return all(
            after <= before + 1e-9 * max(1.0, abs(before))
            for before, after in zip(self.energy_history, self.energy_history[1:])
        )


def _causal_mask(length: int, device: torch.device) -> torch.Tensor:
    return torch.triu(torch.ones(length, length, dtype=torch.bool, device=device), diagonal=1)


def _local_energy(
    model: CausalCharTransformerLM,
    input_state: torch.Tensor,
    hidden_states: tuple[torch.Tensor, ...],
    teacher_logits: torch.Tensor,
    *,
    temperature: float,
    output_weight: float = 1.0,
) -> torch.Tensor:
    if len(hidden_states) != len(model.blocks):
        raise ValueError("one hidden state is required per transformer block")
    mask = _causal_mask(input_state.shape[1], input_state.device)
    energy = input_state.new_zeros(())
    previous = input_state
    for block, observed in zip(model.blocks, hidden_states):
        prediction = block(previous, mask)
        # Match KD's ``batchmean`` convention: sum each sequence/feature error
        # and average only over the batch.  A full elementwise mean suppresses
        # local block credit by seq_len*d_model relative to the output KL.
        local_error = observed - prediction
        energy = energy + 0.5 * local_error.square().flatten(1).sum(dim=1).mean()
        previous = observed
    logits = model.lm_head(model.ln_f(previous))
    return energy + output_weight * kd_loss(logits, teacher_logits, temperature=temperature)


def transformer_epc_objective(
    model: CausalCharTransformerLM,
    tokens: torch.Tensor,
    teacher_logits: torch.Tensor,
    *,
    steps: int,
    temperature: float,
    relaxation_lr: float = 0.2,
    max_backtracks: int = 12,
    output_weight: float = 1.0,
) -> tuple[torch.Tensor, TransformerEPCTrace]:
    """Return the KD endpoint or a relaxed local ePC weight objective.

    Teacher logits are always detached.  ``steps`` counts the initial
    feed-forward state, so depth one is exactly ordinary KD and uses its full
    autograd graph.  Larger depths perform monotone backtracked activity
    inference before constructing a local weight objective on detached states.
    """

    if steps < 1:
        raise ValueError("steps must be at least one")
    if temperature <= 0:
        raise ValueError("temperature must be positive")
    if relaxation_lr <= 0:
        raise ValueError("relaxation_lr must be positive")
    if max_backtracks < 0:
        raise ValueError("max_backtracks must be non-negative")
    if output_weight <= 0:
        raise ValueError("output_weight must be positive")

    target = teacher_logits.detach()
    feedforward = model.forward_states(tokens)
    endpoint = kd_loss(feedforward[-1], target, temperature=temperature)
    if steps == 1:
        value = float(endpoint.detach())
        return endpoint, TransformerEPCTrace((value,), steps, float(temperature))

    input_state = feedforward[0].detach()
    hidden = tuple(state.detach().requires_grad_(True) for state in feedforward[1:-1])
    history: list[float] = []
    accepted_step_sizes: list[float] = []
    backtrack_counts: list[int] = []

    for inference_step in range(steps):
        energy = _local_energy(
            model, input_state, hidden, target, temperature=temperature,
            output_weight=output_weight,
        )
        old_value = float(energy.detach())
        history.append(old_value)
        if inference_step == steps - 1:
            break
        gradients = torch.autograd.grad(energy, hidden)
        step_size = float(relaxation_lr)
        accepted: tuple[torch.Tensor, ...] | None = None
        accepted_value = old_value
        with torch.no_grad():
            accepted_backtracks = max_backtracks + 1
            for backtracks in range(max_backtracks + 1):
                proposal = tuple(
                    state - step_size * gradient
                    for state, gradient in zip(hidden, gradients)
                )
                proposal_value = float(
                    _local_energy(
                        model,
                        input_state,
                        proposal,
                        target,
                        temperature=temperature,
                        output_weight=output_weight,
                    )
                )
                tolerance = 1e-9 * max(1.0, abs(old_value))
                if proposal_value <= old_value + tolerance:
                    accepted = proposal
                    accepted_value = proposal_value
                    accepted_backtracks = backtracks
                    break
                step_size *= 0.5
        if accepted is None:
            accepted = tuple(state.detach() for state in hidden)
            step_size = 0.0
        accepted_step_sizes.append(step_size)
        backtrack_counts.append(accepted_backtracks)
        hidden = tuple(state.detach().requires_grad_(True) for state in accepted)
        # The next loop recomputes this value; retaining it here makes failures
        # to accept a decreasing step visible in the trace comparison.
        if accepted_value > old_value + 1e-9 * max(1.0, abs(old_value)):
            raise RuntimeError("ePC activity inference increased declared energy")

    local_states = tuple(state.detach() for state in hidden)
    objective = _local_energy(
        model, input_state, local_states, target, temperature=temperature,
        output_weight=output_weight,
    )
    trace = TransformerEPCTrace(
        tuple(history), steps, float(temperature),
        tuple(accepted_step_sizes), tuple(backtrack_counts),
    )
    if not trace.monotone:
        raise RuntimeError("ePC energy trace is not monotone")
    return objective, trace
