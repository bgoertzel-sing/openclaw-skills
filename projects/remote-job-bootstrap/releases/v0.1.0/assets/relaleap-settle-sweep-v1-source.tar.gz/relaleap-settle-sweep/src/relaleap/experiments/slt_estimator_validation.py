from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from relaleap.slt import MockCalibrationBenchmark, SLTValidationReport, make_mock_estimator_output
from relaleap.slt.parameter_blocks import ParameterBlockReport as InterfaceParameterBlockReport


def build_mock_validation_report(run_id: str | None = None) -> SLTValidationReport:
    """Create a diagnostic-only report proving that shared schemas serialize.

    This is intentionally not a calibrated estimator run.  It marks RelaLeap SLT
    evidence unusable for scientific decisions until the mandatory gates pass.
    """

    benchmark = MockCalibrationBenchmark()
    data = benchmark.make_data(n=128, seed=7)
    model = benchmark.make_energy_model(data, cfg={})
    block = model.parameter_blocks()[0]
    mock = make_mock_estimator_output(benchmark.benchmark_id, block.name)
    block_report = InterfaceParameterBlockReport(
        block=block,
        theta_hat_status="local_map_pass",
        gauge_policy_id="mock_identity",
        prior_family="mock_unit_gaussian",
        prior_scale=1.0,
        n_parameters_sampled=block.size,
        live_parameter_fraction=1.0,
        notes="diagnostic-only mock block",
    )
    return SLTValidationReport(
        run_id=run_id or datetime.now(timezone.utc).strftime("mock-%Y%m%dT%H%M%SZ"),
        estimator_results=[mock.result],
        parameter_blocks=[block_report],
        compatibility_matrix=[
            {
                "benchmark_id": benchmark.benchmark_id,
                "estimator_kind": mock.result.estimator_kind,
                "prior_family": mock.result.prior_family,
                "gauge_policy_id": mock.result.gauge_policy_id,
                "status": "diagnostic_only",
            }
        ],
        mandatory_gates_passed=False,
        scientific_decision_usable=False,
        reason="Wave 0 interface freeze only; mandatory SLT validation gates have not passed.",
    )


def write_report(out_dir: str | Path, report: SLTValidationReport) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / "manifest.json").write_text(json.dumps(report.to_dict(), indent=2, sort_keys=True), encoding="utf-8")
    lines = [
        "# SLT Estimator Validation Mock Report",
        "",
        f"- run_id: {report.run_id}",
        f"- mandatory_gates_passed: {report.mandatory_gates_passed}",
        f"- scientific_decision_usable: {report.scientific_decision_usable}",
        f"- reason: {report.reason}",
        "",
        "This Wave 0 smoke artifact validates shared schema plumbing only; it is not calibrated SLT evidence.",
    ]
    (out / "report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    report = build_mock_validation_report(run_id="wave0-mock")
    write_report(Path("results") / "slt_estimator_validation" / report.run_id, report)


if __name__ == "__main__":
    main()
