from __future__ import annotations

from dataclasses import asdict, dataclass
from math import isfinite
from typing import Sequence

import torch


@dataclass(frozen=True)
class NullReport:
    null_type: str
    null_estimates: list[float]
    real_estimate: float
    difference: float
    bootstrap_ci: tuple[float, float]
    p_value: float
    margin_excludes_zero: bool

    def validate(self) -> None:
        if not self.null_type:
            raise ValueError("null_type must be non-empty")
        if not self.null_estimates:
            raise ValueError("null_estimates must be non-empty")
        for name, value in {
            "real_estimate": self.real_estimate,
            "difference": self.difference,
            "bootstrap_ci[0]": self.bootstrap_ci[0],
            "bootstrap_ci[1]": self.bootstrap_ci[1],
            "p_value": self.p_value,
        }.items():
            if not isfinite(float(value)):
                raise ValueError(f"{name} must be finite")
        if len(self.bootstrap_ci) != 2 or self.bootstrap_ci[0] > self.bootstrap_ci[1]:
            raise ValueError("bootstrap_ci must be an ordered pair")
        if not 0.0 <= self.p_value <= 1.0:
            raise ValueError("p_value must be in [0, 1]")
        if self.null_type == "mechanism_preserving" and not self.margin_excludes_zero:
            raise ValueError("mechanism-preserving control should retain a non-zero margin")
        # For mechanism_violating, a non-excluding margin is expected and valid.

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def bootstrap_ci(estimates: Sequence[float] | torch.Tensor, n_bootstrap: int = 200, ci: float = 0.95, seed: int = 0) -> tuple[float, float]:
    """Percentile bootstrap CI for the mean of ``estimates``."""

    if n_bootstrap < 1:
        raise ValueError("n_bootstrap must be positive")
    if not 0.0 < ci < 1.0:
        raise ValueError("ci must be in (0, 1)")
    values = torch.as_tensor(estimates, dtype=torch.float64)
    if values.ndim != 1 or values.numel() == 0:
        raise ValueError("estimates must be a non-empty 1D sequence")
    gen = torch.Generator(device=values.device).manual_seed(int(seed))
    n = values.numel()
    indices = torch.randint(0, n, (n_bootstrap, n), generator=gen, device=values.device)
    boot_means = values.index_select(0, indices.reshape(-1)).reshape(n_bootstrap, n).mean(dim=1)
    alpha = (1.0 - ci) / 2.0
    qs = torch.quantile(boot_means, torch.tensor([alpha, 1.0 - alpha], dtype=torch.float64, device=values.device))
    return float(qs[0].item()), float(qs[1].item())


def compare_to_null(
    null_type: str,
    null_estimates: Sequence[float] | torch.Tensor,
    real_estimate: float,
    *,
    n_bootstrap: int = 200,
    ci: float = 0.95,
    seed: int = 0,
) -> NullReport:
    """Build a deterministic two-sided null comparison report."""

    values = torch.as_tensor(null_estimates, dtype=torch.float64)
    if values.ndim != 1 or values.numel() == 0:
        raise ValueError("null_estimates must be a non-empty 1D sequence")
    null_mean = float(values.mean().item())
    difference = float(real_estimate) - null_mean
    centered = torch.abs(values - null_mean)
    p_value = float(((centered >= abs(difference)).sum().item() + 1.0) / (values.numel() + 1.0))
    interval = bootstrap_ci(values, n_bootstrap=n_bootstrap, ci=ci, seed=seed)
    diff_ci = (float(real_estimate) - interval[1], float(real_estimate) - interval[0])
    report = NullReport(
        null_type=null_type,
        null_estimates=[float(x) for x in values.tolist()],
        real_estimate=float(real_estimate),
        difference=difference,
        bootstrap_ci=diff_ci,
        p_value=p_value,
        margin_excludes_zero=diff_ci[0] > 0.0 or diff_ci[1] < 0.0,
    )
    report.validate()
    return report
