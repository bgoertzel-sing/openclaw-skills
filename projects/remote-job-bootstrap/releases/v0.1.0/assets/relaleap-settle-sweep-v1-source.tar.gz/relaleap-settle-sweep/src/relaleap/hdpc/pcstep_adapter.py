"""Replayable GPT-2 block-state ePC/AdamW engineering step.

This is a clean-room transformer generalization.  Mesto's public pcgraph code
anchors the phase ordering (settle with frozen weights, then update), but does
not specify transformer-local learning rules.  Consequently this adapter uses
the existing block-state ePC objective followed by ordinary gated autograd and
AdamW; it is not claimed to reproduce Mesto's unpublished GPT-2 implementation.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import hashlib
import io
from typing import Any, Mapping

import torch

from .gpt2_epc import gpt2_epc_objective


@dataclass(frozen=True)
class PCStepBatch:
    tokens: torch.Tensor
    teacher_logits: torch.Tensor
    cursor: int


@dataclass(frozen=True)
class PCStepSnapshot:
    model_state: dict[str, torch.Tensor]
    optimizer_state: dict[str, Any]
    cpu_rng_state: torch.Tensor
    cuda_rng_states: tuple[torch.Tensor, ...]
    outer_step: int
    batch_cursor: int


@dataclass(frozen=True)
class PCStepResult:
    snapshot: PCStepSnapshot
    objective: float
    energy_history: tuple[float, ...]
    settled_parameter_digest: str


def _tensor_digest(state: Mapping[str, torch.Tensor]) -> str:
    digest = hashlib.sha256()
    for name, value in sorted(state.items()):
        tensor = value.detach().cpu().contiguous()
        digest.update(name.encode("utf-8"))
        digest.update(str(tensor.dtype).encode("ascii"))
        digest.update(str(tuple(tensor.shape)).encode("ascii"))
        digest.update(tensor.numpy().tobytes())
    return digest.hexdigest()


def model_digest(model: Any) -> str:
    """Return a deterministic digest of all model parameters and buffers."""

    return _tensor_digest(model.state_dict())


def snapshot_bytes(snapshot: PCStepSnapshot) -> bytes:
    """Serialize one captured snapshot for byte-identical replay checks."""

    stream = io.BytesIO()
    torch.save(snapshot, stream)
    return stream.getvalue()


def capture_snapshot(
    model: Any,
    optimizer: torch.optim.Optimizer,
    *,
    outer_step: int,
    batch_cursor: int,
) -> PCStepSnapshot:
    if outer_step < 0 or batch_cursor < 0:
        raise ValueError("outer_step and batch_cursor must be non-negative")
    cuda_states = tuple(state.clone() for state in torch.cuda.get_rng_state_all())
    return PCStepSnapshot(
        model_state={name: value.detach().cpu().clone() for name, value in model.state_dict().items()},
        optimizer_state=deepcopy(optimizer.state_dict()),
        cpu_rng_state=torch.get_rng_state().clone(),
        cuda_rng_states=cuda_states,
        outer_step=outer_step,
        batch_cursor=batch_cursor,
    )


def restore_snapshot(
    model: Any,
    optimizer: torch.optim.Optimizer,
    snapshot: PCStepSnapshot,
) -> None:
    model.load_state_dict(snapshot.model_state, strict=True)
    optimizer.load_state_dict(deepcopy(snapshot.optimizer_state))
    torch.set_rng_state(snapshot.cpu_rng_state.clone())
    if snapshot.cuda_rng_states:
        if not torch.cuda.is_available():
            raise RuntimeError("snapshot contains CUDA RNG state but CUDA is unavailable")
        torch.cuda.set_rng_state_all([state.clone() for state in snapshot.cuda_rng_states])


def _validate_gate(model: Any, gate: Mapping[int, bool]) -> dict[int, bool]:
    expected = set(range(len(model.transformer.h)))
    if set(gate) != expected or any(type(value) is not bool for value in gate.values()):
        raise ValueError("gate must contain one exact boolean entry per GPT-2 block")
    return dict(gate)


def pc_step(
    model: Any,
    optimizer: torch.optim.Optimizer,
    batch: PCStepBatch,
    *,
    gate: Mapping[int, bool],
    steps: int,
    temperature: float,
    outer_step: int = 0,
    relaxation_lr: float = 0.2,
    max_backtracks: int = 12,
    output_weight: float = 0.05,
) -> PCStepResult:
    """Settle activities with frozen weights, then take one gated AdamW step."""

    if batch.cursor < 0 or outer_step < 0:
        raise ValueError("batch cursor and outer_step must be non-negative")
    if batch.tokens.ndim != 2 or batch.tokens.dtype not in (torch.int32, torch.int64):
        raise ValueError("tokens must be a rank-two integer tensor")
    if batch.teacher_logits.ndim != 3:
        raise ValueError("teacher_logits must be rank three")
    if batch.teacher_logits.shape[:2] != batch.tokens.shape:
        raise ValueError("teacher logits and tokens must share batch and sequence dimensions")
    checked_gate = _validate_gate(model, gate)

    optimizer.zero_grad(set_to_none=True)
    before = {name: value.detach().cpu().clone() for name, value in model.state_dict().items()}
    before_digest = _tensor_digest(before)
    objective, trace = gpt2_epc_objective(
        model,
        batch.tokens,
        batch.teacher_logits,
        steps=steps,
        temperature=temperature,
        relaxation_lr=relaxation_lr,
        max_backtracks=max_backtracks,
        output_weight=output_weight,
    )
    after_settle = {name: value.detach().cpu() for name, value in model.state_dict().items()}
    after_digest = _tensor_digest(after_settle)
    if before_digest != after_digest:
        raise AssertionError("model weights changed during activity settlement")

    objective.backward()
    for index, enabled in checked_gate.items():
        if not enabled:
            for parameter in model.transformer.h[index].parameters():
                parameter.grad = None
    if not any(
        parameter.grad is not None and torch.isfinite(parameter.grad).all()
        for parameter in model.parameters()
    ):
        raise RuntimeError("no finite parameter gradient survived the module gate")
    if any(
        parameter.grad is not None and not torch.isfinite(parameter.grad).all()
        for parameter in model.parameters()
    ):
        raise RuntimeError("non-finite parameter gradient")
    optimizer.step()
    snapshot = capture_snapshot(
        model,
        optimizer,
        outer_step=outer_step + 1,
        batch_cursor=batch.cursor + int(batch.tokens.shape[0]),
    )
    return PCStepResult(
        snapshot=snapshot,
        objective=float(objective.detach()),
        energy_history=tuple(trace.energy_history),
        settled_parameter_digest=after_digest,
    )
