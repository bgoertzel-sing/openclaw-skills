from __future__ import annotations
import argparse, json, os
from .synthetic import generate_all_regimes
from .reporting import fail_closed_placeholder
from .events import EventLog


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--seed", type=int, default=7)
    p.add_argument("--out", default="results/slice1_smoke")
    args = p.parse_args()
    os.makedirs(args.out, exist_ok=True)
    regimes = generate_all_regimes(seed=args.seed, n=64, d_model=12, c_dim=5, num_columns=4, support_size=2)
    manifest = {name: {"known_regime": data.metadata["known_regime"], "seed": data.metadata["seed"], "shape": list(data.hidden_states.shape)} for name, data in regimes.items()}
    with open(os.path.join(args.out, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, sort_keys=True)
    events = EventLog(); events.append("column_growth", 0, [], "smoke log initialized; no growth in slice1", {}, False, seed=args.seed)
    events.write_jsonl(os.path.join(args.out, "events.jsonl"))
    report = fail_closed_placeholder([f"python -m relaleap.run_slice1_smoke --seed {args.seed} --out {args.out}"], [args.seed], {"n": 64, "d_model": 12, "num_columns": 4})
    report.write(args.out)

if __name__ == "__main__":
    main()
