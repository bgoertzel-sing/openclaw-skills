from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Callable, Literal

import torch

from .energy import EnergyModel
from .priors import Prior

ThetaEnergyFn = Callable[[torch.Tensor], torch.Tensor]
MAPStatus = Literal["local_map_pass", "local_map_fail"]


@dataclass(frozen=True)
class MAPRefinementConfig:
    max_steps: int = 1000
    learning_rate: float = 1e-3
    grad_norm_tolerance: float = 1e-6
    material_decrease_atol: float = 1e-6
    material_decrease_rtol: float = 1e-4


@dataclass(frozen=True)
class MAPRefinementReport:
    theta_hat_status: MAPStatus
    grad_norm_at_theta_hat: float
    map_refinement_steps: int
    energy_before_refinement: float
    energy_after_refinement: float
    objective_before_refinement: float
    objective_after_refinement: float
    loss_decrease_after_refinement: float
    material_decrease_threshold: float
    prior_family: str
    prior_scale: float

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def _objective(total_energy_fn: ThetaEnergyFn, prior: Prior, theta: torch.Tensor) -> torch.Tensor:
    return total_energy_fn(theta) - prior.log_density(theta)


def _call_energy_model(energy_model: EnergyModel, theta: torch.Tensor) -> torch.Tensor:
    # The frozen interface requires data/batch arguments, but QuadraticEnergyModel
    # only uses data.shape[0].  A one-row placeholder keeps refinement focused on
    # theta with all other blocks frozen.
    data = torch.empty((1,), dtype=theta.dtype, device=theta.device)
    return energy_model.total_energy(theta, data)


def _line_search_gradient_descent(
    total_energy_fn: ThetaEnergyFn,
    prior: Prior,
    theta0: torch.Tensor,
    *,
    max_steps: int,
    lr: float,
    tol: float,
) -> tuple[torch.Tensor, int]:
    theta = theta0.detach().clone()
    steps = 0
    for _ in range(max_steps):
        energy_grad = torch.autograd.functional.jacobian(lambda x: total_energy_fn(x), theta).detach()
        prior_grad = prior.grad_log_density(theta).detach()
        objective_grad = energy_grad - prior_grad
        grad_norm = torch.linalg.vector_norm(objective_grad)
        if float(grad_norm.detach().cpu()) <= tol:
            break

        obj_before = _objective(total_energy_fn, prior, theta).detach()
        step_size = float(lr)
        accepted = False
        for _line_search_step in range(40):
            candidate = theta - step_size * objective_grad
            obj_after = _objective(total_energy_fn, prior, candidate).detach()
            if torch.isfinite(obj_after) and obj_after <= obj_before:
                theta = candidate.detach()
                accepted = True
                break
            step_size *= 0.5
        steps += 1
        if not accepted:
            break
    return theta, steps


def refine_map(
    energy_model: EnergyModel,
    prior: Prior,
    theta_init: torch.Tensor,
    max_steps: int = 1000,
    lr: float = 1e-3,
    tol: float = 1e-6,
) -> tuple[torch.Tensor, MAPRefinementReport]:
    """Refine theta_hat against total energy plus negative log prior.

    Only the provided tensor is updated; the energy model is treated as frozen.
    A material decrease in the MAP objective means the original theta_hat is not
    a valid local MAP reference for decision-grade SLT evidence.
    """

    return refine_map_reference(
        theta_init,
        lambda theta: _call_energy_model(energy_model, theta),
        prior,
        MAPRefinementConfig(max_steps=max_steps, learning_rate=lr, grad_norm_tolerance=tol),
    )


def refine_map_reference(
    theta_hat: torch.Tensor,
    total_energy_fn: ThetaEnergyFn,
    prior: Prior,
    config: MAPRefinementConfig | None = None,
) -> tuple[torch.Tensor, MAPRefinementReport]:
    """Deterministically refine a sampled block and gate local MAP validity."""

    cfg = config or MAPRefinementConfig()
    if cfg.max_steps < 0:
        raise ValueError("max_steps must be non-negative")
    if cfg.learning_rate <= 0:
        raise ValueError("learning_rate must be positive")
    if cfg.grad_norm_tolerance < 0:
        raise ValueError("grad_norm_tolerance must be non-negative")

    theta0 = theta_hat.detach().clone()
    energy_grad0 = torch.autograd.functional.jacobian(lambda x: total_energy_fn(x), theta0).detach()
    grad0 = energy_grad0 - prior.grad_log_density(theta0).detach()
    grad_norm0 = float(torch.linalg.vector_norm(grad0).detach().cpu())
    energy0 = float(total_energy_fn(theta0).detach().cpu())
    obj0_float = float(_objective(total_energy_fn, prior, theta0).detach().cpu())

    if cfg.max_steps > 0 and grad_norm0 > cfg.grad_norm_tolerance:
        refined, steps = _line_search_gradient_descent(
            total_energy_fn,
            prior,
            theta0,
            max_steps=cfg.max_steps,
            lr=cfg.learning_rate,
            tol=cfg.grad_norm_tolerance,
        )
    else:
        refined, steps = theta0, 0

    energy1 = float(total_energy_fn(refined).detach().cpu())
    obj1 = float(_objective(total_energy_fn, prior, refined).detach().cpu())
    decrease = obj0_float - obj1
    threshold = cfg.material_decrease_atol + cfg.material_decrease_rtol * max(1.0, abs(obj0_float))
    status: MAPStatus = "local_map_fail" if decrease > threshold else "local_map_pass"
    report = MAPRefinementReport(
        theta_hat_status=status,
        grad_norm_at_theta_hat=grad_norm0,
        map_refinement_steps=steps,
        energy_before_refinement=energy0,
        energy_after_refinement=energy1,
        objective_before_refinement=obj0_float,
        objective_after_refinement=obj1,
        loss_decrease_after_refinement=decrease,
        material_decrease_threshold=threshold,
        prior_family=prior.family_name,
        prior_scale=prior.scale,
    )
    return refined, report
