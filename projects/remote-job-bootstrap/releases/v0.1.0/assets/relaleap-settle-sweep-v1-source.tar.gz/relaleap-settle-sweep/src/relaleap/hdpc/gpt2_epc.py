"""Block-state ePC objective for Hugging Face GPT-2 students.

The adapter is intentionally narrow: it exposes GPT-2 residual-block states
without changing the model or depending on trainer internals.  This keeps the
activity-inference implementation shared across pilot arms while making model
shape and cache/dropout assumptions explicit and fail closed.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any

import torch

from .tinyshakespeare import kd_loss
from .transformer_epc import TransformerEPCTrace


@dataclass(frozen=True)
class GPT2ForwardStates:
    input_state: torch.Tensor
    hidden_states: tuple[torch.Tensor, ...]
    logits: torch.Tensor


class GPT2BlockStateAdapter:
    """Expose the residual stream and per-block prediction seam of GPT-2."""

    def __init__(self, model: Any) -> None:
        required = ("wte", "wpe", "drop", "h", "ln_f")
        transformer = getattr(model, "transformer", None)
        if transformer is None or any(not hasattr(transformer, name) for name in required):
            raise TypeError("model is not a compatible GPT2LMHeadModel")
        if not hasattr(model, "lm_head"):
            raise TypeError("GPT-2 model must expose lm_head")
        config = model.config
        if bool(getattr(config, "use_cache", False)):
            raise ValueError("GPT-2 ePC requires config.use_cache=False")
        dropout = (
            float(getattr(config, "resid_pdrop", 0.0)),
            float(getattr(config, "embd_pdrop", 0.0)),
            float(getattr(config, "attn_pdrop", 0.0)),
        )
        if any(value != 0.0 for value in dropout):
            raise ValueError("GPT-2 ePC requires all dropout probabilities to be zero")
        self.model = model

    @property
    def num_blocks(self) -> int:
        return len(self.model.transformer.h)

    def predict_block(self, index: int, previous: torch.Tensor) -> torch.Tensor:
        output = self.model.transformer.h[index](previous, use_cache=False)
        hidden = output[0] if isinstance(output, tuple) else output
        if hidden.shape != previous.shape:
            raise RuntimeError("GPT-2 block changed the residual-stream shape")
        return hidden

    def logits_from_state(self, state: torch.Tensor) -> torch.Tensor:
        return self.model.lm_head(self.model.transformer.ln_f(state))

    def forward_states(self, tokens: torch.Tensor) -> GPT2ForwardStates:
        if tokens.ndim != 2 or tokens.dtype not in (torch.int32, torch.int64):
            raise ValueError("tokens must be a rank-two integer tensor")
        batch, length = tokens.shape
        if length > int(self.model.config.n_positions):
            raise ValueError("token sequence exceeds GPT-2 positional capacity")
        positions = torch.arange(length, device=tokens.device, dtype=torch.long)
        positions = positions.unsqueeze(0).expand(batch, -1)
        initial = self.model.transformer.drop(
            self.model.transformer.wte(tokens) + self.model.transformer.wpe(positions)
        )
        hidden = initial
        states = []
        for index in range(self.num_blocks):
            hidden = self.predict_block(index, hidden)
            states.append(hidden)
        logits = self.logits_from_state(hidden)
        return GPT2ForwardStates(initial, tuple(states), logits)


def _local_energy(
    adapter: GPT2BlockStateAdapter,
    input_state: torch.Tensor,
    hidden_states: tuple[torch.Tensor, ...],
    teacher_logits: torch.Tensor,
    *,
    temperature: float,
    output_weight: float,
) -> torch.Tensor:
    if len(hidden_states) != adapter.num_blocks:
        raise ValueError("one hidden state is required per GPT-2 block")
    energy = input_state.new_zeros(())
    previous = input_state
    for index, observed in enumerate(hidden_states):
        prediction = adapter.predict_block(index, previous)
        error = observed - prediction
        energy = energy + 0.5 * error.square().flatten(1).sum(dim=1).mean()
        previous = observed
    logits = adapter.logits_from_state(previous)
    return energy + output_weight * kd_loss(logits, teacher_logits, temperature=temperature)


def gpt2_epc_objective(
    model: Any,
    tokens: torch.Tensor,
    teacher_logits: torch.Tensor,
    *,
    steps: int,
    temperature: float,
    relaxation_lr: float = 0.2,
    max_backtracks: int = 12,
    output_weight: float = 0.05,
) -> tuple[torch.Tensor, TransformerEPCTrace]:
    """Return the exact KD endpoint or relaxed GPT-2 local ePC objective."""

    if steps < 1 or temperature <= 0 or relaxation_lr <= 0:
        raise ValueError("steps, temperature, and relaxation_lr must be positive")
    if max_backtracks < 0 or output_weight <= 0:
        raise ValueError("max_backtracks must be non-negative and output_weight positive")
    adapter = GPT2BlockStateAdapter(model)
    target = teacher_logits.detach()
    feedforward = adapter.forward_states(tokens)
    endpoint = kd_loss(feedforward.logits, target, temperature=temperature)
    if steps == 1:
        return endpoint, TransformerEPCTrace((float(endpoint.detach()),), steps, float(temperature))

    hidden = tuple(state.detach().requires_grad_(True) for state in feedforward.hidden_states)
    history: list[float] = []
    accepted_steps: list[float] = []
    backtracks_used: list[int] = []
    for inference_step in range(steps):
        energy = _local_energy(
            adapter, feedforward.input_state.detach(), hidden, target,
            temperature=temperature, output_weight=output_weight,
        )
        old_value = float(energy.detach())
        if not math.isfinite(old_value):
            raise RuntimeError("GPT-2 ePC activity energy is non-finite")
        history.append(old_value)
        if inference_step == steps - 1:
            break
        gradients = torch.autograd.grad(energy, hidden)
        step_size = float(relaxation_lr)
        accepted = None
        accepted_backtracks = max_backtracks + 1
        with torch.no_grad():
            for backtracks in range(max_backtracks + 1):
                proposal = tuple(state - step_size * grad for state, grad in zip(hidden, gradients))
                proposal_value = float(_local_energy(
                    adapter, feedforward.input_state.detach(), proposal, target,
                    temperature=temperature, output_weight=output_weight,
                ))
                if not math.isfinite(proposal_value):
                    step_size *= 0.5
                    continue
                if proposal_value <= old_value + 1e-9 * max(1.0, abs(old_value)):
                    accepted = proposal
                    accepted_backtracks = backtracks
                    break
                step_size *= 0.5
        if accepted is None:
            accepted = tuple(state.detach() for state in hidden)
            step_size = 0.0
        accepted_steps.append(step_size)
        backtracks_used.append(accepted_backtracks)
        hidden = tuple(state.detach().requires_grad_(True) for state in accepted)

    objective = _local_energy(
        adapter, feedforward.input_state.detach(), tuple(state.detach() for state in hidden), target,
        temperature=temperature, output_weight=output_weight,
    )
    trace = TransformerEPCTrace(
        tuple(history), steps, float(temperature), tuple(accepted_steps), tuple(backtracks_used)
    )
    if not trace.monotone:
        raise RuntimeError("GPT-2 ePC activity inference increased energy")
    if not torch.isfinite(objective):
        raise RuntimeError("GPT-2 ePC objective is non-finite")
    return objective, trace
