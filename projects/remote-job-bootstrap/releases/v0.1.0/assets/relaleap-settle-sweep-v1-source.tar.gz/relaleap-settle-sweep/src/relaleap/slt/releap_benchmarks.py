from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Literal
import numpy as np
import torch

from relaleap.slt.releap_ground_truth import RelaLeapGroundTruth
from relaleap.synthetic import SyntheticRegimeData

RelaLeapBenchmarkName = Literal[
    "rank_one_atom_gauge",
    "dead_column",
    "shared_core",
    "mediator",
    "router_collapse",
    "low_rank_trap",
    "oblique_dictionary",
]


@dataclass(frozen=True)
class MockEstimatorOutput:
    """Minimal mock estimator panel used by fixture tests until samplers land."""

    winner: str
    I_lambda_signs: dict[str, str]
    diagnostics: dict[str, Any]


def _rng(seed: int) -> tuple[np.random.Generator, torch.Generator]:
    return np.random.default_rng(seed), torch.Generator().manual_seed(seed)


def _context(h: torch.Tensor, c_dim: int) -> torch.Tensor:
    ctx = torch.zeros(h.shape[0], c_dim, dtype=h.dtype)
    if c_dim:
        ctx[:, 0] = torch.sin(h[:, 0])
    if c_dim > 1:
        ctx[:, 1] = torch.cos(h[:, 1])
    if c_dim > 2:
        ctx[:, 2:] = h[:, : c_dim - 2]
    return ctx


def _unit(x: torch.Tensor, dim: int = -1) -> torch.Tensor:
    return torch.nn.functional.normalize(x, dim=dim)


def _basis(d_model: int, num_columns: int, gen: torch.Generator, *, oblique: bool = False) -> tuple[torch.Tensor, torch.Tensor]:
    a = torch.randn(num_columns, d_model, generator=gen)
    b = torch.randn(num_columns, d_model, generator=gen)
    if not oblique and num_columns <= d_model:
        qa, _ = torch.linalg.qr(a.T, mode="reduced")
        qb, _ = torch.linalg.qr(b.T, mode="reduced")
        a, b = qa.T[:num_columns], qb.T[:num_columns]
    else:
        shared = _unit(torch.randn(1, d_model, generator=gen))
        a = 0.72 * a + 0.28 * shared
        b = 0.68 * b + 0.32 * torch.roll(shared, shifts=1, dims=1)
    return _unit(a), _unit(b)


def _topk(scores: torch.Tensor, k: int) -> torch.Tensor:
    return torch.topk(scores, k=k, dim=1).indices.sort(dim=1).values


def _rank_one_residual(h: torch.Tensor, support: torch.Tensor, a: torch.Tensor, b: torch.Tensor, amplitudes: torch.Tensor | None = None) -> torch.Tensor:
    r = torch.zeros_like(h)
    if amplitudes is None:
        amplitudes = torch.ones(a.shape[0], dtype=h.dtype)
    for row in range(h.shape[0]):
        for col in support[row].tolist():
            r[row] += amplitudes[col] * torch.tanh(h[row].dot(a[col])) * b[col]
    return r


def _targets(h: torch.Tensor, r: torch.Tensor, gen: torch.Generator, num_classes: int) -> torch.Tensor:
    w = torch.randn(h.shape[1], num_classes, generator=gen)
    return torch.argmax((h + r) @ w, dim=1)


def _base(seed: int, n: int, d_model: int, c_dim: int, num_columns: int, support_size: int, *, oblique: bool = False) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, np.random.Generator, torch.Generator]:
    np_rng, gen = _rng(seed)
    h = torch.randn(n, d_model, generator=gen)
    ctx = _context(h, c_dim)
    router_w = torch.randn(num_columns, d_model + c_dim, generator=gen)
    support = _topk(torch.cat([h, ctx], dim=1) @ router_w.T, min(support_size, num_columns))
    a, b = _basis(d_model, num_columns, gen, oblique=oblique)
    return h, ctx, support, a, b, np_rng, gen


def _support_metadata(support: torch.Tensor, *, max_rows: int = 16) -> list[list[int]]:
    return [[int(v) for v in row] for row in support[:max_rows].tolist()]


def _data(name: str, h: torch.Tensor, ctx: torch.Tensor, support: torch.Tensor, r: torch.Tensor, gen: torch.Generator, gt: RelaLeapGroundTruth, num_classes: int) -> SyntheticRegimeData:
    metadata = gt.to_metadata()
    metadata["full_true_support_shape"] = tuple(support.shape)
    metadata["config"] = {"n": h.shape[0], "d_model": h.shape[1], "c_dim": ctx.shape[1], "num_columns": len(gt.true_columns), "support_size": support.shape[1]}
    metadata["mock_estimator_output"] = mock_estimator_output(metadata).__dict__
    return SyntheticRegimeData(h, ctx, support, r, _targets(h, r, gen, num_classes), metadata)


def make_rank_one_atom_gauge_benchmark(*, seed: int = 0, n: int = 256, d_model: int = 16, c_dim: int = 6, num_columns: int = 4, support_size: int = 2, num_classes: int = 4, gauge_scale: float = 3.0) -> SyntheticRegimeData:
    h, ctx, support, a_norm, b_norm, _np_rng, gen = _base(seed, n, d_model, c_dim, num_columns, support_size)
    r = _rank_one_residual(h, support, a_norm, b_norm)
    gt = RelaLeapGroundTruth(
        benchmark_id="rank_one_atom_gauge",
        known_regime="rank_one_atom_gauge",
        true_support=_support_metadata(support),
        true_columns=list(range(num_columns)),
        true_basis={"normalized": {"a": a_norm, "b": b_norm}, "unnormalized": {"a": gauge_scale * a_norm, "b": b_norm / gauge_scale}, "gauge_scale": gauge_scale},
        true_interactions={"gauge_equivalent_columns": list(range(num_columns))},
        expected_winner="gauge_invariant_rank_one_atoms",
        expected_I_lambda_signs={"functional_llc_delta_after_gauge_fix": "near_zero"},
        decision_notes=["Gauge fixing may move coordinates but must not materially change functional LLC estimates."],
    )
    return _data("rank_one_atom_gauge", h, ctx, support, r, gen, gt, num_classes)


def make_dead_column_benchmark(*, seed: int = 0, n: int = 256, d_model: int = 16, c_dim: int = 6, num_columns: int = 5, support_size: int = 2, num_classes: int = 4, dead_column: int | None = None) -> SyntheticRegimeData:
    h, ctx, support, a, b, _np_rng, gen = _base(seed, n, d_model, c_dim, num_columns, support_size)
    dead = num_columns - 1 if dead_column is None else dead_column
    support = support.clone()
    support[support == dead] = 0
    support = support.sort(dim=1).values
    amp = torch.ones(num_columns); amp[dead] = 0.0
    r = _rank_one_residual(h, support, a, b, amp)
    gt = RelaLeapGroundTruth(
        benchmark_id="dead_column",
        known_regime="dead_column",
        true_support=_support_metadata(support),
        true_columns=list(range(num_columns)),
        true_basis={"a": a, "b": b},
        true_interactions={"dead_columns": [dead], "zero_router_probability_columns": [dead], "zero_amplitude_columns": [dead]},
        expected_winner="fail_closed_dead_structure",
        expected_I_lambda_signs={f"column_{dead}_effective_contribution": "near_zero", "dead_column_as_modular_evidence": "not_interpretable"},
        decision_notes=["Low effective contribution is not modular evidence; causal audits should mark dead structure."],
    )
    return _data("dead_column", h, ctx, support, r, gen, gt, num_classes)


def make_shared_core_benchmark(*, seed: int = 0, n: int = 256, d_model: int = 16, c_dim: int = 6, num_columns: int = 4, support_size: int = 2, num_classes: int = 4) -> SyntheticRegimeData:
    h, ctx, support, a, b, _np_rng, gen = _base(seed, n, d_model, c_dim, num_columns, support_size)
    core = _unit(torch.randn(d_model, generator=gen), dim=0)
    support[: n // 3, 0] = 0; support[: n // 3, 1] = 1; support = support.sort(dim=1).values
    active = ((support == 0).any(1) | (support == 1).any(1)).float().unsqueeze(1)
    r = 0.6 * _rank_one_residual(h, support, a, b) + active * torch.tanh(h @ core).unsqueeze(1) * core.unsqueeze(0)
    gt = RelaLeapGroundTruth(
        benchmark_id="shared_core",
        known_regime="shared_core",
        true_support=_support_metadata(support),
        true_columns=list(range(num_columns)),
        true_basis={"a": a, "b": b},
        true_shared_core={"columns": [0, 1], "direction": core},
        true_interactions={"shared_core_columns": [0, 1]},
        expected_winner="shared_core_conditioned_columnar_adapter",
        expected_I_lambda_signs={"I_lambda(A;B)": "positive", "I_lambda(A;B|shared_core)": "near_zero"},
    )
    return _data("shared_core", h, ctx, support, r, gen, gt, num_classes)


def make_mediator_benchmark(*, seed: int = 0, n: int = 256, d_model: int = 16, c_dim: int = 6, num_columns: int = 5, support_size: int = 2, num_classes: int = 4) -> SyntheticRegimeData:
    h, ctx, support, a, b, _np_rng, gen = _base(seed, n, d_model, c_dim, num_columns, support_size)
    mediator = min(2, num_columns - 1)
    support[: n // 2, 0] = 0; support[: n // 2, 1] = mediator; support[n // 2 : 3 * n // 4, 0] = 1; support[n // 2 : 3 * n // 4, 1] = mediator; support = support.sort(dim=1).values
    m_signal = torch.tanh(h @ a[mediator]).unsqueeze(1) * b[mediator].unsqueeze(0)
    a_signal = torch.tanh((h @ a[0]) * (h @ a[mediator])).unsqueeze(1) * b[0].unsqueeze(0)
    b_signal = torch.tanh((h @ a[1]) * (h @ a[mediator])).unsqueeze(1) * b[1].unsqueeze(0)
    r = 0.45 * _rank_one_residual(h, support, a, b) + 0.8 * m_signal + 0.55 * (a_signal + b_signal)
    gt = RelaLeapGroundTruth(
        benchmark_id="mediator",
        known_regime="mediator",
        true_support=_support_metadata(support),
        true_columns=list(range(num_columns)),
        true_basis={"a": a, "b": b},
        true_mediators=[{"name": "M", "column": mediator, "mediates": [0, 1]}],
        true_interactions={"mediated_pair": [0, 1], "mediator_column": mediator},
        expected_winner="mediator_conditioned_columnar_adapter",
        expected_I_lambda_signs={"I_lambda(A;B)": "positive", "I_lambda(A;B|M)": "weakens_when_conditioned"},
        decision_notes=["Pairwise coupling should weaken after sampling or conditioning on mediator M."],
    )
    return _data("mediator", h, ctx, support, r, gen, gt, num_classes)


def make_router_collapse_benchmark(*, seed: int = 0, n: int = 256, d_model: int = 16, c_dim: int = 6, num_columns: int = 5, support_size: int = 1, num_classes: int = 4, dominant_column: int = 0) -> SyntheticRegimeData:
    h, ctx, _support, a, b, _np_rng, gen = _base(seed, n, d_model, c_dim, num_columns, support_size)
    support = torch.full((n, 1), dominant_column, dtype=torch.long)
    tail = max(1, n // 20)
    support[-tail:, 0] = torch.arange(tail) % num_columns
    r = _rank_one_residual(h, support, a, b)
    gt = RelaLeapGroundTruth(
        benchmark_id="router_collapse",
        known_regime="router_collapse",
        true_support=_support_metadata(support),
        true_columns=list(range(num_columns)),
        true_basis={"a": a, "b": b},
        true_interactions={"dominant_column": dominant_column, "dominant_router_fraction": float((support == dominant_column).float().mean())},
        expected_winner="fail_closed_router_collapse",
        expected_I_lambda_signs={"apparent_complexity_gain": "not_interpretable", "non_dominant_column_contribution": "near_zero"},
        decision_notes=["Do not reward low apparent complexity when one router choice dominates."],
    )
    return _data("router_collapse", h, ctx, support, r, gen, gt, num_classes)


def make_low_rank_trap_benchmark(*, seed: int = 0, n: int = 256, d_model: int = 16, c_dim: int = 6, num_columns: int = 5, support_size: int = 2, num_classes: int = 4, rank: int = 2) -> SyntheticRegimeData:
    h, ctx, support, a, b, _np_rng, gen = _base(seed, n, d_model, c_dim, num_columns, support_size)
    u = torch.randn(d_model, rank, generator=gen); v = torch.randn(d_model, rank, generator=gen)
    r = (h @ u) @ v.T / np.sqrt(rank)
    gt = RelaLeapGroundTruth(
        benchmark_id="low_rank_trap",
        known_regime="low_rank_trap",
        true_support=_support_metadata(support),
        true_columns=list(range(num_columns)),
        true_basis={"incidental_column_basis": {"a": a, "b": b}, "low_rank_u": u, "low_rank_v": v},
        true_interactions={"dense_low_rank": True, "rank": rank, "column_support_is_incidental": True},
        expected_winner="svd_low_rank_control",
        expected_I_lambda_signs={"columnar_interpretation": "not_interpretable", "low_rank_control_margin": "positive"},
        decision_notes=["SVD/low-rank controls should win; columnar claims must be blocked."],
    )
    return _data("low_rank_trap", h, ctx, support, r, gen, gt, num_classes)


def make_oblique_dictionary_benchmark(*, seed: int = 0, n: int = 256, d_model: int = 16, c_dim: int = 6, num_columns: int = 5, support_size: int = 2, num_classes: int = 4) -> SyntheticRegimeData:
    h, ctx, support, a, b, _np_rng, gen = _base(seed, n, d_model, c_dim, num_columns, support_size, oblique=True)
    r = _rank_one_residual(h, support, a, b)
    gram = a @ a.T
    gt = RelaLeapGroundTruth(
        benchmark_id="oblique_dictionary",
        known_regime="oblique_dictionary",
        true_support=_support_metadata(support),
        true_columns=list(range(num_columns)),
        true_basis={"a": a, "b": b, "gram": gram},
        true_interactions={"oblique_dictionary": True, "max_off_diagonal_abs_cosine": float((gram - torch.eye(num_columns)).abs().max())},
        expected_winner="nonorthogonal_dictionary",
        expected_I_lambda_signs={"nonorthogonal_vs_orthogonal_margin": "positive", "causal_factorization_after_diagnostics": "positive"},
        decision_notes=["Nonorthogonal dictionary should beat orthogonal sparse basis; diagnostics decide whether it is more than compression."],
    )
    return _data("oblique_dictionary", h, ctx, support, r, gen, gt, num_classes)


_BUILDERS: dict[str, Callable[..., SyntheticRegimeData]] = {
    "rank_one_atom_gauge": make_rank_one_atom_gauge_benchmark,
    "dead_column": make_dead_column_benchmark,
    "shared_core": make_shared_core_benchmark,
    "mediator": make_mediator_benchmark,
    "router_collapse": make_router_collapse_benchmark,
    "low_rank_trap": make_low_rank_trap_benchmark,
    "oblique_dictionary": make_oblique_dictionary_benchmark,
}


def generate_releap_benchmark(name: RelaLeapBenchmarkName, **kwargs: Any) -> SyntheticRegimeData:
    try:
        return _BUILDERS[name](**kwargs)
    except KeyError as exc:
        raise ValueError(f"unknown RelaLeap-shaped benchmark {name!r}") from exc


def generate_all_releap_benchmarks(seed: int = 0, **kwargs: Any) -> dict[str, SyntheticRegimeData]:
    return {name: builder(seed=seed + i * 1009, **kwargs) for i, (name, builder) in enumerate(_BUILDERS.items())}


def mock_estimator_output(metadata: dict[str, Any]) -> MockEstimatorOutput:
    """Return analytic-shaped mock outputs matching the fixture's expected regime.

    This lets tests assert decision wiring before WBIC/SGLD samplers exist.
    """
    return MockEstimatorOutput(
        winner=metadata["expected_winner"],
        I_lambda_signs=dict(metadata["expected_I_lambda_signs"]),
        diagnostics={"known_regime": metadata["known_regime"], "uses_mock_outputs": True},
    )
