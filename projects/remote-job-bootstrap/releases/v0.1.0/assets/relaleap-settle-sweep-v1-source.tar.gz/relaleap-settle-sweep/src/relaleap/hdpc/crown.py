from __future__ import annotations

import torch
from torch import nn


class IdentityPCCrown(nn.Module):
    """A residual prediction crown that is exactly identity at initialization.

    Only the crown correction is initialized to zero; the wrapped/base model is
    deliberately not owned by this module.  This keeps the first crown assay
    detached from base-model training and makes the no-logit-change invariant
    explicit.
    """

    def __init__(self, width: int, hidden_width: int | None = None) -> None:
        super().__init__()
        if width <= 0:
            raise ValueError("width must be positive")
        hidden_width = width if hidden_width is None else hidden_width
        if hidden_width <= 0:
            raise ValueError("hidden_width must be positive")

        self.input = nn.Linear(width, hidden_width)
        self.output = nn.Linear(hidden_width, width)
        nn.init.zeros_(self.output.weight)
        nn.init.zeros_(self.output.bias)

    def correction(self, logits: torch.Tensor) -> torch.Tensor:
        return self.output(torch.tanh(self.input(logits)))

    def forward(self, logits: torch.Tensor) -> torch.Tensor:
        return logits + self.correction(logits)
