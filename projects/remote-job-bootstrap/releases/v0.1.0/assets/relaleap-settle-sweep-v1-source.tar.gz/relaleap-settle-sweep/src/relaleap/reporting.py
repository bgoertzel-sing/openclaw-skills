from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Literal
import csv, json, os

Status = Literal["pass", "fail", "fail_closed", "not_run"]
@dataclass
class DecisionReport:
    prediction: dict[str, Any]
    reconstruction: dict[str, Any]
    causal_modularity: dict[str, Any]
    slt_evidence: dict[str, Any]
    null_margins: dict[str, Any]
    engineering_status: Status
    scientific_status: Status
    promotion_allowed: bool
    reason: str
    commands: list[str]
    seeds: list[int]
    configs: dict[str, Any]

    def validate_fail_closed(self) -> None:
        if self.scientific_status != "pass" and self.promotion_allowed:
            raise ValueError("promotion_allowed must be false unless scientific_status is pass")
        if self.scientific_status == "pass":
            required_slt_fields = {
                "estimator_type",
                "estimated_parameter_blocks",
                "wbic_temperature_schedule",
                "calibration_status",
                "calibration_benchmarks",
                "input_sample_size",
                "input_coverage_report",
                "inference_budget_report",
                "sample_size_sensitivity",
                "null_normalized_margin",
                "finite_sample_caveat",
            }
            missing = sorted(required_slt_fields - set(self.slt_evidence))
            if missing:
                raise ValueError(f"scientific_status=pass requires SLT evidence fields: {missing}")
            if self.slt_evidence.get("calibration_status") != "pass":
                raise ValueError("scientific_status=pass requires slt_evidence.calibration_status == 'pass'")
            blocks = self.slt_evidence.get("estimated_parameter_blocks")
            if not isinstance(blocks, list) or not blocks:
                raise ValueError("scientific_status=pass requires non-empty estimated_parameter_blocks list")
            if self.slt_evidence.get("finite_sample_caveat") is not True:
                raise ValueError("scientific_status=pass must mark finite_sample_caveat=True")
            input_sample_size = self.slt_evidence.get("input_sample_size")
            if not isinstance(input_sample_size, int) or input_sample_size <= 0:
                raise ValueError("scientific_status=pass requires positive integer slt_evidence.input_sample_size")
            for field in ("input_coverage_report", "inference_budget_report", "sample_size_sensitivity"):
                value = self.slt_evidence.get(field)
                if not isinstance(value, str) or not value.strip():
                    raise ValueError(f"scientific_status=pass requires non-empty slt_evidence.{field}")

    def write(self, out_dir: str) -> None:
        self.validate_fail_closed()
        os.makedirs(out_dir, exist_ok=True)
        panels = {
            "prediction_metrics.csv": self.prediction,
            "reconstruction_metrics.csv": self.reconstruction,
            "causal_modularity_metrics.csv": self.causal_modularity,
            "slt_evidence_metrics.csv": self.slt_evidence,
            "null_margins.csv": self.null_margins,
        }
        for name, data in panels.items():
            with open(os.path.join(out_dir, name), "w", newline="", encoding="utf-8") as f:
                w = csv.writer(f); w.writerow(["metric", "value"])
                for k, v in data.items(): w.writerow([k, v])
        summary = asdict(self)
        summary["promotion_allowed"] = bool(self.promotion_allowed)
        with open(os.path.join(out_dir, "summary.json"), "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2, sort_keys=True)
        with open(os.path.join(out_dir, "decision.md"), "w", encoding="utf-8") as f:
            f.write("# Decision Report\n\n")
            for title, data in [("Prediction", self.prediction), ("Reconstruction", self.reconstruction), ("Causal modularity", self.causal_modularity), ("SLT / evidence", self.slt_evidence), ("Null-normalized margins", self.null_margins)]:
                f.write(f"## {title}\n")
                for k, v in data.items(): f.write(f"- {k}: {v}\n")
                f.write("\n")
            f.write("## Decision\n")
            f.write(f"- engineering_status: {self.engineering_status}\n- scientific_status: {self.scientific_status}\n- promotion_allowed: {self.promotion_allowed}\n- reason: {self.reason}\n")

def fail_closed_placeholder(commands: list[str], seeds: list[int], configs: dict[str, Any], reason: str = "first implementation slice; scientific gates not yet run") -> DecisionReport:
    return DecisionReport(
        prediction={"status": "not_run"}, reconstruction={"status": "not_run"}, causal_modularity={"status": "not_run"},
        slt_evidence={"status": "placeholder_not_implemented_in_slice_1"}, null_margins={"status": "not_run"},
        engineering_status="pass", scientific_status="fail_closed", promotion_allowed=False,
        reason=reason, commands=commands, seeds=seeds, configs=configs)
