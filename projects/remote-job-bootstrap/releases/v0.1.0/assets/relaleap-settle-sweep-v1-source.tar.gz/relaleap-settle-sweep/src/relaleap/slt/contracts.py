from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Literal

from .parameter_blocks import ParameterBlockReport as InterfaceParameterBlockReport

EstimatorStatus = Literal["calibrated", "diagnostic_only", "failed"]


@dataclass(frozen=True)
class EstimatorResult:
    """Frozen machine-readable output schema for one estimator run."""

    estimator_status: EstimatorStatus
    estimator_kind: str
    energy_definition: str
    coefficient_on_total_nll: float
    n_data: int
    beta_total_energy: float
    lambda_single_n: float
    lambda_slope_fit: float | None
    multiplicity_proxy_b: float | None
    lambda_stderr: float
    lambda_ci95: tuple[float, float]
    num_chains: int
    num_steps: int
    burn_in: int
    thin: int
    energy_ess_per_chain: list[float]
    rhat_energy: float | None
    trend_test: dict[str, Any]
    nan_or_divergence_count: int
    negative_lambda_policy: str
    prior_family: str
    prior_scale: float
    gauge_policy_id: str
    theta_hat_status: str
    calibration_suite_status: str
    diagnostics: dict[str, Any] = field(default_factory=dict)

    @property
    def lambda_hat(self) -> float:
        """Compatibility alias from the validation plan's minimal interface."""

        return self.lambda_single_n

    @property
    def lambda_se(self) -> float:
        return self.lambda_stderr

    @property
    def status(self) -> EstimatorStatus:
        return self.estimator_status

    def __post_init__(self) -> None:
        if self.estimator_kind != "finite_sample_wbic_sgld_proxy_not_exact_rlct":
            raise ValueError("estimator_kind must preserve finite-sample / not-exact-RLCT wording")
        if self.n_data <= 0:
            raise ValueError("n_data must be positive")
        if self.num_chains <= 0 or self.num_steps <= 0:
            raise ValueError("num_chains and num_steps must be positive")
        if self.burn_in < 0 or self.thin <= 0:
            raise ValueError("burn_in must be non-negative and thin positive")
        if len(self.lambda_ci95) != 2 or self.lambda_ci95[0] > self.lambda_ci95[1]:
            raise ValueError("lambda_ci95 must be an ordered pair")
        if self.negative_lambda_policy != "fail_or_diagnostic_never_clip":
            raise ValueError("negative lambda policy must never clip")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class MockEstimatorOutput:
    benchmark_id: str
    block_name: str
    result: EstimatorResult
    notes: str = "mock output for interface tests only; not scientific evidence"


@dataclass(frozen=True)
class SLTValidationReport:
    """Run-level schema shared by integration and reporting agents."""

    run_id: str
    estimator_results: list[EstimatorResult]
    parameter_blocks: list[InterfaceParameterBlockReport]
    compatibility_matrix: list[dict[str, Any]]
    mandatory_gates_passed: bool
    scientific_decision_usable: bool
    reason: str

    def __post_init__(self) -> None:
        if self.scientific_decision_usable and not self.mandatory_gates_passed:
            raise ValueError("scientific_decision_usable requires mandatory_gates_passed")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def make_mock_estimator_output(benchmark_id: str = "mock_regular_quadratic", block_name: str = "mock_theta") -> MockEstimatorOutput:
    result = EstimatorResult(
        estimator_status="diagnostic_only",
        estimator_kind="finite_sample_wbic_sgld_proxy_not_exact_rlct",
        energy_definition="total_nll",
        coefficient_on_total_nll=1.0,
        n_data=128,
        beta_total_energy=1.0,
        lambda_single_n=1.0,
        lambda_slope_fit=None,
        multiplicity_proxy_b=None,
        lambda_stderr=0.0,
        lambda_ci95=(1.0, 1.0),
        num_chains=1,
        num_steps=1,
        burn_in=0,
        thin=1,
        energy_ess_per_chain=[1.0],
        rhat_energy=None,
        trend_test={"status": "not_run"},
        nan_or_divergence_count=0,
        negative_lambda_policy="fail_or_diagnostic_never_clip",
        prior_family="mock_unit_gaussian",
        prior_scale=1.0,
        gauge_policy_id="mock_identity",
        theta_hat_status="local_map_pass",
        calibration_suite_status="not_run_mock_only",
        diagnostics={"mock": True},
    )
    return MockEstimatorOutput(benchmark_id=benchmark_id, block_name=block_name, result=result)
