from __future__ import annotations

from dataclasses import dataclass
from math import log, sqrt
from statistics import NormalDist
from typing import Literal, Sequence

import torch

from .contracts import EstimatorResult, EstimatorStatus
from .diagnostics import ChainDiagnostics, diagnose_energy_chains
from .energy import EnergyModel, Prior
from .sgld import SGLDConfig, SGLDResult, run_sgld_chains

Tensor = torch.Tensor
EnergyDefinition = Literal["total_nll", "mean_loss"]


@dataclass(frozen=True)
class TemperatureConvention:
    n_data: int
    energy_definition: EnergyDefinition = "total_nll"
    coefficient: float | None = None

    @property
    def beta_total_energy(self) -> float:
        if self.n_data <= 1:
            raise ValueError("n_data must be greater than 1")
        if self.coefficient is None:
            return 1.0 / log(self.n_data)
        if self.energy_definition == "total_nll":
            return float(self.coefficient)
        if self.energy_definition == "mean_loss":
            return float(self.coefficient) / float(self.n_data)
        raise ValueError(f"unknown energy definition: {self.energy_definition}")

    @property
    def coefficient_on_total_nll(self) -> float:
        return self.beta_total_energy

    @property
    def coefficient_on_mean_loss(self) -> float:
        return self.beta_total_energy * float(self.n_data)

    @classmethod
    def wbic_total_energy(cls, n_data: int) -> "TemperatureConvention":
        return cls(n_data=n_data, energy_definition="total_nll", coefficient=1.0 / log(n_data))

    @classmethod
    def wbic_mean_loss(cls, n_data: int) -> "TemperatureConvention":
        return cls(n_data=n_data, energy_definition="mean_loss", coefficient=n_data / log(n_data))

    @classmethod
    def wrong_total_nll_divided_by_n(cls, n_data: int) -> "TemperatureConvention":
        """Known-bad convention: multiplies total NLL by 1/(n log n)."""

        return cls(n_data=n_data, energy_definition="total_nll", coefficient=1.0 / (n_data * log(n_data)))


def wbic_beta_total_energy(n_data: int) -> float:
    return TemperatureConvention.wbic_total_energy(n_data).beta_total_energy


def assert_valid_wbic_temperature(convention: TemperatureConvention, *, rtol: float = 1e-12) -> None:
    expected = 1.0 / log(convention.n_data)
    actual = convention.beta_total_energy
    if abs(actual - expected) > rtol * max(1.0, abs(expected)):
        raise ValueError(
            "invalid WBIC temperature: coefficient on total energy must be "
            f"1/log(n), got {actual:.12g} for n={convention.n_data}"
        )


@dataclass
class WBICResult:
    lambda_hat: float
    lambda_se: float
    status: EstimatorStatus
    diagnostics: dict[str, object]
    energy_mean: float
    energy_reference: float
    coefficient_on_total_nll: float
    beta_total_energy: float
    n_data: int
    lambda_ci95: tuple[float, float]
    estimator_result: EstimatorResult


def estimate_lambda_from_energies(
    sampled_total_energies: Tensor,
    reference_total_energy: float | Tensor,
    n_data: int,
) -> tuple[float, float, tuple[float, float]]:
    energies = sampled_total_energies.detach().double().flatten()
    energies = energies[torch.isfinite(energies)]
    if energies.numel() == 0:
        raise ValueError("no finite energies supplied")
    ref = float(reference_total_energy)
    logn = log(n_data)
    deltas = (energies - ref) / logn
    mean = float(deltas.mean())
    se = float(deltas.std(unbiased=True) / sqrt(deltas.numel())) if deltas.numel() > 1 else float("nan")
    z = NormalDist().inv_cdf(0.975)
    ci = (mean - z * se, mean + z * se) if torch.isfinite(torch.tensor(se)) else (float("nan"), float("nan"))
    return mean, se, ci


def combine_chain_energies(chains: Sequence[SGLDResult]) -> Tensor:
    parts = [c.energy_trace.detach().double().flatten() for c in chains if c.energy_trace.numel()]
    if not parts:
        return torch.empty(0, dtype=torch.double)
    return torch.cat(parts)


def _estimator_status(lam: float, diag: ChainDiagnostics) -> EstimatorStatus:
    if lam < 0 or diag.nan_or_divergence_count:
        return "diagnostic_only"
    return "calibrated"


def estimate_wbic_from_chains(
    model: EnergyModel,
    data: Tensor,
    chains: Sequence[SGLDResult],
    *,
    convention: TemperatureConvention,
    prior: Prior | None = None,
    gauge_policy_id: str = "none",
    theta_hat_status: str = "local_map_pass",
    calibration_suite_status: str = "not_run",
) -> WBICResult:
    assert_valid_wbic_temperature(convention)
    energies = combine_chain_energies(chains)
    theta_hat = model.theta_hat()
    ref_energy = model.total_energy(theta_hat, data)
    lam, se, ci = estimate_lambda_from_energies(energies, ref_energy, convention.n_data)
    diag: ChainDiagnostics = diagnose_energy_chains([c.energy_trace for c in chains])
    status = _estimator_status(lam, diag)
    diagnostics = {
        "estimator_kind": "finite_sample_wbic_sgld_proxy_not_exact_rlct",
        "energy_definition": convention.energy_definition,
        "coefficient_on_total_nll": convention.coefficient_on_total_nll,
        "n_data": convention.n_data,
        "beta_total_energy": convention.beta_total_energy,
        "energy_ess_per_chain": diag.energy_ess_per_chain,
        "rhat_energy": diag.rhat_energy,
        "trend_test": diag.trend_test,
        "nan_or_divergence_count": diag.nan_or_divergence_count,
        "negative_lambda_policy": "fail_or_diagnostic_never_clip",
        "prior_family": getattr(prior, "prior_family", "none"),
        "prior_scale": getattr(prior, "prior_scale", float("inf")),
        "acceptance_rate": diag.acceptance_rate,
    }
    estimator = EstimatorResult(
        estimator_status=status,
        estimator_kind="finite_sample_wbic_sgld_proxy_not_exact_rlct",
        energy_definition=convention.energy_definition,
        coefficient_on_total_nll=convention.coefficient_on_total_nll,
        n_data=convention.n_data,
        beta_total_energy=convention.beta_total_energy,
        lambda_single_n=lam,
        lambda_slope_fit=None,
        multiplicity_proxy_b=None,
        lambda_stderr=se,
        lambda_ci95=ci,
        num_chains=len(chains),
        num_steps=max((c.config.num_steps for c in chains), default=0),
        burn_in=max((c.config.burn_in for c in chains), default=0),
        thin=max((c.config.thin for c in chains), default=1),
        energy_ess_per_chain=diag.energy_ess_per_chain,
        rhat_energy=diag.rhat_energy,
        trend_test=diag.trend_test,
        nan_or_divergence_count=diag.nan_or_divergence_count,
        negative_lambda_policy="fail_or_diagnostic_never_clip",
        prior_family=getattr(prior, "prior_family", "none"),
        prior_scale=float(getattr(prior, "prior_scale", float("inf"))),
        gauge_policy_id=gauge_policy_id,
        theta_hat_status=theta_hat_status,
        calibration_suite_status=calibration_suite_status,
        diagnostics=diagnostics,
    )
    return WBICResult(
        lambda_hat=lam,
        lambda_se=se,
        status=status,
        diagnostics=diagnostics,
        energy_mean=float(energies.mean()),
        energy_reference=float(ref_energy),
        coefficient_on_total_nll=convention.coefficient_on_total_nll,
        beta_total_energy=convention.beta_total_energy,
        n_data=convention.n_data,
        lambda_ci95=ci,
        estimator_result=estimator,
    )


def run_wbic_sgld(
    model: EnergyModel,
    data: Tensor,
    *,
    theta0: Tensor | None = None,
    convention: TemperatureConvention | None = None,
    prior: Prior | None = None,
    config: SGLDConfig | None = None,
    num_chains: int = 4,
) -> tuple[WBICResult, list[SGLDResult]]:
    convention = convention or TemperatureConvention.wbic_total_energy(data.shape[0])
    assert_valid_wbic_temperature(convention)
    chains = run_sgld_chains(
        model,
        data,
        theta0,
        beta_total_energy=convention.beta_total_energy,
        prior=prior,
        config=config,
        num_chains=num_chains,
    )
    return estimate_wbic_from_chains(model, data, chains, convention=convention, prior=prior), chains
