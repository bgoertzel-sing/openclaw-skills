#!/usr/bin/env python3
"""No-update real-teacher scale audit for the historical six-layer ePC model."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
import urllib.parse
import urllib.request
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from relaleap.hdpc.gpt2_epc import GPT2BlockStateAdapter
from relaleap.hdpc.tinyshakespeare import kd_loss

LAMBDAS = (0.005, 0.05, 0.5, 5.0, 50.0)
DEPTHS = (4, 8, 12)
TEACHER_ID = "openai-community/gpt2"
TEACHER_REVISION = "607a30d783dfa663caf39e06633721c8d4cfcd7e"


def _hash_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _fetch_wikitext():
    query = urllib.parse.urlencode(
        {
            "dataset": "Salesforce/wikitext",
            "config": "wikitext-103-raw-v1",
            "split": "validation",
            "offset": 0,
            "length": 64,
        }
    )
    url = f"https://datasets-server.huggingface.co/rows?{query}"
    with urllib.request.urlopen(url, timeout=60) as response:
        payload = response.read()
    rows = json.loads(payload)["rows"]
    text = "\n".join(row["row"]["text"] for row in rows if row["row"]["text"])
    return text, {"url": url, "response_sha256": _hash_bytes(payload)}


def _components(adapter, input_state, hidden, teacher_logits, temperature):
    local = []
    normalized = []
    previous = input_state
    for index, observed in enumerate(hidden):
        prediction = adapter.predict_block(index, previous)
        squared = (observed - prediction).square()
        local.append(0.5 * squared.flatten(1).sum(dim=1).mean())
        normalized.append(0.5 * squared.mean())
        previous = observed
    logits = adapter.logits_from_state(previous)
    kd = kd_loss(logits, teacher_logits, temperature=temperature)
    return local, normalized, kd


def _energy(adapter, input_state, hidden, teacher_logits, temperature, output_weight):
    local, normalized, kd = _components(
        adapter, input_state, hidden, teacher_logits, temperature
    )
    return sum(local) + output_weight * kd, local, normalized, kd


def _relax(adapter, feedforward, teacher_logits, output_weight, steps):
    hidden = tuple(state.detach().requires_grad_(True) for state in feedforward.hidden_states)
    initial = tuple(state.detach() for state in hidden)
    history = []
    accepted_steps = []
    backtracks_used = []
    initial_activity_norms = None
    for step in range(steps):
        energy, local, normalized, kd = _energy(
            adapter,
            feedforward.input_state.detach(),
            hidden,
            teacher_logits,
            2.0,
            output_weight,
        )
        gradients = torch.autograd.grad(energy, hidden, retain_graph=False)
        if initial_activity_norms is None:
            initial_activity_norms = [float(gradient.norm()) for gradient in gradients]
        history.append(float(energy.detach()))
        if step == steps - 1:
            final_gradients = gradients
            break
        step_size = 0.2
        accepted = None
        accepted_backtracks = 13
        with torch.no_grad():
            for backtracks in range(13):
                proposal = tuple(
                    state - step_size * gradient for state, gradient in zip(hidden, gradients)
                )
                proposal_energy = _energy(
                    adapter,
                    feedforward.input_state.detach(),
                    proposal,
                    teacher_logits,
                    2.0,
                    output_weight,
                )[0]
                if math.isfinite(float(proposal_energy)) and float(proposal_energy) <= float(
                    energy.detach()
                ) + 1e-9 * max(1.0, abs(float(energy.detach()))):
                    accepted = proposal
                    accepted_backtracks = backtracks
                    break
                step_size *= 0.5
        if accepted is None:
            accepted = tuple(state.detach() for state in hidden)
            step_size = 0.0
        accepted_steps.append(step_size)
        backtracks_used.append(accepted_backtracks)
        hidden = tuple(state.detach().requires_grad_(True) for state in accepted)

    objective, local, normalized, kd = _energy(
        adapter,
        feedforward.input_state.detach(),
        tuple(state.detach() for state in hidden),
        teacher_logits,
        2.0,
        output_weight,
    )
    return objective, {
        "energy_history": history,
        "accepted_step_sizes": accepted_steps,
        "backtrack_counts": backtracks_used,
        "local_energy_by_layer": [float(value.detach()) for value in local],
        "normalized_local_energy_by_layer": [
            float(value.detach()) for value in normalized
        ],
        "kd": float(kd.detach()),
        "weighted_kd": output_weight * float(kd.detach()),
        "initial_activity_gradient_norms": initial_activity_norms,
        "final_stationarity_norms": [float(gradient.norm()) for gradient in final_gradients],
        "relaxation_displacement_norms": [
            float((state.detach() - start).norm()) for state, start in zip(hidden, initial)
        ],
    }


def _block_index(name: str):
    parts = name.split(".")
    if len(parts) > 2 and parts[0] == "transformer" and parts[1] == "h":
        return int(parts[2])
    return None


def _gradient_comparison(model, objective, reference_gradients, parameters, names):
    gradients = torch.autograd.grad(objective, parameters, allow_unused=True)
    totals = {index: [0.0, 0.0, 0.0] for index in range(6)}
    overall = [0.0, 0.0, 0.0]
    for name, gradient, reference in zip(names, gradients, reference_gradients):
        if gradient is None or reference is None:
            continue
        g = gradient.detach().double().cpu()
        r = reference.double()
        dot = float((g * r).sum())
        g2 = float(g.square().sum())
        r2 = float(r.square().sum())
        for target in (overall, totals.get(_block_index(name))):
            if target is not None:
                target[0] += dot
                target[1] += g2
                target[2] += r2

    def summarize(values):
        dot, g2, r2 = values
        denominator = math.sqrt(g2 * r2)
        return {
            "epc_norm": math.sqrt(g2),
            "ordinary_kd_norm": math.sqrt(r2),
            "cosine_vs_ordinary_kd": None if denominator == 0 else dot / denominator,
        }

    return {
        "overall": summarize(overall),
        "blocks": [dict(block=index, **summarize(totals[index])) for index in range(6)],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--sequence", type=int, default=32)
    args = parser.parse_args()
    device = torch.device(args.device)

    from transformers import AutoModelForCausalLM, AutoTokenizer, GPT2LMHeadModel

    tokenizer = AutoTokenizer.from_pretrained(TEACHER_ID, revision=TEACHER_REVISION)
    text, source = _fetch_wikitext()
    token_ids = tokenizer(text, add_special_tokens=False)["input_ids"][: args.sequence]
    tokens = torch.tensor(token_ids, dtype=torch.long, device=device).unsqueeze(0)
    teacher = AutoModelForCausalLM.from_pretrained(
        TEACHER_ID, revision=TEACHER_REVISION, use_safetensors=True
    ).to(device)
    teacher.eval()
    with torch.no_grad():
        teacher_logits = teacher(tokens, use_cache=False).logits.detach()
    del teacher

    model = GPT2LMHeadModel.from_pretrained(str(args.checkpoint), local_files_only=True).to(device)
    model.config.use_cache = False
    model.train()
    model.config.resid_pdrop = model.config.embd_pdrop = model.config.attn_pdrop = 0.0
    for module in model.modules():
        if isinstance(module, torch.nn.Dropout):
            module.p = 0.0
    adapter = GPT2BlockStateAdapter(model)
    parameters_and_names = [
        (parameter, name) for name, parameter in model.named_parameters() if parameter.requires_grad
    ]
    parameters = [item[0] for item in parameters_and_names]
    names = [item[1] for item in parameters_and_names]

    feedforward = adapter.forward_states(tokens)
    ordinary_kd = kd_loss(feedforward.logits, teacher_logits, temperature=2.0)
    reference_gradients = [
        None if gradient is None else gradient.detach().double().cpu()
        for gradient in torch.autograd.grad(ordinary_kd, parameters, allow_unused=True)
    ]

    rows = []
    for steps in DEPTHS:
        for output_weight in LAMBDAS:
            print(f"steps={steps} lambda={output_weight}", flush=True)
            feedforward = adapter.forward_states(tokens)
            objective, diagnostics = _relax(
                adapter, feedforward, teacher_logits, output_weight, steps
            )
            diagnostics.update(
                {
                    "activity_states": steps,
                    "lambda_output": output_weight,
                    "objective": float(objective.detach()),
                    "parameter_gradients": _gradient_comparison(
                        model, objective, reference_gradients, parameters, names
                    ),
                }
            )
            rows.append(diagnostics)

    result = {
        "schema": "relaleap.epc_real_teacher_scale_audit.v1",
        "checkpoint": str(args.checkpoint.resolve()),
        "teacher": {"id": TEACHER_ID, "revision": TEACHER_REVISION},
        "data_source": source,
        "token_sha256": _hash_bytes(tokens.cpu().numpy().tobytes()),
        "token_shape": list(tokens.shape),
        "device": str(device),
        "optimizer_updates": 0,
        "ordinary_kd": float(ordinary_kd.detach()),
        "rows": rows,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(f"wrote {args.output}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
