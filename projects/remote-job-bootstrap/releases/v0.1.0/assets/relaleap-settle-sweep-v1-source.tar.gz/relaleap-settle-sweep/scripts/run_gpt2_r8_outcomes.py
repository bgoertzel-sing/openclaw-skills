#!/usr/bin/env python3
"""Evaluate r8 checkpoints on OOD, robustness, continual learning, and geometry."""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import random
import sys
from pathlib import Path

import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from run_gpt2_outcome_gpu import (
    _attach_low_rank, _batch, _block_skip_losses, _chunks, _corrupt,
    _documents_to_tokens, _hidden_states, _linear_cka, _loss_vector,
    _mean_loss, _select_chunks, _spectral_summary,
)

ARMS = ("bp_ce", "bp_kd", "epc_original", "epc_deep")


def _summary(values: torch.Tensor) -> dict[str, float]:
    base = _spectral_summary(values)
    x = values.double().reshape(-1, values.shape[-1])
    centered = x - x.mean(0)
    singular = torch.linalg.svdvals(centered)
    norms = F.normalize(x, dim=-1)
    count = min(2048, len(norms))
    sample = norms[:count]
    cosine = sample @ sample.T
    offdiag = (cosine.sum() - cosine.diag().sum()) / max(1, count * (count - 1))
    base.update({
        "stable_rank": float(singular.square().sum() / singular.square().max()),
        "mean_cosine_anisotropy": float(offdiag),
    })
    return base


def _span_corrupt(chunks, vocab_size, probability, seed):
    result = []
    generator = torch.Generator().manual_seed(seed)
    for chunk in chunks:
        changed = chunk.clone()
        count = max(1, round((len(changed) - 1) * probability))
        start = int(torch.randint(max(1, len(changed) - count), (1,), generator=generator))
        changed[start:start + count] = torch.randint(vocab_size, (count,), generator=generator)
        result.append(changed)
    return result


@torch.no_grad()
def _weight_noise_delta(model, chunks, device, scales, seed):
    baseline = _mean_loss(model, chunks, device)
    rows = []
    for scale in scales:
        generator = torch.Generator(device=device).manual_seed(seed)
        rms_values = []
        for parameter in model.parameters():
            if parameter.is_floating_point():
                rms = parameter.detach().float().square().mean().sqrt()
                rms_values.append(rms)
                noise = torch.randn(parameter.shape, device=device,
                                    dtype=parameter.dtype, generator=generator)
                parameter.add_(noise * (scale * rms))
        loss = _mean_loss(model, chunks, device)
        generator.manual_seed(seed)
        cursor = 0
        for parameter in model.parameters():
            if parameter.is_floating_point():
                noise = torch.randn(parameter.shape, device=device,
                                    dtype=parameter.dtype, generator=generator)
                parameter.sub_(noise * (scale * rms_values[cursor]))
                cursor += 1
        rows.append({"scale": scale, "delta_loss": loss - baseline})
    return rows


def _eval_vectors(model, domains, device):
    return {name: _loss_vector(model, chunks, device) for name, chunks in domains.items()}


def _adapt_step(model, optimizer, chunks, generator, device, batch_size=2, accum=4):
    model.train()
    optimizer.zero_grad(set_to_none=True)
    indices = torch.randint(len(chunks), (batch_size * accum,), generator=generator).tolist()
    for k in range(accum):
        selected = [chunks[i] for i in indices[k * batch_size:(k + 1) * batch_size]]
        x, y = _batch(selected, device)
        logits = model(x, use_cache=False).logits
        loss = F.cross_entropy(logits.reshape(-1, logits.shape[-1]), y.reshape(-1))
        (loss / accum).backward()
    optimizer.step()


def _sequential_adaptation(model, train_b, train_c, eval_domains, probe, config, seed, device):
    before_hidden = _hidden_states(model, probe, device)
    spec = config["r8"]["adapter"]
    attached = _attach_low_rank(model, ["attn.c_attn", "mlp.c_fc"], spec["rank"], spec["alpha"])
    optimizer = torch.optim.AdamW(
        [p for p in model.parameters() if p.requires_grad], lr=spec["learning_rate"]
    )
    generator = torch.Generator().manual_seed(seed + 9000)
    checkpoints = set(spec["evaluation_updates"])
    curves = {"B": [], "C": []}
    for phase, train_chunks in (("B", train_b), ("C", train_c)):
        for update in range(spec["updates_per_phase"] + 1):
            if update in checkpoints and not (phase == "C" and update == 0):
                curves[phase].append({"update": update,
                                      "loss_vectors": _eval_vectors(model, eval_domains, device)})
            if update < spec["updates_per_phase"]:
                _adapt_step(model, optimizer, train_chunks, generator, device)
    after_hidden = _hidden_states(model, probe, device)
    drift = [_linear_cka(a, b) for a, b in zip(before_hidden, after_hidden)]
    return {"adapter_locations": attached, "curves": curves,
            "pre_post_representation_cka": drift}


def _load_domains(config, tokenizer):
    from datasets import load_dataset
    source = load_dataset("Salesforce/wikitext", "wikitext-103-raw-v1",
                          revision=config["dataset"]["revision"])
    stories = load_dataset("roneneldan/TinyStories",
                           revision="f54c09fd23315a6f9c86f9dc80f725de7d8f9c64")
    ptb = load_dataset("ptb_text_only", "penn_treebank")
    source_tokens = _documents_to_tokens(source["validation"], tokenizer, 4096)
    story_train = _documents_to_tokens(stories["train"], tokenizer, 4096)
    story_val = _documents_to_tokens(stories["validation"], tokenizer, 1024)
    ptb_train = _documents_to_tokens(ptb["train"], tokenizer, len(ptb["train"]))
    ptb_val = _documents_to_tokens(ptb["validation"], tokenizer, len(ptb["validation"]))
    width = config["training"]["context_length"]
    return {
        "source": _chunks(source_tokens, width),
        "B": _chunks(story_val, width), "C": _chunks(ptb_val, width),
        "train_B": _chunks(story_train, width), "train_C": _chunks(ptb_train, width),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--checkpoints", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    config = json.loads(args.protocol.read_text())
    device = torch.device(args.device)
    from transformers import AutoModelForCausalLM, AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(config["teacher"]["model_id"],
                                              revision=config["teacher"]["revision"])
    pools = _load_domains(config, tokenizer)
    rows, cka_rows = [], []
    for seed in config["evaluation"]["seeds"]:
        eval_domains, manifests = {}, {}
        for offset, name in enumerate(("source", "B", "C")):
            selected, indices = _select_chunks(pools[name], config["r8"]["evaluation_segments"], seed + offset)
            eval_domains[name] = selected
            manifests[name] = hashlib.sha256(json.dumps(indices).encode()).hexdigest()
        probe = eval_domains["source"][:config["r8"]["probe_segments"]]
        hidden_by_arm = {}
        for arm in ARMS:
            checkpoint = args.checkpoints / f"seed{seed}_{arm}"
            model = AutoModelForCausalLM.from_pretrained(checkpoint, local_files_only=True).to(device)
            hidden = {name: _hidden_states(model, chunks[:config["r8"]["probe_segments"]], device)
                      for name, chunks in eval_domains.items()}
            hidden_by_arm[arm] = hidden
            clean = _eval_vectors(model, eval_domains, device)
            corruption = {}
            for name, chunks in eval_domains.items():
                baseline = sum(clean[name]) / len(clean[name])
                corruption[name] = []
                for probability in config["r8"]["corruption_probabilities"]:
                    random_chunks = _corrupt(chunks, model.config.vocab_size, probability, seed + 7000)
                    span_chunks = _span_corrupt(chunks, model.config.vocab_size, probability, seed + 8000)
                    corruption[name].append({
                        "probability": probability,
                        "random_delta": _mean_loss(model, random_chunks, device) - baseline,
                        "span_delta": _mean_loss(model, span_chunks, device) - baseline,
                    })
            block_skip = _block_skip_losses(model, probe, device)
            geometry = {name: [_summary(layer) for layer in layers]
                        for name, layers in hidden.items()}
            weight_noise = _weight_noise_delta(
                model, probe, device, config["r8"]["weight_noise_scales"], seed + 11000
            )
            del model
            model = AutoModelForCausalLM.from_pretrained(checkpoint, local_files_only=True).to(device)
            adaptation = _sequential_adaptation(
                model, pools["train_B"], pools["train_C"], eval_domains, probe,
                config, seed, device,
            )
            rows.append({"seed": seed, "arm": arm, "manifests": manifests,
                         "clean_loss_vectors": clean, "corruption": corruption,
                         "block_skip_losses": block_skip, "geometry": geometry,
                         "weight_noise": weight_noise, "adaptation": adaptation})
            del model
            if device.type == "cuda": torch.cuda.empty_cache()
        for left, right in (("bp_ce", "bp_kd"), ("bp_ce", "epc_original"),
                            ("bp_kd", "epc_original"), ("epc_original", "epc_deep")):
            cka_rows.append({"seed": seed, "comparison": f"{left}_vs_{right}",
                             "by_domain": {name: [_linear_cka(a, b) for a, b in zip(
                                 hidden_by_arm[left][name], hidden_by_arm[right][name])]
                                 for name in ("source", "B", "C")}})
    payload = {"schema": "relaleap.epc_r8_outcomes.v1",
               "protocol_sha256": hashlib.sha256(args.protocol.read_bytes()).hexdigest(),
               "rows": rows, "cka": cka_rows}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
