#!/usr/bin/env python3
"""Corrected real-data representation audit for preserved ePC checkpoints."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import urllib.parse
import urllib.request
from itertools import combinations
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from relaleap.hdpc.gpt2_epc import GPT2BlockStateAdapter
from relaleap.hdpc.representation import (
    centered_rank_summary,
    linear_cka_feature,
    linear_cka_gram,
)

SCHEMA = "relaleap.epc_representation_correctness_audit.v1"
TEACHER_ID = "openai-community/gpt2"
TEACHER_REVISION = "607a30d783dfa663caf39e06633721c8d4cfcd7e"
DATASETS = {
    "wikitext": ("Salesforce/wikitext", "wikitext-103-raw-v1", "validation"),
    "tinystories": ("roneneldan/TinyStories", "default", "validation"),
}


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _canonical_hash(value) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return _sha256_bytes(payload)


def _fetch_texts(dataset: str, config: str, split: str, length: int = 64):
    query = urllib.parse.urlencode(
        {
            "dataset": dataset,
            "config": config,
            "split": split,
            "offset": 0,
            "length": length,
        }
    )
    url = f"https://datasets-server.huggingface.co/rows?{query}"
    with urllib.request.urlopen(url, timeout=60) as response:
        payload = response.read()
    decoded = json.loads(payload)
    texts = [row["row"]["text"] for row in decoded["rows"] if row["row"]["text"]]
    if not texts:
        raise RuntimeError(f"no nonempty rows returned for {dataset}")
    return texts, {"url": url, "response_sha256": _sha256_bytes(payload)}


def _fixed_tokens(tokenizer, texts: list[str], *, batch: int, sequence: int):
    ids = tokenizer("\n".join(texts), add_special_tokens=False)["input_ids"]
    required = batch * sequence
    if len(ids) < required:
        raise RuntimeError(f"real-data token stream has {len(ids)} tokens; need {required}")
    tensor = torch.tensor(ids[:required], dtype=torch.long).reshape(batch, sequence)
    return tensor


def _load_checkpoint(path: Path):
    from transformers import GPT2LMHeadModel

    model = GPT2LMHeadModel.from_pretrained(str(path), local_files_only=True)
    model.config.use_cache = False
    model.eval()
    return model


def _states(model, tokens: torch.Tensor):
    adapter = GPT2BlockStateAdapter(model)
    with torch.no_grad():
        result = adapter.forward_states(tokens)
    return [result.input_state.cpu(), *(state.cpu() for state in result.hidden_states)]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoints", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--batch", type=int, default=4)
    parser.add_argument("--sequence", type=int, default=64)
    args = parser.parse_args()

    from transformers import AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(TEACHER_ID, revision=TEACHER_REVISION)
    tokenizer.model_max_length = 10**9
    probes = {}
    sources = {}
    for name, spec in DATASETS.items():
        texts, source = _fetch_texts(*spec)
        probes[name] = _fixed_tokens(
            tokenizer, texts, batch=args.batch, sequence=args.sequence
        )
        sources[name] = source
    generator = torch.Generator().manual_seed(42)
    probes["random_ood"] = torch.randint(
        0, tokenizer.vocab_size, (args.batch, args.sequence), generator=generator
    )

    checkpoint_paths = sorted(
        path for path in args.checkpoints.iterdir() if (path / "model.safetensors").is_file()
    )
    if len(checkpoint_paths) != 9:
        raise RuntimeError(f"expected 9 checkpoints, found {len(checkpoint_paths)}")

    representations = {name: {} for name in probes}
    ranks = {name: {} for name in probes}
    for checkpoint in checkpoint_paths:
        print(f"loading {checkpoint.name}", flush=True)
        model = _load_checkpoint(checkpoint)
        for probe_name, tokens in probes.items():
            layer_states = _states(model, tokens)
            representations[probe_name][checkpoint.name] = layer_states
            ranks[probe_name][checkpoint.name] = [
                {"layer": layer, **centered_rank_summary(state)}
                for layer, state in enumerate(layer_states)
            ]
        del model

    cka = {}
    maximum_symmetry_error = 0.0
    maximum_formulation_error = 0.0
    for probe_name, by_checkpoint in representations.items():
        probe_pairs = []
        for first, second in combinations(sorted(by_checkpoint), 2):
            layers = []
            for layer, (x, y) in enumerate(zip(by_checkpoint[first], by_checkpoint[second])):
                xy = linear_cka_feature(x, y)
                yx = linear_cka_feature(y, x)
                gram = linear_cka_gram(x, y)
                symmetry_error = abs(xy - yx)
                formulation_error = abs(xy - gram)
                maximum_symmetry_error = max(maximum_symmetry_error, symmetry_error)
                maximum_formulation_error = max(maximum_formulation_error, formulation_error)
                if symmetry_error > 1e-5 or formulation_error > 1e-4:
                    raise RuntimeError(
                        f"CKA cross-check failed for {probe_name}/{first}/{second}/L{layer}"
                    )
                layers.append(
                    {
                        "layer": layer,
                        "cka": xy,
                        "symmetry_error": symmetry_error,
                        "feature_vs_gram_error": formulation_error,
                    }
                )
            probe_pairs.append({"first": first, "second": second, "layers": layers})
        cka[probe_name] = probe_pairs

    result = {
        "schema": SCHEMA,
        "checkpoint_root": str(args.checkpoints.resolve()),
        "checkpoints": [path.name for path in checkpoint_paths],
        "teacher_tokenizer": {"id": TEACHER_ID, "revision": TEACHER_REVISION},
        "probe_shape": [args.batch, args.sequence],
        "probe_token_sha256": {
            name: _sha256_bytes(tokens.numpy().tobytes()) for name, tokens in probes.items()
        },
        "real_data_sources": sources,
        "ranks": ranks,
        "cka": cka,
        "checks": {
            "same_tokens_per_checkpoint": True,
            "maximum_symmetry_error": maximum_symmetry_error,
            "maximum_feature_vs_gram_error": maximum_formulation_error,
            "passes": True,
        },
    }
    result["canonical_content_sha256"] = _canonical_hash(result)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result["checks"], indent=2, sort_keys=True), flush=True)
    print(f"wrote {args.output}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
