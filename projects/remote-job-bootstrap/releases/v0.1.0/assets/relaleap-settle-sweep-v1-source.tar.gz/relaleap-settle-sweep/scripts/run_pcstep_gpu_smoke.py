#!/usr/bin/env python3
"""One-step, replayable CUDA smoke for ``clean_room_transformer_epc_v1``.

This is an engineering check, not a training run or an efficacy evaluation.
It uses the pinned GPT-2 teacher and the frozen six-layer student shape, then
verifies that ``pc_step`` settles with frozen parameters and replays exactly.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, GPT2Config, GPT2LMHeadModel

from relaleap.hdpc.pcstep_adapter import (
    PCStepBatch,
    capture_snapshot,
    model_digest,
    pc_step,
    restore_snapshot,
    snapshot_bytes,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--revision", required=True)
    parser.add_argument("--seed", type=int, default=1729)
    parser.add_argument("--sequence-length", type=int, default=16)
    args = parser.parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for this smoke")
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    device = torch.device("cuda")
    teacher = AutoModelForCausalLM.from_pretrained(
        "openai-community/gpt2", revision=args.revision,
    ).to(device).eval()
    for parameter in teacher.parameters():
        parameter.requires_grad_(False)
    config = GPT2Config(
        vocab_size=50257, n_positions=256, n_ctx=256, n_embd=768,
        n_layer=6, n_head=12, n_inner=3072, use_cache=False,
        resid_pdrop=0.0, embd_pdrop=0.0, attn_pdrop=0.0,
    )
    student = GPT2LMHeadModel(config).to(device).train()
    optimizer = torch.optim.AdamW(student.parameters(), lr=1e-4, weight_decay=0.01)
    tokens = torch.randint(config.vocab_size, (1, args.sequence_length), device=device)
    with torch.no_grad():
        teacher_logits = teacher(tokens, use_cache=False).logits
    batch = PCStepBatch(tokens=tokens, teacher_logits=teacher_logits, cursor=0)
    initial = capture_snapshot(student, optimizer, outer_step=0, batch_cursor=0)
    before = model_digest(student)
    gate = {index: True for index in range(config.n_layer)}
    first = pc_step(student, optimizer, batch, gate=gate, steps=1, temperature=2.0)
    if first.settled_parameter_digest != before:
        raise AssertionError("parameters changed during settlement")
    first_snapshot = snapshot_bytes(first.snapshot)
    restore_snapshot(student, optimizer, initial)
    second = pc_step(student, optimizer, batch, gate=gate, steps=1, temperature=2.0)
    replay_exact = first_snapshot == snapshot_bytes(second.snapshot)
    if not replay_exact:
        raise AssertionError("snapshot replay was not byte-identical")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps({
        "schema": "relaleap.clean_room_transformer_epc_gpu_smoke.v1",
        "status": "passed",
        "seed": args.seed,
        "device": torch.cuda.get_device_name(device),
        "torch": torch.__version__,
        "student": {"layers": config.n_layer, "d_model": config.n_embd,
                    "parameters": sum(p.numel() for p in student.parameters())},
        "teacher_parameters": sum(p.numel() for p in teacher.parameters()),
        "objective": first.objective,
        "energy_history": first.energy_history,
        "settlement_frozen": True,
        "replay_exact": replay_exact,
        "peak_cuda_bytes": int(torch.cuda.max_memory_allocated(device)),
    }, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
