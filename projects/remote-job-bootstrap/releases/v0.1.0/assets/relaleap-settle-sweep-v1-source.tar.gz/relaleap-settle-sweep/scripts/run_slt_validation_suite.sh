#!/usr/bin/env bash
set -euo pipefail

PYTHON_BIN="${PYTHON:-python3}"
if [[ -x ".venv/bin/python" ]]; then
  PYTHON_BIN=".venv/bin/python"
fi
export PYTHONPATH="src${PYTHONPATH:+:${PYTHONPATH}}"
"${PYTHON_BIN}" -m relaleap.experiments.slt_estimator_validation
"${PYTHON_BIN}" -m pytest tests/test_slt_interfaces.py "$@"
