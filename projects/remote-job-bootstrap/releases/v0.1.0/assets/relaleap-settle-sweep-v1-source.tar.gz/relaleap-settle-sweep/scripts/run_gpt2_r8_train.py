#!/usr/bin/env python3
"""Train the frozen five-seed r8 BP/KD/ePC checkpoint matrix."""
from __future__ import annotations

import argparse
import copy
import json
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from relaleap.hdpc.gpt2_adapter import build_hf_gpt2_models
from relaleap.hdpc.pilot_protocol import load_pilot_protocol
from run_gpt2_pilot_gpu import _prepare_data, run_arm


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--source-commit", required=True)
    parser.add_argument("--offline", action="store_true")
    args = parser.parse_args()
    protocol = load_pilot_protocol(args.protocol)
    device = torch.device(args.device)
    args.output.mkdir(parents=True, exist_ok=True)

    from transformers import AutoTokenizer
    teacher, template = build_hf_gpt2_models(protocol, local_files_only=True)
    del template
    teacher.to(device).eval()
    for parameter in teacher.parameters():
        parameter.requires_grad_(False)
    tokenizer = AutoTokenizer.from_pretrained(
        protocol["teacher"]["model_id"], revision=protocol["teacher"]["revision"],
        local_files_only=True,
    )
    train_iter_fn, eval_segments, eval_manifests = _prepare_data(protocol, tokenizer, device)
    records = []
    variants = protocol["r8"]["epc_variants"]

    for seed in protocol["evaluation"]["seeds"]:
        torch.manual_seed(seed)
        _, initial = build_hf_gpt2_models(protocol, local_files_only=True)
        init_state = {name: value.clone() for name, value in initial.state_dict().items()}
        del initial
        seed_records = {}
        for arm in protocol["controls"]["primary"]:
            arm_protocol = copy.deepcopy(protocol)
            if arm in variants:
                arm_protocol["epc"]["state_count_including_feedforward"] = variants[arm]
            print(f"R8 seed={seed} arm={arm}", flush=True)
            record = run_arm(
                arm_protocol, seed, arm, init_state, teacher, train_iter_fn,
                eval_segments[seed], device,
                checkpoint_dir=args.output / "checkpoints" / f"seed{seed}_{arm}",
            )
            record.update(source_commit=args.source_commit,
                          match_type="update_matched",
                          evaluation_manifest=eval_manifests[seed])
            (args.output / f"seed{seed}_{arm}.json").write_text(
                json.dumps(record, indent=2, sort_keys=True) + "\n"
            )
            records.append(record)
            seed_records[arm] = record
            if device.type == "cuda":
                torch.cuda.empty_cache()

        budget = seed_records["epc_original"]["elapsed_seconds"]
        print(f"R8 seed={seed} arm=bp_kd_wallclock budget={budget:.1f}s", flush=True)
        wall = run_arm(
            protocol, seed, "bp_kd", init_state, teacher, train_iter_fn,
            eval_segments[seed], device, elapsed_budget_seconds=budget,
        )
        wall["arm"] = "bp_kd_wallclock"
        wall.update(source_commit=args.source_commit, match_type="wall_clock_matched",
                    wall_clock_budget_seconds=budget,
                    evaluation_manifest=eval_manifests[seed])
        (args.output / f"seed{seed}_bp_kd_wallclock.json").write_text(
            json.dumps(wall, indent=2, sort_keys=True) + "\n"
        )
        records.append(wall)

    summary = {
        "schema": "relaleap.epc_r8_train.v1",
        "source_commit": args.source_commit,
        "seeds": protocol["evaluation"]["seeds"],
        "arms": ["bp_ce", "bp_kd", "epc_original", "epc_deep", "bp_kd_wallclock"],
        "records": [{key: row[key] for key in (
            "seed", "arm", "update_count", "elapsed_seconds", "student_val_loss",
            "student_val_perplexity", "kd_gap_nats", "activity_energy_monotone"
        )} for row in records],
    }
    (args.output / "training_summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
