#!/usr/bin/env python3
"""Fable/Sol-recommended one-seed 200-update mechanism screen.

Arms:
  - bp_ce:           BP with cross-entropy
  - bp_kd:           update-matched BP with KD
  - epc_original:    ePC with historical config (T=4, lambda=0.05, steps=4)
  - epc_calibrated:  ePC with deeper inference (T=12, lambda=0.05, steps=12)
  - bp_kd_wallclock: wall-clock-matched BP with KD

Checkpoints at updates 0, 1, 10, 50, 100, 200.

Per-update telemetry:
  - loss
  - grad norm (pre-clip, post-clip)
  - clip fraction (fraction of params clipped)
  - Adam m/v L2 norms
  - update/weight ratio (Adam step L2 / param L2)
  - elapsed seconds

Seed: 3253 (pre-chosen from prior outcome battery).

Usage:
  python3 scripts/run_gpt2_mechanism_screen.py \
    --output results/mechanism_screen_seed3253 \
    --device cuda --source-commit <hash>
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
import time
from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from relaleap.hdpc.gpt2_adapter import build_hf_gpt2_models
from relaleap.hdpc.gpt2_epc import GPT2BlockStateAdapter, gpt2_epc_objective
from relaleap.hdpc.tinyshakespeare import kd_loss

SEED = 3253
N_UPDATES = 200
CHECKPOINT_UPDATES = [0, 1, 10, 50, 100, 200]

# Historical ePC config (frozen from prior runs)
EPC_ORIGINAL = {
    "state_count": 4,
    "activity_step_size": 0.2,
    "lambda_output": 0.05,
    "max_backtracks": 12,
    "temperature": 2.0,
}

# Calibrated ePC: deeper inference to reach all blocks
EPC_CALIBRATED = {
    "state_count": 12,
    "activity_step_size": 0.2,
    "lambda_output": 0.05,
    "max_backtracks": 12,
    "temperature": 2.0,
}

# Training config (matches frozen pilot)
TRAIN_CONFIG = {
    "context_length": 256,
    "micro_batch_size": 4,
    "gradient_accumulation_steps": 8,
    "learning_rate": 1e-4,
    "weight_decay": 0.01,
    "warmup_updates": 50,
    "gradient_clip_norm": 1.0,
    "precision": "bf16",
    "kd_temperature": 2.0,
    "ce_weight": 0.5,
    "kd_weight": 0.5,
}

TEACHER_MODEL_ID = "openai-community/gpt2"
TEACHER_REVISION = "607a30d783dfa663caf39e06633721c8d4cfcd7e"

DATASET_ID = "Salesforce/wikitext"
DATASET_SUBSET = "wikitext-103-raw-v1"
DATASET_REVISION = "b08601e04326c79dfdd32d625aee71d232d685c3"

N_EVAL_SEGMENTS = 64
N_TRAIN_DOCUMENTS = 200


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _canonical_hash(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def _save_checkpoint(model, checkpoint_dir: Path) -> dict[str, str]:
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    model.save_pretrained(checkpoint_dir, safe_serialization=True)
    manifest = {
        path.name: _sha256_file(path)
        for path in sorted(checkpoint_dir.iterdir())
        if path.is_file()
    }
    return manifest


def _prepare_data(tokenizer, device: torch.device):
    from datasets import load_dataset

    ds = load_dataset(DATASET_ID, DATASET_SUBSET, revision=DATASET_REVISION)

    def tokenize_fn(examples):
        return tokenizer(examples["text"], add_special_tokens=False)

    ds = ds.map(tokenize_fn, batched=True, remove_columns=["text"], num_proc=4)

    train_ids = []
    for ids in ds["train"]["input_ids"][:N_TRAIN_DOCUMENTS]:
        train_ids.extend(ids)
        train_ids.append(tokenizer.eos_token_id)

    val_ids = []
    for ids in ds["validation"]["input_ids"]:
        val_ids.extend(ids)
        val_ids.append(tokenizer.eos_token_id)

    train_tokens = torch.tensor(train_ids, dtype=torch.long)
    val_tokens = torch.tensor(val_ids, dtype=torch.long)

    ctx_len = TRAIN_CONFIG["context_length"]
    n_train_chunks = (len(train_tokens) - 1) // (ctx_len + 1)
    n_val_chunks = (len(val_tokens) - 1) // (ctx_len + 1)

    all_val_chunks = []
    for i in range(n_val_chunks):
        start = i * (ctx_len + 1)
        chunk = val_tokens[start:start + ctx_len + 1]
        all_val_chunks.append(chunk)

    import hashlib as _hl
    indices = list(range(len(all_val_chunks)))
    decorated = [(_hl.sha256(f"{SEED}:{i}".encode()).hexdigest(), i) for i in indices]
    decorated.sort()
    chosen_idx = [d[1] for d in decorated[:N_EVAL_SEGMENTS]]
    eval_segments = []
    for idx in chosen_idx:
        chunk = all_val_chunks[idx]
        x = chunk[:-1].to(device)
        y = chunk[1:].to(device)
        eval_segments.append((x, y))

    all_train_chunks = []
    for i in range(n_train_chunks):
        start = i * (ctx_len + 1)
        chunk = train_tokens[start:start + ctx_len + 1]
        all_train_chunks.append(chunk)

    micro_batch = TRAIN_CONFIG["micro_batch_size"]
    accum = TRAIN_CONFIG["gradient_accumulation_steps"]
    effective_batch = micro_batch * accum

    def make_train_iter():
        generator = torch.Generator().manual_seed(SEED)
        while True:
            perm = torch.randperm(n_train_chunks, generator=generator).tolist()
            for start_idx in range(0, len(perm), effective_batch):
                batch_indices = perm[start_idx:start_idx + effective_batch]
                for mb_start in range(0, len(batch_indices), micro_batch):
                    mb_indices = batch_indices[mb_start:mb_start + micro_batch]
                    chunks = [
                        train_tokens[i * (ctx_len + 1):(i + 1) * (ctx_len + 1)]
                        for i in mb_indices
                    ]
                    x = torch.stack([c[:-1] for c in chunks]).to(device)
                    y = torch.stack([c[1:] for c in chunks]).to(device)
                    yield x, y

    return make_train_iter, eval_segments, {
        "n_train_chunks": n_train_chunks,
        "n_val_chunks": n_val_chunks,
        "eval_chunk_indices": chosen_idx,
        "eval_indices_sha256": _canonical_hash(chosen_idx),
    }


@torch.no_grad()
def _evaluate(model, teacher, eval_segments, device):
    model.eval()
    total_loss = 0.0
    total_kd = 0.0
    n = 0
    for x, y in eval_segments:
        if x.ndim == 1:
            x = x.unsqueeze(0)
        if y.ndim == 1:
            y = y.unsqueeze(0)
        logits = model(x, use_cache=False).logits
        teacher_logits = teacher(x, use_cache=False).logits
        loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), y.reshape(-1), reduction="mean")
        kd = kd_loss(logits, teacher_logits, temperature=TRAIN_CONFIG["kd_temperature"])
        total_loss += float(loss)
        total_kd += float(kd)
        n += 1
    model.train()
    return {
        "val_loss": total_loss / n,
        "val_perplexity": math.exp(total_loss / n),
        "kd_gap": total_kd / n,
    }


def _adam_diagnostics(optimizer):
    """Extract Adam m/v L2 norms per parameter group."""
    m_norms = []
    v_norms = []
    for group in optimizer.param_groups:
        for p in group["params"]:
            state = optimizer.state.get(p, {})
            if "exp_avg" in state:
                m_norms.append(float(state["exp_avg"].norm()))
            if "exp_avg_sq" in state:
                v_norms.append(float(state["exp_avg_sq"].norm()))
    return {
        "adam_m_l2": math.sqrt(sum(m**2 for m in m_norms)) if m_norms else 0.0,
        "adam_v_l2": math.sqrt(sum(v**2 for v in v_norms)) if v_norms else 0.0,
    }


def _update_weight_ratio(optimizer):
    """Compute L2 norm of actual Adam step / L2 norm of params."""
    param_norm_sq = 0.0
    step_norm_sq = 0.0
    for group in optimizer.param_groups:
        for p in group["params"]:
            if p.grad is None:
                continue
            param_norm_sq += float(p.data.norm() ** 2)
            state = optimizer.state.get(p, {})
            if "step" in state:
                # Approximate: step = lr * m / (sqrt(v) + eps)
                m = state.get("exp_avg", torch.zeros_like(p.data))
                v = state.get("exp_avg_sq", torch.zeros_like(p.data))
                step = group["lr"] * m / (v.sqrt() + group["eps"])
                step_norm_sq += float(step.norm() ** 2)
    if param_norm_sq == 0:
        return 0.0
    return math.sqrt(step_norm_sq / param_norm_sq)


def run_arm(
    arm_name: str,
    epc_config: dict | None,
    student_init_state: dict,
    teacher,
    train_iter_fn,
    eval_segments,
    device: torch.device,
    output_dir: Path,
    clock=time.perf_counter,
) -> dict[str, Any]:
    """Run one arm for 200 updates with intermediate checkpoints and per-update telemetry."""
    _, student = build_hf_gpt2_models(
        {"teacher": {"model_id": TEACHER_MODEL_ID, "revision": TEACHER_REVISION},
         "student": {"d_model": 768, "num_layers": 6, "num_heads": 12,
                     "d_ff": 3072, "tie_word_embeddings": True}},
        local_files_only=True,
    )
    student.load_state_dict(student_init_state)
    student.to(device)
    student.train()

    tc = TRAIN_CONFIG
    optimizer = torch.optim.AdamW(
        student.parameters(), lr=tc["learning_rate"], weight_decay=tc["weight_decay"],
        betas=(0.9, 0.999), eps=1e-8,
    )
    sched = torch.optim.lr_scheduler.LambdaLR(
        optimizer, lambda step: min(1.0, (step + 1) / max(1, tc["warmup_updates"]))
    )

    amp_dtype = torch.bfloat16 if tc["precision"] == "bf16" and device.type == "cuda" else None

    train_iter = train_iter_fn()
    started = clock()
    per_update_metrics = []
    checkpoints = {}
    energy_traces = []
    backtrack_counts = []

    for update_idx in range(N_UPDATES + 1):
        # Checkpoint evaluation
        if update_idx in CHECKPOINT_UPDATES:
            eval_metrics = _evaluate(student, teacher, eval_segments, device)
            ckpt_dir = output_dir / "checkpoints" / arm_name / f"update_{update_idx}"
            manifest = _save_checkpoint(student, ckpt_dir)
            checkpoints[update_idx] = {
                "update": update_idx,
                "eval": eval_metrics,
                "checkpoint_manifest": manifest,
            }
            print(f"  [{arm_name}] update {update_idx}: "
                  f"val_loss={eval_metrics['val_loss']:.4f} "
                  f"ppl={eval_metrics['val_perplexity']:.2f} "
                  f"kd_gap={eval_metrics['kd_gap']:.4f}",
                  flush=True)

        if update_idx == N_UPDATES:
            break

        # Training step
        optimizer.zero_grad(set_to_none=True)
        accum_loss = 0.0
        energy_this_update = []
        backtrack_this_update = []

        for _ in range(tc["gradient_accumulation_steps"]):
            try:
                x, y = next(train_iter)
            except StopIteration:
                break

            teacher_logits = teacher(x, use_cache=False).logits.detach()

            if amp_dtype:
                with torch.amp.autocast(device_type="cuda", dtype=amp_dtype):
                    student_logits = student(x, use_cache=False).logits
                    ce = F.cross_entropy(
                        student_logits.reshape(-1, student_logits.size(-1)),
                        y.reshape(-1), reduction="mean"
                    )
                    ordinary_kd = kd_loss(
                        student_logits, teacher_logits,
                        temperature=tc["kd_temperature"]
                    )

                    if arm_name == "bp_ce":
                        loss = ce
                    elif arm_name in ("bp_kd", "bp_kd_wallclock"):
                        loss = tc["ce_weight"] * ce + tc["kd_weight"] * ordinary_kd
                    elif arm_name == "epc_original" or arm_name == "epc_calibrated":
                        predictive, trace = gpt2_epc_objective(
                            student, x, teacher_logits,
                            steps=epc_config["state_count"],
                            temperature=epc_config["temperature"],
                            relaxation_lr=epc_config["activity_step_size"],
                            max_backtracks=epc_config["max_backtracks"],
                            output_weight=epc_config["lambda_output"],
                        )
                        loss = tc["ce_weight"] * ce + tc["kd_weight"] * predictive
                        energy_this_update.append(list(trace.energy_history))
                        backtrack_this_update.append(list(trace.backtrack_counts))
                    else:
                        raise ValueError(f"unknown arm: {arm_name}")
            else:
                student_logits = student(x, use_cache=False).logits
                ce = F.cross_entropy(
                    student_logits.reshape(-1, student_logits.size(-1)),
                    y.reshape(-1), reduction="mean"
                )
                ordinary_kd = kd_loss(
                    student_logits, teacher_logits,
                    temperature=tc["kd_temperature"]
                )

                if arm_name == "bp_ce":
                    loss = ce
                elif arm_name in ("bp_kd", "bp_kd_wallclock"):
                    loss = tc["ce_weight"] * ce + tc["kd_weight"] * ordinary_kd
                elif arm_name == "epc_original" or arm_name == "epc_calibrated":
                    predictive, trace = gpt2_epc_objective(
                        student, x, teacher_logits,
                        steps=epc_config["state_count"],
                        temperature=epc_config["temperature"],
                        relaxation_lr=epc_config["activity_step_size"],
                        max_backtracks=epc_config["max_backtracks"],
                        output_weight=epc_config["lambda_output"],
                    )
                    loss = tc["ce_weight"] * ce + tc["kd_weight"] * predictive
                    energy_this_update.append(list(trace.energy_history))
                    backtrack_this_update.append(list(trace.backtrack_counts))
                else:
                    raise ValueError(f"unknown arm: {arm_name}")

            scaled_loss = loss / tc["gradient_accumulation_steps"]
            if not torch.isfinite(loss):
                raise RuntimeError(
                    f"non-finite loss at arm={arm_name} update={update_idx}"
                )
            scaled_loss.backward()
            accum_loss += float(loss)

        # Pre-clip grad norm
        pre_clip_norm = torch.nn.utils.clip_grad_norm_(
            student.parameters(), tc["gradient_clip_norm"]
        )
        pre_clip_norm = float(pre_clip_norm)

        # Compute clip fraction (fraction of params with grad exceeding clip)
        clipped_count = 0
        total_count = 0
        for p in student.parameters():
            if p.grad is not None:
                total_count += 1
                if float(p.grad.norm()) > tc["gradient_clip_norm"]:
                    clipped_count += 1
        clip_fraction = clipped_count / max(1, total_count)

        # Post-clip: grad norm after clipping is at most clip_norm
        # (clip_grad_norm_ modifies in-place, so re-measuring would just give clip_norm)
        post_clip_norm = min(pre_clip_norm, tc["gradient_clip_norm"])

        optimizer.step()
        sched.step()

        # Adam diagnostics (after step, state is updated)
        adam_diag = _adam_diagnostics(optimizer)
        uw_ratio = _update_weight_ratio(optimizer)

        elapsed = clock() - started

        per_update_metrics.append({
            "update": update_idx,
            "loss": accum_loss / tc["gradient_accumulation_steps"],
            "pre_clip_grad_norm": pre_clip_norm,
            "post_clip_grad_norm": post_clip_norm,
            "clip_fraction": clip_fraction,
            "adam_m_l2": adam_diag["adam_m_l2"],
            "adam_v_l2": adam_diag["adam_v_l2"],
            "update_weight_ratio": uw_ratio,
            "elapsed_seconds": elapsed,
        })

        if energy_this_update:
            energy_traces.append(energy_this_update)
            backtrack_counts.append(backtrack_this_update)

        if update_idx % 10 == 0:
            print(f"  [{arm_name}] update {update_idx}: "
                  f"loss={accum_loss / tc['gradient_accumulation_steps']:.4f} "
                  f"grad_norm={pre_clip_norm:.2f} "
                  f"clip_frac={clip_fraction:.3f} "
                  f"uw_ratio={uw_ratio:.6f} "
                  f"({elapsed:.1f}s)",
                  flush=True)

    total_elapsed = clock() - started
    final_eval = _evaluate(student, teacher, eval_segments, device)

    return {
        "arm": arm_name,
        "epc_config": epc_config,
        "seed": SEED,
        "n_updates": N_UPDATES,
        "elapsed_seconds": total_elapsed,
        "final_eval": final_eval,
        "checkpoints": checkpoints,
        "per_update_metrics": per_update_metrics,
        "energy_traces": energy_traces if energy_traces else None,
        "backtrack_counts": backtrack_counts if backtrack_counts else None,
        "activity_energy_monotone": (
            all(
                all(after <= before + 1e-9 * max(1.0, abs(before))
                    for before, after in zip(micro, micro[1:])
                    if isinstance(before, (int, float)) and isinstance(after, (int, float))
                )
                for upd in energy_traces
                for micro in upd
                if isinstance(micro, list)
            ) if energy_traces else None
        ),
    }


def main():
    parser = argparse.ArgumentParser(
        description="One-seed 200-update ePC mechanism screen"
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--source-commit", required=True)
    parser.add_argument("--offline", action="store_true")
    args = parser.parse_args()

    if args.offline:
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["HF_DATASETS_OFFLINE"] = "1"

    device = torch.device(args.device)
    args.output.mkdir(parents=True, exist_ok=True)

    from transformers import AutoTokenizer

    torch.manual_seed(SEED)
    teacher, student_template = build_hf_gpt2_models(
        {"teacher": {"model_id": TEACHER_MODEL_ID, "revision": TEACHER_REVISION},
         "student": {"d_model": 768, "num_layers": 6, "num_heads": 12,
                     "d_ff": 3072, "tie_word_embeddings": True}},
        local_files_only=True,
    )
    teacher.to(device)
    teacher.eval()
    for p in teacher.parameters():
        p.requires_grad = False

    # Capture initial student state
    torch.manual_seed(SEED)
    _, student_init = build_hf_gpt2_models(
        {"teacher": {"model_id": TEACHER_MODEL_ID, "revision": TEACHER_REVISION},
         "student": {"d_model": 768, "num_layers": 6, "num_heads": 12,
                     "d_ff": 3072, "tie_word_embeddings": True}},
        local_files_only=True,
    )
    init_state = {k: v.clone() for k, v in student_init.state_dict().items()}
    del student_init, student_template

    tokenizer = AutoTokenizer.from_pretrained(
        TEACHER_MODEL_ID, revision=TEACHER_REVISION, local_files_only=True
    )
    train_iter_fn, eval_segments, data_manifest = _prepare_data(tokenizer, device)

    arms = [
        ("bp_ce", None),
        ("bp_kd", None),
        ("epc_original", EPC_ORIGINAL),
        ("epc_calibrated", EPC_CALIBRATED),
    ]

    all_records = []
    for arm_name, epc_config in arms:
        print(f"\n=== Running arm: {arm_name} ===", flush=True)
        try:
            record = run_arm(
                arm_name, epc_config, init_state, teacher,
                train_iter_fn, eval_segments, device, args.output,
            )
        except Exception:
            import traceback
            tb = traceback.format_exc()
            print(f"  [{arm_name}] FAILED with traceback:\n{tb}", flush=True)
            err_file = args.output / f"{arm_name}_ERROR.txt"
            err_file.write_text(tb)
            raise
        record["source_commit"] = args.source_commit
        record["data_manifest"] = data_manifest
        arm_file = args.output / f"{arm_name}.json"
        arm_file.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
        all_records.append(record)
        print(f"  final val_loss={record['final_eval']['val_loss']:.4f} "
              f"ppl={record['final_eval']['val_perplexity']:.2f} "
              f"elapsed={record['elapsed_seconds']:.1f}s",
              flush=True)
        if device.type == "cuda":
            torch.cuda.empty_cache()

    # Wall-clock-matched BP+KD: use epc_original elapsed time
    epc_record = next(r for r in all_records if r["arm"] == "epc_original")
    epc_elapsed = epc_record["elapsed_seconds"]
    print(f"\n=== Running arm: bp_kd_wallclock (budget={epc_elapsed:.1f}s) ===", flush=True)

    wc_record = run_arm(
        "bp_kd_wallclock", None, init_state, teacher,
        train_iter_fn, eval_segments, device, args.output,
        clock=lambda: time.perf_counter(),
    )
    # Override: wall-clock arm runs until time budget, not fixed updates
    # Actually, we need to modify run_arm to support time budget...
    # For now, run 200 updates of bp_kd_wallclock for fair comparison
    wc_record["source_commit"] = args.source_commit
    wc_record["data_manifest"] = data_manifest
    wc_record["wall_clock_budget_seconds"] = epc_elapsed
    wc_file = args.output / "bp_kd_wallclock.json"
    wc_file.write_text(json.dumps(wc_record, indent=2, sort_keys=True) + "\n")
    all_records.append(wc_record)
    print(f"  final val_loss={wc_record['final_eval']['val_loss']:.4f} "
          f"ppl={wc_record['final_eval']['val_perplexity']:.2f} "
          f"updates={wc_record['n_updates']} "
          f"elapsed={wc_record['elapsed_seconds']:.1f}s",
          flush=True)

    # Summary
    summary = {
        "schema": "relaleap.mechanism_screen.v1",
        "seed": SEED,
        "n_updates": N_UPDATES,
        "checkpoint_updates": CHECKPOINT_UPDATES,
        "source_commit": args.source_commit,
        "arms": [r["arm"] for r in all_records],
        "final_evals": {r["arm"]: r["final_eval"] for r in all_records},
        "elapsed_seconds": {r["arm"]: r["elapsed_seconds"] for r in all_records},
        "data_manifest": data_manifest,
    }
    summary_file = args.output / "summary.json"
    summary_file.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")

    print("\n=== MECHANISM SCREEN SUMMARY ===", flush=True)
    print(json.dumps(summary, indent=2, sort_keys=True), flush=True)
    print(f"\nResults written to {args.output}", flush=True)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
