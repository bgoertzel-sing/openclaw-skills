#!/usr/bin/env python3
"""Evaluate frozen six-layer GPT-2 BP/KD/ePC checkpoints on a real shift."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F
from torch import nn
from torch.nn.utils import parametrize


def _canonical_hash(value: Any) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(payload).hexdigest()


def _validate_config(config: dict[str, Any]) -> None:
    if config.get("schema") != "relaleap.gpt2_epc_outcome.v1":
        raise ValueError("unexpected outcome protocol schema")
    if config.get("status") != "frozen_pre_run":
        raise ValueError("outcome protocol must be frozen before execution")
    if config.get("student_layers") != 6:
        raise ValueError("this gate is frozen for the six-layer student")
    if len(config.get("seeds", ())) < 3:
        raise ValueError("at least three seeds are required")
    adaptation = config["adaptation"]
    if adaptation["evaluation_updates"][0] != 0:
        raise ValueError("adaptation curve must include the unadapted checkpoint")
    if adaptation["evaluation_updates"][-1] != adaptation["updates"]:
        raise ValueError("adaptation curve must include the final update")


class _LowRankDelta(nn.Module):
    def __init__(self, shape: torch.Size, rank: int, alpha: float) -> None:
        super().__init__()
        if len(shape) != 2 or rank <= 0:
            raise ValueError("low-rank adaptation requires a matrix and positive rank")
        self.a = nn.Parameter(torch.empty(shape[0], rank))
        self.b = nn.Parameter(torch.zeros(rank, shape[1]))
        nn.init.normal_(self.a, std=0.02)
        self.scale = alpha / rank

    def forward(self, original: torch.Tensor) -> torch.Tensor:
        return original + self.scale * (self.a @ self.b)


def _attach_low_rank(model: nn.Module, locations: list[str], rank: int, alpha: float) -> int:
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    attached = 0
    for name, module in model.named_modules():
        if any(name.endswith(location) for location in locations):
            if not hasattr(module, "weight") or module.weight.ndim != 2:
                raise ValueError(f"unsupported adapter target: {name}")
            parametrize.register_parametrization(
                module, "weight", _LowRankDelta(module.weight.shape, rank, alpha)
            )
            attached += 1
    if attached == 0:
        raise ValueError("no low-rank adapter locations matched")
    return attached


def _documents_to_tokens(dataset, tokenizer, count: int) -> torch.Tensor:
    count = min(count, len(dataset))
    token_ids: list[int] = []
    for text in dataset.select(range(count))["text"]:
        if text:
            token_ids.extend(tokenizer(text, add_special_tokens=False)["input_ids"])
            token_ids.append(tokenizer.eos_token_id)
    if not token_ids:
        raise ValueError("dataset slice produced no tokens")
    return torch.tensor(token_ids, dtype=torch.long)


def _chunks(tokens: torch.Tensor, context_length: int) -> list[torch.Tensor]:
    width = context_length + 1
    return [tokens[start:start + width] for start in range(0, len(tokens) - width, width)]


def _select_chunks(chunks: list[torch.Tensor], count: int, seed: int) -> tuple[list[torch.Tensor], list[int]]:
    ranked = sorted(
        range(len(chunks)),
        key=lambda index: hashlib.sha256(f"{seed}:{index}".encode()).digest(),
    )
    indices = ranked[:count]
    if len(indices) != count:
        raise ValueError("insufficient dataset chunks for frozen probe")
    return [chunks[index] for index in indices], indices


def _batch(chunks: list[torch.Tensor], device: torch.device) -> tuple[torch.Tensor, torch.Tensor]:
    stacked = torch.stack(chunks).to(device)
    return stacked[:, :-1], stacked[:, 1:]


@torch.no_grad()
def _loss_vector(model, chunks: list[torch.Tensor], device: torch.device, batch_size: int = 4) -> list[float]:
    model.eval()
    losses: list[float] = []
    for start in range(0, len(chunks), batch_size):
        x, y = _batch(chunks[start:start + batch_size], device)
        logits = model(x, use_cache=False).logits
        token_losses = F.cross_entropy(
            logits.transpose(1, 2), y, reduction="none"
        ).mean(dim=1)
        losses.extend(float(value) for value in token_losses)
    return losses


def _mean_loss(model, chunks: list[torch.Tensor], device: torch.device, batch_size: int = 4) -> float:
    losses = _loss_vector(model, chunks, device, batch_size)
    return sum(losses) / len(losses)


@torch.no_grad()
def _hidden_states(model, chunks: list[torch.Tensor], device: torch.device) -> list[torch.Tensor]:
    collected: list[list[torch.Tensor]] = []
    for chunk in chunks:
        x, _ = _batch([chunk], device)
        states = model(x, use_cache=False, output_hidden_states=True).hidden_states[1:]
        if not collected:
            collected = [[] for _ in states]
        for destination, state in zip(collected, states):
            destination.append(state.detach().cpu())
    return [torch.cat(values, dim=0) for values in collected]


def _linear_cka(left: torch.Tensor, right: torch.Tensor) -> float:
    x = left.double().reshape(-1, left.shape[-1])
    y = right.double().reshape(-1, right.shape[-1])
    x, y = x - x.mean(0), y - y.mean(0)
    denominator = torch.linalg.matrix_norm(x.T @ x) * torch.linalg.matrix_norm(y.T @ y)
    if denominator <= 0:
        raise ValueError("CKA is undefined for constant activations")
    return float((torch.linalg.matrix_norm(x.T @ y).square() / denominator).clamp(0, 1))


def _spectral_summary(values: torch.Tensor) -> dict[str, float]:
    matrix = values.double().reshape(-1, values.shape[-1])
    matrix = matrix - matrix.mean(0)
    eigenvalues = torch.linalg.svdvals(matrix).square()
    probabilities = eigenvalues / eigenvalues.sum()
    nonzero = probabilities[probabilities > 0]
    return {
        "effective_rank": float(torch.exp(-(nonzero * nonzero.log()).sum())),
        "participation_ratio": float(eigenvalues.sum().square() / eigenvalues.square().sum()),
    }


@torch.no_grad()
def _block_skip_losses(model, chunks, device) -> list[float]:
    baseline = _mean_loss(model, chunks, device)
    results = []
    for block in model.transformer.h:
        def skip(_module, inputs, output):
            return (inputs[0], *output[1:]) if isinstance(output, tuple) else inputs[0]
        handle = block.register_forward_hook(skip)
        try:
            results.append(_mean_loss(model, chunks, device) - baseline)
        finally:
            handle.remove()
    return results


def _corrupt(chunks: list[torch.Tensor], vocab_size: int, probability: float, seed: int) -> list[torch.Tensor]:
    generator = torch.Generator().manual_seed(seed)
    result = []
    for chunk in chunks:
        changed = chunk.clone()
        mask = torch.rand(changed[:-1].shape, generator=generator) < probability
        replacement = torch.randint(vocab_size, changed[:-1].shape, generator=generator)
        changed[:-1][mask] = replacement[mask]
        result.append(changed)
    return result


def _adapt(model, train_chunks, source_eval, target_eval, config, device) -> list[dict[str, float]]:
    adaptation = config["adaptation"]
    attached = _attach_low_rank(
        model, adaptation["locations"], adaptation["rank"], adaptation["alpha"]
    )
    trainable = [parameter for parameter in model.parameters() if parameter.requires_grad]
    optimizer = torch.optim.AdamW(
        trainable, lr=adaptation["learning_rate"], weight_decay=adaptation["weight_decay"]
    )
    checkpoints = set(adaptation["evaluation_updates"])
    curve = []
    generator = torch.Generator().manual_seed(config["active_seed"] + 9000)
    order = torch.randperm(len(train_chunks), generator=generator).tolist()
    cursor = 0
    for update in range(adaptation["updates"] + 1):
        if update in checkpoints:
            source_segments = _loss_vector(model, source_eval, device)
            target_segments = _loss_vector(model, target_eval, device)
            curve.append({
                "update": update,
                "source_loss": sum(source_segments) / len(source_segments),
                "target_loss": sum(target_segments) / len(target_segments),
                "source_segment_losses": source_segments,
                "target_segment_losses": target_segments,
            })
        if update == adaptation["updates"]:
            break
        model.train()
        optimizer.zero_grad(set_to_none=True)
        for _ in range(adaptation["gradient_accumulation_steps"]):
            size = adaptation["batch_size"]
            if cursor + size > len(order):
                order = torch.randperm(len(train_chunks), generator=generator).tolist()
                cursor = 0
            selected = [train_chunks[index] for index in order[cursor:cursor + size]]
            cursor += size
            x, y = _batch(selected, device)
            logits = model(x, use_cache=False).logits
            loss = F.cross_entropy(logits.reshape(-1, logits.shape[-1]), y.reshape(-1))
            if not torch.isfinite(loss):
                raise RuntimeError("non-finite adapter loss")
            (loss / adaptation["gradient_accumulation_steps"]).backward()
        optimizer.step()
    for row in curve:
        row["adapter_locations"] = attached
    return curve


def _auc(curve: list[dict[str, float]], key: str) -> float:
    area = 0.0
    for left, right in zip(curve, curve[1:]):
        area += (right["update"] - left["update"]) * (left[key] + right[key]) / 2
    return area / curve[-1]["update"]


def _segment_auc(curve: list[dict[str, Any]], key: str, index: int) -> float:
    points = [{"update": row["update"], "loss": row[key][index]} for row in curve]
    return _auc(points, "loss")


def _percentile(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    return ordered[round(probability * (len(ordered) - 1))]


def _evaluate_outcome(rows: list[dict[str, Any]], config: dict[str, Any]) -> dict[str, Any]:
    by_key = {(row["seed"], row["arm"]): row for row in rows}
    expected = {(seed, arm) for seed in config["seeds"] for arm in config["checkpoint_arms"]}
    if set(by_key) != expected:
        raise RuntimeError("missing or duplicate seed/arm outcome rows")
    generator = torch.Generator().manual_seed(20260717)
    contrasts = {}
    for control in ("bp_ce", "bp_kd"):
        draws = []
        for _ in range(config["bootstrap_replicates"]):
            sampled_seed_positions = torch.randint(
                len(config["seeds"]), (len(config["seeds"]),), generator=generator
            ).tolist()
            seed_values = []
            for position in sampled_seed_positions:
                seed = config["seeds"][position]
                control_row, epc_row = by_key[(seed, control)], by_key[(seed, "epc_kd")]
                count = len(control_row["curve"][0]["target_segment_losses"])
                sampled_segments = torch.randint(count, (count,), generator=generator).tolist()
                control_auc = sum(
                    _segment_auc(control_row["curve"], "target_segment_losses", index)
                    for index in sampled_segments
                ) / count
                epc_auc = sum(
                    _segment_auc(epc_row["curve"], "target_segment_losses", index)
                    for index in sampled_segments
                ) / count
                seed_values.append(control_auc - epc_auc)
            draws.append(sum(seed_values) / len(seed_values))
        contrasts[control] = {
            "mean_auc_gain": sum(draws) / len(draws),
            "ci95": [_percentile(draws, 0.025), _percentile(draws, 0.975)],
        }
    epc_rows = [by_key[(seed, "epc_kd")] for seed in config["seeds"]]
    mean_forgetting = sum(row["source_forgetting"] for row in epc_rows) / len(epc_rows)
    max_pre_regression = max(
        by_key[(seed, "epc_kd")]["pre_target_loss"]
        - by_key[(seed, control)]["pre_target_loss"]
        for seed in config["seeds"] for control in ("bp_ce", "bp_kd")
    )
    promotion = config["promotion"]
    passes = (
        all(value["ci95"][0] > 0 for value in contrasts.values())
        and mean_forgetting <= promotion["max_source_forgetting_nats"]
        and max_pre_regression <= promotion["max_pre_adaptation_loss_regression_nats"]
    )
    return {
        "contrasts": contrasts,
        "mean_epc_source_forgetting": mean_forgetting,
        "max_epc_pre_adaptation_regression_nats": max_pre_regression,
        "passes": passes,
        "claim_if_passed": promotion["claim_if_passed"],
    }


def _local_checkpoint(root: Path, seed: int, arm: str) -> Path:
    checkpoint = (root / f"seed{seed}_{arm}").resolve()
    if not checkpoint.is_dir():
        raise FileNotFoundError(f"local checkpoint directory not found: {checkpoint}")
    return checkpoint


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--checkpoints", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--offline", action="store_true")
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    _validate_config(config)
    if args.offline:
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["HF_DATASETS_OFFLINE"] = "1"
    from datasets import load_dataset
    from transformers import AutoModelForCausalLM, AutoTokenizer

    device = torch.device(args.device)
    tokenizer = AutoTokenizer.from_pretrained("openai-community/gpt2", local_files_only=True)
    source_spec, target_spec = config["source_dataset"], config["target_dataset"]
    source = load_dataset(source_spec["id"], source_spec["subset"], revision=source_spec["revision"])
    target = load_dataset(target_spec["id"], target_spec["subset"], revision=target_spec["revision"])
    source_tokens = _documents_to_tokens(
        source[source_spec["validation_split"]], tokenizer, config["source_validation_documents"]
    )
    target_train_tokens = _documents_to_tokens(
        target[target_spec["train_split"]], tokenizer, config["target_train_documents"]
    )
    target_val_tokens = _documents_to_tokens(
        target[target_spec["validation_split"]], tokenizer, config["target_validation_documents"]
    )
    source_chunks = _chunks(source_tokens, config["context_length"])
    target_train_chunks = _chunks(target_train_tokens, config["context_length"])
    target_val_chunks = _chunks(target_val_tokens, config["context_length"])
    rows, comparisons = [], []
    for seed in config["seeds"]:
        source_eval, source_indices = _select_chunks(source_chunks, config["evaluation_segments"], seed)
        target_eval, target_indices = _select_chunks(target_val_chunks, config["evaluation_segments"], seed)
        probe = source_eval[:config["probe_segments"]]
        hidden_by_arm = {}
        for arm in config["checkpoint_arms"]:
            checkpoint = _local_checkpoint(args.checkpoints, seed, arm)
            model = AutoModelForCausalLM.from_pretrained(
                str(checkpoint), local_files_only=True
            ).to(device)
            if model.config.n_layer != config["student_layers"]:
                raise RuntimeError(f"checkpoint depth drift: {checkpoint}")
            hidden = _hidden_states(model, probe, device)
            hidden_by_arm[arm] = hidden
            pre_source = _mean_loss(model, source_eval, device)
            pre_target = _mean_loss(model, target_eval, device)
            probe_source = _mean_loss(model, probe, device)
            corrupted = _corrupt(
                probe, model.config.vocab_size, config["corruption_probability"], seed + 7000
            )
            corruption_delta = _mean_loss(model, corrupted, device) - probe_source
            block_skip_delta = _block_skip_losses(model, probe, device)
            active = dict(config, active_seed=seed)
            curve = _adapt(model, target_train_chunks, source_eval, target_eval, active, device)
            rows.append({
                "seed": seed,
                "arm": arm,
                "pre_source_loss": pre_source,
                "pre_target_loss": pre_target,
                "source_forgetting": curve[-1]["source_loss"] - pre_source,
                "target_adaptation_gain": pre_target - curve[-1]["target_loss"],
                "target_validation_loss_auc": _auc(curve, "target_loss"),
                "curve": curve,
                "spectral_summary": [_spectral_summary(state) for state in hidden],
                "block_skip_delta": block_skip_delta,
                "corruption_delta": corruption_delta,
                "source_indices_sha256": _canonical_hash(source_indices),
                "target_indices_sha256": _canonical_hash(target_indices),
            })
            del model
            if device.type == "cuda":
                torch.cuda.empty_cache()
        for left, right in (("bp_ce", "bp_kd"), ("bp_ce", "epc_kd"), ("bp_kd", "epc_kd")):
            comparisons.append({
                "seed": seed,
                "comparison": f"{left}_vs_{right}",
                "linear_cka": [
                    _linear_cka(a, b) for a, b in zip(hidden_by_arm[left], hidden_by_arm[right])
                ],
            })
    payload = {
        "schema": "relaleap.gpt2_epc_outcome.result.v1",
        "config_sha256": hashlib.sha256(args.config.read_bytes()).hexdigest(),
        "rows": rows,
        "comparisons": comparisons,
        "promotion": _evaluate_outcome(rows, config),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
