#!/usr/bin/env python3
"""Production GPU runner for the frozen GPT-2-small ePC distillation pilot.

This script runs the full frozen protocol on a GPU pod. It:
  - loads and validates the frozen protocol JSON
  - builds pinned teacher and random 6-block student via Hugging Face
  - prepares WikiText-103 training and validation streams
  - runs BP+CE, BP+KD, and ePC+KD arms for each frozen seed
  - runs wall-clock-matched BP+KD after ePC completes
  - emits structured JSON metrics after every arm/seed
  - evaluates against the frozen promotion rule
  - writes a machine-readable summary

Usage:
  python3 scripts/run_gpt2_pilot_gpu.py \
    --protocol configs/gpt2_small_epc_pilot.json \
    --output results/gpt2_small_epc_pilot/<run-id> \
    --device cuda

All outputs are structured for the experiment ledger.  No tuning,
no threshold changes, no post-hoc modifications.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
import time
from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from relaleap.hdpc.pilot_protocol import load_pilot_protocol, validate_pilot_protocol
from relaleap.hdpc.gpt2_adapter import build_hf_gpt2_models
from relaleap.hdpc.gpt2_epc import GPT2BlockStateAdapter, gpt2_epc_objective
from relaleap.hdpc.transformer_epc import TransformerEPCTrace
from relaleap.hdpc.tinyshakespeare import kd_loss

SCHEMA = "relaleap.gpt2_epc_gpu_metrics.v1"


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _canonical_hash(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def _save_checkpoint(model, checkpoint_dir: Path) -> dict[str, str]:
    """Save one auditable, safetensors-backed Hugging Face checkpoint."""
    checkpoint_dir.mkdir(parents=True, exist_ok=False)
    model.save_pretrained(checkpoint_dir, safe_serialization=True)
    manifest = {
        path.name: _sha256_file(path)
        for path in sorted(checkpoint_dir.iterdir())
        if path.is_file()
    }
    if "model.safetensors" not in manifest or "config.json" not in manifest:
        raise RuntimeError("checkpoint is missing model.safetensors or config.json")
    return manifest


def _resolve_device(name: str) -> torch.device:
    if name == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but not available")
    return torch.device(name)


def _prepare_data(protocol: dict, tokenizer, device: torch.device):
    """Prepare WikiText-103 token streams from the pinned revision."""
    from datasets import load_dataset

    dataset_id = protocol["dataset"]["id"]
    subset = protocol["dataset"]["subset"]
    revision = protocol["dataset"]["revision"]

    ds = load_dataset(dataset_id, subset, revision=revision)

    # Batched tokenization via datasets.map for speed (Rust fast tokenizer)
    def tokenize_fn(examples):
        return tokenizer(examples["text"], add_special_tokens=False)
    ds = ds.map(tokenize_fn, batched=True, remove_columns=["text"], num_proc=4)
    train_ids = []
    for ids in ds["train"]["input_ids"]:
        train_ids.extend(ids)
        train_ids.append(tokenizer.eos_token_id)
    val_ids = []
    for ids in ds["validation"]["input_ids"]:
        val_ids.extend(ids)
        val_ids.append(tokenizer.eos_token_id)
    train_tokens = torch.tensor(train_ids, dtype=torch.long)
    val_tokens = torch.tensor(val_ids, dtype=torch.long)

    ctx_len = protocol["training"]["context_length"]
    n_train_chunks = (len(train_tokens) - 1) // (ctx_len + 1)
    n_val_chunks = (len(val_tokens) - 1) // (ctx_len + 1)

    # Deterministic eval set: SHA256(seed || chunk_index) ordering
    seeds = protocol["evaluation"]["seeds"]
    n_eval_segments = protocol["evaluation"]["fixed_validation_segments"]
    eval_segments: dict[int, list[tuple[torch.Tensor, torch.Tensor]]] = {}
    eval_manifests: dict[int, dict[str, Any]] = {}

    all_val_chunks = []
    for i in range(n_val_chunks):
        start = i * (ctx_len + 1)
        chunk = val_tokens[start:start + ctx_len + 1]
        all_val_chunks.append(chunk)

    for seed in seeds:
        indices = list(range(len(all_val_chunks)))
        # Deterministic shuffle by SHA256(seed:idx)
        import hashlib as _hl
        decorated = [(_hl.sha256(f"{seed}:{i}".encode()).hexdigest(), i) for i in indices]
        decorated.sort()
        chosen_idx = [d[1] for d in decorated[:n_eval_segments]]
        segments = []
        for idx in chosen_idx:
            chunk = all_val_chunks[idx]
            x = chunk[:-1].to(device)
            y = chunk[1:].to(device)
            segments.append((x, y))
        eval_segments[seed] = segments
        eval_manifests[seed] = {
            "chunk_indices": chosen_idx,
            "chunk_indices_sha256": _canonical_hash(chosen_idx),
        }

    # Training batches: sequential non-overlapping chunks
    micro_batch = protocol["training"]["micro_batch_size"]
    accum = protocol["training"]["gradient_accumulation_steps"]
    effective_batch = micro_batch * accum

    def make_train_iter(seed: int, n_updates: int | None):
        generator = torch.Generator().manual_seed(seed)
        remaining_chunks = None if n_updates is None else n_updates * effective_batch
        while remaining_chunks is None or remaining_chunks > 0:
            perm = torch.randperm(n_train_chunks, generator=generator).tolist()
            if remaining_chunks is not None:
                perm = perm[:remaining_chunks]
            for start_idx in range(0, len(perm), effective_batch):
                batch_indices = perm[start_idx:start_idx + effective_batch]
                for mb_start in range(0, len(batch_indices), micro_batch):
                    mb_indices = batch_indices[mb_start:mb_start + micro_batch]
                    chunks = [
                        train_tokens[i * (ctx_len + 1):(i + 1) * (ctx_len + 1)]
                        for i in mb_indices
                    ]
                    x = torch.stack([c[:-1] for c in chunks]).to(device)
                    y = torch.stack([c[1:] for c in chunks]).to(device)
                    yield x, y
            if remaining_chunks is not None:
                remaining_chunks -= len(perm)

    return make_train_iter, eval_segments, eval_manifests


def _evaluate(model, teacher, eval_segments, device):
    model.eval()
    with torch.no_grad():
        total_loss = 0.0
        total_kd = 0.0
        n = 0
        for x, y in eval_segments:
            # Evaluation segments are stored as individual [sequence] tensors,
            # while Hugging Face causal language models require
            # [batch, sequence] input IDs. Keep the batch dimension explicit;
            # otherwise GPT-2 receives 2-D hidden states and its lm_head fails.
            if x.ndim == 1:
                x = x.unsqueeze(0)
            if y.ndim == 1:
                y = y.unsqueeze(0)
            if x.ndim != 2 or y.ndim != 2:
                raise ValueError(
                    f"evaluation tensors must be rank 1 or 2, got x={x.ndim}, y={y.ndim}"
                )
            logits = model(x, use_cache=False).logits
            teacher_logits = teacher(x, use_cache=False).logits
            loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), y.reshape(-1), reduction="mean")
            kd = kd_loss(logits, teacher_logits, temperature=2.0)
            total_loss += float(loss)
            total_kd += float(kd)
            n += 1
    model.train()
    return total_loss / n, math.exp(total_loss / n), total_kd / n


def _block_credit_gpt2(adapter: GPT2BlockStateAdapter, tokens, teacher_logits, protocol):
    """Compute per-block credit diagnostics for the GPT-2 ePC arm."""
    ordinary = kd_loss(adapter.forward_states(tokens).logits, teacher_logits, temperature=protocol["training"]["kd_temperature"])
    predictive, trace = gpt2_epc_objective(
        adapter.model, tokens, teacher_logits,
        steps=protocol["epc"]["state_count_including_feedforward"],
        temperature=protocol["training"]["kd_temperature"],
        relaxation_lr=protocol["epc"]["activity_step_size"],
        max_backtracks=protocol["epc"]["max_backtracks"],
        output_weight=protocol["epc"]["lambda_output"],
    )
    # Compute gradient norms for each block under both objectives
    ordinary.backward(retain_graph=True)
    bp_norms = {}
    for name, param in adapter.model.named_parameters():
        if param.grad is not None and name.startswith("transformer.h."):
            block_key = ".".join(name.split(".")[:3])
            bp_norms[block_key] = bp_norms.get(block_key, 0.0) + float(param.grad.norm()) ** 2
    adapter.model.zero_grad()

    predictive.backward()
    epc_norms = {}
    cosines = {}
    for name, param in adapter.model.named_parameters():
        if param.grad is not None and name.startswith("transformer.h."):
            block_key = ".".join(name.split(".")[:3])
            epc_norms[block_key] = epc_norms.get(block_key, 0.0) + float(param.grad.norm()) ** 2
    adapter.model.zero_grad()

    credit = []
    for block_key in sorted(set(list(bp_norms.keys()) + list(epc_norms.keys()))):
        bp = math.sqrt(bp_norms.get(block_key, 0.0))
        epc = math.sqrt(epc_norms.get(block_key, 0.0))
        credit.append({
            "block": block_key,
            "ordinary_kd_norm": bp,
            "epc_norm": epc,
            "norm_ratio": None if bp == 0 else epc / bp,
            "finite": math.isfinite(bp) and math.isfinite(epc),
        })
    return credit, trace


def run_arm(
    protocol: dict,
    seed: int,
    arm: str,
    student_init_state: dict,
    teacher,
    train_iter_fn,
    eval_segments: list,
    device: torch.device,
    *,
    elapsed_budget_seconds: float | None = None,
    checkpoint_dir: Path | None = None,
    clock=time.perf_counter,
) -> dict[str, Any]:
    """Run a single arm for one seed."""
    from relaleap.hdpc.gpt2_adapter import build_hf_gpt2_models

    # Rebuild student with same init
    _, student = build_hf_gpt2_models(protocol, local_files_only=True)
    student.load_state_dict(student_init_state)
    student.to(device)
    student.train()

    training = protocol["training"]
    lr = training["learning_rate"]
    wd = training["weight_decay"]
    warmup = training["warmup_updates"]
    grad_clip = training["gradient_clip_norm"]
    n_updates = training["updates"]
    micro_batch = training["micro_batch_size"]
    accum = training["gradient_accumulation_steps"]
    ce_w = training["ce_weight"]
    kd_w = training["kd_weight"]
    kd_T = training["kd_temperature"]
    precision = training["precision"]

    optimizer = torch.optim.AdamW(student.parameters(), lr=lr, weight_decay=wd)
    sched = torch.optim.lr_scheduler.LambdaLR(optimizer, lambda step: min(1.0, (step + 1) / max(1, warmup)))

    scaler = torch.amp.GradScaler() if precision == "bf16" and device.type == "cuda" else None
    amp_dtype = torch.bfloat16 if precision == "bf16" and device.type == "cuda" else None

    epc_config = protocol["epc"]
    energy_traces = []
    accepted_steps = []
    backtrack_counts = []
    credit = []

    if elapsed_budget_seconds is not None and elapsed_budget_seconds <= 0:
        raise ValueError("elapsed budget must be positive")
    started = clock()
    update_count = 0
    # Update-matched arms stop at the frozen count. The wall-clock control is
    # deliberately not capped there: it consumes batches until the ePC time
    # budget expires, as preregistered.
    train_iter = train_iter_fn(seed, None if elapsed_budget_seconds is not None else n_updates)

    update_idx = 0
    while elapsed_budget_seconds is not None or update_idx < n_updates:
        # The frozen wall-clock rule completes an update already in flight but
        # never starts another after the ePC elapsed-time budget is reached.
        if update_count and elapsed_budget_seconds is not None:
            if clock() - started >= elapsed_budget_seconds:
                break
        optimizer.zero_grad(set_to_none=True)
        accum_loss = 0.0
        for _ in range(accum):
            try:
                x, y = next(train_iter)
            except StopIteration:
                break

            teacher_logits = teacher(x, use_cache=False).logits.detach()

            if amp_dtype:
                with torch.amp.autocast(device_type="cuda", dtype=amp_dtype):
                    student_logits = student(x, use_cache=False).logits
                    ce = F.cross_entropy(student_logits.reshape(-1, student_logits.size(-1)), y.reshape(-1), reduction="mean")
                    ordinary_kd = kd_loss(student_logits, teacher_logits, temperature=kd_T)
                    if arm == "bp_ce":
                        loss = ce
                    elif arm == "bp_kd":
                        loss = ce_w * ce + kd_w * ordinary_kd
                    else:  # epc_kd
                        adapter = GPT2BlockStateAdapter(student)
                        predictive, trace = gpt2_epc_objective(
                            student, x, teacher_logits,
                            steps=epc_config["state_count_including_feedforward"],
                            temperature=kd_T,
                            relaxation_lr=epc_config["activity_step_size"],
                            max_backtracks=epc_config["max_backtracks"],
                            output_weight=epc_config["lambda_output"],
                        )
                        loss = ce_w * ce + kd_w * predictive
                        energy_traces.append(list(trace.energy_history))
                        accepted_steps.append(list(trace.accepted_step_sizes))
                        backtrack_counts.append(list(trace.backtrack_counts))
                        if update_idx == 0:
                            credit, _ = _block_credit_gpt2(adapter, x, teacher_logits, protocol)
            else:
                student_logits = student(x, use_cache=False).logits
                ce = F.cross_entropy(student_logits.reshape(-1, student_logits.size(-1)), y.reshape(-1), reduction="mean")
                ordinary_kd = kd_loss(student_logits, teacher_logits, temperature=kd_T)
                if arm == "bp_ce":
                    loss = ce
                elif arm == "bp_kd":
                    loss = ce_w * ce + kd_w * ordinary_kd
                else:
                    adapter = GPT2BlockStateAdapter(student)
                    predictive, trace = gpt2_epc_objective(
                        student, x, teacher_logits,
                        steps=epc_config["state_count_including_feedforward"],
                        temperature=kd_T,
                        relaxation_lr=epc_config["activity_step_size"],
                        max_backtracks=epc_config["max_backtracks"],
                        output_weight=epc_config["lambda_output"],
                    )
                    loss = ce_w * ce + kd_w * predictive
                    energy_traces.append(list(trace.energy_history))
                    accepted_steps.append(list(trace.accepted_step_sizes))
                    backtrack_counts.append(list(trace.backtrack_counts))
                    if update_idx == 0:
                        credit, _ = _block_credit_gpt2(adapter, x, teacher_logits, protocol)

            scaled_loss = loss / accum
            if not torch.isfinite(loss):
                raise RuntimeError(
                    f"non-finite training loss at seed={seed} arm={arm} update={update_idx}"
                )
            if scaler:
                scaler.scale(scaled_loss).backward()
            else:
                scaled_loss.backward()
            accum_loss += float(loss)

        if scaler:
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(student.parameters(), grad_clip)
            scaler.step(optimizer)
            scaler.update()
        else:
            torch.nn.utils.clip_grad_norm_(student.parameters(), grad_clip)
            optimizer.step()
        sched.step()
        update_count += 1
        update_idx += 1

    elapsed = clock() - started
    student_loss, student_ppl, kd_gap = _evaluate(student, teacher, eval_segments, device)
    # Re-eval teacher properly
    teacher.eval()
    with torch.no_grad():
        t_loss = 0.0
        t_n = 0
        for x, y in eval_segments:
            if x.ndim == 1:
                x = x.unsqueeze(0)
            if y.ndim == 1:
                y = y.unsqueeze(0)
            tl = teacher(x, use_cache=False).logits
            t_loss += float(F.cross_entropy(tl.reshape(-1, tl.size(-1)), y.reshape(-1), reduction="mean"))
            t_n += 1
    teacher_loss = t_loss / max(1, t_n)
    teacher_ppl = math.exp(teacher_loss)

    checkpoint_manifest = (
        _save_checkpoint(student, checkpoint_dir)
        if checkpoint_dir is not None else None
    )
    record = {
        "schema": SCHEMA,
        "mode": "gpu_production",
        "protocol_sha256": _canonical_hash(protocol),
        "seed": seed,
        "arm": arm,
        "update_count": update_count,
        "elapsed_seconds": elapsed,
        "student_val_loss": student_loss,
        "student_val_perplexity": student_ppl,
        "teacher_val_loss": teacher_loss,
        "teacher_val_perplexity": teacher_ppl,
        "kd_gap_nats": kd_gap,
        "credit_assignment": credit,
        "activity_energy_traces": energy_traces,
        "accepted_step_sizes": accepted_steps,
        "backtrack_counts": backtrack_counts,
        "activity_energy_monotone": all(
            all(after <= before + 1e-9 * max(1.0, abs(before))
                for before, after in zip(tr, tr[1:]))
            for tr in energy_traces
        ) if energy_traces else None,
        "device": str(device),
        "precision": precision,
        "checkpoint_dir": None if checkpoint_dir is None else checkpoint_dir.name,
        "checkpoint_manifest": checkpoint_manifest,
    }
    return record


def evaluate_promotion(records: list[dict], protocol: dict) -> dict:
    """Check the frozen promotion rule."""
    promo = protocol["promotion"]
    seeds = protocol["evaluation"]["seeds"]

    epc_records = {r["seed"]: r for r in records if r["arm"] == "epc_kd"}
    kd_by_seed = {
        r["seed"]: r for r in records
        if r["arm"] == "bp_kd" and r.get("match_type") == "update_matched"
    }

    all_checks = {}
    required_keys = {
        (seed, "epc_kd", "update_matched") for seed in seeds
    } | {
        (seed, "bp_kd", "update_matched") for seed in seeds
    } | {
        (seed, "bp_kd", "wall_clock_matched") for seed in seeds
    }
    observed_keys = [
        (r["seed"], r["arm"], r.get("match_type"))
        for r in records
        if r["arm"] in {"epc_kd", "bp_kd"}
    ]
    all_checks["require_unique_complete_primary_records"] = (
        required_keys.issubset(observed_keys)
        and all(observed_keys.count(key) == 1 for key in required_keys)
    )

    # Check 1: mean val loss gain vs update-matched BP+KD
    gains_update = []
    for seed in seeds:
        if seed in epc_records and seed in kd_by_seed:
            gain = kd_by_seed[seed]["student_val_loss"] - epc_records[seed]["student_val_loss"]
            gains_update.append(gain)
    mean_gain_update = sum(gains_update) / len(gains_update) if gains_update else None
    all_checks["mean_val_loss_gain_vs_update_matched_bp_kd_nats"] = mean_gain_update
    all_checks["passes_update_matched_gain"] = (
        len(gains_update) == len(seeds)
        and mean_gain_update is not None
        and mean_gain_update >= promo["mean_val_loss_gain_vs_update_matched_bp_kd_nats"]
    )

    # Check 2: no seed regresses by more than threshold
    max_regression = max((max(0.0, -gain) for gain in gains_update), default=0.0)
    all_checks["max_per_seed_regression_vs_update_matched_bp_kd_nats"] = max_regression
    all_checks["passes_no_seed_regression"] = (
        len(gains_update) == len(seeds)
        and max_regression <= promo["max_per_seed_regression_vs_update_matched_bp_kd_nats"]
    )

    # Check 3: mean gain vs wall-clock-matched BP+KD
    kd_wallclock_by_seed = {}
    for r in records:
        if r["arm"] == "bp_kd" and r.get("match_type") == "wall_clock_matched" and r["seed"] in seeds:
            kd_wallclock_by_seed[r["seed"]] = r
    gains_wallclock = []
    for seed in seeds:
        if seed in epc_records and seed in kd_wallclock_by_seed:
            gain = kd_wallclock_by_seed[seed]["student_val_loss"] - epc_records[seed]["student_val_loss"]
            gains_wallclock.append(gain)
    mean_gain_wallclock = sum(gains_wallclock) / len(gains_wallclock) if gains_wallclock else None
    all_checks["mean_val_loss_gain_vs_wall_clock_matched_bp_kd_nats"] = mean_gain_wallclock
    all_checks["passes_wall_clock_matched_gain"] = (
        len(gains_wallclock) == len(seeds)
        and mean_gain_wallclock is not None
        and mean_gain_wallclock >= promo["mean_val_loss_gain_vs_wall_clock_matched_bp_kd_nats"]
    )

    # Check 4: monotone activity energy
    epc_records_list = [epc_records[s] for s in seeds if s in epc_records]
    all_checks["require_monotone_activity_energy"] = (
        len(epc_records_list) == len(seeds)
        and all(r["activity_energy_monotone"] for r in epc_records_list)
    )
    # Check 5: finite metrics
    required_records = [
        r for r in records
        if (r["seed"], r["arm"], r.get("match_type")) in required_keys
    ]
    all_checks["require_finite_metrics"] = (
        len(required_records) == len(required_keys)
        and all(
        all(math.isfinite(r[key]) for key in (
            "student_val_loss", "student_val_perplexity", "teacher_val_loss",
            "teacher_val_perplexity", "kd_gap_nats", "elapsed_seconds",
        ))
        for r in required_records
        )
    )
    # Check 6: nonzero credit all blocks
    expected_blocks = protocol["student"]["num_layers"]
    all_checks["require_nonzero_credit_all_student_blocks"] = (
        len(epc_records_list) == len(seeds)
        and all(
            len(r["credit_assignment"]) == expected_blocks
            and len({b["block"] for b in r["credit_assignment"]}) == expected_blocks
            and all(b["finite"] and b["epc_norm"] > 0 for b in r["credit_assignment"])
            for r in epc_records_list
        )
    )

    all_checks["required_seed_count"] = promo["required_seed_count"]
    all_checks["seeds_run"] = len(epc_records)
    all_checks["passes_all"] = all(
        v is True for k, v in all_checks.items()
        if k.startswith("passes_") or k in (
            "require_unique_complete_primary_records",
            "require_monotone_activity_energy", "require_finite_metrics",
            "require_nonzero_credit_all_student_blocks",
        )
    ) and len(epc_records) >= promo["required_seed_count"]

    all_checks["claim_if_passed"] = promo["claim_if_passed"]
    return all_checks


def main():
    parser = argparse.ArgumentParser(description="Run the frozen GPT-2-small ePC distillation pilot on GPU")
    parser.add_argument("--protocol", type=Path, required=True, help="Path to frozen protocol JSON")
    parser.add_argument("--output", type=Path, required=True, help="Output directory for results")
    parser.add_argument("--device", type=str, default="cuda", help="Device (cuda or cpu)")
    parser.add_argument("--source-commit", type=str, required=True, help="Git commit hash of the source code")
    args = parser.parse_args()

    protocol = load_pilot_protocol(args.protocol)
    device = _resolve_device(args.device)

    args.output.mkdir(parents=True, exist_ok=True)

    # Build models
    teacher, student_template = build_hf_gpt2_models(protocol, local_files_only=True)
    teacher.to(device)
    teacher.eval()
    for p in teacher.parameters():
        p.requires_grad = False

    # Prepare data
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(
        protocol["teacher"]["model_id"],
        revision=protocol["teacher"]["revision"],
        local_files_only=True,
    )
    train_iter_fn, eval_segments, eval_manifests = _prepare_data(protocol, tokenizer, device)

    seeds = protocol["evaluation"]["seeds"]
    arms = protocol["controls"]["primary"]

    all_records = []

    for seed in seeds:
        # Capture initial student state for this seed
        torch.manual_seed(seed)
        _, student_init = build_hf_gpt2_models(protocol, local_files_only=True)
        init_state = {k: v.clone() for k, v in student_init.state_dict().items()}

        for arm in arms:
            print(f"Running seed={seed} arm={arm}...", flush=True)
            record = run_arm(
                protocol, seed, arm, init_state, teacher,
                train_iter_fn, eval_segments[seed], device,
                checkpoint_dir=args.output / "checkpoints" / f"seed{seed}_{arm}",
            )
            record["source_commit"] = args.source_commit
            record["match_type"] = "update_matched"
            record["evaluation_manifest"] = eval_manifests[seed]

            # Write per-arm JSON
            arm_file = args.output / f"seed{seed}_{arm}.json"
            arm_file.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
            all_records.append(record)
            print(f"  val_loss={record['student_val_loss']:.4f} ppl={record['student_val_perplexity']:.2f} elapsed={record['elapsed_seconds']:.1f}s", flush=True)

        # Wall-clock-matched BP+KD: run until ePC elapsed budget is exhausted
        epc_record = next((r for r in all_records if r["seed"] == seed and r["arm"] == "epc_kd"), None)
        if epc_record:
            epc_elapsed = epc_record["elapsed_seconds"]
            print(f"Running wall-clock-matched BP+KD for seed={seed} (budget={epc_elapsed:.1f}s)...", flush=True)
            wc_record = run_arm(
                protocol, seed, "bp_kd", init_state, teacher,
                train_iter_fn, eval_segments[seed], device,
                elapsed_budget_seconds=epc_elapsed,
            )
            wc_record["source_commit"] = args.source_commit
            wc_record["match_type"] = "wall_clock_matched"
            wc_record["wall_clock_budget_seconds"] = epc_elapsed
            wc_record["evaluation_manifest"] = eval_manifests[seed]
            wc_file = args.output / f"seed{seed}_bp_kd_wallclock.json"
            wc_file.write_text(json.dumps(wc_record, indent=2, sort_keys=True) + "\n")
            all_records.append(wc_record)
            print(f"  val_loss={wc_record['student_val_loss']:.4f} ppl={wc_record['student_val_perplexity']:.2f} updates={wc_record['update_count']}", flush=True)

    # Evaluate promotion
    promotion = evaluate_promotion(all_records, protocol)
    summary = {
        "schema": "relaleap.gpt2_epc_pilot_summary.v1",
        "protocol_sha256": _canonical_hash(protocol),
        "source_commit": args.source_commit,
        "device": str(device),
        "seeds": seeds,
        "arms": arms,
        "records": len(all_records),
        "promotion": promotion,
    }
    summary_file = args.output / "summary.json"
    summary_file.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")

    print("\n=== PROMOTION EVALUATION ===", flush=True)
    print(json.dumps(promotion, indent=2, sort_keys=True), flush=True)
    print(f"\nResults written to {args.output}", flush=True)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
