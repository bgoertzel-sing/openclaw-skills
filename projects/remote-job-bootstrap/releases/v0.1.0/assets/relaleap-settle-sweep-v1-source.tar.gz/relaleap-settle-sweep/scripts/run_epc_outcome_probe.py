#!/usr/bin/env python3
"""Run the frozen local BP/KD/ePC outcome-probe pilot."""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
from pathlib import Path

import torch

from relaleap.hdpc.outcome_probes import (
    block_skip_losses,
    collect_hidden_states,
    common_ce_adaptation,
    corrupt_batches,
    linear_cka,
    mean_loss,
    spectral_summary,
)
from relaleap.hdpc.tinyshakespeare import (
    CausalCharTransformerLM,
    TinyCharTransformerConfig,
    cross_entropy_for_logits,
    get_batch,
    kd_loss,
    prepare_tinyshakespeare_data,
)
from relaleap.hdpc.transformer_epc import transformer_epc_objective


def _batches(tokens, *, count, batch_size, seq_len, seed, device):
    generator = torch.Generator().manual_seed(seed)
    return tuple(get_batch(
        tokens, batch_size=batch_size, seq_len=seq_len, device=device, generator=generator
    ) for _ in range(count))


def _batch_hash(batches) -> str:
    digest = hashlib.sha256()
    for tokens, targets in batches:
        digest.update(tokens.detach().cpu().numpy().tobytes())
        digest.update(targets.detach().cpu().numpy().tobytes())
    return digest.hexdigest()


def _state_hash(model) -> str:
    digest = hashlib.sha256()
    for name, tensor in sorted(model.state_dict().items()):
        digest.update(name.encode())
        digest.update(tensor.detach().cpu().numpy().tobytes())
    return digest.hexdigest()


def _train_teacher(config, model_config, batches, device):
    teacher = CausalCharTransformerLM(model_config).to(device)
    optimizer = torch.optim.AdamW(teacher.parameters(), lr=config["learning_rate"])
    for tokens, targets in batches:
        optimizer.zero_grad(set_to_none=True)
        loss = cross_entropy_for_logits(teacher(tokens), targets)
        loss.backward()
        optimizer.step()
    teacher.eval()
    return teacher


def _train_arm(config, model_config, initial_state, batches, anchors, arm, device):
    model = CausalCharTransformerLM(model_config).to(device)
    model.load_state_dict(initial_state)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config["learning_rate"])
    monotone = True
    for (tokens, targets), anchor in zip(batches, anchors):
        optimizer.zero_grad(set_to_none=True)
        logits = model(tokens)
        ce = cross_entropy_for_logits(logits, targets)
        if arm == "bp":
            loss = ce
        elif arm == "kd":
            ordinary = kd_loss(logits, anchor, temperature=config["kd_temperature"])
            loss = (1.0 - config["kd_lambda"]) * ce + config["kd_lambda"] * ordinary
        elif arm == "epc":
            predictive, trace = transformer_epc_objective(
                model,
                tokens,
                anchor,
                steps=config["epc_state_count"],
                temperature=config["kd_temperature"],
                relaxation_lr=config["epc_activity_step_size"],
            )
            monotone = monotone and all(
                after <= before + 1e-9 * max(1.0, abs(before))
                for before, after in zip(trace.energy_history, trace.energy_history[1:])
            )
            loss = (1.0 - config["kd_lambda"]) * ce + config["kd_lambda"] * predictive
        else:
            raise ValueError(f"unknown arm: {arm}")
        loss.backward()
        optimizer.step()
    if not monotone:
        raise ValueError("ePC activity energy was non-monotone")
    return model


def _arm_metrics(config, model, eval_a, eval_b, adapt_b, seed):
    pre_a = mean_loss(model, eval_a)
    pre_b = mean_loss(model, eval_b)
    hidden = collect_hidden_states(model, eval_a)
    spectra = [spectral_summary(layer) for layer in hidden]
    skip = block_skip_losses(model, eval_a)
    corrupted = corrupt_batches(
        eval_a,
        vocab_size=model.config.vocab_size,
        probability=config["token_corruption_probability"],
        seed=seed + 7000,
    )
    corrupt_loss = mean_loss(model, corrupted)
    adapted = common_ce_adaptation(
        model, adapt_b, learning_rate=config["adapt_learning_rate"]
    )
    post_a = mean_loss(adapted, eval_a)
    post_b = mean_loss(adapted, eval_b)
    return {
        "checkpoint_sha256": _state_hash(model),
        "pre_domain_a_loss": pre_a,
        "pre_domain_b_loss": pre_b,
        "post_domain_a_loss": post_a,
        "post_domain_b_loss": post_b,
        "forgetting_domain_a": post_a - pre_a,
        "adaptation_gain_domain_b": pre_b - post_b,
        "corrupted_domain_a_loss": corrupt_loss,
        "corruption_delta": corrupt_loss - pre_a,
        "block_skip_loss": skip,
        "block_skip_delta": [value - pre_a for value in skip],
        "spectral_summary": spectra,
    }, hidden


def _validate_finite(value, path="root"):
    if isinstance(value, dict):
        for key, child in value.items():
            _validate_finite(child, f"{path}.{key}")
    elif isinstance(value, list):
        for index, child in enumerate(value):
            _validate_finite(child, f"{path}[{index}]")
    elif isinstance(value, float) and not math.isfinite(value):
        raise ValueError(f"non-finite metric at {path}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cpu")
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    if config.get("schema") != "relaleap.epc_outcome_probe.local.v1":
        raise ValueError("unexpected probe config schema")

    dataset = prepare_tinyshakespeare_data(args.data_dir, download=False)
    midpoint = len(dataset.train) // 2
    domain_a, domain_b = dataset.train[:midpoint], dataset.train[midpoint:]
    corpus_hash = hashlib.sha256(dataset.source_path.read_bytes()).hexdigest()
    rows = []
    for seed in config["seeds"]:
        torch.manual_seed(seed)
        teacher_config = TinyCharTransformerConfig(
            vocab_size=dataset.vocab_size,
            seq_len=config["seq_len"],
            d_model=config["teacher_d_model"],
            nhead=config["nhead"],
            d_ff=4 * config["teacher_d_model"],
            num_layers=config["num_layers"],
            dropout=0.0,
        )
        teacher_batches = _batches(
            domain_a, count=config["teacher_steps"], batch_size=config["batch_size"],
            seq_len=config["seq_len"], seed=seed + 1000, device=args.device,
        )
        teacher = _train_teacher(config, teacher_config, teacher_batches, args.device)
        student_config = TinyCharTransformerConfig(
            vocab_size=dataset.vocab_size,
            seq_len=config["seq_len"],
            d_model=config["student_d_model"],
            nhead=config["nhead"],
            d_ff=4 * config["student_d_model"],
            num_layers=config["num_layers"],
            dropout=0.0,
        )
        torch.manual_seed(seed + 2000)
        template = CausalCharTransformerLM(student_config).to(args.device)
        initial_state = copy.deepcopy(template.state_dict())
        initial_hash = _state_hash(template)
        train_a = _batches(
            domain_a, count=config["train_steps"], batch_size=config["batch_size"],
            seq_len=config["seq_len"], seed=seed + 3000, device=args.device,
        )
        eval_a = _batches(
            domain_a, count=config["eval_batches"], batch_size=config["batch_size"],
            seq_len=config["seq_len"], seed=seed + 4000, device=args.device,
        )
        eval_b = _batches(
            domain_b, count=config["eval_batches"], batch_size=config["batch_size"],
            seq_len=config["seq_len"], seed=seed + 5000, device=args.device,
        )
        adapt_b = _batches(
            domain_b, count=config["adapt_steps"], batch_size=config["batch_size"],
            seq_len=config["seq_len"], seed=seed + 6000, device=args.device,
        )
        with torch.no_grad():
            anchors = tuple(teacher(tokens).detach() for tokens, _ in train_a)
        trained, hidden = {}, {}
        for arm in ("bp", "kd", "epc"):
            trained[arm] = _train_arm(
                config, student_config, initial_state, train_a, anchors, arm, args.device
            )
            metrics, hidden[arm] = _arm_metrics(
                config, trained[arm], eval_a, eval_b, adapt_b, seed
            )
            rows.append({"seed": seed, "arm": arm, "initial_sha256": initial_hash, **metrics})
        for left, right in (("bp", "kd"), ("bp", "epc"), ("kd", "epc")):
            rows.append({
                "seed": seed,
                "comparison": f"{left}_vs_{right}",
                "linear_cka": [
                    linear_cka(a, b) for a, b in zip(hidden[left], hidden[right])
                ],
            })
        hashes = {_batch_hash(value) for value in (train_a, eval_a, eval_b, adapt_b)}
        if len(hashes) != 4:
            raise ValueError("train/evaluation/adaptation batches unexpectedly collide")

    payload = {
        "schema": "relaleap.epc_outcome_probe.result.v1",
        "config": config,
        "config_sha256": hashlib.sha256(args.config.read_bytes()).hexdigest(),
        "corpus_sha256": corpus_hash,
        "device": args.device,
        "scientific_status": "instrumentation_pilot_only",
        "rows": rows,
    }
    _validate_finite(payload)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"output": str(args.output), "rows": len(rows)}, sort_keys=True))


if __name__ == "__main__":
    main()
