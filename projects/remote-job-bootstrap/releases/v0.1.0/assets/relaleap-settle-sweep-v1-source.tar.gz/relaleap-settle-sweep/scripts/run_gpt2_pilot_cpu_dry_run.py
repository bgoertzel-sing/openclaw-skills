#!/usr/bin/env python3
"""Run the frozen three-seed/two-layer pilot gate twice and compare outputs."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from relaleap.hdpc.pilot_dry_run import comparable_payload, run_cpu_dry_run, write_metrics
from relaleap.hdpc.pilot_protocol import load_pilot_protocol


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    protocol = load_pilot_protocol(args.protocol)
    first = run_cpu_dry_run(protocol)
    second = run_cpu_dry_run(protocol)
    if comparable_payload(first) != comparable_payload(second):
        raise RuntimeError("repeated CPU dry-runs differ outside declared timing fields")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    write_metrics(args.output, first)
    digest = hashlib.sha256(args.output.read_bytes()).hexdigest()
    summary = {
        "schema": "relaleap.gpt2_epc_cpu_dry_run.v1",
        "status": "implementation_gate_passed",
        "scientific_promotion_eligible": False,
        "record_count": len(first),
        "repeat_deterministic_excluding": ["elapsed_seconds"],
        "metrics_sha256": digest,
    }
    print(json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
