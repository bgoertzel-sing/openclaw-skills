#!/usr/bin/env python3
"""Run the frozen clean-room KD-only multi-step ePC comparison.

Download/use only the pinned GPT-2 revision and public WikiText-103 tokens.
The output includes both arms, exact-replay status, and model digests. This
runner is an engineering/learning comparison, not Mesto reproduction.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch
from datasets import load_dataset
from transformers import AutoModelForCausalLM, AutoTokenizer, GPT2Config, GPT2LMHeadModel

from relaleap.hdpc.multistep import replay_is_exact, run_arm
from relaleap.hdpc.pcstep_adapter import PCStepBatch, capture_snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--revision", required=True)
    parser.add_argument("--dataset-revision", required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--updates", type=int, default=100)
    parser.add_argument("--settle-steps", type=int, default=4)
    parser.add_argument("--context", type=int, default=64)
    parser.add_argument("--evaluation-batches", type=int, default=16)
    args = parser.parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    device = torch.device("cuda")
    teacher = AutoModelForCausalLM.from_pretrained(
        "openai-community/gpt2", revision=args.revision,
    ).to(device).eval()
    for parameter in teacher.parameters():
        parameter.requires_grad_(False)
    tokenizer = AutoTokenizer.from_pretrained("openai-community/gpt2", revision=args.revision)
    dataset = load_dataset("Salesforce/wikitext", "wikitext-103-raw-v1", revision=args.dataset_revision, split="train")
    token_ids: list[int] = []
    required_tokens = (args.updates + args.evaluation_batches) * args.context
    for text in dataset["text"]:
        token_ids.extend(tokenizer(text, add_special_tokens=False)["input_ids"])
        token_ids.append(tokenizer.eos_token_id)
        if len(token_ids) >= required_tokens:
            break
    if len(token_ids) < required_tokens:
        raise RuntimeError("insufficient public token stream for fixed batch plan")
    config = GPT2Config(
        vocab_size=50257, n_positions=args.context, n_ctx=args.context,
        n_embd=768, n_layer=6, n_head=12, n_inner=3072, use_cache=False,
        resid_pdrop=0.0, embd_pdrop=0.0, attn_pdrop=0.0,
    )
    model = GPT2LMHeadModel(config).to(device).train()
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4, weight_decay=0.01)
    initial = capture_snapshot(model, optimizer, outer_step=0, batch_cursor=0)

    def batches(index: int) -> PCStepBatch:
        start = index * args.context
        tokens = torch.tensor(token_ids[start:start + args.context], device=device).unsqueeze(0)
        with torch.no_grad():
            teacher_logits = teacher(tokens, use_cache=False).logits
        return PCStepBatch(tokens=tokens, teacher_logits=teacher_logits, cursor=index)

    gate = {index: True for index in range(config.n_layer)}
    common = dict(updates=args.updates, settle_steps=args.settle_steps, temperature=2.0, gate=gate)
    baseline = run_arm(model, optimizer, initial, batches, arm="t1_kd", **common)
    epc = run_arm(model, optimizer, initial, batches, arm="settled_epc", **common)
    replay = replay_is_exact(model, optimizer, initial, batches, arm="settled_epc", **common)
    if not replay:
        raise RuntimeError("multi-step settled arm was not exactly replayable")
    def held_out_kd(snapshot) -> float:
        from relaleap.hdpc.pcstep_adapter import restore_snapshot
        restore_snapshot(model, optimizer, snapshot)
        model.eval()
        total = 0.0
        with torch.no_grad():
            for index in range(args.evaluation_batches):
                start = (args.updates + index) * args.context
                tokens = torch.tensor(token_ids[start:start + args.context], device=device).unsqueeze(0)
                student_logits = model(tokens, use_cache=False).logits
                teacher_logits = teacher(tokens, use_cache=False).logits
                total += float(torch.nn.functional.kl_div(
                    torch.nn.functional.log_softmax(student_logits / 2.0, dim=-1),
                    torch.nn.functional.softmax(teacher_logits / 2.0, dim=-1),
                    reduction="batchmean",
                ) * 4.0)
        model.train()
        return total / args.evaluation_batches

    baseline_val_kd = held_out_kd(baseline.final_snapshot)
    epc_val_kd = held_out_kd(epc.final_snapshot)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps({
        "schema": "relaleap.clean_room_transformer_epc_multistep.v1",
        "status": "passed",
        "seed": args.seed,
        "updates": args.updates,
        "settle_steps": args.settle_steps,
        "replay_exact": replay,
        "held_out_kd": {"t1_kd": baseline_val_kd, "settled_epc": epc_val_kd,
                          "gain_nats": baseline_val_kd - epc_val_kd,
                          "batches": args.evaluation_batches},
        "student_parameters": sum(p.numel() for p in model.parameters()),
        "arms": {name: {"objectives": result.objectives,
                        "final_model_digest": result.final_model_digest}
                 for name, result in (("t1_kd", baseline), ("settled_epc", epc))},
        "peak_cuda_bytes": int(torch.cuda.max_memory_allocated(device)),
    }, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
