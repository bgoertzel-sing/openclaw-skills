#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from relaleap.hdpc import HDPCTrainingConfig, run_homotopy_kd_training


def _temperatures(value: str) -> tuple[float, ...]:
    values = tuple(float(part) for part in value.split(",") if part.strip())
    if not values:
        raise argparse.ArgumentTypeError("at least one temperature is required")
    if any(temperature <= 0 for temperature in values):
        raise argparse.ArgumentTypeError("temperatures must be positive")
    return values


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the HDPC/ePC Tiny Shakespeare smoke pipeline.")
    parser.add_argument("--device", choices=("cuda", "cpu"), default="cuda")
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--seq_len", type=int, default=128)
    parser.add_argument("--d_model", type=int, default=64)
    parser.add_argument("--temperature", type=_temperatures, default=(1.0, 2.0, 4.0, 8.0), help="single T or comma sweep, e.g. 1,2,4,8")
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--steps_per_epoch", type=int, default=20)
    parser.add_argument("--data_dir", type=Path, default=Path("data/tinyshakespeare"))
    parser.add_argument("--artifact_dir", type=Path, default=Path("results/hdpc_tinyshakespeare"))
    args = parser.parse_args()

    config = HDPCTrainingConfig(
        data_dir=args.data_dir,
        device=args.device,
        epochs=args.epochs,
        seq_len=args.seq_len,
        d_model=args.d_model,
        temperatures=args.temperature,
        batch_size=args.batch_size,
        steps_per_epoch=args.steps_per_epoch,
        artifact_dir=args.artifact_dir,
    )
    result = run_homotopy_kd_training(config)
    diagnostics = result.diagnostics
    print(f"source={result.source_path}")
    print(f"teacher_parameters={result.teacher_parameters}")
    print(f"student_parameters={result.student_parameters}")
    print(f"artifact={result.artifact_path}")
    print(f"teacher_perplexity={diagnostics.teacher_perplexity:.4f}")
    print(f"student_perplexity={diagnostics.student_perplexity:.4f}")
    print(f"perplexity_delta={diagnostics.perplexity_delta:.4f}")
    print(f"update_sparsity_histogram={diagnostics.update_sparsity_histogram}")
    print("gradient_diagnostics=head")
    for diagnostic in diagnostics.gradients[:10]:
        print(
            f"  {diagnostic.name}: bp_norm={diagnostic.bp_norm:.6g} "
            f"pc_norm={diagnostic.pc_norm:.6g} cosine={diagnostic.cosine} shape={diagnostic.shape}"
        )


if __name__ == "__main__":
    main()
