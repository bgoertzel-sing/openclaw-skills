#!/usr/bin/env python3
"""Extended HDPC/ePC controlled grid on Tiny Shakespeare.

Runs four conditions across multiple seeds and lambda_kd values:
1. teacher-only (no student)
2. student/no-crown (plain KD, no PC crown)
3. detached crown (HDPC student with detached crown)
4. coupled crown (HDPC student with coupled crown)
"""

import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

import torch
from relaleap.hdpc.tinyshakespeare import (
    HDPCTrainingConfig,
    HDPCTrainingResult,
    run_homotopy_kd_training,
    CausalCharTransformerLM,
    TinyCharTransformerConfig,
    TinyShakespeareTokenizer,
    prepare_tinyshakespeare_data,
    get_batch,
    cross_entropy_for_logits,
    count_parameters,
    estimate_perplexity,
    kd_loss,
)
from torch import nn
import torch.nn.functional as F


def run_teacher_only(config: HDPCTrainingConfig) -> dict:
    """Train a teacher-only model with same compute budget, no student/crown."""
    torch.manual_seed(config.seed)
    device = torch.device(config.device)
    dataset = prepare_tinyshakespeare_data(config.data_dir, download=config.download)
    model_config = TinyCharTransformerConfig(
        vocab_size=dataset.vocab_size,
        seq_len=config.seq_len,
        d_model=config.d_model,
        nhead=config.nhead,
        d_ff=config.d_ff,
        num_layers=config.num_layers,
    )
    model = CausalCharTransformerLM(model_config).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config.learning_rate)
    generator = torch.Generator().manual_seed(config.seed)

    for _ in range(config.epochs):
        for temperature in config.temperatures:
            for _ in range(config.steps_per_epoch):
                x, y = get_batch(dataset.train, batch_size=config.batch_size,
                                seq_len=config.seq_len, device=device, generator=generator)
                optimizer.zero_grad(set_to_none=True)
                loss = cross_entropy_for_logits(model(x), y)
                loss.backward()
                optimizer.step()

    val_ppl = estimate_perplexity(model, dataset.val, seq_len=config.seq_len,
                                  batch_size=min(config.batch_size, 16),
                                  device=device, steps=config.eval_batches)
    return {
        "condition": "teacher_only",
        "seed": config.seed,
        "heldout_perplexity": val_ppl,
        "parameters": count_parameters(model),
        "elapsed": 0.0,
    }


def run_student_no_crown(config: HDPCTrainingConfig) -> dict:
    """Train a plain student (no PC crown) with same KD loss and compute budget."""
    torch.manual_seed(config.seed)
    device = torch.device(config.device)
    dataset = prepare_tinyshakespeare_data(config.data_dir, download=config.download)
    model_config = TinyCharTransformerConfig(
        vocab_size=dataset.vocab_size,
        seq_len=config.seq_len,
        d_model=config.d_model,
        nhead=config.nhead,
        d_ff=config.d_ff,
        num_layers=config.num_layers,
    )
    teacher = CausalCharTransformerLM(model_config).to(device)
    student = CausalCharTransformerLM(model_config).to(device)
    student.load_state_dict(teacher.state_dict())

    teacher_optimizer = torch.optim.AdamW(teacher.parameters(), lr=config.learning_rate)
    student_optimizer = torch.optim.AdamW(student.parameters(), lr=config.learning_rate)
    generator = torch.Generator().manual_seed(config.seed)

    for _ in range(config.epochs):
        for temperature in config.temperatures:
            for _ in range(config.steps_per_epoch):
                x, y = get_batch(dataset.train, batch_size=config.batch_size,
                                seq_len=config.seq_len, device=device, generator=generator)
                teacher_optimizer.zero_grad(set_to_none=True)
                teacher_logits = teacher(x)
                teacher_loss = cross_entropy_for_logits(teacher_logits, y)
                teacher_loss.backward()
                teacher_optimizer.step()

                student_optimizer.zero_grad(set_to_none=True)
                with torch.no_grad():
                    anchor = teacher(x).detach()
                student_logits = student(x)
                ce = cross_entropy_for_logits(student_logits, y)
                distill = kd_loss(student_logits, anchor, temperature=temperature)
                loss = (1.0 - config.lambda_kd) * ce + config.lambda_kd * distill
                loss.backward()
                student_optimizer.step()

    val_ppl = estimate_perplexity(student, dataset.val, seq_len=config.seq_len,
                                  batch_size=min(config.batch_size, 16),
                                  device=device, steps=config.eval_batches)
    teacher_ppl = estimate_perplexity(teacher, dataset.val, seq_len=config.seq_len,
                                      batch_size=min(config.batch_size, 16),
                                      device=device, steps=config.eval_batches)
    return {
        "condition": "student_no_crown",
        "seed": config.seed,
        "lambda_kd": config.lambda_kd,
        "teacher_perplexity": teacher_ppl,
        "student_perplexity": val_ppl,
        "perplexity_delta": val_ppl - teacher_ppl,
        "student_parameters": count_parameters(student),
        "elapsed": 0.0,
    }


def run_hdpc_condition(config: HDPCTrainingConfig, detached: bool) -> dict:
    """Run HDPC with detached or coupled crown."""
    cfg = HDPCTrainingConfig(**{**config.__dict__, "detached_crown": detached})
    result = run_homotopy_kd_training(cfg)
    condition_name = "detached_crown" if detached else "coupled_crown"
    entry = {
        "condition": condition_name,
        "seed": cfg.seed,
        "lambda_kd": cfg.lambda_kd,
        "teacher_perplexity": result.diagnostics.teacher_perplexity,
        "student_perplexity": result.diagnostics.student_perplexity,
        "perplexity_delta": result.diagnostics.student_perplexity - result.diagnostics.teacher_perplexity,
        "student_parameters": result.student_parameters,
        "energy_profile_length": len(result.diagnostics.energy_profile),
        "update_sparsity_histogram": list(result.diagnostics.update_sparsity_histogram),
        "gradient_cosines": [
            {"name": g.name, "cosine": g.cosine, "bp_norm": g.bp_norm, "pc_norm": g.pc_norm}
            for g in result.diagnostics.gradients
        ],
        "elapsed": 0.0,
    }
    return entry


def main() -> None:
    parser = argparse.ArgumentParser(description="Extended HDPC/ePC controlled grid v2")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--steps-per-epoch", type=int, default=200)
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--d-model", type=int, default=256)
    parser.add_argument("--nhead", type=int, default=4)
    parser.add_argument("--d-ff", type=int, default=1024)
    parser.add_argument("--num-layers", type=int, default=6)
    parser.add_argument("--seq-len", type=int, default=256)
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--data-dir", default="data/tinyshakespeare")
    parser.add_argument("--artifact-dir", default="results/hdpc_grid_v2")
    args = parser.parse_args()

    artifact_dir = Path(args.artifact_dir)
    artifact_dir.mkdir(parents=True, exist_ok=True)

    seeds = [42, 1234, 5678]
    lambdas = [0.01, 0.05, 0.10]
    temperatures = (1.0, 2.0, 4.0, 8.0)

    all_results = []
    start = time.time()

    print(f"=== HDPC/ePC Extended Grid V2 ===")
    print(f"Conditions: teacher_only, student_no_crown, detached_crown, coupled_crown")
    print(f"Seeds: {seeds}, Lambdas: {lambdas}")
    print(f"Model: d_model={args.d_model}, layers={args.num_layers}, batch={args.batch_size}, seq_len={args.seq_len}")
    print(f"Epochs: {args.epochs}, Steps/epoch: {args.steps_per_epoch}")
    print()

    for seed in seeds:
        base_kwargs = dict(
            device=args.device, epochs=args.epochs, steps_per_epoch=args.steps_per_epoch,
            batch_size=args.batch_size, seq_len=args.seq_len, d_model=args.d_model,
            nhead=args.nhead, d_ff=args.d_ff, num_layers=args.num_layers,
            learning_rate=args.learning_rate, seed=seed,
            data_dir=Path(args.data_dir), download=True,
            artifact_dir=artifact_dir,
        )

        # 1. Teacher-only
        cfg = HDPCTrainingConfig(**base_kwargs)
        print(f"--- Seed {seed}: teacher_only ---")
        t0 = time.time()
        r = run_teacher_only(cfg)
        r["elapsed"] = time.time() - t0
        print(f"  teacher_only heldout_ppl: {r['heldout_perplexity']:.2f} ({r['elapsed']:.0f}s)")
        all_results.append(r)

        for lam in lambdas:
            lam_kwargs = {**base_kwargs, "lambda_kd": lam,
                          "artifact_dir": artifact_dir / f"seed{seed}_lam{lam}"}

            cfg = HDPCTrainingConfig(**lam_kwargs)

            # 2. Student/no-crown
            print(f"--- Seed {seed}, lam={lam}: student_no_crown ---")
            t0 = time.time()
            r = run_student_no_crown(cfg)
            r["elapsed"] = time.time() - t0
            print(f"  student_no_crown: ppl={r['student_perplexity']:.2f}, delta={r['perplexity_delta']:+.2f} ({r['elapsed']:.0f}s)")
            all_results.append(r)

            # 3. Detached crown
            print(f"--- Seed {seed}, lam={lam}: detached_crown ---")
            t0 = time.time()
            r = run_hdpc_condition(cfg, detached=True)
            r["elapsed"] = time.time() - t0
            print(f"  detached_crown: ppl={r['student_perplexity']:.2f}, delta={r['perplexity_delta']:+.2f} ({r['elapsed']:.0f}s)")
            all_results.append(r)

            # 4. Coupled crown
            print(f"--- Seed {seed}, lam={lam}: coupled_crown ---")
            t0 = time.time()
            r = run_hdpc_condition(cfg, detached=False)
            r["elapsed"] = time.time() - t0
            print(f"  coupled_crown: ppl={r['student_perplexity']:.2f}, delta={r['perplexity_delta']:+.2f} ({r['elapsed']:.0f}s)")
            all_results.append(r)

    elapsed = time.time() - start
    summary = {
        "config": vars(args),
        "conditions": ["teacher_only", "student_no_crown", "detached_crown", "coupled_crown"],
        "seeds": seeds,
        "lambdas": lambdas,
        "temperatures": list(temperatures),
        "total_elapsed": elapsed,
        "results": all_results,
    }
    summary_path = artifact_dir / "grid_v2_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2))

    print(f"\n=== Grid V2 Complete ({elapsed:.0f}s total) ===")
    print(f"Total runs: {len(all_results)}")
    # Summary table
    for condition in ["teacher_only", "student_no_crown", "detached_crown", "coupled_crown"]:
        cond_results = [r for r in all_results if r["condition"] == condition]
        if cond_results:
            ppls = [r.get("student_perplexity", r.get("heldout_perplexity", float("nan"))) for r in cond_results]
            deltas = [r.get("perplexity_delta", float("nan")) for r in cond_results]
            print(f"  {condition:20s}: n={len(cond_results)}, mean_ppl={sum(ppls)/len(ppls):.2f}, mean_delta={sum(d for d in deltas if d == d)/max(1,len([d for d in deltas if d == d])):.2f}")
    print(f"\nSummary: {summary_path}")


if __name__ == "__main__":
    main()
