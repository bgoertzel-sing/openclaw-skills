#!/usr/bin/env python3
"""Run one seed of the frozen clean-room settlement-depth sweep."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch
from datasets import load_dataset
from transformers import AutoModelForCausalLM, AutoTokenizer, GPT2Config, GPT2LMHeadModel

from relaleap.hdpc.multistep import replay_is_exact, run_arm
from relaleap.hdpc.pcstep_adapter import PCStepBatch, capture_snapshot, restore_snapshot
from relaleap.hdpc.settle_sweep import (
    FROZEN_DEPTHS,
    validate_arm_record,
    validate_seed_record,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--revision", required=True)
    parser.add_argument("--dataset-revision", required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--updates", type=int, default=100)
    parser.add_argument("--context", type=int, default=64)
    parser.add_argument("--evaluation-batches", type=int, default=16)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    existing_arms: dict[str, object] = {}
    if args.resume and args.output.exists():
        existing = json.loads(args.output.read_text())
        if existing.get("seed") != args.seed or existing.get("updates") != args.updates:
            raise RuntimeError("resume artifact seed/update contract mismatch")
        if existing.get("status") == "passed":
            validate_seed_record(existing)
            return
        if existing.get("status") != "partial":
            raise RuntimeError("resume artifact has unknown status")
        existing_arms = dict(existing.get("arms", {}))
        for depth_text, arm in existing_arms.items():
            validate_arm_record(int(depth_text), arm)
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")

    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    device = torch.device("cuda")
    teacher = AutoModelForCausalLM.from_pretrained(
        "openai-community/gpt2", revision=args.revision,
    ).to(device).eval()
    for parameter in teacher.parameters():
        parameter.requires_grad_(False)
    tokenizer = AutoTokenizer.from_pretrained(
        "openai-community/gpt2", revision=args.revision,
    )
    dataset = load_dataset(
        "Salesforce/wikitext", "wikitext-103-raw-v1",
        revision=args.dataset_revision, split="train",
    )
    token_ids: list[int] = []
    required_tokens = (args.updates + args.evaluation_batches) * args.context
    for text in dataset["text"]:
        token_ids.extend(tokenizer(text, add_special_tokens=False)["input_ids"])
        token_ids.append(tokenizer.eos_token_id)
        if len(token_ids) >= required_tokens:
            break
    if len(token_ids) < required_tokens:
        raise RuntimeError("insufficient public token stream for fixed batch plan")

    config = GPT2Config(
        vocab_size=50257, n_positions=args.context, n_ctx=args.context,
        n_embd=768, n_layer=6, n_head=12, n_inner=3072, use_cache=False,
        resid_pdrop=0.0, embd_pdrop=0.0, attn_pdrop=0.0,
    )
    model = GPT2LMHeadModel(config).to(device).train()
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4, weight_decay=0.01)

    fixed_batches: list[PCStepBatch] = []
    with torch.no_grad():
        for index in range(args.updates + args.evaluation_batches):
            start = index * args.context
            tokens = torch.tensor(
                token_ids[start:start + args.context], device=device,
            ).unsqueeze(0)
            teacher_logits = teacher(tokens, use_cache=False).logits
            fixed_batches.append(
                PCStepBatch(
                    tokens=tokens,
                    teacher_logits=teacher_logits,
                    cursor=index,
                )
            )
    initial = capture_snapshot(model, optimizer, outer_step=0, batch_cursor=0)

    def batches(index: int) -> PCStepBatch:
        return fixed_batches[index]

    def held_out_kd(snapshot) -> float:
        restore_snapshot(model, optimizer, snapshot)
        model.eval()
        total = 0.0
        with torch.no_grad():
            for index in range(args.evaluation_batches):
                batch = fixed_batches[args.updates + index]
                tokens = batch.tokens
                student_logits = model(tokens, use_cache=False).logits
                total += float(torch.nn.functional.kl_div(
                    torch.nn.functional.log_softmax(student_logits / 2.0, dim=-1),
                    torch.nn.functional.softmax(batch.teacher_logits / 2.0, dim=-1),
                    reduction="batchmean",
                ) * 4.0)
        model.train()
        return total / args.evaluation_batches

    gate = {index: True for index in range(config.n_layer)}
    arms: dict[str, object] = existing_arms
    for depth in FROZEN_DEPTHS:
        if str(depth) in arms:
            continue
        common = {
            "updates": args.updates,
            "settle_steps": depth,
            "temperature": 2.0,
            "gate": gate,
        }
        result = run_arm(
            model, optimizer, initial, batches, arm="settled_epc", **common,
        )
        replay = replay_is_exact(
            model, optimizer, initial, batches, arm="settled_epc", **common,
        )
        if not replay:
            raise RuntimeError(f"settled arm T={depth} was not exactly replayable")
        arms[str(depth)] = {
            "settle_steps": depth,
            "replay_exact": replay,
            "held_out_kd_nats": held_out_kd(result.final_snapshot),
            "objectives": result.objectives,
            "final_model_digest": result.final_model_digest,
        }
        partial = {
            "schema": "relaleap.clean_room_transformer_epc_settle_sweep.v1",
            "status": "partial",
            "seed": args.seed,
            "updates": args.updates,
            "student_parameters": sum(
                parameter.numel() for parameter in model.parameters()
            ),
            "arms": arms,
            "peak_cuda_bytes": int(torch.cuda.max_memory_allocated(device)),
        }
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(partial, indent=2, sort_keys=True) + "\n")

    record = {
        "schema": "relaleap.clean_room_transformer_epc_settle_sweep.v1",
        "status": "passed",
        "seed": args.seed,
        "updates": args.updates,
        "student_parameters": sum(parameter.numel() for parameter in model.parameters()),
        "arms": arms,
        "peak_cuda_bytes": int(torch.cuda.max_memory_allocated(device)),
    }
    validate_seed_record(record)
    args.output.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
