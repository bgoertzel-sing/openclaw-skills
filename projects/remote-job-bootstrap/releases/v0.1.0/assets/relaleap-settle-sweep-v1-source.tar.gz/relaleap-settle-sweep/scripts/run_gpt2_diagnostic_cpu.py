#!/usr/bin/env python3
"""CPU-only diagnostic battery for the RelaLeap six-layer GPT-2 outcome report.

Addresses the four "Plausible explanations" from the 2026-07-19 report:
  1. Under-effective teacher transfer (KD gap ~880-893 nats)
  2. Overly restrictive representation (ePC effective rank ~4-5 vs BP ~40-57)
  3. Credit-assignment scale/optimization mismatch
  4. Interaction with the fixed adapter rule

The report suggested: "hold the checkpoint and downstream probe fixed while
measuring layerwise teacher-logit/hidden-state matching and gradient/activity
scales across preregistered ePC hyperparameters."

We have 9 preserved checkpoints (3 seeds x 3 arms) and no teacher model or
GPU.  This script runs five CPU-feasible diagnostics on those checkpoints
using random-token probes (deterministic, no data dependency):

  D1: Weight-space spectral analysis per layer
  D2: Representation geometry on fixed random input
  D3: Cross-checkpoint layerwise linear CKA
  D4: ePC hyperparameter sweep on fixed checkpoints
  D5: Gradient flow comparison (CE loss gradient norms per layer)

Usage:
  python3 scripts/run_gpt2_diagnostic_cpu.py \
    --checkpoints /path/to/checkpoints \
    --output /path/to/output \
    --device cpu
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
import time
from itertools import combinations
from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from relaleap.hdpc.gpt2_epc import GPT2BlockStateAdapter, gpt2_epc_objective
from relaleap.hdpc.representation import linear_cka_feature
from relaleap.hdpc.tinyshakespeare import kd_loss

SCHEMA = "relaleap.gpt2_diagnostic_cpu.v1"

SEEDS = [1729, 3253, 6421]
ARMS = ["bp_ce", "bp_kd", "epc_kd"]

# Deterministic probe configuration
PROBE_SEQ_LEN = 64
PROBE_BATCH = 2
PROBE_TOKEN_SEED = 42

# ePC hyperparameter sweep grid (preregistered)
EPC_SWEEP = {
    "lambda_output": [0.01, 0.05, 0.1, 0.3, 0.5],
    "relaxation_lr": [0.05, 0.1, 0.2, 0.4],
    "steps": [1, 2, 4, 8],
}


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _canonical_hash(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def _make_probe_tokens(seq_len: int, batch: int, vocab_size: int = 50257) -> torch.Tensor:
    g = torch.Generator().manual_seed(PROBE_TOKEN_SEED)
    return torch.randint(0, vocab_size, (batch, seq_len), generator=g, dtype=torch.long)


def _linear_cka(x: torch.Tensor, y: torch.Tensor) -> float:
    """Standard linear CKA between two [N, D] feature matrices."""
    return linear_cka_feature(x, y)


def _effective_rank(features: torch.Tensor) -> float:
    """Effective rank via participation ratio of singular values."""
    s = torch.linalg.svdvals(features.float().reshape(-1, features.shape[-1]))
    s = s[s > 1e-10]
    if len(s) == 0:
        return 0.0
    p = s ** 2
    return float(p.sum() ** 2 / (p ** 2).sum())


def _participation_ratio(features: torch.Tensor) -> float:
    s = torch.linalg.svdvals(features.float().reshape(-1, features.shape[-1]))
    s = s[s > 1e-10]
    if len(s) == 0:
        return 0.0
    p = s ** 2
    return float(p.sum() ** 2 / (p ** 2).sum())


def _activation_stats(t: torch.Tensor) -> dict[str, float]:
    t = t.float()
    return {
        "mean": float(t.mean()),
        "std": float(t.std()),
        "abs_mean": float(t.abs().mean()),
        "max_abs": float(t.abs().max()),
        "kurtosis": float(((t - t.mean()) / (t.std() + 1e-12)).pow(4).mean() - 3.0),
        "sparsity": float((t.abs() < 0.01 * t.abs().max()).float().mean()),
        "effective_rank": _effective_rank(t),
        "participation_ratio": _participation_ratio(t),
    }


def load_checkpoint(ckpt_dir: Path, device: torch.device) -> Any:
    from transformers import GPT2LMHeadModel
    model = GPT2LMHeadModel.from_pretrained(str(ckpt_dir), local_files_only=True)
    model.to(device)
    model.eval()
    # Ensure cache is off; dropout is already 0 in the checkpoint config
    model.config.use_cache = False
    return model


# ---------------------------------------------------------------------------
# D1: Weight-space spectral analysis
# ---------------------------------------------------------------------------

def d1_weight_spectral(model: Any) -> dict[str, Any]:
    """Per-layer weight matrix spectral norms and condition numbers."""
    results = []
    transformer = model.transformer

    # Embedding norms
    emb_norm = float(transformer.wte.weight.norm())
    pos_norm = float(transformer.wpe.weight.norm())

    for i, block in enumerate(transformer.h):
        block_data = {"layer": i}
        # Attention: c_attn, c_proj
        for name in ["c_attn", "c_proj"]:
            w = getattr(block.attn, name).weight
            s = torch.linalg.svdvals(w.float())
            block_data[f"attn_{name}_spectral_norm"] = float(s[0])
            block_data[f"attn_{name}_nuclear_norm"] = float(s.sum())
            block_data[f"attn_{name}_effective_rank"] = _effective_rank(w.unsqueeze(0))
            # Condition number (ratio of largest to smallest singular value)
            block_data[f"attn_{name}_condition"] = float(s[0] / (s[-1] + 1e-12))

        # MLP: c_fc, c_proj
        for name in ["c_fc", "c_proj"]:
            w = getattr(block.mlp, name).weight
            s = torch.linalg.svdvals(w.float())
            block_data[f"mlp_{name}_spectral_norm"] = float(s[0])
            block_data[f"mlp_{name}_nuclear_norm"] = float(s.sum())
            block_data[f"mlp_{name}_effective_rank"] = _effective_rank(w.unsqueeze(0))
            block_data[f"mlp_{name}_condition"] = float(s[0] / (s[-1] + 1e-12))

        # Layer norm weights
        for name in ["ln_1", "ln_2"]:
            ln = getattr(block, name)
            if hasattr(ln, "weight") and ln.weight is not None:
                block_data[f"ln_{name}_weight_norm"] = float(ln.weight.norm())
                block_data[f"ln_{name}_bias_norm"] = float(ln.bias.norm() if ln.bias is not None else 0)

        results.append(block_data)

    return {
        "embedding_weight_norm": emb_norm,
        "positional_weight_norm": pos_norm,
        "layers": results,
    }


# ---------------------------------------------------------------------------
# D2: Representation geometry on fixed random input
# ---------------------------------------------------------------------------

def d2_representation_geometry(model: Any, tokens: torch.Tensor) -> dict[str, Any]:
    """Hidden state geometry per layer on a fixed random-token probe."""
    adapter = GPT2BlockStateAdapter(model)
    states = adapter.forward_states(tokens)

    input_stats = _activation_stats(states.input_state)
    layer_stats = []
    for i, h in enumerate(states.hidden_states):
        layer_stats.append({"layer": i, **_activation_stats(h)})

    logits_stats = _activation_stats(states.logits)

    return {
        "input_state": input_stats,
        "hidden_states": layer_stats,
        "logits": logits_stats,
        "seq_len": tokens.shape[1],
        "batch": tokens.shape[0],
    }


# ---------------------------------------------------------------------------
# D3: Cross-checkpoint layerwise linear CKA
# ---------------------------------------------------------------------------

def d3_cross_checkpoint_cka(
    models: dict[str, Any],
    tokens: torch.Tensor,
) -> dict[str, Any]:
    """Pairwise layerwise linear CKA between all checkpoint pairs."""
    # Collect hidden states for each model
    all_states: dict[str, list[torch.Tensor]] = {}
    for key, model in models.items():
        adapter = GPT2BlockStateAdapter(model)
        states = adapter.forward_states(tokens)
        all_states[key] = [states.input_state] + list(states.hidden_states)

    n_layers = len(next(iter(all_states.values())))
    pairs = list(combinations(sorted(all_states.keys()), 2))
    results = []
    for key_a, key_b in pairs:
        layer_cka = []
        for layer_idx in range(n_layers):
            cka = _linear_cka(all_states[key_a][layer_idx], all_states[key_b][layer_idx])
            layer_cka.append(cka)
        results.append({
            "pair": f"{key_a}_vs_{key_b}",
            "layer_cka": layer_cka,
            "mean_cka": float(sum(layer_cka) / len(layer_cka)),
        })
    return {"pairs": results, "n_layers": n_layers}


# ---------------------------------------------------------------------------
# D4: ePC hyperparameter sweep on fixed checkpoints
# ---------------------------------------------------------------------------

def d4_epc_sweep(
    model: Any,
    tokens: torch.Tensor,
    teacher_logits: torch.Tensor,
) -> dict[str, Any]:
    """Sweep ePC hyperparameters on a fixed checkpoint.

    Uses the model's own feedforward logits as a self-reference teacher
    (since we don't have the real teacher model cached locally).  This
    measures the ePC mechanism's sensitivity to hyperparameters on
    already-trained weights, not teacher transfer quality.
    """
    results = []

    # Baseline: ordinary KD (steps=1)
    endpoint = kd_loss(
        model(tokens, use_cache=False).logits,
        teacher_logits,
        temperature=2.0,
    )
    results.append({
        "lambda_output": 0.05,
        "relaxation_lr": 0.2,
        "steps": 1,
        "energy": float(endpoint.detach()),
        "energy_history": [float(endpoint.detach())],
        "accepted_step_sizes": [],
        "backtrack_counts": [],
        "grad_norms_per_block": [],
        "credit_ratios": [],
    })

    # Sweep: vary one parameter at a time from the frozen baseline
    baseline = {"lambda_output": 0.05, "relaxation_lr": 0.2, "steps": 4}

    # Sweep lambda_output
    for lam in EPC_SWEEP["lambda_output"]:
        if lam == baseline["lambda_output"]:
            continue
        result = _run_single_epc(model, tokens, teacher_logits,
                                  steps=baseline["steps"],
                                  relaxation_lr=baseline["relaxation_lr"],
                                  output_weight=lam)
        result["swept_param"] = "lambda_output"
        result["swept_value"] = lam
        results.append(result)

    # Sweep relaxation_lr
    for lr in EPC_SWEEP["relaxation_lr"]:
        if lr == baseline["relaxation_lr"]:
            continue
        result = _run_single_epc(model, tokens, teacher_logits,
                                  steps=baseline["steps"],
                                  relaxation_lr=lr,
                                  output_weight=baseline["lambda_output"])
        result["swept_param"] = "relaxation_lr"
        result["swept_value"] = lr
        results.append(result)

    # Sweep steps
    for steps in EPC_SWEEP["steps"]:
        if steps == baseline["steps"]:
            continue
        result = _run_single_epc(model, tokens, teacher_logits,
                                  steps=steps,
                                  relaxation_lr=baseline["relaxation_lr"],
                                  output_weight=baseline["lambda_output"])
        result["swept_param"] = "steps"
        result["swept_value"] = steps
        results.append(result)

    # Also run the baseline explicitly
    result = _run_single_epc(model, tokens, teacher_logits,
                              steps=baseline["steps"],
                              relaxation_lr=baseline["relaxation_lr"],
                              output_weight=baseline["lambda_output"])
    result["swept_param"] = "baseline"
    result["swept_value"] = None
    results.append(result)

    return {"sweep": results, "baseline": baseline}


def _run_single_epc(
    model: Any,
    tokens: torch.Tensor,
    teacher_logits: torch.Tensor,
    *,
    steps: int,
    relaxation_lr: float,
    output_weight: float,
) -> dict[str, Any]:
    """Run one ePC configuration and collect diagnostics."""
    objective, trace = gpt2_epc_objective(
        model, tokens, teacher_logits,
        steps=steps,
        temperature=2.0,
        relaxation_lr=relaxation_lr,
        max_backtracks=12,
        output_weight=output_weight,
    )

    # Compute per-block gradient norms under the ePC objective
    model.zero_grad()
    objective.backward(retain_graph=False)
    grad_norms = {}
    for name, param in model.named_parameters():
        if param.grad is not None and name.startswith("transformer.h."):
            block_key = ".".join(name.split(".")[:3])
            grad_norms[block_key] = grad_norms.get(block_key, 0.0) + float(param.grad.norm()) ** 2
    model.zero_grad()

    # Also compute ordinary KD gradient norms for credit ratio
    ordinary_kd = kd_loss(
        model(tokens, use_cache=False).logits,
        teacher_logits,
        temperature=2.0,
    )
    model.zero_grad()
    ordinary_kd.backward(retain_graph=False)
    bp_norms = {}
    for name, param in model.named_parameters():
        if param.grad is not None and name.startswith("transformer.h."):
            block_key = ".".join(name.split(".")[:3])
            bp_norms[block_key] = bp_norms.get(block_key, 0.0) + float(param.grad.norm()) ** 2
    model.zero_grad()

    credit_ratios = []
    for block_key in sorted(set(list(bp_norms.keys()) + list(grad_norms.keys()))):
        bp = math.sqrt(bp_norms.get(block_key, 0.0))
        epc = math.sqrt(grad_norms.get(block_key, 0.0))
        credit_ratios.append({
            "block": block_key,
            "bp_kd_norm": bp,
            "epc_norm": epc,
            "ratio": None if bp == 0 else epc / bp,
        })

    return {
        "lambda_output": output_weight,
        "relaxation_lr": relaxation_lr,
        "steps": steps,
        "energy": float(objective.detach()),
        "energy_history": list(trace.energy_history),
        "accepted_step_sizes": list(trace.accepted_step_sizes),
        "backtrack_counts": list(trace.backtrack_counts),
        "grad_norms_per_block": credit_ratios,
        "credit_ratios": credit_ratios,
    }


# ---------------------------------------------------------------------------
# D5: Gradient flow comparison (CE loss gradient norms per layer)
# ---------------------------------------------------------------------------

def d5_gradient_flow(model: Any, tokens: torch.Tensor) -> dict[str, Any]:
    """Per-layer gradient norms under CE loss on fixed random tokens.

    This reveals whether ePC-trained models have different gradient flow
    properties than BP-trained models, which would support or refute the
    credit-assignment mismatch hypothesis.
    """
    # Use the model's own logits as pseudo-targets (self-consistency)
    with torch.no_grad():
        target_logits = model(tokens, use_cache=False).logits.detach()
        target_tokens = target_logits.argmax(dim=-1)  # greedy tokens

    logits = model(tokens, use_cache=False).logits
    ce_loss = F.cross_entropy(
        logits.reshape(-1, logits.size(-1)),
        target_tokens.reshape(-1),
        reduction="mean",
    )

    model.zero_grad()
    ce_loss.backward()

    layer_grads = []
    for name, param in model.named_parameters():
        if param.grad is not None and name.startswith("transformer.h."):
            block_key = ".".join(name.split(".")[:3])
            grad_norm = float(param.grad.norm())

    # Collect per-block
    block_grads: dict[str, float] = {}
    block_counts: dict[str, int] = {}
    for name, param in model.named_parameters():
        if param.grad is not None and name.startswith("transformer.h."):
            block_key = ".".join(name.split(".")[:3])
            block_grads[block_key] = block_grads.get(block_key, 0.0) + float(param.grad.norm()) ** 2
            block_counts[block_key] = block_counts.get(block_key, 0) + 1

    for block_key in sorted(block_grads.keys()):
        layer_grads.append({
            "block": block_key,
            "grad_norm": math.sqrt(block_grads[block_key]),
            "n_params_groups": block_counts[block_key],
        })

    # Also get embedding gradient
    emb_grad = 0.0
    if model.transformer.wte.weight.grad is not None:
        emb_grad = float(model.transformer.wte.weight.grad.norm())

    model.zero_grad()

    return {
        "ce_loss": float(ce_loss.detach()),
        "layer_grads": layer_grads,
        "embedding_grad_norm": emb_grad,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Run CPU-only diagnostic battery on saved GPT-2 checkpoints"
    )
    parser.add_argument(
        "--checkpoints", type=Path, required=True,
        help="Directory containing seed{S}_{arm}/ checkpoint subdirectories",
    )
    parser.add_argument(
        "--output", type=Path, required=True,
        help="Output directory for diagnostic results",
    )
    parser.add_argument(
        "--source-commit", type=str, default="unknown",
        help="Git commit hash of the source code",
    )
    parser.add_argument("--device", type=str, default="cpu")
    args = parser.parse_args()

    device = torch.device(args.device)
    args.output.mkdir(parents=True, exist_ok=True)

    probe_tokens = _make_probe_tokens(PROBE_SEQ_LEN, PROBE_BATCH).to(device)

    # Load all 9 checkpoints
    models: dict[str, Any] = {}
    checkpoint_manifest: dict[str, dict] = {}

    for seed in SEEDS:
        for arm in ARMS:
            key = f"seed{seed}_{arm}"
            ckpt_dir = args.checkpoints / key
            if not ckpt_dir.exists():
                print(f"WARNING: checkpoint {key} not found at {ckpt_dir}", file=sys.stderr)
                continue
            print(f"Loading {key}...", flush=True)
            model = load_checkpoint(ckpt_dir, device)
            models[key] = model
            # Hash the safetensors file
            sf = ckpt_dir / "model.safetensors"
            checkpoint_manifest[key] = {
                "path": str(ckpt_dir),
                "model_sha256": _sha256_file(sf) if sf.exists() else None,
            }

    if not models:
        print("ERROR: no checkpoints loaded", file=sys.stderr)
        return 1

    all_results: dict[str, Any] = {
        "schema": SCHEMA,
        "source_commit": args.source_commit,
        "device": str(device),
        "probe_seq_len": PROBE_SEQ_LEN,
        "probe_batch": PROBE_BATCH,
        "probe_token_seed": PROBE_TOKEN_SEED,
        "checkpoint_manifest": checkpoint_manifest,
    }

    # D1: Weight-space spectral analysis (per checkpoint)
    print("\n=== D1: Weight-space spectral analysis ===", flush=True)
    d1_results = {}
    for key, model in models.items():
        print(f"  D1: {key}...", flush=True)
        d1_results[key] = d1_weight_spectral(model)
    all_results["d1_weight_spectral"] = d1_results

    # D2: Representation geometry (per checkpoint)
    print("\n=== D2: Representation geometry ===", flush=True)
    d2_results = {}
    for key, model in models.items():
        print(f"  D2: {key}...", flush=True)
        d2_results[key] = d2_representation_geometry(model, probe_tokens)
    all_results["d2_representation_geometry"] = d2_results

    # D3: Cross-checkpoint CKA
    print("\n=== D3: Cross-checkpoint CKA ===", flush=True)
    # Load all models into a dict for CKA (they should already be loaded)
    d3_results = d3_cross_checkpoint_cka(models, probe_tokens)
    all_results["d3_cross_checkpoint_cka"] = d3_results

    # D4: ePC hyperparameter sweep (only on ePC checkpoints)
    print("\n=== D4: ePC hyperparameter sweep ===", flush=True)
    d4_results = {}
    for seed in SEEDS:
        key = f"seed{seed}_epc_kd"
        if key not in models:
            continue
        print(f"  D4: {key}...", flush=True)
        model = models[key]
        # Use the model's own feedforward logits as self-reference teacher
        with torch.no_grad():
            teacher_logits = model(probe_tokens, use_cache=False).logits.detach()
        d4_results[key] = d4_epc_sweep(model, probe_tokens, teacher_logits)
    all_results["d4_epc_sweep"] = d4_results

    # D5: Gradient flow comparison (all checkpoints)
    print("\n=== D5: Gradient flow comparison ===", flush=True)
    d5_results = {}
    for key, model in models.items():
        print(f"  D5: {key}...", flush=True)
        d5_results[key] = d5_gradient_flow(model, probe_tokens)
    all_results["d5_gradient_flow"] = d5_results

    # Write results
    output_file = args.output / "diagnostic_results.json"
    output_file.write_text(json.dumps(all_results, indent=2, sort_keys=True) + "\n")

    # Compute and write summary
    summary = _compute_summary(all_results)
    summary_file = args.output / "summary.json"
    summary_file.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")

    print(f"\nResults written to {args.output}", flush=True)
    print(f"  Full results: {output_file}", flush=True)
    print(f"  Summary: {summary_file}", flush=True)

    # Free memory
    for model in models.values():
        del model
    import gc
    gc.collect()

    return 0


def _compute_summary(results: dict[str, Any]) -> dict[str, Any]:
    """Compute a human-readable summary of the diagnostic battery."""
    summary: dict[str, Any] = {
        "schema": "relaleap.gpt2_diagnostic_summary.v1",
    }

    # D1 summary: compare weight spectral norms across arms
    d1 = results.get("d1_weight_spectral", {})
    if d1:
        d1_comp = {}
        for arm in ARMS:
            arm_keys = [k for k in d1 if arm in k]
            if not arm_keys:
                continue
            # Average spectral norms across seeds for each layer
            layer_norms: dict[int, list[float]] = {}
            for key in arm_keys:
                for layer in d1[key]["layers"]:
                    li = layer["layer"]
                    for pname in ["attn_c_attn_spectral_norm", "attn_c_proj_spectral_norm",
                                  "mlp_c_fc_spectral_norm", "mlp_c_proj_spectral_norm"]:
                        if pname in layer:
                            layer_norms.setdefault(li, {}).setdefault(pname, []).append(layer[pname])
            d1_comp[arm] = {
                f"layer{li}_{pname}_mean": float(sum(vals) / len(vals))
                for li, pvals in sorted(layer_norms.items())
                for pname, vals in sorted(pvals.items())
            }
        summary["d1_weight_spectral_by_arm"] = d1_comp

    # D2 summary: effective rank by arm and layer
    d2 = results.get("d2_representation_geometry", {})
    if d2:
        d2_comp = {}
        for arm in ARMS:
            arm_keys = [k for k in d2 if arm in k]
            if not arm_keys:
                continue
            layer_er: dict[int, list[float]] = {}
            for key in arm_keys:
                for layer in d2[key]["hidden_states"]:
                    li = layer["layer"]
                    layer_er.setdefault(li, []).append(layer["effective_rank"])
            d2_comp[arm] = {
                f"layer{li}_effective_rank_mean": float(sum(v) / len(v))
                for li, v in sorted(layer_er.items())
            }
        summary["d2_effective_rank_by_arm"] = d2_comp

    # D3 summary: mean CKA within-arm vs cross-arm
    d3 = results.get("d3_cross_checkpoint_cka", {})
    if d3 and "pairs" in d3:
        within_arm: dict[str, list[float]] = {}
        cross_arm: dict[str, list[float]] = {}
        for pair in d3["pairs"]:
            pair_str = pair["pair"]
            # Extract arm names
            parts = pair_str.split("_vs_")
            if len(parts) != 2:
                continue
            arm_a = "_".join(parts[0].split("_")[1:])  # e.g., "bp_ce" from "seed1729_bp_ce"
            arm_b = "_".join(parts[1].split("_")[1:])
            if arm_a == arm_b:
                within_arm.setdefault(arm_a, []).append(pair["mean_cka"])
            else:
                cross_key = f"{arm_a}_vs_{arm_b}"
                cross_arm.setdefault(cross_key, []).append(pair["mean_cka"])
        summary["d3_cka_within_arm"] = {
            arm: float(sum(v) / len(v)) for arm, v in within_arm.items()
        }
        summary["d3_cka_cross_arm"] = {
            key: float(sum(v) / len(v)) for key, v in cross_arm.items()
        }

    # D4 summary: energy and credit ratio sensitivity
    d4 = results.get("d4_epc_sweep", {})
    if d4:
        d4_comp = {}
        for ckpt_key, sweep_data in d4.items():
            sweep = sweep_data.get("sweep", [])
            energies = [s["energy"] for s in sweep]
            d4_comp[ckpt_key] = {
                "energy_min": min(energies) if energies else None,
                "energy_max": max(energies) if energies else None,
                "energy_range": (max(energies) - min(energies)) if energies else None,
                "n_configs": len(sweep),
            }
        summary["d4_epc_sweep_summary"] = d4_comp

    # D5 summary: gradient norm comparison across arms
    d5 = results.get("d5_gradient_flow", {})
    if d5:
        d5_comp = {}
        for arm in ARMS:
            arm_keys = [k for k in d5 if arm in k]
            if not arm_keys:
                continue
            layer_grads: dict[int, list[float]] = {}
            for key in arm_keys:
                for layer in d5[key]["layer_grads"]:
                    block_num = int(layer["block"].split(".")[-1])
                    layer_grads.setdefault(block_num, []).append(layer["grad_norm"])
            d5_comp[arm] = {
                f"layer{li}_grad_norm_mean": float(sum(v) / len(v))
                for li, v in sorted(layer_grads.items())
            }
        summary["d5_gradient_norms_by_arm"] = d5_comp

    return summary


if __name__ == "__main__":
    raise SystemExit(main())
