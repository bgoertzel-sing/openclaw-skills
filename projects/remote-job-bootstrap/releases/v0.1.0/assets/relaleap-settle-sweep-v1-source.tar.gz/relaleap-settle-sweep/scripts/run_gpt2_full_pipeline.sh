#!/usr/bin/env bash
set -euo pipefail

# Versioned fail-fast launcher for the six-layer distillation -> outcome run.
# Stage 2 is reached if and only if Stage 1 exits successfully.

if [[ "$#" -ne 2 ]]; then
  echo "usage: $0 <distillation-output-dir> <outcome-output-json>" >&2
  exit 2
fi

distillation_output="$1"
outcome_output="$2"

PYTHONPATH=src python3 scripts/run_gpt2_pilot_gpu.py \
  --protocol configs/gpt2_small_epc_pilot.json \
  --output "$distillation_output" \
  --device cuda \
  --source-commit "$(tr -d '[:space:]' < SOURCE_COMMIT)"

PYTHONPATH=src python3 scripts/run_gpt2_outcome_gpu.py \
  --config configs/gpt2_epc_outcome_6layer.json \
  --checkpoints "$distillation_output/checkpoints" \
  --output "$outcome_output" \
  --device cuda \
  --offline
