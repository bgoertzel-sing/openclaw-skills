#!/usr/bin/env bash
set -euo pipefail

if [[ "$#" -ne 1 ]]; then
  echo "usage: $0 <output-directory>" >&2
  exit 2
fi
out="$1"
mkdir -p "$out"
for seed in 1729 3253 6421; do
  PYTHONPATH=src python3 scripts/run_cleanroom_epc_multistep.py \
    --output "$out/seed${seed}.json" \
    --revision 607a30d783dfa663caf39e06633721c8d4cfcd7e \
    --dataset-revision b08601e04326c79dfdd32d625aee71d232d685c3 \
    --seed "$seed" --updates 100 --settle-steps 4 --context 64 --evaluation-batches 16
done
python3 - "$out" <<'PY'
import json, math, pathlib, sys
out = pathlib.Path(sys.argv[1])
records = [json.loads((out / f"seed{s}.json").read_text()) for s in (1729, 3253, 6421)]
if not all(r["status"] == "passed" and r["replay_exact"] for r in records):
    raise SystemExit("required replay/status invariant failed")
gains = [r["held_out_kd"]["gain_nats"] for r in records]
if not all(math.isfinite(value) for value in gains):
    raise SystemExit("non-finite held-out KD gain")
(out / "summary.json").write_text(json.dumps({
    "schema": "relaleap.clean_room_transformer_epc_multistep_summary.v1",
    "status": "completed",
    "seeds": [1729, 3253, 6421],
    "mean_held_out_kd_gain_nats": sum(gains) / len(gains),
    "per_seed_held_out_kd_gain_nats": gains,
    "all_replays_exact": True,
}, indent=2, sort_keys=True) + "\n")
PY
