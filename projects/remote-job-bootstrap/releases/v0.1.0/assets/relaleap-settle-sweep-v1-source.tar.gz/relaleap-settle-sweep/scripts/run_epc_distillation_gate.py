#!/usr/bin/env python3
"""Matched-state BP/KD/ePC Tiny Shakespeare diagnostic gate."""
from __future__ import annotations

import argparse
import copy
from dataclasses import asdict
import hashlib
import json
import math
from pathlib import Path
import resource
import time

import torch

from relaleap.hdpc import (
    CausalCharTransformerLM,
    TinyCharTransformerConfig,
    compare_bp_and_pc_gradients,
    cross_entropy_for_logits,
    get_batch,
    kd_loss,
    prepare_tinyshakespeare_data,
    transformer_epc_objective,
)


def _csv_numbers(value: str, cast):
    values = tuple(cast(item.strip()) for item in value.split(",") if item.strip())
    if not values:
        raise argparse.ArgumentTypeError("list must not be empty")
    return values


def _model_config(dataset, args, *, teacher: bool) -> TinyCharTransformerConfig:
    return TinyCharTransformerConfig(
        vocab_size=dataset.vocab_size,
        seq_len=args.seq_len,
        d_model=args.teacher_d_model if teacher else args.student_d_model,
        nhead=args.nhead,
        d_ff=(args.teacher_d_model if teacher else args.student_d_model) * 4,
        num_layers=args.num_layers,
        dropout=0.0,
    )


def _fixed_batches(tokens, args, seed, device, count):
    generator = torch.Generator().manual_seed(seed)
    return tuple(
        get_batch(
            tokens,
            batch_size=args.batch_size,
            seq_len=args.seq_len,
            device=device,
            generator=generator,
        )
        for _ in range(count)
    )


@torch.no_grad()
def _fixed_perplexity(model, batches):
    model.eval()
    losses = [float(cross_entropy_for_logits(model(x), y)) for x, y in batches]
    model.train()
    return math.exp(sum(losses) / len(losses))


def _block_gradient_summary(model, ordinary, predictive):
    rows = compare_bp_and_pc_gradients(model, ordinary, predictive)
    groups = {}
    for row in rows:
        if row.name.startswith("blocks."):
            key = ".".join(row.name.split(".")[:2])
        elif row.name.startswith(("token_embedding", "position_embedding")):
            key = "embedding"
        elif row.name.startswith(("ln_f", "lm_head")):
            key = "head"
        else:
            key = row.name.split(".", 1)[0]
        groups.setdefault(key, []).append(row)
    summary = []
    for key, members in sorted(groups.items()):
        bp_norm = math.sqrt(sum(member.bp_norm**2 for member in members))
        pc_norm = math.sqrt(sum(member.pc_norm**2 for member in members))
        finite_cosines = [member.cosine for member in members if member.cosine is not None]
        summary.append(
            {
                "block": key,
                "bp_norm": bp_norm,
                "epc_norm": pc_norm,
                "norm_ratio": None if bp_norm == 0 else pc_norm / bp_norm,
                "mean_parameter_cosine": (
                    None if not finite_cosines else sum(finite_cosines) / len(finite_cosines)
                ),
            }
        )
    return summary


def _train_arm(template_state, config, batches, anchors, eval_batches, args, arm, lam, steps):
    model = CausalCharTransformerLM(config).to(args.device)
    model.load_state_dict(template_state)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate)
    energy_profiles = []
    gradient_summary = []
    start_rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    if args.device == "cuda":
        torch.cuda.reset_peak_memory_stats()
    started = time.perf_counter()

    for batch_index, ((x, y), anchor) in enumerate(zip(batches, anchors)):
        optimizer.zero_grad(set_to_none=True)
        logits = model(x)
        ce = cross_entropy_for_logits(logits, y)
        if arm == "bp" or lam == 0.0:
            loss = ce
        elif arm == "kd":
            distill = kd_loss(logits, anchor, temperature=args.temperature)
            loss = (1.0 - lam) * ce + lam * distill
        else:
            distill, trace = transformer_epc_objective(
                model,
                x,
                anchor,
                steps=steps,
                temperature=args.temperature,
                relaxation_lr=args.relaxation_lr,
            )
            loss = (1.0 - lam) * ce + lam * distill
            energy_profiles.append(trace.energy_history)
            if batch_index == 0:
                ordinary = kd_loss(logits, anchor, temperature=args.temperature)
                gradient_summary = _block_gradient_summary(model, ordinary, distill)
        loss.backward()
        optimizer.step()

    elapsed = time.perf_counter() - started
    end_rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return {
        "arm": arm,
        "lambda": lam,
        "inference_steps": steps if arm == "epc" else None,
        "perplexity": _fixed_perplexity(model, eval_batches),
        "wall_seconds": elapsed,
        "max_rss_kib": end_rss,
        "max_rss_delta_kib": max(0, end_rss - start_rss),
        "cuda_peak_bytes": (
            int(torch.cuda.max_memory_allocated()) if args.device == "cuda" else None
        ),
        "energy_profiles": energy_profiles,
        "energy_monotone": all(
            all(b <= a + 1e-9 * max(1.0, abs(a)) for a, b in zip(p, p[1:]))
            for p in energy_profiles
        ),
        "gradient_summary": gradient_summary,
    }


def _gate(rows, seeds):
    by_key = {(row["seed"], row["arm"], row["lambda"], row["inference_steps"]): row for row in rows}
    candidates = []
    for row in rows:
        if row["arm"] != "epc" or row["lambda"] <= 0 or row["inference_steps"] <= 1:
            continue
        comparisons = []
        invariant_ok = True
        for seed in seeds:
            epc = by_key[(seed, "epc", row["lambda"], row["inference_steps"])]
            kd = by_key[(seed, "kd", row["lambda"], None)]
            bp = by_key[(seed, "bp", 0.0, None)]
            comparisons.append(epc["perplexity"] < min(kd["perplexity"], bp["perplexity"]))
            invariant_ok = invariant_ok and epc["energy_monotone"] and all(
                math.isfinite(block["bp_norm"]) and math.isfinite(block["epc_norm"])
                for block in epc["gradient_summary"]
            )
        key = (row["lambda"], row["inference_steps"])
        if not any(candidate["lambda"] == key[0] and candidate["inference_steps"] == key[1] for candidate in candidates):
            candidates.append(
                {
                    "lambda": key[0],
                    "inference_steps": key[1],
                    "beats_bp_and_kd_each_seed": all(comparisons),
                    "invariants_pass": invariant_ok,
                    "promote": len(seeds) >= 2 and all(comparisons) and invariant_ok,
                }
            )
    return {"passed": any(item["promote"] for item in candidates), "candidates": candidates}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, default=Path("data/tinyshakespeare"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cpu")
    parser.add_argument("--seeds", type=lambda v: _csv_numbers(v, int), default=(11, 29, 47))
    parser.add_argument("--lambdas", type=lambda v: _csv_numbers(v, float), default=(0.0, 0.001, 0.01, 0.05))
    parser.add_argument("--inference-steps", type=lambda v: _csv_numbers(v, int), default=(1, 2, 4, 8))
    parser.add_argument("--temperature", type=float, default=2.0)
    parser.add_argument("--relaxation-lr", type=float, default=0.2)
    parser.add_argument("--seq-len", type=int, default=64)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--teacher-d-model", type=int, default=64)
    parser.add_argument("--student-d-model", type=int, default=32)
    parser.add_argument("--nhead", type=int, default=2)
    parser.add_argument("--num-layers", type=int, default=2)
    parser.add_argument("--teacher-steps", type=int, default=40)
    parser.add_argument("--train-steps", type=int, default=20)
    parser.add_argument("--eval-batches", type=int, default=8)
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    args = parser.parse_args()
    if any(not 0.0 <= lam < 1.0 for lam in args.lambdas):
        parser.error("lambdas must be in [0,1)")
    if any(step < 1 for step in args.inference_steps):
        parser.error("inference steps must be positive")

    dataset = prepare_tinyshakespeare_data(args.data_dir, download=False)
    corpus_hash = hashlib.sha256(dataset.source_path.read_bytes()).hexdigest()
    rows = []
    for seed in args.seeds:
        torch.manual_seed(seed)
        teacher_config = _model_config(dataset, args, teacher=True)
        teacher = CausalCharTransformerLM(teacher_config).to(args.device)
        teacher_optimizer = torch.optim.AdamW(teacher.parameters(), lr=args.learning_rate)
        teacher_batches = _fixed_batches(dataset.train, args, seed + 1000, args.device, args.teacher_steps)
        for x, y in teacher_batches:
            teacher_optimizer.zero_grad(set_to_none=True)
            loss = cross_entropy_for_logits(teacher(x), y)
            loss.backward()
            teacher_optimizer.step()
        teacher.eval()

        train_batches = _fixed_batches(dataset.train, args, seed + 2000, args.device, args.train_steps)
        eval_batches = _fixed_batches(dataset.val, args, seed + 3000, args.device, args.eval_batches)
        with torch.no_grad():
            anchors = tuple(teacher(x).detach() for x, _ in train_batches)

        torch.manual_seed(seed + 4000)
        student_config = _model_config(dataset, args, teacher=False)
        template = CausalCharTransformerLM(student_config).to(args.device)
        template_state = copy.deepcopy(template.state_dict())

        bp = _train_arm(template_state, student_config, train_batches, anchors, eval_batches, args, "bp", 0.0, 1)
        bp["seed"] = seed
        rows.append(bp)
        for lam in args.lambdas:
            if lam == 0.0:
                continue
            kd = _train_arm(template_state, student_config, train_batches, anchors, eval_batches, args, "kd", lam, 1)
            kd["seed"] = seed
            rows.append(kd)
            for steps in args.inference_steps:
                epc = _train_arm(template_state, student_config, train_batches, anchors, eval_batches, args, "epc", lam, steps)
                epc["seed"] = seed
                rows.append(epc)

    payload = {
        "schema": "relaleap.epc_distillation_gate.v1",
        "config": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
        "dropout": 0.0,
        "corpus_sha256": corpus_hash,
        "rows": rows,
        "gate": _gate(rows, args.seeds),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(args.output), "gate": payload["gate"]}, sort_keys=True))


if __name__ == "__main__":
    main()
