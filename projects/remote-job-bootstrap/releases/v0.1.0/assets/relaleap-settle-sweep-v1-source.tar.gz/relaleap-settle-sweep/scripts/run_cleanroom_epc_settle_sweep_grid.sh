#!/usr/bin/env bash
set -euo pipefail

if [[ "$#" -ne 1 ]]; then
  echo "usage: $0 <output-directory>" >&2
  exit 2
fi
out="$1"
mkdir -p "$out"
for seed in 1729 3253 6421; do
  PYTHONPATH=src python3 scripts/run_cleanroom_epc_settle_sweep.py \
    --output "$out/seed${seed}.json" \
    --revision 607a30d783dfa663caf39e06633721c8d4cfcd7e \
    --dataset-revision b08601e04326c79dfdd32d625aee71d232d685c3 \
    --seed "$seed" --updates 100 --context 64 --evaluation-batches 16 --resume
done
PYTHONPATH=src python3 - "$out" <<'PY'
import json
import pathlib
import sys

from relaleap.hdpc.settle_sweep import aggregate_seed_records

out = pathlib.Path(sys.argv[1])
records = [
    json.loads((out / f"seed{seed}.json").read_text())
    for seed in (1729, 3253, 6421)
]
(out / "summary.json").write_text(
    json.dumps(aggregate_seed_records(records), indent=2, sort_keys=True) + "\n"
)
PY
sha256sum "$out"/seed*.json "$out"/summary.json > "$out/SHA256SUMS"
