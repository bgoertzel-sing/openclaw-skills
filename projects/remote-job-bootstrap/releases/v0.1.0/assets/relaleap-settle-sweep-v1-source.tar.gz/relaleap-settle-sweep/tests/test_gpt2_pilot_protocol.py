from pathlib import Path

import pytest

from relaleap.hdpc.pilot_protocol import load_pilot_protocol, validate_pilot_protocol
from relaleap.hdpc.tinyshakespeare import CausalCharTransformerLM, TinyCharTransformerConfig, kd_loss
from relaleap.hdpc.transformer_epc import transformer_epc_objective
import torch


PROTOCOL = Path(__file__).parents[1] / "configs" / "gpt2_small_epc_pilot.json"


def test_frozen_gpt2_pilot_protocol_is_complete() -> None:
    protocol = load_pilot_protocol(PROTOCOL)
    assert protocol["teacher"]["weights_sha256"] == "248dfc3911869ec493c76e65bf2fcf7f615828b0254c12b473182f0f81d3a707"
    assert protocol["student"]["num_layers"] == 6
    assert protocol["training"]["context_length"] == 256
    assert protocol["evaluation"]["seeds"] == [1729, 3253, 6421]
    assert protocol["epc"]["hidden_state_arm"]["enabled_in_primary"] is False


def test_protocol_rejects_missing_wall_clock_control() -> None:
    protocol = load_pilot_protocol(PROTOCOL)
    protocol["controls"]["wall_clock_matched"] = False
    with pytest.raises(ValueError, match="wall-clock"):
        validate_pilot_protocol(protocol)


def test_protocol_rejects_toy_teacher_architecture() -> None:
    protocol = load_pilot_protocol(PROTOCOL)
    protocol["teacher"]["num_layers"] = 2
    with pytest.raises(ValueError, match="GPT-2-small"):
        validate_pilot_protocol(protocol)


def test_output_weight_does_not_break_exact_depth_one_kd_endpoint() -> None:
    torch.manual_seed(27)
    config = TinyCharTransformerConfig(
        vocab_size=11, seq_len=4, d_model=8, nhead=2, d_ff=16, num_layers=2
    )
    teacher = CausalCharTransformerLM(config)
    student = CausalCharTransformerLM(config)
    tokens = torch.randint(0, 11, (2, 4))
    with torch.no_grad():
        anchor = teacher(tokens)
    expected = kd_loss(student(tokens), anchor, temperature=2.0)
    actual, _ = transformer_epc_objective(
        student, tokens, anchor, steps=1, temperature=2.0, output_weight=0.05
    )
    assert torch.equal(actual, expected)
