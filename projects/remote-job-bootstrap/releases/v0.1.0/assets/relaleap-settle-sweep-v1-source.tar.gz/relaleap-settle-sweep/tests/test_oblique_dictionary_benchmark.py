from relaleap.slt.releap_benchmarks import generate_all_releap_benchmarks, generate_releap_benchmark, mock_estimator_output


def test_oblique_dictionary_declares_nonorthogonal_winner_and_basis_overlap():
    data = generate_releap_benchmark("oblique_dictionary", seed=6, n=88, d_model=12, num_columns=5)
    md = data.metadata
    assert md["true_interactions"]["oblique_dictionary"] is True
    assert md["true_interactions"]["max_off_diagonal_abs_cosine"] > 0.05
    assert md["expected_winner"] == "nonorthogonal_dictionary"
    assert md["expected_I_lambda_signs"]["nonorthogonal_vs_orthogonal_margin"] == "positive"
    assert md["expected_I_lambda_signs"]["causal_factorization_after_diagnostics"] == "positive"
    assert mock_estimator_output(md).winner == "nonorthogonal_dictionary"


def test_all_releap_shaped_benchmarks_have_ground_truth_contract():
    fixtures = generate_all_releap_benchmarks(seed=10, n=32, d_model=10, num_columns=4)
    assert set(fixtures) == {
        "rank_one_atom_gauge",
        "dead_column",
        "shared_core",
        "mediator",
        "router_collapse",
        "low_rank_trap",
        "oblique_dictionary",
    }
    for name, data in fixtures.items():
        md = data.metadata
        assert md["benchmark_id"] == name
        assert md["true_support"]
        assert md["true_columns"]
        assert md["true_basis"]
        assert md["true_interactions"] is not None
        assert md["expected_winner"]
        assert md["expected_I_lambda_signs"]
