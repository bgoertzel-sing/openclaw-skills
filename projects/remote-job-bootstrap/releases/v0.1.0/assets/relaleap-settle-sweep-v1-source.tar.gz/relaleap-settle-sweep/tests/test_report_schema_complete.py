import dataclasses

import pytest

from relaleap.slt.reports import (
    FINITE_SAMPLE_WORDING,
    CalibrationReport,
    EstimatorRunReport,
    LambdaEstimate,
    ParameterBlockReport,
    ReportValidationError,
    SamplerDiagnostics,
    SampleSizeSensitivity,
)


VALIDATION_PLAN_TEXT = "Finite-sample WBIC validation with SGLD diagnostics, calibration, and null normalization."


def passing_report(**overrides):
    data = dict(
        estimator_type="finite_sample_wbic_sgld_proxy",
        validation_plan_text=VALIDATION_PLAN_TEXT,
        parameter_blocks=[
            ParameterBlockReport(
                block_id="adapter.column_0",
                parameter_names=["u", "v"],
                trainable=True,
                fitted_from_frozen_cache=False,
                gauge_policy="signed_norm_policy",
                map_reference_check="pass",
                prior_check="pass",
            )
        ],
        calibration=CalibrationReport(
            status="pass",
            benchmarks=["gaussian"],
            expected_lambda={"gaussian": 1.0},
            observed_lambda={"gaussian": 1.0},
            tolerance=0.1,
            notes="passes analytic benchmark",
        ),
        sampler_diagnostics=SamplerDiagnostics(
            chains=4,
            effective_sample_size=250,
            r_hat=1.01,
            monte_carlo_cv=0.1,
            target_matches_map_loss=True,
            wbic_temperature=0.12,
            wbic_temperature_formula="beta = 1/log(n)",
        ),
        input_sample_size=4096,
        input_coverage_report="coverage ok",
        inference_budget_report="budget ok",
        sample_size_sensitivity=SampleSizeSensitivity(
            input_counts=[1024, 2048, 4096],
            slope_fit="stable linear-in-log fit",
            stable_sign=True,
            stable_margin=True,
            notes="stable",
        ),
        lambda_estimates=[
            LambdaEstimate(
                target="module_vs_joint",
                lambda_hat=0.72,
                standard_error=0.03,
                null_normalized_margin=0.31,
                interpretation="positive margin",
            )
        ],
        finite_sample_wording=FINITE_SAMPLE_WORDING,
        module_vs_joint_report="joint differs from module sum",
        interaction_null_report="null margin positive",
        decision="allow_releap_evidence",
        metadata={"seed": 1},
    )
    data.update(overrides)
    return EstimatorRunReport(**data)


def test_complete_passing_report_validates():
    passing_report().validate_complete_schema()


@pytest.mark.parametrize(
    "field_name,bad_value",
    [
        ("estimator_type", ""),
        ("validation_plan_text", "no required terms"),
        ("parameter_blocks", []),
        ("input_sample_size", 0),
        ("input_coverage_report", ""),
        ("inference_budget_report", ""),
        ("lambda_estimates", []),
        ("finite_sample_wording", "exact RLCT"),
        ("module_vs_joint_report", ""),
        ("interaction_null_report", ""),
        ("decision", "block_releap_evidence"),
    ],
)
def test_missing_each_required_top_level_field_fails(field_name, bad_value):
    with pytest.raises(ReportValidationError):
        passing_report(**{field_name: bad_value}).validate_complete_schema()


def test_missing_required_nested_fields_fail():
    nested_cases = [
        {"calibration": dataclasses.replace(passing_report().calibration, benchmarks=[])},
        {"sampler_diagnostics": dataclasses.replace(passing_report().sampler_diagnostics, effective_sample_size=199)},
        {"sample_size_sensitivity": dataclasses.replace(passing_report().sample_size_sensitivity, slope_fit="")},
        {"lambda_estimates": [dataclasses.replace(passing_report().lambda_estimates[0], target="")]},
        {"parameter_blocks": [dataclasses.replace(passing_report().parameter_blocks[0], parameter_names=[])]},
    ]
    for override in nested_cases:
        with pytest.raises(ReportValidationError):
            passing_report(**override).validate_complete_schema()
