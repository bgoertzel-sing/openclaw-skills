import torch

from relaleap.slt.energy import QuadraticEnergyModel
from relaleap.slt.map_refinement import MAPRefinementConfig, refine_map, refine_map_reference
from relaleap.slt.parameter_blocks import ParameterBlock
from relaleap.slt.priors import GaussianPrior


def test_refine_map_passes_at_known_quadratic_map_in_one_step_or_less():
    center = torch.tensor([0.0, 0.0], dtype=torch.float64)
    block = ParameterBlock(name="theta", role="joint", size=2)
    model = QuadraticEnergyModel(reference=center, blocks=[block])
    prior = GaussianPrior(mean=center, scale=10.0)

    refined, report = refine_map(model, prior, center, max_steps=25, lr=1.0)
    assert report.theta_hat_status == "local_map_pass"
    assert report.map_refinement_steps <= 1
    assert report.loss_decrease_after_refinement <= report.material_decrease_threshold
    assert report.grad_norm_at_theta_hat == 0.0
    assert torch.allclose(refined, center, atol=1e-8)


def test_refine_map_recovers_map_from_perturbed_theta():
    reference = torch.tensor([1.0, -2.0], dtype=torch.float64)
    theta_hat = torch.tensor([5.0, 5.0], dtype=torch.float64)
    block = ParameterBlock(name="theta", role="joint", size=2)
    prior = GaussianPrior(mean=torch.zeros(2, dtype=torch.float64), scale=2.0)
    model = QuadraticEnergyModel(reference=reference, blocks=[block])

    refined, report = refine_map(model, prior, theta_hat, max_steps=200, lr=0.5, tol=1e-10)
    expected_map = reference / (1.0 + 1.0 / prior.scale**2)
    assert report.theta_hat_status == "local_map_fail"
    assert report.loss_decrease_after_refinement > report.material_decrease_threshold
    assert report.energy_after_refinement < report.energy_before_refinement
    assert torch.allclose(refined, expected_map, atol=1e-4)


def test_map_refinement_passes_at_known_quadratic_map_with_function_api():
    center = torch.tensor([0.2, -0.1], dtype=torch.float64)
    prior = GaussianPrior(mean=torch.zeros(2, dtype=torch.float64), scale=10.0)
    # Choose energy so energy - log_prior has its MAP exactly at center.
    def energy(theta):
        return 0.5 * torch.sum((theta - center) ** 2) + prior.log_density(theta)

    refined, report = refine_map_reference(center, energy, prior, MAPRefinementConfig(max_steps=25, learning_rate=0.5))
    assert report.theta_hat_status == "local_map_pass"
    assert report.loss_decrease_after_refinement <= report.material_decrease_threshold
    assert torch.allclose(refined, center, atol=1e-5)
