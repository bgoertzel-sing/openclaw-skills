import os
import subprocess
from pathlib import Path


REPO = Path(__file__).parents[1]
PIPELINE = REPO / "scripts" / "run_gpt2_full_pipeline.sh"


def _write_executable(path: Path, content: str) -> None:
    path.write_text(content)
    path.chmod(0o755)


def test_pipeline_skips_outcome_after_distillation_failure(tmp_path: Path) -> None:
    fake_bin = tmp_path / "bin"
    fake_bin.mkdir()
    calls = tmp_path / "calls"
    _write_executable(
        fake_bin / "python3",
        "#!/usr/bin/env bash\n"
        f"echo \"$*\" >> {calls}\n"
        "if [[ \"$*\" == *run_gpt2_pilot_gpu.py* ]]; then exit 17; fi\n"
        "exit 0\n",
    )
    env = dict(os.environ, PATH=f"{fake_bin}:{os.environ['PATH']}")
    result = subprocess.run(
        ["bash", str(PIPELINE), str(tmp_path / "distill"), str(tmp_path / "out.json")],
        cwd=REPO,
        env=env,
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 17
    recorded = calls.read_text()
    assert "run_gpt2_pilot_gpu.py" in recorded
    assert "run_gpt2_outcome_gpu.py" not in recorded
