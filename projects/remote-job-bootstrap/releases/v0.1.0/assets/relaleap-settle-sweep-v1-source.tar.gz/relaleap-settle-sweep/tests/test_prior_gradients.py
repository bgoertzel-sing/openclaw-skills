import torch

from relaleap.slt.priors import GaussianPrior, ImproperUniform, LaplacePrior, finite_difference_grad


def test_gaussian_prior_gradient_matches_finite_difference():
    theta = torch.tensor([0.25, -0.7, 1.3], dtype=torch.float64)
    prior = GaussianPrior(mean=torch.tensor([0.1, 0.2, -0.3], dtype=torch.float64), scale=1.7)
    fd = finite_difference_grad(prior.log_density, theta, eps=1e-6)
    assert torch.allclose(prior.grad_log_density(theta), fd, atol=1e-5, rtol=1e-5)


def test_gaussian_prior_backward_compatible_negative_log_gradient():
    theta = torch.tensor([0.25, -0.7, 1.3], dtype=torch.float64)
    prior = GaussianPrior(scale=1.7)
    fd = finite_difference_grad(prior.negative_log_prob, theta, eps=1e-6)
    assert torch.allclose(prior.grad(theta), fd, atol=1e-5, rtol=1e-5)


def test_laplace_prior_gradient_matches_finite_difference_away_from_zero():
    theta = torch.tensor([0.25, -0.7, 1.3], dtype=torch.float64)
    prior = LaplacePrior(scale=2.0)
    fd = finite_difference_grad(prior.log_density, theta, eps=1e-6)
    assert torch.allclose(prior.grad_log_density(theta), fd, atol=1e-5, rtol=1e-5)


def test_improper_uniform_gradient_matches_finite_difference():
    theta = torch.tensor([0.25, -0.7, 1.3], dtype=torch.float64)
    prior = ImproperUniform()
    fd = finite_difference_grad(prior.log_density, theta, eps=1e-6)
    assert torch.allclose(prior.grad_log_density(theta), fd, atol=1e-12, rtol=0.0)
    assert prior.family_name == "improper_uniform"
