import json
from pathlib import Path

import torch

from scripts.run_gpt2_r8_outcomes import _span_corrupt, _summary
from relaleap.hdpc.pilot_protocol import load_pilot_protocol


def test_r8_protocol_is_frozen_and_five_seed():
    protocol = load_pilot_protocol(Path("configs/gpt2_epc_r8.json"))
    assert len(protocol["evaluation"]["seeds"]) == 5
    assert protocol["r8"]["epc_variants"] == {"epc_original": 4, "epc_deep": 12}


def test_span_corruption_is_deterministic_and_mass_matched():
    chunks = [torch.arange(101)]
    first = _span_corrupt(chunks, 1000, .1, 7)[0]
    second = _span_corrupt(chunks, 1000, .1, 7)[0]
    assert torch.equal(first, second)
    assert 1 <= int((first != chunks[0]).sum()) <= 10
    assert first[-1] == chunks[0][-1]


def test_representation_summary_recovers_known_rank_and_is_finite():
    torch.manual_seed(3)
    base = torch.randn(256, 4)
    values = torch.cat([base, base @ torch.randn(4, 12)], dim=1)
    result = _summary(values)
    assert 3.0 < result["effective_rank"] <= 4.1
    assert 1.0 <= result["stable_rank"] <= 4.1
    assert all(torch.isfinite(torch.tensor(value)) for value in result.values())
