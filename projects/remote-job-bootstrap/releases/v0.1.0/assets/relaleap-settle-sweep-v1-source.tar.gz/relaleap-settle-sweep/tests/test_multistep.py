import pytest
import torch

from relaleap.hdpc.multistep import replay_is_exact, run_arm
from relaleap.hdpc.pcstep_adapter import PCStepBatch, capture_snapshot

transformers = pytest.importorskip("transformers")


def test_multistep_epc_replay_is_exact_and_arms_diverge():
    torch.manual_seed(123)
    config = transformers.GPT2Config(
        vocab_size=31, n_positions=8, n_ctx=8, n_embd=16, n_layer=2,
        n_head=2, n_inner=32, use_cache=False, resid_pdrop=0.0,
        embd_pdrop=0.0, attn_pdrop=0.0,
    )
    model = transformers.GPT2LMHeadModel(config).train()
    teacher = transformers.GPT2LMHeadModel(config).eval()
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4)
    initial = capture_snapshot(model, optimizer, outer_step=0, batch_cursor=0)

    def batches(index):
        tokens = torch.tensor([[index + 1, 2, 3, 4, 5, 6, 7, 8]]) % 31
        with torch.no_grad():
            logits = teacher(tokens, use_cache=False).logits
        return PCStepBatch(tokens, logits, cursor=index)

    common = dict(updates=3, settle_steps=3, temperature=2.0, gate={0: True, 1: True})
    baseline = run_arm(model, optimizer, initial, batches, arm="t1_kd", **common)
    epc = run_arm(model, optimizer, initial, batches, arm="settled_epc", **common)
    assert replay_is_exact(model, optimizer, initial, batches, arm="settled_epc", **common)
    assert baseline.final_model_digest != epc.final_model_digest
