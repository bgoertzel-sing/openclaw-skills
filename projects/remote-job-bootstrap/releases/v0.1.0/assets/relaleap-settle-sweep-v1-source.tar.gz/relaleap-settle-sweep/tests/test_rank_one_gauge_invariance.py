import torch

from relaleap.slt.gauge import GaugePolicy, canonicalize_rank_one_atoms, rank_one_function


def test_rank_one_scale_sign_permutation_canonicalization_preserves_function():
    read = torch.tensor([[-2.0, 0.5, 0.0], [0.0, -3.0, 4.0], [1.0, 1.0, 0.0]])
    write = torch.tensor([[0.0, -6.0], [-1.0, 1.0], [-2.0, 0.0]])
    amplitude = torch.tensor([0.25, -0.5, 2.0])
    usage = torch.tensor([0.3, 0.9, 0.1])
    inputs = torch.randn(17, 3)

    before = rank_one_function(read, write, amplitude, inputs)
    c_read, c_write, c_amp, membership, report = canonicalize_rank_one_atoms(
        read,
        write,
        amplitude,
        usage=usage,
        membership=torch.eye(3),
        policy=GaugePolicy(sort_atoms_by="usage"),
    )
    after = rank_one_function(c_read, c_write, c_amp, inputs)

    assert torch.allclose(after, before, atol=1e-6)
    assert torch.allclose(c_read.norm(dim=1), torch.ones(3), atol=1e-6)
    assert torch.allclose(c_write.norm(dim=1), torch.ones(3), atol=1e-6)
    assert report.permutation == (1, 0, 2)
    assert membership is not None and membership.shape == (3, 3)
    for row in c_read:
        assert row[torch.nonzero(row.abs() > 1e-12, as_tuple=False)[0, 0]] > 0
    for row in c_write:
        assert row[torch.nonzero(row.abs() > 1e-12, as_tuple=False)[0, 0]] > 0


def test_rank_one_canonicalization_collapses_equivalent_coordinates():
    read = torch.tensor([[2.0, -4.0], [-1.0, 0.5]])
    write = torch.tensor([[-3.0, 0.0], [0.0, -2.0]])
    amplitude = torch.tensor([0.5, 8.0])

    transformed_read = read.clone()
    transformed_write = write.clone()
    transformed_amp = amplitude.clone()
    transformed_read[0] *= -7.0
    transformed_write[0] *= 0.25
    transformed_amp[0] *= -1.0 / (7.0 * 0.25)
    transformed_read[1] *= 3.0
    transformed_write[1] *= -5.0
    transformed_amp[1] *= -1.0 / (3.0 * 5.0)

    args = dict(policy=GaugePolicy(sort_atoms_by="none"))
    base = canonicalize_rank_one_atoms(read, write, amplitude, **args)
    equiv = canonicalize_rank_one_atoms(transformed_read, transformed_write, transformed_amp, **args)

    for a, b in zip(base[:3], equiv[:3]):
        assert torch.allclose(a, b, atol=1e-6)
