from __future__ import annotations

import torch

from relaleap.hdpc import (
    CausalCharTransformerLM,
    HDPCTinyShakespeareStudent,
    TinyCharTransformerConfig,
    TinyShakespeareTokenizer,
    compare_bp_and_pc_gradients,
    cross_entropy_for_logits,
    get_batch,
    kd_loss,
    prepare_tinyshakespeare_data,
    transformer_epc_objective,
)


SAMPLE_TEXT = "First Citizen:\nBefore we proceed any further, hear me speak.\nAll:\nSpeak, speak.\n"


def test_tinyshakespeare_tokenizer_round_trips_text() -> None:
    tokenizer = TinyShakespeareTokenizer.from_text(SAMPLE_TEXT)
    encoded = tokenizer.encode("Speak\n")

    assert tokenizer.vocab_size == len(set(SAMPLE_TEXT))
    assert encoded.dtype == torch.long
    assert tokenizer.decode(encoded) == "Speak\n"


def test_data_loading_uses_90_10_split_without_network(tmp_path) -> None:
    data_dir = tmp_path / "tinyshakespeare"
    data_dir.mkdir()
    (data_dir / "tinyshakespeare.txt").write_text(SAMPLE_TEXT * 10, encoding="utf-8")

    dataset = prepare_tinyshakespeare_data(data_dir, download=False)

    assert dataset.source_path == data_dir / "tinyshakespeare.txt"
    assert len(dataset.train) == int(0.9 * len(SAMPLE_TEXT * 10))
    assert len(dataset.val) == len(SAMPLE_TEXT * 10) - len(dataset.train)
    x, y = get_batch(dataset.train, batch_size=4, seq_len=8, device="cpu")
    assert x.shape == y.shape == (4, 8)
    assert int(x.max()) < dataset.vocab_size


def _tiny_config(vocab_size: int = 17) -> TinyCharTransformerConfig:
    return TinyCharTransformerConfig(
        vocab_size=vocab_size,
        seq_len=16,
        d_model=16,
        nhead=2,
        d_ff=32,
        num_layers=2,
    )


def test_model_construction_and_identity_crown_forward() -> None:
    torch.manual_seed(11)
    config = _tiny_config()
    teacher = CausalCharTransformerLM(config)
    student = HDPCTinyShakespeareStudent(config)
    student.backbone.load_state_dict(teacher.state_dict())
    idx = torch.randint(0, config.vocab_size, (3, config.seq_len))

    with torch.no_grad():
        teacher_logits = teacher(idx)
        student_logits = student(idx, detached_crown=True)

    assert teacher_logits.shape == (3, config.seq_len, config.vocab_size)
    assert torch.equal(student_logits, teacher_logits)


def test_single_forward_backward_pass_with_detached_kd_anchor() -> None:
    torch.manual_seed(12)
    config = _tiny_config()
    teacher = CausalCharTransformerLM(config)
    student = HDPCTinyShakespeareStudent(config)
    idx = torch.randint(0, config.vocab_size, (2, config.seq_len))
    targets = torch.randint(0, config.vocab_size, (2, config.seq_len))

    with torch.no_grad():
        anchor = teacher(idx).detach()
    logits = student(idx, detached_crown=True)
    loss = 0.95 * cross_entropy_for_logits(logits, targets) + 0.05 * kd_loss(
        logits, anchor, temperature=2.0
    )
    loss.backward()

    backbone_grad = student.backbone.lm_head.weight.grad
    crown_grad = student.crown.output.weight.grad
    assert backbone_grad is not None and backbone_grad.shape == student.backbone.lm_head.weight.shape
    assert crown_grad is not None and crown_grad.shape == student.crown.output.weight.shape
    assert teacher.lm_head.weight.grad is None


def test_pc_vs_bp_gradient_diagnostic_shapes_match_parameters() -> None:
    torch.manual_seed(13)
    config = _tiny_config()
    teacher = CausalCharTransformerLM(config)
    student = HDPCTinyShakespeareStudent(config)
    idx = torch.randint(0, config.vocab_size, (2, config.seq_len))
    targets = torch.randint(0, config.vocab_size, (2, config.seq_len))

    with torch.no_grad():
        anchor = teacher(idx).detach()
    logits = student(idx, detached_crown=True)
    bp_loss = cross_entropy_for_logits(logits, targets)
    pc_loss = kd_loss(logits, anchor, temperature=4.0)
    diagnostics = compare_bp_and_pc_gradients(student, bp_loss, pc_loss)
    parameter_shapes = {
        name: tuple(parameter.shape)
        for name, parameter in student.named_parameters()
        if parameter.requires_grad
    }

    assert diagnostics
    assert {diagnostic.name for diagnostic in diagnostics} == set(parameter_shapes)
    for diagnostic in diagnostics:
        assert diagnostic.shape == parameter_shapes[diagnostic.name]
        assert diagnostic.bp_norm >= 0.0
        assert diagnostic.pc_norm >= 0.0


def test_transformer_epc_depth_one_is_exact_kd_endpoint() -> None:
    torch.manual_seed(14)
    config = _tiny_config()
    teacher = CausalCharTransformerLM(config)
    student = CausalCharTransformerLM(config)
    idx = torch.randint(0, config.vocab_size, (2, config.seq_len))
    with torch.no_grad():
        teacher_logits = teacher(idx)

    expected = kd_loss(student(idx), teacher_logits, temperature=2.0)
    actual, trace = transformer_epc_objective(
        student, idx, teacher_logits, steps=1, temperature=2.0
    )

    assert torch.equal(actual, expected)
    assert trace.energy_history == (float(expected.detach()),)
    assert trace.monotone


def test_transformer_epc_relaxation_is_monotone_and_locally_differentiable() -> None:
    torch.manual_seed(15)
    config = _tiny_config()
    teacher = CausalCharTransformerLM(config)
    student = CausalCharTransformerLM(config)
    idx = torch.randint(0, config.vocab_size, (2, config.seq_len))
    with torch.no_grad():
        teacher_logits = teacher(idx)

    objective, trace = transformer_epc_objective(
        student,
        idx,
        teacher_logits,
        steps=4,
        temperature=4.0,
        relaxation_lr=0.5,
    )
    objective.backward()

    assert len(trace.energy_history) == 4
    assert trace.monotone
    assert trace.energy_history[-1] <= trace.energy_history[0]
    assert student.blocks[0].attn.in_proj_weight.grad is not None
    assert student.lm_head.weight.grad is not None


def test_transformer_epc_propagates_nonzero_credit_into_earlier_blocks() -> None:
    torch.manual_seed(16)
    config = _tiny_config()
    teacher = CausalCharTransformerLM(config)
    student = CausalCharTransformerLM(config)
    idx = torch.randint(0, config.vocab_size, (2, config.seq_len))
    with torch.no_grad():
        teacher_logits = teacher(idx)

    objective, trace = transformer_epc_objective(
        student,
        idx,
        teacher_logits,
        steps=4,
        temperature=2.0,
        relaxation_lr=0.2,
    )
    objective.backward()

    first = student.blocks[0].attn.in_proj_weight.grad
    second = student.blocks[1].attn.in_proj_weight.grad
    assert trace.monotone
    assert first is not None and float(first.norm()) > 0.0
    assert second is not None and float(second.norm()) > float(first.norm())
