import torch
from relaleap.synthetic import generate_regime, generate_all_regimes

REGIMES = ["exact_factorized", "shared_core_redundant", "synergistic_pair", "low_rank_trap", "oblique_dictionary", "random_null"]

def test_all_regimes_shapes_and_metadata():
    for name in REGIMES:
        data = generate_regime(name, seed=7, n=64, d_model=12, c_dim=5, num_columns=4, support_size=2)
        assert data.hidden_states.shape == (64, 12)
        assert data.context_features.shape == (64, 5)
        assert data.true_supports.shape == (64, 2)
        assert data.ground_truth_residuals.shape == (64, 12)
        assert data.metadata["known_regime"] == name
        assert data.metadata["seed"] == 7

def test_deterministic_seed():
    a = generate_regime("exact_factorized", seed=11)
    b = generate_regime("exact_factorized", seed=11)
    assert torch.allclose(a.hidden_states, b.hidden_states)
    assert torch.allclose(a.ground_truth_residuals, b.ground_truth_residuals)
    assert torch.equal(a.true_supports, b.true_supports)

def test_regime_specific_metadata():
    shared = generate_regime("shared_core_redundant", seed=1)
    syn = generate_regime("synergistic_pair", seed=1)
    low = generate_regime("low_rank_trap", seed=1)
    assert shared.metadata["true_interactions"]["shared_core_columns"] == [0, 1]
    assert syn.metadata["true_interactions"]["synergistic_pairs"] == [[0, 1]]
    assert low.metadata["true_interactions"]["low_rank"] >= 1
    assert set(generate_all_regimes(seed=3).keys()) == set(REGIMES)
