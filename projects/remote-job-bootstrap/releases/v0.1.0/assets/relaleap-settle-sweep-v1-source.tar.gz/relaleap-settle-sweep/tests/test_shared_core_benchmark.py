from relaleap.slt.releap_benchmarks import generate_releap_benchmark, mock_estimator_output


def test_shared_core_metadata_expects_positive_unconditioned_interaction():
    data = generate_releap_benchmark("shared_core", seed=5, n=96, d_model=12, num_columns=4)
    md = data.metadata
    assert md["true_shared_core"]["columns"] == [0, 1]
    assert md["true_interactions"]["shared_core_columns"] == [0, 1]
    assert md["expected_winner"] == "shared_core_conditioned_columnar_adapter"
    assert md["expected_I_lambda_signs"]["I_lambda(A;B)"] == "positive"
    assert md["expected_I_lambda_signs"]["I_lambda(A;B|shared_core)"] == "near_zero"
    mock = mock_estimator_output(md)
    assert mock.I_lambda_signs["I_lambda(A;B)"] == "positive"
