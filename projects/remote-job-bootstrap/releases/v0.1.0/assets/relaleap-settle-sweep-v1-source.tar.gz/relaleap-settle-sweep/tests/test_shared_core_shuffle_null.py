import torch

from relaleap.slt.nulls import shared_core_shuffle_null


def test_shared_core_shuffle_permutes_columns_not_rows():
    shared_core_dirs = torch.arange(20, dtype=torch.float32).reshape(4, 5)
    shuffled = shared_core_shuffle_null(shared_core_dirs, seed=5)
    shuffled_again = shared_core_shuffle_null(shared_core_dirs, seed=5)

    assert shuffled.shape == shared_core_dirs.shape
    assert torch.equal(shuffled, shuffled_again)
    assert not torch.equal(shuffled, shared_core_dirs)
    assert torch.equal(torch.sort(shuffled, dim=1).values, torch.sort(shared_core_dirs, dim=1).values)
    assert not torch.equal(shuffled[:, 0], shared_core_dirs[:, 0])
