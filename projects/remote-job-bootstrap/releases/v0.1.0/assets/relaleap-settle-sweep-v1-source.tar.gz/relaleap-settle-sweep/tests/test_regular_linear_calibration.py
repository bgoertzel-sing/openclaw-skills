import torch

from relaleap.slt.analytic_registry import BenchmarkFamily, regular_linear_gaussian
from relaleap.slt.calibration_benchmarks import TargetMetadataEstimator, check_estimate
from relaleap.slt.contracts import make_mock_estimator_output


def test_regular_linear_gaussian_target_is_d_over_two():
    bench = regular_linear_gaussian(d=6)
    assert bench.family is BenchmarkFamily.REGULAR_LINEAR_GAUSSIAN
    assert bench.target.lambda_true == 3.0
    assert bench.target.multiplicity_true == 1
    assert bench.loss(bench.theta_star + torch.ones(6, dtype=torch.float64)).item() == 3.0


def test_regular_linear_data_energy_and_mock_output_contract():
    bench = regular_linear_gaussian(d=4)
    data = bench.make_data(n=32, seed=7)
    assert data.shape == (32, 5)
    model = bench.make_energy_model(data, cfg={})
    assert torch.isclose(model.mean_loss(model.theta_hat(), data), torch.tensor(0.0, dtype=torch.float64))
    assert [block.name for block in model.parameter_blocks()] == ["AB"]
    output = make_mock_estimator_output(bench.benchmark_id, model.parameter_blocks()[0].name)
    assert output.benchmark_id == bench.benchmark_id


def test_regular_linear_mock_estimator_passes_contract():
    bench = regular_linear_gaussian(d=4)
    result = check_estimate(bench, TargetMetadataEstimator().estimate(bench))
    assert result.status == "pass"
    assert result.expected_lambda == 2.0
