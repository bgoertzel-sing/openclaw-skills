import pytest
import torch
from relaleap.arms import RankOneColumnLearner, FlatValueSameRouter, SVDLowRankControl


def test_identity_init_for_rank_one_atoms():
    arm = RankOneColumnLearner(8, 3, num_columns=4, atoms_per_column=2, top_k=2)
    h = torch.randn(10, 8); c = torch.randn(10, 3)
    r, aux = arm.forward_residual(h, c, return_aux=True)
    assert torch.allclose(r, torch.zeros_like(r), atol=1e-7)
    assert torch.allclose(arm.beta, torch.zeros_like(arm.beta))
    assert aux["column_mask"].shape == (10, 4)


def test_parameter_blocks_present():
    arm = RankOneColumnLearner(8, 3, 4, 2)
    blocks = arm.parameter_blocks()
    for key in ["atom_input_directions", "atom_output_directions", "atom_amplitudes", "column_membership", "router", "alpha"]:
        assert key in blocks and blocks[key]


def test_flat_value_control_is_not_zero_control_after_values_set():
    arm = FlatValueSameRouter(6, 2, num_columns=3, top_k=1)
    with torch.no_grad():
        arm.values.fill_(0.5)
        arm.alpha.bias.fill_(1.0)
    r = arm.forward_residual(torch.randn(5, 6), torch.randn(5, 2))
    assert r.shape == (5, 6)
    assert not torch.allclose(r, torch.zeros_like(r))


def test_svd_basis_fit_on_train_only_and_shape():
    arm = SVDLowRankControl(7, 2, rank=3)
    h = torch.randn(9, 7); c = torch.randn(9, 2)
    with pytest.raises(RuntimeError):
        arm.forward_residual(h, c)
    train_resid = torch.randn(20, 7)
    arm.fit_basis_from_residuals(train_resid)
    r = arm.forward_residual(h, c)
    assert arm.basis_fitted
    assert arm.basis.shape == (7, 3)
    assert r.shape == (9, 7)
