import pytest
import torch

from relaleap.hdpc.gpt2_epc import GPT2BlockStateAdapter, gpt2_epc_objective
from relaleap.hdpc.tinyshakespeare import kd_loss


transformers = pytest.importorskip("transformers")


def _model(*, dropout: float = 0.0, use_cache: bool = False):
    config = transformers.GPT2Config(
        vocab_size=31, n_positions=8, n_ctx=8, n_embd=16, n_layer=2, n_head=2,
        n_inner=32, resid_pdrop=dropout, embd_pdrop=dropout,
        attn_pdrop=dropout, use_cache=use_cache,
    )
    model = transformers.GPT2LMHeadModel(config)
    model.train()
    return model


def test_adapter_forward_states_match_native_gpt2_logits() -> None:
    torch.manual_seed(7)
    model = _model()
    tokens = torch.randint(31, (2, 8))
    adapter = GPT2BlockStateAdapter(model)
    states = adapter.forward_states(tokens)
    native = model(tokens, use_cache=False).logits
    assert len(states.hidden_states) == 2
    assert states.input_state.shape == (2, 8, 16)
    torch.testing.assert_close(states.logits, native, rtol=0, atol=0)


def test_depth_one_is_exact_kd_and_relaxation_is_monotone() -> None:
    torch.manual_seed(11)
    model = _model()
    teacher = _model()
    tokens = torch.randint(31, (2, 8))
    with torch.no_grad():
        teacher_logits = teacher(tokens, use_cache=False).logits
    native_kd = kd_loss(model(tokens, use_cache=False).logits, teacher_logits, temperature=2.0)
    endpoint, endpoint_trace = gpt2_epc_objective(
        model, tokens, teacher_logits, steps=1, temperature=2.0,
    )
    torch.testing.assert_close(endpoint, native_kd, rtol=0, atol=0)
    assert endpoint_trace.steps == 1

    objective, trace = gpt2_epc_objective(
        model, tokens, teacher_logits, steps=4, temperature=2.0,
        relaxation_lr=0.2, max_backtracks=12, output_weight=0.05,
    )
    assert trace.monotone
    assert len(trace.energy_history) == 4
    assert len(trace.accepted_step_sizes) == 3
    objective.backward()
    assert all(parameter.grad is None or torch.isfinite(parameter.grad).all() for parameter in model.parameters())
    assert any(parameter.grad is not None for parameter in model.transformer.h[0].parameters())


def test_adapter_rejects_cache_dropout_and_bad_tokens() -> None:
    with pytest.raises(ValueError, match="dropout"):
        GPT2BlockStateAdapter(_model(dropout=0.1))
    with pytest.raises(ValueError, match="use_cache"):
        GPT2BlockStateAdapter(_model(use_cache=True))
    adapter = GPT2BlockStateAdapter(_model())
    with pytest.raises(ValueError, match="rank-two integer"):
        adapter.forward_states(torch.zeros(2, 8))
