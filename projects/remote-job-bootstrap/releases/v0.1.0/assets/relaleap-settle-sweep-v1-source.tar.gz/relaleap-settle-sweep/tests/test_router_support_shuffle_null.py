import torch

from relaleap.slt.nulls import router_support_shuffle_null


def test_router_support_shuffle_is_seeded_row_permutation():
    router_probs = torch.softmax(torch.arange(24, dtype=torch.float32).reshape(8, 3) / 7.0, dim=1)
    shuffled = router_support_shuffle_null(router_probs, seed=13)
    shuffled_again = router_support_shuffle_null(router_probs, seed=13)

    assert shuffled.shape == router_probs.shape
    assert torch.equal(shuffled, shuffled_again)
    assert not torch.equal(shuffled, router_probs)
    assert torch.allclose(shuffled.sum(dim=1), torch.ones(router_probs.shape[0]))
    assert torch.allclose(torch.sort(shuffled[:, 0]).values, torch.sort(router_probs[:, 0]).values)
