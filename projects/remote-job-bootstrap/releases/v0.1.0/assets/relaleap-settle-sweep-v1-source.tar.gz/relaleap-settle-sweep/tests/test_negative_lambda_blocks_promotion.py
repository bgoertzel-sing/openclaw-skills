import dataclasses

from relaleap.slt.ci_gates import evaluate_ci_gates
from relaleap.slt.decision_report import decision_summary
from test_report_schema_complete import passing_report


def test_any_negative_lambda_blocks_promotion():
    base = passing_report()
    report = passing_report(lambda_estimates=[dataclasses.replace(base.lambda_estimates[0], lambda_hat=-0.01)])
    summary = decision_summary(report)
    assert summary["promotion_allowed"] is False
    assert summary["scientific_decision_usable"] is False
    assert any(not gate.passed and gate.gate_name == "negative_lambda" for gate in evaluate_ci_gates(report))
