import dataclasses

from relaleap.slt.ci_gates import evaluate_ci_gates
from relaleap.slt.decision_report import decision_summary
from test_report_schema_complete import passing_report


def test_failed_calibration_blocks_scientific_decision_use():
    report = passing_report(
        calibration=dataclasses.replace(
            passing_report().calibration,
            status="fail",
            observed_lambda={"gaussian": 1.4},
        )
    )
    summary = decision_summary(report)
    assert summary["scientific_decision_usable"] is False
    assert summary["releap_slt_evidence_allowed"] is False
    assert any(not gate.passed and gate.gate_name == "analytic_calibration" for gate in evaluate_ci_gates(report))
