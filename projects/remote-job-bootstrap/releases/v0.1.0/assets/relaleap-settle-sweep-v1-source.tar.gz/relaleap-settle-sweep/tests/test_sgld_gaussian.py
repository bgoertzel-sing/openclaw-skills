from __future__ import annotations

import pytest
import torch

from relaleap.slt.diagnostics import diagnose_energy_chains
from relaleap.slt.energy import GaussianPrior, GaussianQuadraticEnergyModel, exact_gaussian_posterior_moments
from relaleap.slt.sgld import SGLDConfig, run_sgld_chain
from relaleap.slt.wbic import TemperatureConvention, estimate_wbic_from_chains


def pytest_approx(value: float, **kwargs):
    return pytest.approx(value, **kwargs)


def test_exact_gaussian_posterior_moments_with_prior() -> None:
    h = torch.diag(torch.tensor([2.0, 5.0]))
    center = torch.tensor([1.0, -2.0])
    model = GaussianQuadraticEnergyModel(h, center, n_data=128)
    prior = GaussianPrior(prior_scale=2.0)
    beta = 0.7

    mean, cov = exact_gaussian_posterior_moments(model, beta_total_energy=beta, prior=prior)
    precision = beta * h + torch.eye(2) / 4.0
    expected_cov = torch.linalg.inv(precision)
    expected_mean = expected_cov @ (beta * h @ center)

    assert torch.allclose(mean, expected_mean, atol=1e-6)
    assert torch.allclose(cov, expected_cov, atol=1e-6)


@pytest.mark.filterwarnings("ignore:cov\(\):UserWarning")
def test_sgld_recovers_exact_gaussian_mean_covariance_and_energy() -> None:
    torch.set_default_dtype(torch.float64)
    try:
        n = 256
        data = torch.zeros(n, 1, dtype=torch.float64)
        h = torch.diag(torch.tensor([1.2, 2.0], dtype=torch.float64))
        center = torch.tensor([0.25, -0.15], dtype=torch.float64)
        model = GaussianQuadraticEnergyModel(h, center, n_data=n)
        convention = TemperatureConvention.wbic_total_energy(n)
        cfg = SGLDConfig(num_steps=80_000, step_size=0.03, burn_in=5_000, thin=20, seed=11, init_noise=0.1)

        result = run_sgld_chain(
            model,
            data,
            model.theta_hat(),
            beta_total_energy=convention.beta_total_energy,
            config=cfg,
        )
        samples = result.samples.to(torch.float64)
        mean = samples.mean(dim=0)
        cov = torch.cov(samples.T)
        expected_mean, expected_cov = exact_gaussian_posterior_moments(
            model, beta_total_energy=convention.beta_total_energy
        )
        energies = torch.stack([model.total_energy(s, data) for s in samples])
        expected_delta_energy = h.shape[0] / (2.0 * convention.beta_total_energy)

        assert torch.allclose(mean, expected_mean, atol=0.25)
        assert torch.allclose(cov, expected_cov, rtol=0.30, atol=0.35)
        assert float(energies.mean()) == pytest_approx(float(expected_delta_energy), rel=0.22)
    finally:
        torch.set_default_dtype(torch.float32)


def test_wbic_lambda_for_quadratic_gaussian_samples_matches_regular_target() -> None:
    torch.set_default_dtype(torch.float64)
    try:
        n = 512
        d = 2
        data = torch.zeros(n, 1, dtype=torch.float64)
        h = torch.eye(d, dtype=torch.float64)
        model = GaussianQuadraticEnergyModel(h, torch.zeros(d, dtype=torch.float64), n_data=n)
        convention = TemperatureConvention.wbic_total_energy(n)
        cfg = SGLDConfig(num_steps=45_000, step_size=0.03, burn_in=3_000, thin=20, seed=7, init_noise=0.1)
        chain = run_sgld_chain(model, data, model.theta_hat(), beta_total_energy=convention.beta_total_energy, config=cfg)
        # Energy traces include burn-in by design; WBIC is estimated from post-burn-in thinned samples.
        chain.energy_trace = torch.stack([model.total_energy(s, data) for s in chain.samples])
        wbic = estimate_wbic_from_chains(model, data, [chain], convention=convention)

        assert wbic.lambda_hat == pytest_approx(d / 2.0, rel=0.20)
        assert wbic.lambda_hat >= 0.0
        assert wbic.diagnostics["negative_lambda_policy"] == "fail_or_diagnostic_never_clip"
    finally:
        torch.set_default_dtype(torch.float32)


def test_energy_diagnostics_report_ess_rhat_trend_and_nans() -> None:
    c1 = torch.linspace(0.0, 1.0, 100)
    c2 = torch.linspace(0.1, 1.1, 100)
    c2[5] = float("nan")
    diag = diagnose_energy_chains([c1, c2])

    assert len(diag.energy_ess_per_chain) == 2
    assert diag.nan_or_divergence_count == 1
    assert "has_trend" in diag.trend_test
    assert isinstance(diag.rhat_energy, float)
