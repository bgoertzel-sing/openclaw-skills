import importlib.util
import json
from pathlib import Path

import pytest
import torch
from torch import nn


SCRIPT = Path(__file__).parents[1] / "scripts" / "run_gpt2_outcome_gpu.py"
SPEC = importlib.util.spec_from_file_location("gpt2_outcome_gpu", SCRIPT)
RUNNER = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(RUNNER)
CONFIG = Path(__file__).parents[1] / "configs" / "gpt2_epc_outcome_6layer.json"


def test_six_layer_outcome_protocol_is_frozen() -> None:
    protocol = json.loads(CONFIG.read_text())
    RUNNER._validate_config(protocol)
    assert protocol["student_layers"] == 6
    assert protocol["target_dataset"]["revision"] == "f54c09fd23315a6f9c86f9dc80f725de7d8f9c64"


def test_low_rank_adapter_freezes_backbone_and_starts_as_identity() -> None:
    class Model(nn.Module):
        def __init__(self):
            super().__init__()
            self.attn = nn.Module()
            self.attn.c_attn = nn.Linear(5, 7, bias=False)

    model = Model()
    original = model.attn.c_attn.weight.detach().clone()
    assert RUNNER._attach_low_rank(model, ["attn.c_attn"], 2, 4.0) == 1
    assert torch.equal(model.attn.c_attn.weight.detach(), original)
    trainable = [name for name, value in model.named_parameters() if value.requires_grad]
    assert trainable == [
        "attn.c_attn.parametrizations.weight.0.a",
        "attn.c_attn.parametrizations.weight.0.b",
    ]


def test_outcome_protocol_rejects_unfrozen_or_wrong_depth() -> None:
    protocol = json.loads(CONFIG.read_text())
    protocol["status"] = "draft"
    with pytest.raises(ValueError, match="frozen"):
        RUNNER._validate_config(protocol)
    protocol["status"] = "frozen_pre_run"
    protocol["student_layers"] = 12
    with pytest.raises(ValueError, match="six-layer"):
        RUNNER._validate_config(protocol)


def test_two_level_bootstrap_promotes_clear_epc_adaptation_advantage() -> None:
    protocol = json.loads(CONFIG.read_text())
    protocol["bootstrap_replicates"] = 50
    rows = []
    for seed in protocol["seeds"]:
        for arm, losses in (
            ("bp_ce", (2.0, 1.8)),
            ("bp_kd", (2.0, 1.7)),
            ("epc_kd", (2.0, 1.3)),
        ):
            curve = [
                {"update": 0, "target_segment_losses": [losses[0]] * 4},
                {"update": 100, "target_segment_losses": [losses[1]] * 4},
            ]
            rows.append({
                "seed": seed,
                "arm": arm,
                "curve": curve,
                "pre_target_loss": losses[0],
                "source_forgetting": 0.0,
            })
    result = RUNNER._evaluate_outcome(rows, protocol)
    assert result["passes"] is True
    assert result["contrasts"]["bp_kd"]["ci95"][0] > 0


def test_checkpoint_loader_resolves_and_requires_local_directory(tmp_path: Path) -> None:
    relative_root = tmp_path / "nested" / ".." / "checkpoints"
    checkpoint = tmp_path / "checkpoints" / "seed1729_bp_ce"
    checkpoint.mkdir(parents=True)
    resolved = RUNNER._local_checkpoint(relative_root, 1729, "bp_ce")
    assert resolved == checkpoint.resolve()
    assert resolved.is_absolute()
    with pytest.raises(FileNotFoundError, match="local checkpoint directory not found"):
        RUNNER._local_checkpoint(relative_root, 1729, "epc_kd")
