import torch

from relaleap.slt.analytic_registry import InteractionSign, product_singularity
from relaleap.slt.calibration_benchmarks import TargetMetadataEstimator, check_estimate
from relaleap.slt.contracts import make_mock_estimator_output


def test_product_singularity_true_metadata_negative_interaction():
    bench = product_singularity()
    target = bench.target
    assert target.lambda_A == 0.0
    assert target.lambda_B == 0.0
    assert target.lambda_AB == 0.5
    assert target.interaction == -0.5
    assert target.interaction_sign is InteractionSign.NEGATIVE
    assert bench.loss([2.0, 3.0]).item() == 36.0


def test_product_singularity_energy_landscape_flat_singletons_nonflat_joint():
    bench = product_singularity()
    data = bench.make_data(8, seed=3)
    model = bench.make_energy_model(data, {})
    assert data.shape == (8, 1)
    assert torch.isclose(model.mean_loss(torch.tensor([4.0, 0.0]), data), torch.tensor(0.0, dtype=torch.float64))
    assert torch.isclose(model.mean_loss(torch.tensor([0.0, -5.0]), data), torch.tensor(0.0, dtype=torch.float64))
    assert model.mean_loss(torch.tensor([2.0, 3.0]), data).item() == 36.0
    assert torch.allclose(model.grad_total_energy(torch.tensor([4.0, 0.0]), data), torch.zeros(2))
    assert [block.name for block in model.parameter_blocks()] == ["A", "B", "AB"]
    assert make_mock_estimator_output(bench.benchmark_id, "AB").benchmark_id == bench.benchmark_id


def test_product_singularity_mock_estimator_passes_interaction_contract():
    bench = product_singularity()
    result = check_estimate(bench, TargetMetadataEstimator().estimate(bench))
    assert result.status == "pass"
    assert result.expected_interaction_sign is InteractionSign.NEGATIVE
    assert result.observed_interaction < 0
