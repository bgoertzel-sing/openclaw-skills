import importlib.util
import inspect
from pathlib import Path

import pytest
import torch


SCRIPT = Path(__file__).parents[1] / "scripts" / "run_gpt2_pilot_gpu.py"
SPEC = importlib.util.spec_from_file_location("gpt2_pilot_gpu_runner", SCRIPT)
RUNNER = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(RUNNER)


def _protocol():
    return {
        "evaluation": {"seeds": [1, 2, 3]},
        "student": {"num_layers": 2},
        "promotion": {
            "required_seed_count": 3,
            "mean_val_loss_gain_vs_update_matched_bp_kd_nats": 0.005,
            "max_per_seed_regression_vs_update_matched_bp_kd_nats": 0.002,
            "mean_val_loss_gain_vs_wall_clock_matched_bp_kd_nats": 0.002,
            "claim_if_passed": "test only",
        },
    }


def _record(seed, arm, loss, *, match_type=None, credit=True):
    row = {
        "seed": seed,
        "arm": arm,
        "student_val_loss": loss,
        "student_val_perplexity": 10.0,
        "teacher_val_loss": 0.9,
        "teacher_val_perplexity": 9.0,
        "kd_gap_nats": 0.1,
        "elapsed_seconds": 1.0,
        "activity_energy_monotone": True if arm == "epc_kd" else None,
        "credit_assignment": (
            [
                {"block": "transformer.h.0", "epc_norm": 1.0, "finite": True},
                {"block": "transformer.h.1", "epc_norm": 1.0, "finite": True},
            ]
            if arm == "epc_kd" and credit else []
        ),
    }
    if match_type is not None:
        row["match_type"] = match_type
    return row


def _passing_records():
    rows = []
    for seed in (1, 2, 3):
        rows.extend([
            _record(seed, "epc_kd", 0.990, match_type="update_matched"),
            _record(seed, "bp_kd", 1.000, match_type="update_matched"),
            _record(seed, "bp_kd", 0.995, match_type="wall_clock_matched"),
        ])
    return rows


def test_promotion_passes_complete_records() -> None:
    result = RUNNER.evaluate_promotion(_passing_records(), _protocol())
    assert result["passes_all"] is True


def test_promotion_detects_single_seed_regression() -> None:
    rows = _passing_records()
    next(row for row in rows if row["seed"] == 2 and row["arm"] == "epc_kd")[
        "student_val_loss"
    ] = 1.003
    result = RUNNER.evaluate_promotion(rows, _protocol())
    assert result["max_per_seed_regression_vs_update_matched_bp_kd_nats"] == pytest.approx(0.003)
    assert result["passes_no_seed_regression"] is False
    assert result["passes_all"] is False


def test_promotion_requires_credit_in_every_student_block() -> None:
    rows = _passing_records()
    row = next(row for row in rows if row["seed"] == 3 and row["arm"] == "epc_kd")
    row["credit_assignment"] = row["credit_assignment"][:1]
    result = RUNNER.evaluate_promotion(rows, _protocol())
    assert result["require_nonzero_credit_all_student_blocks"] is False
    assert result["passes_all"] is False


def test_promotion_fails_closed_when_a_seed_or_match_label_is_missing() -> None:
    rows = _passing_records()
    rows = [
        row for row in rows
        if not (row["seed"] == 3 and row.get("match_type") == "update_matched")
    ]
    result = RUNNER.evaluate_promotion(rows, _protocol())
    assert result["passes_no_seed_regression"] is False
    assert result["passes_all"] is False


def test_promotion_fails_closed_on_duplicate_primary_record() -> None:
    rows = _passing_records()
    rows.append(dict(rows[0]))
    result = RUNNER.evaluate_promotion(rows, _protocol())
    assert result["require_unique_complete_primary_records"] is False
    assert result["passes_all"] is False


def test_promotion_fails_closed_on_nonfinite_matched_control() -> None:
    rows = _passing_records()
    row = next(
        row for row in rows
        if row["seed"] == 1 and row.get("match_type") == "wall_clock_matched"
    )
    row["student_val_loss"] = float("inf")
    result = RUNNER.evaluate_promotion(rows, _protocol())
    assert result["require_finite_metrics"] is False
    assert result["passes_all"] is False


def test_wall_clock_arm_is_not_capped_at_update_matched_count() -> None:
    source = inspect.getsource(RUNNER.run_arm)
    assert "None if elapsed_budget_seconds is not None else n_updates" in source
    assert "while elapsed_budget_seconds is not None or update_idx < n_updates" in source


def test_scientific_runner_uses_preflight_cache_only() -> None:
    source = SCRIPT.read_text()
    assert "local_files_only=False" not in source
    assert source.count("local_files_only=True") >= 4


def test_checkpoint_manifest_requires_hf_weights_and_config(tmp_path) -> None:
    class FakeModel:
        def save_pretrained(self, output, *, safe_serialization):
            assert safe_serialization is True
            (output / "model.safetensors").write_bytes(b"weights")
            (output / "config.json").write_text("{}")

    manifest = RUNNER._save_checkpoint(FakeModel(), tmp_path / "checkpoint")
    assert set(manifest) == {"config.json", "model.safetensors"}
    assert all(len(digest) == 64 for digest in manifest.values())


def test_checkpoint_manifest_fails_closed_on_incomplete_save(tmp_path) -> None:
    class FakeModel:
        def save_pretrained(self, output, *, safe_serialization):
            (output / "config.json").write_text("{}")

    with pytest.raises(RuntimeError, match="missing model.safetensors"):
        RUNNER._save_checkpoint(FakeModel(), tmp_path / "checkpoint")


def test_evaluate_adds_batch_dimension_to_single_segments() -> None:
    class FakeOutput:
        def __init__(self, logits):
            self.logits = logits

    class FakeModel:
        def __init__(self):
            self.training = True

        def eval(self):
            self.training = False

        def train(self):
            self.training = True

        def __call__(self, tokens, *, use_cache):
            assert tokens.ndim == 2
            assert tokens.shape == (1, 4)
            assert use_cache is False
            return FakeOutput(torch.zeros(1, 4, 8))

    model = FakeModel()
    teacher = FakeModel()
    x = torch.tensor([1, 2, 3, 4])
    y = torch.tensor([2, 3, 4, 5])
    loss, perplexity, kd = RUNNER._evaluate(model, teacher, [(x, y)], "cpu")
    assert loss > 0
    assert perplexity > 1
    assert kd == pytest.approx(0.0)
    assert model.training is True
