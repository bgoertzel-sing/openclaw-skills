from relaleap.slt.releap_benchmarks import generate_releap_benchmark, mock_estimator_output


def test_low_rank_trap_svd_control_wins_and_blocks_column_claims():
    data = generate_releap_benchmark("low_rank_trap", seed=2, n=72, d_model=12, num_columns=5, rank=2)
    md = data.metadata
    assert md["true_interactions"]["dense_low_rank"] is True
    assert md["true_interactions"]["rank"] == 2
    assert md["true_interactions"]["column_support_is_incidental"] is True
    assert md["expected_winner"] == "svd_low_rank_control"
    assert md["expected_I_lambda_signs"]["columnar_interpretation"] == "not_interpretable"
    assert md["expected_I_lambda_signs"]["low_rank_control_margin"] == "positive"
    assert mock_estimator_output(md).winner == "svd_low_rank_control"
