import torch

from relaleap.slt.energy import QuadraticEnergyModel
from relaleap.slt.parameter_blocks import ParameterBlock
from relaleap.slt.priors import GaussianPrior
from relaleap.slt.prior_sensitivity import PriorSensitivityCandidate, prior_sensitivity_report, prior_sensitivity_sweep


def test_prior_sensitivity_report_stable_ranking():
    candidates = [
        PriorSensitivityCandidate("arm_a", torch.tensor([0.1, 0.1]), data_score=1.0),
        PriorSensitivityCandidate("arm_b", torch.tensor([0.2, 0.2]), data_score=2.0),
    ]
    report = prior_sensitivity_report(candidates, lambda scale: GaussianPrior(scale=scale), [0.5, 1.0, 2.0])
    assert report.status == "ranking_stable"
    assert report.stable is True
    assert report.ranking_flipped is False
    assert report.top_arm_by_scale == ["arm_a", "arm_a", "arm_a"]
    assert report.rankings == report.rankings_by_scale
    assert "finite-sample" in report.notes


def test_prior_sensitivity_report_diagnostic_only_when_ranking_flips():
    candidates = [
        PriorSensitivityCandidate("accurate_large", torch.tensor([10.0]), data_score=0.0),
        PriorSensitivityCandidate("small_underfit", torch.tensor([0.1]), data_score=0.6),
    ]
    report = prior_sensitivity_report(candidates, lambda scale: GaussianPrior(scale=scale), [0.5, 100.0])
    assert report.status == "diagnostic_only"
    assert report.stable is False
    assert report.ranking_flipped is True
    assert report.top_arm_by_scale == ["small_underfit", "accurate_large"]
    assert "diagnostic-only" in report.caveat


def test_prior_sensitivity_sweep_stable_lambda_estimates_on_quadratic_model():
    block = ParameterBlock(name="theta", role="joint", size=1)
    model = QuadraticEnergyModel(reference=torch.zeros(1), blocks=[block])

    def estimator_fn(energy_model, prior):
        _ = energy_model, prior
        return {"arm_a": 1.0, "arm_b": 2.0}

    report = prior_sensitivity_sweep(model, lambda scale: GaussianPrior(scale=scale), [0.5, 1.0, 2.0], estimator_fn)
    assert report.stable is True
    assert report.status == "ranking_stable"
    assert report.lambda_hats == [{"arm_a": 1.0, "arm_b": 2.0}] * 3
    assert report.rankings == [["arm_a", "arm_b"]] * 3


def test_prior_sensitivity_sweep_reports_instability():
    block = ParameterBlock(name="theta", role="joint", size=1)
    model = QuadraticEnergyModel(reference=torch.zeros(1), blocks=[block])

    def estimator_fn(energy_model, prior, scale):
        _ = energy_model, prior
        return {"arm_a": scale, "arm_b": 3.0 - scale}

    report = prior_sensitivity_sweep(model, lambda scale: GaussianPrior(scale=scale), [0.5, 2.5], estimator_fn)
    assert report.stable is False
    assert report.status == "diagnostic_only"
    assert report.rankings == [["arm_a", "arm_b"], ["arm_b", "arm_a"]]
    assert "diagnostic_only" in report.notes
