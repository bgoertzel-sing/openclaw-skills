import torch
from relaleap.slt.releap_benchmarks import generate_releap_benchmark, mock_estimator_output


def test_rank_one_atom_gauge_metadata_and_mock_estimator():
    data = generate_releap_benchmark("rank_one_atom_gauge", seed=7, n=64, d_model=12, num_columns=4)
    md = data.metadata
    assert md["known_regime"] == "rank_one_atom_gauge"
    assert md["expected_winner"] == "gauge_invariant_rank_one_atoms"
    assert md["expected_I_lambda_signs"]["functional_llc_delta_after_gauge_fix"] == "near_zero"
    normalized = md["true_basis"]["normalized"]
    unnormalized = md["true_basis"]["unnormalized"]
    scale = md["true_basis"]["gauge_scale"]
    assert torch.allclose(unnormalized["a"] / scale, normalized["a"])
    assert torch.allclose(unnormalized["b"] * scale, normalized["b"])
    mock = mock_estimator_output(md)
    assert mock.winner == md["expected_winner"]
    assert mock.I_lambda_signs == md["expected_I_lambda_signs"]
