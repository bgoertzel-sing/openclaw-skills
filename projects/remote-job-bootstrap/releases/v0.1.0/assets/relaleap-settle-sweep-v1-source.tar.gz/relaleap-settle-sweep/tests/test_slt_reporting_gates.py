import pytest

from relaleap.slt.ci_gates import assert_ci_gates, evaluate_ci_gates
from relaleap.slt.decision_report import build_decision_markdown, decision_summary
from relaleap.slt.reports import (
    FINITE_SAMPLE_WORDING,
    CalibrationReport,
    EstimatorRunReport,
    LambdaEstimate,
    ParameterBlockReport,
    ReportValidationError,
    SamplerDiagnostics,
    SampleSizeSensitivity,
)


VALIDATION_PLAN_TEXT = """
Mock validation plan: run finite-sample WBIC estimates with SGLD over the actual
trained RelaLeap adapter parameter blocks. Validate temperature convention,
known Gaussian posterior and product singularity benchmarks, MAP/prior/gauge
checks, input-count sweeps, module-vs-joint estimates, and null normalization
before using any RelaLeap evidence.
""".strip()


def mock_report(**overrides):
    report = EstimatorRunReport(
        estimator_type="finite_sample_wbic_sgld_proxy",
        validation_plan_text=VALIDATION_PLAN_TEXT,
        parameter_blocks=[
            ParameterBlockReport(
                block_id="adapter.column_0",
                parameter_names=["columns.0.u", "columns.0.v"],
                trainable=True,
                fitted_from_frozen_cache=False,
                gauge_policy="signed-norm gauge with preregistered rescaling check",
                map_reference_check="pass",
                prior_check="pass",
            )
        ],
        calibration=CalibrationReport(
            status="pass",
            benchmarks=["exact_gaussian_posterior", "product_singularity"],
            expected_lambda={"exact_gaussian_posterior": 1.0, "product_singularity": 0.5},
            observed_lambda={"exact_gaussian_posterior": 1.02, "product_singularity": 0.48},
            tolerance=0.1,
            notes="Mock calibration recovers known finite-sample lambda signs and margins.",
        ),
        sampler_diagnostics=SamplerDiagnostics(
            chains=4,
            effective_sample_size=256,
            r_hat=1.02,
            monte_carlo_cv=0.12,
            target_matches_map_loss=True,
            wbic_temperature=1.0 / 8.0,
            wbic_temperature_formula="beta = 1/log(n) for finite-sample WBIC",
        ),
        input_sample_size=4096,
        input_coverage_report="Mock stratified coverage over regimes, labels, supports, and loss quantiles.",
        inference_budget_report="Mock budget: 4096 inputs x 4 chains x 3 temperatures; no remote compute.",
        sample_size_sensitivity=SampleSizeSensitivity(
            input_counts=[1024, 2048, 4096],
            slope_fit="Delta E_n = a log n + b log log n + c; stable sign in mock data",
            stable_sign=True,
            stable_margin=True,
            notes="Mock sensitivity keeps the calibrated margin positive as n grows.",
        ),
        lambda_estimates=[
            LambdaEstimate(
                target="module_vs_joint.column_0",
                lambda_hat=0.73,
                standard_error=0.04,
                null_normalized_margin=0.31,
                interpretation="Finite-sample proxy supports module-vs-joint separation in mock data.",
            )
        ],
        finite_sample_wording=FINITE_SAMPLE_WORDING,
        module_vs_joint_report="Mock joint estimate compared with sum of module estimates.",
        interaction_null_report="Mock dependency-aware null margin remains positive.",
        decision="allow_releap_evidence",
        metadata={"seed": 7, "source": "unit-test mock data"},
    )
    return report.__class__(**(report.to_dict() | overrides))


def test_complete_schema_passes_with_mock_validation_plan_text():
    report = mock_report()
    report.validate_complete_schema()
    assert_ci_gates(report)
    summary = decision_summary(report)
    assert summary["releap_slt_evidence_allowed"] is True
    assert summary["promotion_allowed"] is True


def test_failed_calibration_blocks_releap_evidence():
    bad = mock_report(
        calibration=CalibrationReport(
            status="fail",
            benchmarks=["exact_gaussian_posterior"],
            expected_lambda={"exact_gaussian_posterior": 1.0},
            observed_lambda={"exact_gaussian_posterior": 1.5},
            tolerance=0.1,
            notes="Mock failure: observed lambda misses known Gaussian posterior tolerance.",
        )
    )
    gates = evaluate_ci_gates(bad)
    assert decision_summary(bad)["releap_slt_evidence_allowed"] is False
    assert any((not gate.passed) and "failed calibration blocks RelaLeap SLT evidence" in gate.reason for gate in gates)
    with pytest.raises(ReportValidationError, match="failed calibration blocks RelaLeap SLT evidence"):
        assert_ci_gates(bad)


def test_negative_lambda_blocks_promotion_without_clipping():
    bad = mock_report(
        lambda_estimates=[
            LambdaEstimate(
                target="module_vs_joint.column_0",
                lambda_hat=-0.02,
                standard_error=0.04,
                null_normalized_margin=-0.3,
                interpretation="Mock negative estimate must be surfaced, not clipped.",
            )
        ]
    )
    gates = evaluate_ci_gates(bad)
    assert decision_summary(bad)["promotion_allowed"] is False
    assert any((not gate.passed) and "negative lambda estimate blocks promotion" in gate.reason for gate in gates)


def test_finite_sample_wording_required_in_schema_and_markdown():
    report = mock_report()
    markdown = build_decision_markdown(report)
    assert "Finite-sample WBIC/SGLD proxy only" in markdown
    assert "not an exact RLCT claim" in markdown

    bad = mock_report(finite_sample_wording="WBIC estimate proves the exact RLCT.")
    gates = evaluate_ci_gates(bad)
    assert decision_summary(bad)["promotion_allowed"] is False
    assert any((not gate.passed) and "finite_sample_wording missing required caveat" in gate.reason for gate in gates)
