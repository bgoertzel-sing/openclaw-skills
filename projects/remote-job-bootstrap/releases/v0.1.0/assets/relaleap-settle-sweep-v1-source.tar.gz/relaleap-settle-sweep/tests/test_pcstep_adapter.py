from copy import deepcopy

import pytest
import torch

from relaleap.hdpc.gpt2_epc import gpt2_epc_objective
from relaleap.hdpc.pcstep_adapter import (
    PCStepBatch,
    capture_snapshot,
    model_digest,
    pc_step,
    restore_snapshot,
    snapshot_bytes,
)


transformers = pytest.importorskip("transformers")


def _model():
    config = transformers.GPT2Config(
        vocab_size=31, n_positions=8, n_ctx=8, n_embd=16, n_layer=2, n_head=2,
        n_inner=32, resid_pdrop=0.0, embd_pdrop=0.0, attn_pdrop=0.0,
        use_cache=False,
    )
    return transformers.GPT2LMHeadModel(config).train()


def _fixture(seed: int = 17):
    torch.manual_seed(seed)
    model = _model()
    teacher = _model().eval()
    tokens = torch.randint(31, (2, 8))
    with torch.no_grad():
        logits = teacher(tokens, use_cache=False).logits
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4, weight_decay=0.0)
    return model, optimizer, PCStepBatch(tokens, logits, cursor=0)


def test_t1_objective_matches_existing_kd_endpoint_and_settlement_is_frozen():
    model, optimizer, batch = _fixture()
    expected, _ = gpt2_epc_objective(
        model, batch.tokens, batch.teacher_logits, steps=1, temperature=2.0,
    )
    before_digest = model_digest(model)
    result = pc_step(
        model, optimizer, batch, gate={0: True, 1: True}, steps=1, temperature=2.0,
    )
    assert result.objective == float(expected.detach())
    assert result.energy_history == (float(expected.detach()),)
    assert result.settled_parameter_digest == before_digest
    assert result.snapshot.outer_step == 1
    assert result.snapshot.batch_cursor == 2


def test_outer_step_and_batch_cursor_advance_explicitly():
    model, optimizer, batch = _fixture()
    later = PCStepBatch(batch.tokens, batch.teacher_logits, cursor=14)
    result = pc_step(
        model, optimizer, later, gate={0: True, 1: True}, steps=1,
        temperature=2.0, outer_step=6,
    )
    assert result.snapshot.outer_step == 7
    assert result.snapshot.batch_cursor == 16


def test_disabled_block_is_unchanged_while_enabled_block_updates():
    model, optimizer, batch = _fixture()
    before0 = deepcopy(model.transformer.h[0].state_dict())
    before1 = deepcopy(model.transformer.h[1].state_dict())
    pc_step(
        model, optimizer, batch, gate={0: False, 1: True}, steps=2, temperature=2.0,
    )
    assert all(torch.equal(before0[name], model.transformer.h[0].state_dict()[name]) for name in before0)
    assert any(not torch.equal(before1[name], model.transformer.h[1].state_dict()[name]) for name in before1)


def test_snapshot_restore_and_replay_are_exact():
    model, optimizer, batch = _fixture()
    initial = capture_snapshot(model, optimizer, outer_step=0, batch_cursor=0)
    first = pc_step(
        model, optimizer, batch, gate={0: True, 1: True}, steps=3, temperature=2.0,
    )
    first_bytes = snapshot_bytes(first.snapshot)
    restore_snapshot(model, optimizer, initial)
    second = pc_step(
        model, optimizer, batch, gate={0: True, 1: True}, steps=3, temperature=2.0,
    )
    assert first.objective == second.objective
    assert first.energy_history == second.energy_history
    assert first_bytes == snapshot_bytes(second.snapshot)


@pytest.mark.parametrize(
    "gate",
    [{0: True}, {0: True, 1: 1}, {0: True, 1: True, 2: False}],
)
def test_invalid_gates_fail_closed(gate):
    model, optimizer, batch = _fixture()
    with pytest.raises(ValueError, match="gate"):
        pc_step(model, optimizer, batch, gate=gate, steps=1, temperature=2.0)


def test_invalid_batch_plan_fails_closed():
    model, optimizer, batch = _fixture()
    bad = PCStepBatch(batch.tokens, batch.teacher_logits[:, :-1], cursor=0)
    with pytest.raises(ValueError, match="share batch"):
        pc_step(model, optimizer, bad, gate={0: True, 1: True}, steps=1, temperature=2.0)
