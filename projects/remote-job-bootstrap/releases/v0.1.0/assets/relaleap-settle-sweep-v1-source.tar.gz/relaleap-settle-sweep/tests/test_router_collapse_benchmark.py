from relaleap.slt.releap_benchmarks import generate_releap_benchmark, mock_estimator_output


def test_router_collapse_blocks_low_complexity_modular_success():
    data = generate_releap_benchmark("router_collapse", seed=4, n=100, d_model=12, num_columns=5)
    md = data.metadata
    dominant = md["true_interactions"]["dominant_column"]
    assert dominant == 0
    assert md["true_interactions"]["dominant_router_fraction"] > 0.9
    assert md["expected_winner"] == "fail_closed_router_collapse"
    assert md["expected_I_lambda_signs"]["apparent_complexity_gain"] == "not_interpretable"
    assert md["expected_I_lambda_signs"]["non_dominant_column_contribution"] == "near_zero"
    assert mock_estimator_output(md).winner == "fail_closed_router_collapse"
