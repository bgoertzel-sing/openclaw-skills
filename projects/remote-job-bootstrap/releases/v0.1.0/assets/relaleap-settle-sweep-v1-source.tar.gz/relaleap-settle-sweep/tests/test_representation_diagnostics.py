import pytest
import torch

from relaleap.hdpc.representation import (
    centered_rank_summary,
    linear_cka_feature,
    linear_cka_gram,
)


def test_linear_cka_is_symmetric_self_one_and_matches_gram_form():
    generator = torch.Generator().manual_seed(19)
    x = torch.randn(24, 9, generator=generator)
    y = torch.randn(24, 7, generator=generator)
    xy = linear_cka_feature(x, y)
    yx = linear_cka_feature(y, x)
    gram = linear_cka_gram(x, y)
    assert xy == pytest.approx(yx, abs=1e-6)
    assert xy == pytest.approx(gram, abs=1e-5)
    assert linear_cka_feature(x, x) == pytest.approx(1.0, abs=1e-6)


def test_centered_rank_removes_constant_offset():
    generator = torch.Generator().manual_seed(23)
    x = torch.randn(32, 5, generator=generator)
    offset = torch.arange(5, dtype=x.dtype) * 10
    base = centered_rank_summary(x)
    shifted = centered_rank_summary(x + offset)
    assert shifted["entropy_effective_rank"] == pytest.approx(
        base["entropy_effective_rank"], rel=1e-5
    )
    assert shifted["participation_ratio"] == pytest.approx(
        base["participation_ratio"], rel=1e-5
    )


def test_cka_rejects_mismatched_sample_counts():
    with pytest.raises(ValueError, match="identical sample counts"):
        linear_cka_feature(torch.randn(4, 3), torch.randn(5, 3))
