import json
import os
import subprocess
import sys

import pytest
import torch

from relaleap.slt import (
    EstimatorResult,
    MockCalibrationBenchmark,
    ParameterBlock,
    SLTValidationReport,
    make_mock_estimator_output,
)
from relaleap.experiments.slt_estimator_validation import build_mock_validation_report, write_report


def test_mock_benchmark_and_energy_model_contract():
    benchmark = MockCalibrationBenchmark(dim=3)
    data = benchmark.make_data(n=16, seed=7)
    model = benchmark.make_energy_model(data, cfg={})
    theta = torch.ones(3)
    assert model.total_energy(theta, data).item() == pytest.approx(24.0)
    assert model.mean_loss(theta, data[:4]).item() == pytest.approx(1.5)
    assert torch.allclose(model.grad_total_energy(theta, data[:4]), torch.full((3,), 4.0))
    assert model.theta_hat().shape == (3,)
    assert model.parameter_blocks()[0].trainable is True
    assert benchmark.true_targets().lambda_target == pytest.approx(1.0)


def test_estimator_result_schema_preserves_finite_sample_language_and_negative_policy():
    result = make_mock_estimator_output().result
    assert result.lambda_hat == result.lambda_single_n
    assert result.lambda_se == result.lambda_stderr
    assert result.status == "diagnostic_only"
    assert result.to_dict()["estimator_kind"] == "finite_sample_wbic_sgld_proxy_not_exact_rlct"
    assert result.to_dict()["negative_lambda_policy"] == "fail_or_diagnostic_never_clip"


def test_estimator_result_rejects_exact_rlct_wording_or_clipping_policy():
    kwargs = make_mock_estimator_output().result.to_dict()
    kwargs["estimator_kind"] = "exact_rlct"
    with pytest.raises(ValueError, match="not-exact-RLCT"):
        EstimatorResult(**kwargs)
    kwargs = make_mock_estimator_output().result.to_dict()
    kwargs["negative_lambda_policy"] = "clip_to_zero"
    with pytest.raises(ValueError, match="never clip"):
        EstimatorResult(**kwargs)


def test_validation_report_fail_closed_for_scientific_decisions(tmp_path):
    report = build_mock_validation_report(run_id="test-run")
    assert report.mandatory_gates_passed is False
    assert report.scientific_decision_usable is False
    write_report(tmp_path, report)
    manifest = json.loads((tmp_path / "manifest.json").read_text())
    assert manifest["run_id"] == "test-run"
    assert manifest["scientific_decision_usable"] is False
    assert (tmp_path / "report.md").exists()
    with pytest.raises(ValueError, match="requires mandatory_gates_passed"):
        SLTValidationReport(
            run_id="bad",
            estimator_results=report.estimator_results,
            parameter_blocks=report.parameter_blocks,
            compatibility_matrix=[],
            mandatory_gates_passed=False,
            scientific_decision_usable=True,
            reason="bad",
        )


def test_parameter_block_validation():
    with pytest.raises(ValueError, match="positive"):
        ParameterBlock(name="bad", role="joint", size=0)


def test_mock_validation_entrypoint_writes_schema_artifacts(tmp_path):
    code = (
        "from relaleap.experiments.slt_estimator_validation import build_mock_validation_report, write_report; "
        f"write_report({str(tmp_path)!r}, build_mock_validation_report('cli-test'))"
    )
    env = {**os.environ, "PYTHONPATH": "src"}
    subprocess.run([sys.executable, "-c", code], check=True, env=env)
    assert (tmp_path / "manifest.json").exists()
    assert (tmp_path / "report.md").exists()
