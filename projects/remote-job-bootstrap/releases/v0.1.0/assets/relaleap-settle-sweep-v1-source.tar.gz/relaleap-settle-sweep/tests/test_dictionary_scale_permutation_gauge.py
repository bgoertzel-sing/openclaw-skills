import torch

from relaleap.slt.gauge import GaugePolicy, canonicalize_dictionary, dictionary_function
from relaleap.slt.releap_parameterizations import canonical_rank_one_atom_snapshot
from relaleap.arms import RankOneColumnLearner


def test_dictionary_scale_sign_permutation_gauge_preserves_function():
    atoms = torch.tensor([[-2.0, 0.0, 1.0], [0.0, -4.0, 0.0], [3.0, 1.0, 0.0]])
    coeff = torch.tensor([[1.0, -2.0, 0.5], [0.0, 3.0, -1.0]])
    usage = torch.tensor([0.2, 0.8, 0.1])

    before = dictionary_function(atoms, coeff)
    c_atoms, c_coeff, report = canonicalize_dictionary(atoms, coeff, usage=usage, policy=GaugePolicy(sort_atoms_by="usage"))
    after = dictionary_function(c_atoms, c_coeff)

    assert c_coeff is not None
    assert torch.allclose(after, before, atol=1e-6)
    assert torch.allclose(c_atoms.norm(dim=1), torch.ones(3), atol=1e-6)
    assert report.permutation == (1, 0, 2)
    for row in c_atoms:
        assert row[torch.nonzero(row.abs() > 1e-12, as_tuple=False)[0, 0]] > 0


def test_rank_one_learner_parameterization_helper_reports_canonical_atoms():
    arm = RankOneColumnLearner(5, 2, num_columns=2, atoms_per_column=2)
    with torch.no_grad():
        arm.a[0] = torch.tensor([-2.0, 0.0, 0.0, 0.0, 0.0])
        arm.b[0] = torch.tensor([0.0, -3.0, 0.0, 0.0, 0.0])
        arm.beta[0] = 0.25
    snap = canonical_rank_one_atom_snapshot(arm, usage=torch.tensor([10.0, 1.0, 2.0, 3.0]))
    assert snap.report is not None
    assert snap.report.policy_id == "rank_one_linear_v1"
    assert snap.read.shape == arm.a.shape
    assert snap.write.shape == arm.b.shape
    assert snap.amplitude.shape == arm.beta.shape
    assert snap.membership_atoms_by_column.shape == (arm.num_atoms, arm.num_columns)
    assert torch.allclose(snap.read.norm(dim=1), torch.ones(arm.num_atoms), atol=1e-6)
    assert torch.allclose(snap.write.norm(dim=1), torch.ones(arm.num_atoms), atol=1e-6)
