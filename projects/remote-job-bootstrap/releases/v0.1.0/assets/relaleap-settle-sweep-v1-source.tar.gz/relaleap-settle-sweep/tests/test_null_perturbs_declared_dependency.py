import pytest
import torch

from relaleap.slt.null_reports import NullReport, bootstrap_ci, compare_to_null
from relaleap.slt.nulls import mechanism_preserving_control, mechanism_violating_control, residual_shuffle_null, target_shuffle_null


def test_target_and_residual_shuffle_are_deterministic_and_perturb_dependency():
    data = {
        "x": torch.arange(20).reshape(10, 2),
        "y": torch.arange(10),
        "residuals": torch.arange(30, dtype=torch.float32).reshape(10, 3),
    }

    shuffled = target_shuffle_null(data, seed=7)
    shuffled_again = target_shuffle_null(data, seed=7)
    assert shuffled["y"].shape == data["y"].shape
    assert torch.equal(shuffled["y"], shuffled_again["y"])
    assert not torch.equal(shuffled["y"], data["y"])
    assert torch.equal(torch.sort(shuffled["y"]).values, data["y"])
    assert torch.equal(shuffled["x"], data["x"])

    residual = residual_shuffle_null(data, seed=11)
    assert residual["residuals"].shape == data["residuals"].shape
    assert not torch.equal(residual["residuals"], data["residuals"])
    assert torch.equal(torch.sort(residual["residuals"][:, 0]).values, data["residuals"][:, 0])


def test_mechanism_controls_target_specific_channels():
    data = {
        "x": torch.arange(12).reshape(6, 2),
        "context": torch.arange(18).reshape(6, 3),
        "y": torch.arange(6),
    }
    preserving = mechanism_preserving_control(data, seed=3)
    violating = mechanism_violating_control(data, seed=3)
    assert not torch.equal(preserving["context"], data["context"])
    assert torch.equal(preserving["x"], data["x"])
    assert not torch.equal(violating["x"], data["x"])
    assert torch.equal(violating["y"], data["y"])


def test_bootstrap_ci_known_constant_data_and_null_report_validation():
    assert bootstrap_ci([2.0, 2.0, 2.0, 2.0], n_bootstrap=200, ci=0.95) == pytest.approx((2.0, 2.0))
    report = compare_to_null("target_shuffle", [0.0, 0.0, 0.0, 0.0], 1.0, n_bootstrap=200)
    assert report.difference == pytest.approx(1.0)
    assert report.margin_excludes_zero is True

    NullReport(
        null_type="mechanism_violating",
        null_estimates=[1.0, 1.1],
        real_estimate=1.0,
        difference=0.0,
        bootstrap_ci=(-0.1, 0.1),
        p_value=1.0,
        margin_excludes_zero=False,
    ).validate()
    with pytest.raises(ValueError, match="mechanism-preserving"):
        NullReport(
            null_type="mechanism_preserving",
            null_estimates=[1.0, 1.1],
            real_estimate=1.0,
            difference=0.0,
            bootstrap_ci=(-0.1, 0.1),
            p_value=1.0,
            margin_excludes_zero=False,
        ).validate()
