from __future__ import annotations

from math import log

import pytest
import torch

from relaleap.slt.energy import GaussianQuadraticEnergyModel
from relaleap.slt.wbic import (
    TemperatureConvention,
    assert_valid_wbic_temperature,
    estimate_lambda_from_energies,
)


def test_total_energy_and_mean_loss_conventions_have_same_effective_target() -> None:
    n = 512
    total = TemperatureConvention.wbic_total_energy(n)
    mean = TemperatureConvention.wbic_mean_loss(n)

    assert total.coefficient_on_total_nll == pytest.approx(1.0 / log(n))
    assert mean.coefficient_on_total_nll == pytest.approx(total.coefficient_on_total_nll)
    assert mean.coefficient_on_mean_loss == pytest.approx(n / log(n))

    data = torch.zeros(n, 1)
    theta = torch.tensor([0.3, -0.4])
    model = GaussianQuadraticEnergyModel(torch.eye(2), torch.zeros(2), n_data=n)
    total_exponent = total.coefficient_on_total_nll * model.total_energy(theta, data)
    mean_exponent = mean.coefficient_on_mean_loss * model.mean_loss(theta, data)
    assert float(total_exponent) == pytest.approx(float(mean_exponent))


def test_total_nll_coefficient_one_over_n_log_n_is_rejected() -> None:
    n = 512
    wrong = TemperatureConvention.wrong_total_nll_divided_by_n(n)
    assert wrong.coefficient_on_total_nll == pytest.approx(1.0 / (n * log(n)))
    with pytest.raises(ValueError, match="coefficient on total energy"):
        assert_valid_wbic_temperature(wrong)


def test_wrong_total_nll_coefficient_gives_wrong_lambda_negative_control() -> None:
    n = 512
    d = 3
    # For a regular Gaussian quadratic at beta=1/log(n), E[En]-En(theta_hat)=d/(2 beta).
    correct_delta_energy = d * log(n) / 2.0
    energies = torch.full((200,), correct_delta_energy)
    lambda_hat, _, _ = estimate_lambda_from_energies(energies, 0.0, n)
    assert lambda_hat == pytest.approx(d / 2.0)

    # If code samples with total-NLL coefficient 1/(n log n), the expected energy delta is n times too large.
    wrong_delta_energy = n * correct_delta_energy
    wrong_lambda, _, _ = estimate_lambda_from_energies(torch.full((200,), wrong_delta_energy), 0.0, n)
    assert wrong_lambda == pytest.approx(n * d / 2.0)
    assert wrong_lambda != pytest.approx(d / 2.0, rel=0.05)


def test_negative_lambda_is_reported_not_clipped() -> None:
    n = 256
    lam, _, _ = estimate_lambda_from_energies(torch.tensor([-2.0, -1.0, -3.0]), 0.0, n)
    assert lam < 0.0
