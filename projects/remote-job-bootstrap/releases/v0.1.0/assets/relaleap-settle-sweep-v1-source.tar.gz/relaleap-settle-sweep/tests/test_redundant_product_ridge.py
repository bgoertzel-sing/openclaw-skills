import torch

from relaleap.slt.analytic_registry import InteractionSign, nonzero_product_ridge
from relaleap.slt.calibration_benchmarks import TargetMetadataEstimator, check_estimate
from relaleap.slt.contracts import make_mock_estimator_output


def test_nonzero_product_ridge_true_metadata_positive_interaction():
    bench = nonzero_product_ridge(c=1.0)
    target = bench.target
    assert target.lambda_A == 0.5
    assert target.lambda_B == 0.5
    assert target.lambda_AB == 0.5
    assert target.interaction == 0.5
    assert target.interaction_sign is InteractionSign.POSITIVE
    assert bench.loss([0.0, 0.0]).item() == 0.0


def test_nonzero_product_ridge_energy_has_ridge_and_regular_frozen_blocks():
    bench = nonzero_product_ridge(c=1.0)
    data = bench.make_data(10, seed=5)
    model = bench.make_energy_model(data, None)
    assert data.shape == (10, 1)
    assert torch.isclose(model.mean_loss(torch.tensor([0.0, 0.0]), data), torch.tensor(0.0, dtype=torch.float64))
    assert model.mean_loss(torch.tensor([0.25, 0.0]), data).item() > 0.0
    assert model.mean_loss(torch.tensor([0.0, -0.25]), data).item() > 0.0
    # Along the product-preserving joint ridge: (1+δa)(1+δb)=1.
    assert torch.isclose(model.mean_loss(torch.tensor([1.0, -0.5]), data), torch.tensor(0.0, dtype=torch.float64))
    assert make_mock_estimator_output(bench.benchmark_id, "AB").block_name == "AB"


def test_nonzero_product_ridge_mock_estimator_passes_interaction_contract():
    bench = nonzero_product_ridge()
    result = check_estimate(bench, TargetMetadataEstimator().estimate(bench))
    assert result.status == "pass"
    assert result.expected_interaction_sign is InteractionSign.POSITIVE
    assert result.observed_interaction > 0
