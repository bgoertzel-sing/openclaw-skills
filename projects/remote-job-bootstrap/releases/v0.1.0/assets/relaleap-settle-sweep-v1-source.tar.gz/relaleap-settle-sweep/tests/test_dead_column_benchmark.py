from relaleap.slt.releap_benchmarks import generate_releap_benchmark, mock_estimator_output


def test_dead_column_declared_not_modular_evidence():
    data = generate_releap_benchmark("dead_column", seed=3, n=80, d_model=12, num_columns=5)
    md = data.metadata
    dead = md["true_interactions"]["dead_columns"][0]
    assert dead in md["true_interactions"]["zero_router_probability_columns"]
    assert dead in md["true_interactions"]["zero_amplitude_columns"]
    assert not (data.true_supports == dead).any()
    assert md["expected_winner"] == "fail_closed_dead_structure"
    assert md["expected_I_lambda_signs"][f"column_{dead}_effective_contribution"] == "near_zero"
    assert md["expected_I_lambda_signs"]["dead_column_as_modular_evidence"] == "not_interpretable"
    assert mock_estimator_output(md).winner == "fail_closed_dead_structure"
