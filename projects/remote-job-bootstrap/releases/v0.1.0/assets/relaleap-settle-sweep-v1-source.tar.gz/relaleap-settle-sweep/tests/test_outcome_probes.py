import torch

from relaleap.hdpc.outcome_probes import (
    block_skip_losses,
    collect_hidden_states,
    corrupt_batches,
    linear_cka,
    spectral_summary,
)
from relaleap.hdpc.tinyshakespeare import CausalCharTransformerLM, TinyCharTransformerConfig


def _model():
    torch.manual_seed(3)
    return CausalCharTransformerLM(TinyCharTransformerConfig(
        vocab_size=11, seq_len=6, d_model=8, nhead=2, d_ff=16, num_layers=2,
    ))


def _batches():
    generator = torch.Generator().manual_seed(5)
    return tuple(
        (torch.randint(11, (2, 6), generator=generator), torch.randint(11, (2, 6), generator=generator))
        for _ in range(2)
    )


def test_cka_identity_and_orthogonal_invariance():
    generator = torch.Generator().manual_seed(7)
    x = torch.randn(32, 6, generator=generator)
    q, _ = torch.linalg.qr(torch.randn(6, 6, generator=generator))
    assert abs(linear_cka(x, x) - 1.0) < 1e-10
    assert abs(linear_cka(x, x @ q) - 1.0) < 1e-10


def test_spectral_summary_recovers_isotropic_rank():
    values = torch.eye(8).repeat(4, 1)
    summary = spectral_summary(values)
    assert 6.9 < summary["effective_rank"] <= 8.0
    assert 6.9 < summary["participation_ratio"] <= 8.0


def test_hidden_block_skip_and_corruption_are_deterministic():
    model, batches = _model(), _batches()
    states = collect_hidden_states(model, batches)
    assert len(states) == 3
    assert all(state.shape == (4, 6, 8) for state in states)
    losses = block_skip_losses(model, batches)
    assert len(losses) == 2
    assert all(torch.isfinite(torch.tensor(losses)))
    first = corrupt_batches(batches, vocab_size=11, probability=0.25, seed=13)
    second = corrupt_batches(batches, vocab_size=11, probability=0.25, seed=13)
    assert all(torch.equal(a[0], b[0]) and torch.equal(a[1], b[1]) for a, b in zip(first, second))
