import copy
import math
from pathlib import Path

import pytest

from relaleap.hdpc.pilot_dry_run import (
    comparable_payload,
    run_cpu_dry_run,
    validate_metric_record,
    write_metrics,
)
from relaleap.hdpc.pilot_protocol import load_pilot_protocol


PROTOCOL = Path(__file__).parents[1] / "configs" / "gpt2_small_epc_pilot.json"


@pytest.fixture(scope="module")
def repeated_runs():
    protocol = load_pilot_protocol(PROTOCOL)
    return run_cpu_dry_run(protocol), run_cpu_dry_run(protocol)


def test_cpu_stub_uses_all_frozen_seeds_and_arms(repeated_runs) -> None:
    first, _ = repeated_runs
    assert len(first) == 9
    assert {(row["seed"], row["arm"]) for row in first} == {
        (seed, arm)
        for seed in (1729, 3253, 6421)
        for arm in ("bp_ce", "bp_kd", "epc_kd")
    }
    assert all(row["mode"] == "cpu_two_layer_stub" for row in first)


def test_cpu_stub_is_deterministic_except_declared_timing(repeated_runs) -> None:
    first, second = repeated_runs
    assert comparable_payload(first) == comparable_payload(second)


def test_epc_stub_exercises_relaxation_and_credit(repeated_runs) -> None:
    first, _ = repeated_runs
    epc = [row for row in first if row["arm"] == "epc_kd"]
    assert all(row["activity_energy_monotone"] for row in epc)
    assert all(len(trace) == 4 for row in epc for trace in row["activity_energy_traces"])
    assert all(len(trace) == 3 for row in epc for trace in row["accepted_step_sizes"])
    assert all(len(trace) == 3 for row in epc for trace in row["backtrack_counts"])
    assert all(len(row["credit_assignment"]) == 2 for row in epc)
    assert all(block["finite"] for row in epc for block in row["credit_assignment"])


def test_metric_validation_and_json_write_fail_closed(tmp_path, repeated_runs) -> None:
    first, _ = repeated_runs
    output = tmp_path / "metrics.json"
    write_metrics(output, first)
    assert output.read_text().endswith("\n")
    malformed = copy.deepcopy(first[0])
    malformed["student_val_loss"] = math.nan
    with pytest.raises(ValueError, match="finite"):
        validate_metric_record(malformed)
    missing = copy.deepcopy(first[0])
    del missing["eval_set_sha256"]
    with pytest.raises(ValueError, match="missing"):
        validate_metric_record(missing)
