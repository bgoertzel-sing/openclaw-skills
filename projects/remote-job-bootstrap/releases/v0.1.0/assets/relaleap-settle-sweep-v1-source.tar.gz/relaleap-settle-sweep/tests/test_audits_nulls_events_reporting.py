import json
import torch
from relaleap.audits import ExactAblationAuditor, FrozenLinearSuffix
from relaleap.arms import ArmDependencyContract
from relaleap.nulls import dependency_aware_null_specs, assert_null_adequacy
from relaleap.events import EventLog
import pytest
from relaleap.reporting import DecisionReport, fail_closed_placeholder


def test_exact_ablation_manual_loss_and_synergy():
    h = torch.zeros(4, 3)
    col = torch.zeros(4, 2, 3)
    col[:, 0, 0] = 1.0
    col[:, 1, 1] = 1.0
    weight = torch.tensor([[2.0, -2.0], [1.0, -1.0], [0.0, 0.0]])
    targets = torch.zeros(4, dtype=torch.long)
    auditor = ExactAblationAuditor(FrozenLinearSuffix(weight), targets)
    base = auditor.exact_support_loss(h, col, [])
    one = auditor.exact_support_loss(h, col, [0])
    assert torch.allclose(auditor.singleton_gain(h, col, 0), base - one)
    syn = auditor.pair_synergy(h, col, 0, 1)
    manual = (base - auditor.exact_support_loss(h, col, [0, 1])) - (base - one) - (base - auditor.exact_support_loss(h, col, [1]))
    assert torch.allclose(syn, manual)
    assert auditor.one_swap_regret(h, col, [0]) >= 0


def test_dependency_null_adequacy():
    contract = ArmDependencyContract(uses_hidden=True, uses_context=True, uses_teacher_residuals=True, uses_router_support=True)
    specs = dependency_aware_null_specs(contract)
    names = {s.name for s in specs}
    assert {"hidden_shuffle", "context_shuffle", "teacher_residual_shuffle", "router_support_shuffle"} <= names
    assert_null_adequacy(contract, specs)


def test_event_log_jsonl(tmp_path):
    log = EventLog()
    log.append("column_growth", 3, [1], "coherent residual", {"gain": 0.2}, True, seed=7)
    path = tmp_path / "events.jsonl"
    log.write_jsonl(str(path))
    row = json.loads(path.read_text().splitlines()[0])
    assert row["event_type"] == "column_growth"
    assert row["accepted"] is True


def test_fail_closed_report(tmp_path):
    report = fail_closed_placeholder(["pytest"], [7], {"top_k": 2})
    report.write(str(tmp_path))
    summary = json.loads((tmp_path / "summary.json").read_text())
    assert summary["engineering_status"] == "pass"
    assert summary["scientific_status"] == "fail_closed"
    assert summary["promotion_allowed"] is False
    assert (tmp_path / "prediction_metrics.csv").exists()


def test_scientific_pass_requires_meaningful_slt_evidence_contract():
    report = DecisionReport(
        prediction={"status": "pass"},
        reconstruction={"status": "pass"},
        causal_modularity={"status": "pass"},
        slt_evidence={"status": "uncalibrated_wbic_proxy"},
        null_margins={"status": "pass"},
        engineering_status="pass",
        scientific_status="pass",
        promotion_allowed=True,
        reason="synthetic gates passed",
        commands=["pytest"],
        seeds=[7],
        configs={},
    )
    with pytest.raises(ValueError, match="requires SLT evidence fields"):
        report.validate_fail_closed()


def test_scientific_pass_accepts_calibrated_finite_sample_slt_contract():
    report = DecisionReport(
        prediction={"status": "pass"},
        reconstruction={"status": "pass"},
        causal_modularity={"status": "pass"},
        slt_evidence={
            "estimator_type": "finite_sample_wbic_sgld_proxy",
            "estimated_parameter_blocks": ["column_0", "column_1", "joint_0_1"],
            "wbic_temperature_schedule": "n/log(n) with preregistered sensitivity sweep",
            "calibration_status": "pass",
            "calibration_benchmarks": ["regular_linear", "known_singular_mixture", "two_column_interaction"],
            "input_sample_size": 4096,
            "input_coverage_report": "stratified over synthetic regimes, labels, router supports, and loss quantiles",
            "inference_budget_report": "4096 inputs x 4 chains x 3 temperatures; exact command and wall-clock recorded",
            "sample_size_sensitivity": "stable sign/margin at n in {1024, 2048, 4096}",
            "null_normalized_margin": 0.42,
            "finite_sample_caveat": True,
        },
        null_margins={"status": "pass"},
        engineering_status="pass",
        scientific_status="pass",
        promotion_allowed=True,
        reason="synthetic gates passed",
        commands=["pytest"],
        seeds=[7],
        configs={},
    )
    report.validate_fail_closed()
