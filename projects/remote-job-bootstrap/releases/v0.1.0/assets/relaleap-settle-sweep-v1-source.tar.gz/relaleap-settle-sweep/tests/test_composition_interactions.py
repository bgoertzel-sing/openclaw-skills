import torch

from relaleap.slt.analytic_registry import (
    BenchmarkFamily,
    InteractionSign,
    crossing_singularity,
    cusp_singularity,
    get_benchmark,
    independent_composition,
    list_benchmarks,
    overparameterized_mixture,
    redundant_composition,
    synergistic_composition,
)
from relaleap.slt.calibration_benchmarks import TargetMetadataEstimator, run_calibration
from relaleap.slt.contracts import make_mock_estimator_output


def test_independent_composition_metadata_zero_interaction():
    bench = independent_composition()
    assert bench.family is BenchmarkFamily.INDEPENDENT_COMPOSITION
    assert bench.target.lambda_A == 0.5
    assert bench.target.lambda_B == 0.5
    assert bench.target.lambda_AB == 1.0
    assert bench.target.interaction == 0.0
    assert bench.target.interaction_sign is InteractionSign.ZERO
    data = bench.make_data(12, 1)
    model = bench.make_energy_model(data, {})
    assert model.mean_loss(torch.tensor([2.0, 0.0]), data).item() == 2.0
    assert model.mean_loss(torch.tensor([0.0, 2.0]), data).item() == 2.0


def test_redundant_composition_metadata_positive_interaction():
    bench = redundant_composition()
    assert bench.family is BenchmarkFamily.REDUNDANT_COMPOSITION
    assert bench.target.interaction_sign is InteractionSign.POSITIVE
    assert bench.target.interaction > 0
    data = bench.make_data(12, 2)
    model = bench.make_energy_model(data, None)
    assert torch.isclose(model.mean_loss(torch.tensor([1.0, -1.0]), data), torch.tensor(0.0, dtype=torch.float64))
    assert model.mean_loss(torch.tensor([1.0, 0.0]), data).item() > 0.0


def test_synergistic_composition_metadata_negative_interaction():
    bench = synergistic_composition()
    assert bench.family is BenchmarkFamily.SYNERGISTIC_COMPOSITION
    assert bench.target.interaction_sign is InteractionSign.NEGATIVE
    assert bench.target.interaction < 0
    data = bench.make_data(12, 3)
    model = bench.make_energy_model(data, None)
    assert model.mean_loss(torch.tensor([0.0, 5.0]), data).item() == 0.0
    assert model.mean_loss(torch.tensor([2.0, 5.0]), data).item() > 0.0


def test_cusp_crossing_and_mixture_registry_landscapes():
    cusp = cusp_singularity()
    crossing = crossing_singularity()
    mixture = overparameterized_mixture()
    assert cusp.loss([1.0, 1.0]).item() == 0.0
    assert cusp.loss([1.0, 0.0]).item() == 1.0
    assert crossing.loss([0.0, 0.0, 0.0]).item() == 0.0
    assert crossing.loss([1.0, 1.0, 0.0]).item() == 1.0
    assert mixture.target.lambda_target < 1.5
    assert mixture.make_data(9, seed=4).shape == (9, 1)
    assert make_mock_estimator_output(mixture.benchmark_id, "mixture").benchmark_id == mixture.benchmark_id


def test_registry_contains_required_subagent_b_fixtures_and_mock_estimator_passes_all():
    names = list_benchmarks()
    required_families = {
        BenchmarkFamily.REGULAR_LINEAR_GAUSSIAN,
        BenchmarkFamily.RANK_DEFICIENT_LINEAR,
        BenchmarkFamily.PRODUCT_SINGULARITY,
        BenchmarkFamily.NONZERO_PRODUCT_RIDGE,
        BenchmarkFamily.CUSP,
        BenchmarkFamily.CROSSING,
        BenchmarkFamily.OVERPARAMETERIZED_MIXTURE,
        BenchmarkFamily.INDEPENDENT_COMPOSITION,
        BenchmarkFamily.REDUNDANT_COMPOSITION,
        BenchmarkFamily.SYNERGISTIC_COMPOSITION,
    }
    assert {get_benchmark(name).family for name in names} == required_families
    results = run_calibration(TargetMetadataEstimator(), names)
    assert results
    assert all(result.status == "pass" for result in results)
