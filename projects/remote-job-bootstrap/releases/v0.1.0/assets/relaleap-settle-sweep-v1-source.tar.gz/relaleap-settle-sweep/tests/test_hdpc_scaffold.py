from __future__ import annotations

import copy

import pytest
import torch

from relaleap.hdpc import IdentityPCCrown, PredictiveCodingMLP


def _parameter_gradients(model: torch.nn.Module, objective: torch.Tensor) -> tuple[torch.Tensor, ...]:
    return tuple(
        gradient.detach().clone()
        for gradient in torch.autograd.grad(objective, tuple(model.parameters()))
    )


def _flat(tensors: tuple[torch.Tensor, ...]) -> torch.Tensor:
    return torch.cat([tensor.reshape(-1) for tensor in tensors])


def test_zero_error_identity_matches_vanilla_forward() -> None:
    torch.manual_seed(1)
    model = PredictiveCodingMLP((3, 5, 2))
    inputs = torch.randn(7, 3)
    vanilla = model(inputs)

    objective, trace = model.pc_objective(inputs, vanilla.detach(), steps=8)

    assert objective.item() == pytest.approx(0.0, abs=1e-12)
    assert trace.energy_history == pytest.approx((0.0,) * 8, abs=1e-12)
    assert torch.equal(model(inputs), vanilla)


@pytest.mark.parametrize("steps", [1, 4, 16])
def test_student_equals_teacher_is_a_pure_distillation_anchor(steps: int) -> None:
    torch.manual_seed(2)
    teacher = PredictiveCodingMLP((4, 6, 3))
    student = copy.deepcopy(teacher)
    inputs = torch.randn(5, 4)

    with torch.no_grad():
        teacher_output = teacher(inputs)
    objective, _ = student.pc_objective(inputs, teacher_output, steps=steps, output_weight=0.05)
    gradients = _parameter_gradients(student, objective)

    assert objective.item() == pytest.approx(0.0, abs=1e-12)
    assert torch.count_nonzero(_flat(gradients)).item() == 0


def test_relaxation_energy_is_non_increasing() -> None:
    torch.manual_seed(3)
    model = PredictiveCodingMLP((3, 8, 5, 2))
    inputs = torch.randn(11, 3)
    target = torch.randn(11, 2)

    _, trace = model.pc_objective(
        inputs,
        target,
        steps=12,
        output_weight=0.05,
        relaxation_lr=0.5,
    )

    assert len(trace.energy_history) == 12
    assert all(
        later <= earlier + 1e-10
        for earlier, later in zip(trace.energy_history, trace.energy_history[1:])
    )
    assert trace.energy_history[-1] < trace.energy_history[0]


def test_one_step_endpoint_matches_output_weight_times_bp_gradient() -> None:
    torch.manual_seed(4)
    model = PredictiveCodingMLP((3, 7, 2))
    inputs = torch.randn(9, 3)
    target = torch.randn(9, 2)
    output_weight = 0.05

    bp_loss = 0.5 * (target - model(inputs)).square().sum(dim=-1).mean()
    bp_gradients = _parameter_gradients(model, bp_loss)
    pc_objective, _ = model.pc_objective(
        inputs, target, steps=1, output_weight=output_weight
    )
    pc_gradients = _parameter_gradients(model, pc_objective)

    for pc_gradient, bp_gradient in zip(pc_gradients, bp_gradients):
        assert torch.allclose(pc_gradient, output_weight * bp_gradient, atol=1e-7, rtol=1e-6)


def test_relaxed_pc_endpoint_is_distinct_from_bp_on_perturbed_target() -> None:
    torch.manual_seed(5)
    model = PredictiveCodingMLP((4, 9, 6, 3))
    inputs = torch.randn(13, 4)
    target = model(inputs).detach() + 0.4 * torch.randn(13, 3)

    bp_objective, _ = model.pc_objective(inputs, target, steps=1, output_weight=0.05)
    bp_gradient = _flat(_parameter_gradients(model, bp_objective))
    pc_objective, _ = model.pc_objective(
        inputs, target, steps=10, output_weight=0.05, relaxation_lr=0.3
    )
    pc_gradient = _flat(_parameter_gradients(model, pc_objective))

    cosine = torch.nn.functional.cosine_similarity(bp_gradient, pc_gradient, dim=0)
    assert torch.isfinite(cosine)
    assert not torch.allclose(pc_gradient, bp_gradient, atol=1e-7, rtol=1e-4)
    assert cosine.item() < 0.999


def test_zero_initialized_crown_changes_no_logits() -> None:
    torch.manual_seed(6)
    crown = IdentityPCCrown(width=11, hidden_width=7)
    logits = torch.randn(2, 5, 11)

    crowned = crown(logits)

    assert torch.equal(crowned, logits)
    assert torch.count_nonzero(crown.correction(logits)).item() == 0


def test_static_and_error_based_pc_state_gradients_agree_on_toy_mlp() -> None:
    """Local ePC errors reproduce gradients of the explicit static PC energy."""

    torch.manual_seed(7)
    model = PredictiveCodingMLP((2, 5, 4, 1))
    inputs = torch.randn(8, 2)
    target = torch.randn(8, 1)
    objective, trace = model.pc_objective(
        inputs, target, steps=6, output_weight=0.05, relaxation_lr=0.2
    )

    static_energy = model.energy_from_states(trace.states, target, output_weight=0.05)
    static_gradients = model.static_state_gradients(trace.states, target, output_weight=0.05)
    error_gradients = model.error_state_gradients(trace.states, target, output_weight=0.05)

    assert torch.allclose(objective, static_energy, atol=1e-8, rtol=1e-7)
    assert objective.item() == pytest.approx(trace.energy_history[-1], rel=1e-6, abs=1e-8)
    for static_gradient, error_gradient in zip(static_gradients, error_gradients):
        assert torch.allclose(static_gradient, error_gradient, atol=1e-7, rtol=1e-6)
