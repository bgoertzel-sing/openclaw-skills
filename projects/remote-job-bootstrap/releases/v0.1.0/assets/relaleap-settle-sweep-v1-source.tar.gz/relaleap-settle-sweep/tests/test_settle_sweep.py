import pytest

from relaleap.hdpc.settle_sweep import (
    aggregate_seed_records,
    validate_arm_record,
    validate_seed_record,
)


def _record(seed, kd):
    return {
        "status": "passed",
        "seed": seed,
        "arms": {
            str(depth): {
                "settle_steps": depth,
                "replay_exact": True,
                "held_out_kd_nats": value,
                "objectives": [1.0, 0.5],
            }
            for depth, value in zip((1, 2, 4, 8), kd)
        },
    }


def test_sweep_summary_reports_prespecified_monotonic_signature():
    records = [
        _record(1, [10.0, 9.5, 9.0, 8.0]),
        _record(2, [8.0, 7.75, 7.0, 6.5]),
    ]
    summary = aggregate_seed_records(records)
    assert summary["mean_gain_nondecreasing"] is True
    assert summary["mean_gain_vs_t1_nats"] == {
        "1": 0.0,
        "2": 0.375,
        "4": 1.0,
        "8": 1.75,
    }
    assert summary["positive_gain_fraction"] == {"2": 1.0, "4": 1.0, "8": 1.0}
    assert summary["per_seed_depth_gain_spearman"] == {"1": 1.0, "2": 1.0}
    assert summary["mean_depth_gain_spearman"] == 1.0


@pytest.mark.parametrize("mutation", ["missing", "replay", "nan", "objectives"])
def test_sweep_validation_fails_closed(mutation):
    record = _record(1, [10.0, 9.5, 9.0, 8.0])
    if mutation == "missing":
        del record["arms"]["8"]
    elif mutation == "replay":
        record["arms"]["4"]["replay_exact"] = False
    elif mutation == "nan":
        record["arms"]["2"]["held_out_kd_nats"] = float("nan")
    else:
        record["arms"]["1"]["objectives"] = []
    with pytest.raises(ValueError):
        validate_seed_record(record)


def test_partial_arm_validation_supports_resume_but_rejects_depth_mismatch():
    arm = _record(1, [10.0, 9.5, 9.0, 8.0])["arms"]["2"]
    validate_arm_record(2, arm)
    arm["settle_steps"] = 4
    with pytest.raises(ValueError):
        validate_arm_record(2, arm)
