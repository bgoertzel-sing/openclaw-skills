import torch

from relaleap.slt.gauge import rank_one_function
from relaleap.slt.nulls import block_assignment_shuffle_null, gauge_randomization_null
from relaleap.slt.parameter_blocks import ParameterBlock


def test_gauge_randomization_is_deterministic_perturbation_preserving_rank_one_function():
    read = torch.tensor([[-2.0, 0.5, 1.0], [0.0, -3.0, 4.0], [1.0, 1.0, 0.0]])
    write = torch.tensor([[0.0, -6.0], [-1.0, 1.0], [-2.0, 0.0]])
    amplitude = torch.tensor([0.25, -0.5, 2.0])
    inputs = torch.randn(17, 3, generator=torch.Generator().manual_seed(101))

    before = rank_one_function(read, write, amplitude, inputs)
    g_read, g_write, g_amp = gauge_randomization_null(read, write, amplitude, seed=23)
    g_read_again, g_write_again, g_amp_again = gauge_randomization_null(read, write, amplitude, seed=23)
    after = rank_one_function(g_read, g_write, g_amp, inputs)

    assert g_read.shape == read.shape
    assert g_write.shape == write.shape
    assert g_amp.shape == amplitude.shape
    assert torch.equal(g_read, g_read_again)
    assert torch.equal(g_write, g_write_again)
    assert torch.equal(g_amp, g_amp_again)
    assert not torch.allclose(g_read, read)
    assert torch.allclose(after, before, atol=1e-5)


def test_block_assignment_shuffle_preserves_identities_and_sizes_but_changes_roles():
    blocks = [
        ParameterBlock(name="a", role="atoms", size=2, parent="p0"),
        ParameterBlock(name="r", role="router", size=3, parent="p1"),
        ParameterBlock(name="s", role="shared_core", size=4, parent="p2"),
    ]
    shuffled = block_assignment_shuffle_null(blocks, seed=0)
    shuffled_again = block_assignment_shuffle_null(blocks, seed=0)

    assert [b.name for b in shuffled] == ["a", "r", "s"]
    assert [b.size for b in shuffled] == [2, 3, 4]
    assert [b.role for b in shuffled] == [b.role for b in shuffled_again]
    assert [b.role for b in shuffled] != [b.role for b in blocks]
    assert {b.metadata["assignment_source"] for b in shuffled} == {"a", "r", "s"}
