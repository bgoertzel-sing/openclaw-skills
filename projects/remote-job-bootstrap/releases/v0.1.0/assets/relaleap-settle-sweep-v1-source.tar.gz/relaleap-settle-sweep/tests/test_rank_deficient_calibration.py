import torch

from relaleap.slt.analytic_registry import BenchmarkFamily, rank_deficient_linear
from relaleap.slt.calibration_benchmarks import TargetMetadataEstimator, check_estimate
from relaleap.slt.contracts import make_mock_estimator_output


def test_rank_deficient_target_is_rank_not_parameter_count():
    bench = rank_deficient_linear(d=7, rank=3)
    assert bench.family is BenchmarkFamily.RANK_DEFICIENT_LINEAR
    assert bench.target.lambda_true == 1.5
    assert bench.dimensions["d"] == 7
    assert bench.dimensions["rank"] == 3
    theta = bench.theta_star.clone()
    theta[:3] += torch.tensor([1.0, 2.0, 2.0], dtype=torch.float64)
    theta[3:] = 100.0
    assert bench.loss(theta).item() == 4.5


def test_rank_deficient_energy_ignores_null_parameters_at_optimum():
    bench = rank_deficient_linear(d=5, rank=2)
    data = bench.make_data(16, seed=11)
    assert data.shape == (16, 6)
    model = bench.make_energy_model(data, None)
    theta = model.theta_hat()
    theta[2:] = 99.0
    assert torch.isclose(model.mean_loss(theta, data), torch.tensor(0.0, dtype=torch.float64))
    output = make_mock_estimator_output(bench.benchmark_id, "AB")
    assert output.result.lambda_hat == 1.0


def test_rank_deficient_mock_estimator_passes_contract():
    bench = rank_deficient_linear(d=5, rank=2)
    result = check_estimate(bench, TargetMetadataEstimator().estimate(bench))
    assert result.status == "pass"
    assert result.observed_lambda == 1.0
