from relaleap.slt.releap_benchmarks import generate_releap_benchmark, mock_estimator_output


def test_mediator_metadata_expects_conditioning_to_weaken_pairwise_signal():
    data = generate_releap_benchmark("mediator", seed=9, n=96, d_model=12, num_columns=5)
    md = data.metadata
    mediator = md["true_mediators"][0]
    assert mediator["name"] == "M"
    assert mediator["mediates"] == [0, 1]
    assert md["true_interactions"]["mediated_pair"] == [0, 1]
    assert md["expected_winner"] == "mediator_conditioned_columnar_adapter"
    assert md["expected_I_lambda_signs"]["I_lambda(A;B)"] == "positive"
    assert md["expected_I_lambda_signs"]["I_lambda(A;B|M)"] == "weakens_when_conditioned"
    assert mock_estimator_output(md).I_lambda_signs["I_lambda(A;B|M)"] == "weakens_when_conditioned"
