#!/usr/bin/env bash
set -euo pipefail

MODEL="${1:?Usage: scripts/run_quick.sh OLLAMA_MODEL [OUTPUT_DIR]}"
OUTPUT="${2:-runs/quick_${MODEL//[:\/]/_}}"

python -m orl_ollama check --model "$MODEL"
python -m orl_ollama run \
  --model "$MODEL" \
  --repeats 4 \
  --task-id coreference_analysis \
  --task-id prepositional_attachment \
  --output "$OUTPUT" \
  --analyze \
  --bootstrap 500

echo "Core results: $OUTPUT/analysis_summary.md"
echo "For the optional operator-compression fit:"
echo "  python -m orl_ollama compress --run-dir '$OUTPUT' --dimension 2 --restarts 3"
