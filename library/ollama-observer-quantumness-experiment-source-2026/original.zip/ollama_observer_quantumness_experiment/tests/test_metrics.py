import math

import numpy as np

from orl_ollama.metrics import cbd_cyclic4, empirical_joint, s_odd, total_variation


def test_s_odd_chsh_pattern():
    assert math.isclose(s_odd([1.0, 1.0, 1.0, -1.0]), 4.0)


def test_cbd_noncontextual_all_equal():
    contexts = [[(1, 1)] * 20 for _ in range(4)]
    result = cbd_cyclic4(contexts)
    assert math.isclose(result.raw_excess, 0.0)


def test_cbd_pr_box_pattern():
    balanced_same = [(1, 1)] * 10 + [(-1, -1)] * 10
    balanced_opposite = [(1, -1)] * 10 + [(-1, 1)] * 10
    contexts = [balanced_same, balanced_same, balanced_same, balanced_opposite]
    result = cbd_cyclic4(contexts)
    assert math.isclose(result.inconsistent_connectedness, 0.0)
    assert math.isclose(result.s_odd_value, 4.0)
    assert math.isclose(result.raw_excess, 2.0)
    assert math.isclose(result.contextuality_measure, 1.0)


def test_total_variation():
    left = empirical_joint([(1, 1)] * 10, alpha=0.0)
    right = empirical_joint([(-1, -1)] * 10, alpha=0.0)
    assert math.isclose(total_variation(left, right), 1.0)
