import pytest


torch = pytest.importorskip("torch")

from orl_ollama.compression import _make_model


@pytest.mark.parametrize("kind", ["real_povm", "complex_povm"])
def test_povm_model_probabilities_normalize(kind):
    model = _make_model(kind, p=3, c=4, o=4, rank=None, d=2, seed=7)
    probabilities = model.log_probabilities().exp()
    assert probabilities.shape == (3, 4, 4)
    assert torch.all(probabilities >= 0)
    assert torch.allclose(probabilities.sum(dim=-1), torch.ones(3, 4), atol=1e-5, rtol=1e-5)
