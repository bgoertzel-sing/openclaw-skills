import pytest

from orl_ollama.client import parse_choice


@pytest.mark.parametrize(
    "text,expected",
    [
        ('{"choice":"A"}', "A"),
        ('prefix {"choice": "B"} suffix', "B"),
        ("choice: A", "A"),
        ("B", "B"),
    ],
)
def test_parse_choice(text, expected):
    assert parse_choice(text)[0] == expected


def test_parse_choice_rejects_explanation_without_label():
    with pytest.raises(ValueError):
        parse_choice("I cannot decide")
