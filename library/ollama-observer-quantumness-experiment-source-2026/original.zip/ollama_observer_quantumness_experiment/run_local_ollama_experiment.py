#!/usr/bin/env python3
"""Run the package directly from a checkout without installing it."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from orl_ollama.__main__ import main  # noqa: E402


if __name__ == "__main__":
    raise SystemExit(main())
