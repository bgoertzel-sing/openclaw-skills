# Local Ollama test of observer-relative operator linguistics

This package runs a deliberately conservative black-box experiment on a local instruction model served by Ollama.
It asks whether unresolved linguistic interpretation exhibits more than ordinary stochastic ambiguity.
The experiment separates four progressively stronger observations:

1. **Choice uncertainty:** ambiguous passages should yield more variable judgments than disambiguated passages.
2. **Sequential order effects:** asking two related frame/grammar questions in opposite orders may change their joint distribution.
3. **Residual contextuality:** a cyclic-4 Contextuality-by-Default (CbD) criterion asks whether pairwise results exceed what can be explained by the observed marginal/direct influences alone.
4. **Operator compression:** an optional PyTorch fit compares a complex state-plus-POVM model with matched classical nonnegative, signed-real, and real-POVM baselines on held-out trials.

The package does **not** claim that the model or language is physically quantum. Ollama exposes generated behavior, not hidden activations, so this version also does not test internal complex resonances.

## 1. Prerequisites

- Python 3.10 or newer.
- Ollama running locally, normally at `http://localhost:11434`.
- At least one locally installed instruction/chat model.

From the package directory:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -e .
```

For the optional operator-compression comparison:

```bash
pip install -e '.[compression]'
```

For the tests:

```bash
pip install -e '.[dev]'
pytest
python -m orl_ollama self-test
```

The top-level `run_local_ollama_experiment.py` wrapper can also be used without an editable install once the packages in `requirements.txt` are present. For example:

```bash
python run_local_ollama_experiment.py self-test
python run_local_ollama_experiment.py check
```

## 2. Check Ollama

List the server version and locally available models:

```bash
python -m orl_ollama check
```

Check a selected model:

```bash
python -m orl_ollama check --model YOUR_MODEL_NAME
```

The program uses Ollama's native `/api/chat` endpoint with non-streaming structured output. It requests a tiny JSON schema containing only an `A` or `B` choice. Because some model/backend combinations occasionally ignore or incompletely satisfy constrained JSON, the client also has a strict fallback parser, retries, and an auditable error log.

## 3. Inspect the prompts without calling a model

```bash
python -m orl_ollama preview \
  --tasks tasks/default_tasks.json \
  --output runs/prompt_preview
```

Open:

```text
runs/prompt_preview/dry_run_prompt_preview.json
```

Each trial announces a pair of binary questions, asks the first, preserves the model's first answer in the chat history, and then asks the second. The two semantic options are independently randomized onto displayed labels `A` and `B` on every trial, so a persistent label preference should cancel in canonical `+1/-1` coding.

## 4. Run a small smoke experiment

The bundled shell script uses two tasks and four repetitions:

```bash
scripts/run_quick.sh YOUR_MODEL_NAME
```

Equivalent explicit command:

```bash
python -m orl_ollama run \
  --model YOUR_MODEL_NAME \
  --repeats 4 \
  --task-id coreference_analysis \
  --task-id prepositional_attachment \
  --output runs/quick_test \
  --analyze \
  --bootstrap 500
```

A complete trial makes two model calls. With both query directions enabled, the call count is:

```text
2 calls * tasks * conditions * 4 cycle edges * 2 directions * repeats
```

Four repetitions are suitable only for checking plumbing. A preliminary scientific screen should use substantially more repetitions, inspect bootstrap intervals, and be replicated across seeds, model families, and quantizations.

## 5. Run the complete bundled task set

```bash
python -m orl_ollama run \
  --model YOUR_MODEL_NAME \
  --repeats 24 \
  --output runs/full_model_test \
  --analyze \
  --bootstrap 2000
```

The runner is resumable. Repeating the same command with the same output directory skips completed trial IDs and retries only missing work. It refuses to mix a changed model digest, task file, prompt protocol, or generation setting into an existing run directory.

Useful controls:

```bash
# Only canonical cycle directions: enough for CbD, not enough for swap-defect comparison
python -m orl_ollama run --model YOUR_MODEL_NAME --directions canonical --repeats 24 --output runs/cbd_only

# Restrict to ambiguous passages
python -m orl_ollama run --model YOUR_MODEL_NAME --conditions ambiguous --repeats 24 --output runs/ambiguous_only

# Test one task
python -m orl_ollama run --model YOUR_MODEL_NAME --task-id causal_attribution --repeats 24 --output runs/causal_only

# Stop after a few trials while debugging
python -m orl_ollama run --model YOUR_MODEL_NAME --max-trials 8 --output runs/debug
```

## 6. Analyze an existing run

```bash
python -m orl_ollama analyze \
  --run-dir runs/full_model_test \
  --bootstrap 2000
```

Principal outputs:

- `analysis_summary.md` — plain-language result ladder and caveats.
- `swap_defects.csv` — forward/reverse total-variation and Jensen-Shannon differences by task, condition, and cycle edge.
- `cbd_contextuality.csv` — cyclic-4 correlations, inconsistent connectedness, bound, excess, and bootstrap intervals.
- `choice_entropy.csv` — empirical choice probabilities and entropy.
- `resolved_accuracy.csv` — agreement with the explicit facts added in the resolved passages.
- `trial_counts.csv`, `parse_methods.csv`, and `label_randomization_balance.csv` — run-integrity diagnostics.
- `swap_defect_by_condition.png`.
- `contextuality_by_condition.png`.
- `choice_entropy_by_condition.png`.

### How to read the behavioral results

A useful manipulation check is:

```text
entropy(ambiguous) > entropy(resolved)
```

A pre-confluence order-effect prediction is:

```text
swap_defect(ambiguous) > swap_defect(resolved)
```

The CbD result is stronger. For the four canonical contexts

```text
(q1,q2), (q2,q3), (q3,q4), (q4,q1),
```

let `c1,...,c4` be the observed product expectations and let `ICC` be the sum of marginal differences for each content across its two contexts. The rank-4 noncontextuality criterion is

```text
S_odd(c1,c2,c3,c4) <= 2 + ICC,
```

where `S_odd` maximizes the signed sum over sign patterns containing an odd number of minus signs. The code reports

```text
raw_excess = max(0, S_odd - 2 - ICC)
CbD_measure = raw_excess / 2.
```

A positive point estimate with a small sample is not persuasive because the maximum operation is upward-biased. Look for replication and a bootstrap lower bound above zero.

## 7. Run the operator-compression comparison

Install the optional dependency and fit dimension two:

```bash
pip install -e '.[compression]'
python -m orl_ollama compress \
  --run-dir runs/full_model_test \
  --dimension 2 \
  --restarts 8 \
  --steps 1600
```

The compression matrix treats:

- a **preparation** as a task plus ambiguity condition;
- a **measurement context** as one ordered pair of questions;
- an **outcome** as one of the four joint `(+/-1,+/-1)` response pairs.

Repeated trials are split into training and held-out counts. The fitted baselines and candidate model are:

- `nmf_rank_d2`: nonnegative latent mixture, classical rank `d^2`;
- `signed_rank_d2`: unrestricted signed-real low-rank logits, rank `d^2`;
- `real_povm_same_dimension`: real PSD states and normalized real POVMs of dimension `d`;
- `real_povm_matched_or_larger_budget`: the smallest real dimension whose symmetric-matrix degrees of freedom are at least those of a complex Hermitian `d`-dimensional model;
- `complex_povm_d`: complex PSD states and normalized complex POVMs of dimension `d`.

A complex-operator result is interesting only if it wins on held-out likelihood against **all four** baselines, including the real-POVM model with a matched or slightly larger effective matrix budget. In particular:

- beating NMF but not signed real suggests that signs, not operator geometry, explain the gain;
- beating NMF and signed real but not the real-POVM controls suggests noncommutative/PSD structure without evidence that complex phase matters;
- beating both real-POVM controls as well is the relevant preliminary signature for a genuinely complex operator representation.

The fit is nonconvex and is only a model-selection proxy for approximate PSD rank. Use multiple restarts and repeat the whole experiment.

## 8. Files and reproducibility

Every run directory contains:

- `manifest.json`: model name and digest, generation settings, task/prompt hashes, server version, platform, and planned trial count;
- `tasks_snapshot.json`: the exact task interface used by the run;
- `records.jsonl`: one complete auditable record per two-question trial;
- `errors.jsonl`: failures, if any;
- analysis and optional compression outputs.

Do not merge results from different model digests, quantizations, temperatures, task revisions, or prompt revisions without recording them as separate experimental conditions.

## 9. What would count as preliminary support?

The strongest pattern available to this black-box package is:

1. the ambiguous condition is empirically less settled than the resolved condition;
2. sequential swap defects are larger before disambiguation and collapse after it;
3. CbD excess survives correction for observed direct influences in the ambiguous condition and weakens after resolution;
4. a compact complex POVM predicts held-out joint judgments better than matched nonnegative, signed-real, and real-POVM models;
5. the pattern replicates across task paraphrases, random seeds, and at least two model families.

Anything weaker should be described more modestly:

- order effects alone: contextual disturbance;
- positive ICC alone: direct influence or signaling;
- complex eigenvalues in a classical transition matrix: phase-like classical dynamics;
- NMF loss without a signed/real-operator comparison: inadequate classical baseline;
- complex-POVM fit without held-out advantage: flexible redescription.

## 10. Next step beyond Ollama

A true test of the complex-resonance and causal-coding hypotheses requires a model runtime that exposes hidden states and permits intervention. The coding-agent specification describes an extension using a local Hugging Face or llama.cpp-compatible model to record layer-wise states, estimate Koopman/dynamic-mode spectra, and perform activation patching or causal scrubbing.
