# Coding-Agent Specification: Local Empirical Probe of Observer-Relative Operator Linguistics

## 1. Mission

Build, validate, and extend a reproducible local experiment that asks whether a resource-bounded linguistic observer of a language model's inference exhibits an empirically useful operator-valued description.

The implementation must enforce a strict evidential ladder. It must never infer quantumness merely from discreteness, probability, ambiguity, vector representations, order effects, or complex eigenvalues. The target claim is narrower:

> Relative to a fixed grammatical/semantic interrogation interface, unresolved model behavior may sometimes be represented more compactly and predictively by a low-dimensional contextual operator model than by comparably economical classical nonnegative, signed-real, or real-operator models.

The current package is a **black-box behavioral probe** over Ollama. It cannot establish physical quantum computation and cannot directly test hidden-state complex resonances. Its job is to determine whether there is enough behavioral structure to justify a deeper white-box experiment.

## 2. Theoretical basis to preserve

### 2.1 Observer-relative quantumness

The relevant observer-relative proposal treats the full system as potentially classical. Quantumness is a property of the minimal faithful model available to a bounded observer, not a claim about physical substrate.

Three distinctions are load-bearing:

1. **Compression gap, not incompressibility.** Compare a classical nonnegative latent explanation with a PSD/operator explanation. Random or complicated behavior is not enough.
2. **Contextuality, not mere order dependence.** Sequential disturbance and noncommuting updates may have ordinary classical explanations. A contextuality test must include direct marginal influences in its null bound.
3. **Actual phase-bearing dynamics, not arbitrary complex coordinates.** Complex phase should eventually be traced to long-lived off-axis modes of the model's coarse inference dynamics, rather than assigned to words or interpretations by hand.

The current code addresses (1) approximately and (2) behaviorally. It deliberately postpones (3) until hidden states are available.

### 2.2 TUG-style observer interface

A linguistic observer is defined by what it can ask and distinguish. The task file is therefore part of the scientific object, not a mere prompt collection. Each task specifies:

- a passage or preparation;
- an ambiguous and a resolved condition;
- four binary semantic/grammatical contents;
- a cyclic family of pair contexts.

The interface quotients away everything not expressed in these contents. Results are always relative to this interface.

### 2.3 Category-guided causal coding

The broader architectural hypothesis separates stable frame/grammar structure, explicit mediators, context routing, and plastic statistical residue. An operator sector should be introduced only after ordinary causal factorization and mediator explanations have been tested.

The implementation implication is:

> Use strong classical controls first. Quantize only an irreducible residual, and only when held-out model selection rewards doing so.

## 3. Scientific questions

The package should answer the following questions in order.

### Q1. Did the ambiguity manipulation work?

For each content, estimate the empirical binary choice entropy. The resolved condition should normally reduce entropy relative to the ambiguous condition.

Failure of this manipulation check invalidates stronger interpretations for that task. A task on which a model gives the same answer in every trial is not an informative contextuality experiment, even when that answer is linguistically reasonable.

### Q2. Does sequential interrogation produce a swap defect?

For each cycle edge `(qi,qj)`, run both:

```text
qi -> qj
qj -> qi
```

After converting the reverse trial back into canonical `(qi,qj)` outcome order, estimate the two four-outcome distributions. Define:

```text
swap_TV = 0.5 * sum_o |P_forward(o) - P_reverse(o)|.
```

Also report Jensen-Shannon divergence. The pre-confluence prediction is:

```text
swap_TV(ambiguous) > swap_TV(resolved).
```

This is evidence of context-sensitive updating, not yet contextuality.

### Q3. Is there residual cyclic contextuality after direct influences?

Use the four canonical contexts:

```text
C1=(q1,q2)
C2=(q2,q3)
C3=(q3,q4)
C4=(q4,q1).
```

All outcomes are encoded as `+1/-1`. Let:

```text
ci = E[product of the two outcomes in context Ci].
```

For each question/content, compute the difference between its mean in the two contexts in which it appears. Sum the four absolute differences to obtain `ICC`, the inconsistent-connectedness/direct-influence term.

Compute:

```text
S_odd(c1,c2,c3,c4)
```

as the maximum signed sum over sign vectors with an odd number of negative signs. For rank four:

```text
noncontextual iff S_odd <= 2 + ICC.
raw_excess = max(0, S_odd - 2 - ICC)
CbD_measure = raw_excess / 2.
```

Bootstrap by resampling within each context. Do not pool trials across semantically different tasks before computing the criterion. A positive finite-sample point estimate is not sufficient; report the full interval and replication rate.

### Q4. Does a complex operator model compress behavior better?

Construct a conditional preparation-measurement tensor from repeated responses:

```text
preparation p = task_id x condition
context c     = ordered question pair
outcome o     = one of four joint binary answer pairs
counts[p,c,o]
```

Split repetitions into training and held-out counts.

Compare:

1. **NMF**: nonnegative latent mixture with rank `d^2`.
2. **Signed real**: unrestricted real low-rank logits with rank `d^2`.
3. **Real POVM, same dimension**: real PSD states and normalized real PSD effects of dimension `d`.
4. **Real POVM, matched-or-larger budget**: choose the smallest real dimension `d_r` with `d_r(d_r+1)/2 >= d^2`.
5. **Complex POVM**: complex PSD states and normalized complex PSD effects of dimension `d`.

The POVM parameterization must satisfy normalization by construction. Given raw effects `F_co >= 0`, form:

```text
S_c = sum_o F_co
E_co = S_c^(-1/2) F_co S_c^(-1/2)
sum_o E_co = I.
```

Given a raw state factor `A_p >= 0`, use:

```text
rho_p = A_p / Tr(A_p)
P(o|p,c) = Tr(rho_p E_co).
```

Use multiple random restarts, held-out log loss, and a parameter-budget table. Do not call the result a rank proof: PSD-rank optimization is nonconvex and exact PSD rank is computationally difficult. The result is a practical approximate compression comparison.

The complex model must beat the nonnegative and signed-real baselines and both real-POVM baselines on held-out prediction. The matched-or-larger real baseline makes the phase comparison conservative: a complex win should not be attributable merely to having more real matrix degrees of freedom.

### Q5. Does the effect track unresolved inference?

The central condition comparison is ambiguous versus resolved. Required summaries:

```text
Delta_entropy = entropy_ambiguous - entropy_resolved
Delta_swap    = swap_ambiguous - swap_resolved
Delta_CbD     = CbD_ambiguous - CbD_resolved
Delta_complex_advantage across conditions.
```

The predicted pattern is positive deltas that shrink toward zero after disambiguation. A model showing equally strong effects after explicit resolution is more plausibly exhibiting prompt instability or output noise.

## 4. Current architecture

### 4.1 File layout

```text
pyproject.toml
requirements.txt
requirements-compression.txt
README.md
CODING_AGENT_SPEC.md
run_local_ollama_experiment.py
tasks/default_tasks.json
docs/SOURCE_MAP.md
docs/PRIOR_POS_PILOT_SUMMARY.md
scripts/run_quick.sh
src/orl_ollama/
  __init__.py
  __main__.py
  client.py
  design.py
  runner.py
  tasks.py
  metrics.py
  analyze.py
  compression.py
  util.py
tests/
  test_metrics.py
  test_parsing.py
```

### 4.2 Ollama client

`client.py` uses the native non-streaming chat endpoint. Each request includes:

- model name;
- complete chat history;
- a minimal JSON schema with `choice` in `{A,B}`;
- generation options including temperature, top-p, seed, and short output budget;
- a keep-alive setting.

The client must:

- check the server and installed model list before a run;
- parse exact JSON first;
- use narrow fallbacks only for an unambiguous A/B result;
- retry malformed responses;
- never silently invent a choice;
- expose raw response metadata for auditing;
- support a configurable host and timeout.

Do not enable or disable model reasoning implicitly. The CLI's default is to omit the `think` field, because behavior differs across model families and backends. Any explicit reasoning setting must be recorded in the manifest.

### 4.3 Trial design

Each complete trial has two calls in one fresh chat:

1. Announce the passage and both questions; ask the first question.
2. Insert the first answer as an assistant message; ask the second question.

The first judgment therefore knows the full pair context, while the second judgment is additionally conditioned on the first answer. This gives a well-defined sequential pair rather than two unrelated calls.

Both semantic options are randomly assigned to displayed labels A/B independently for each question and trial. Store both the displayed map and the canonical `+1/-1` value.

### 4.4 Trial identity and reproducibility

A trial ID consists of:

```text
task | condition | edge_index | direction | repeat
```

All random choices derive from a stable cryptographic hash of the base seed and trial ID. The run is append-only and resumable. Completed IDs are skipped on restart. Failures are recorded separately.

### 4.5 Data record contract

Each JSONL record must include at least:

```text
trial_id
timestamp_utc
task_id
family
condition
edge_index
direction
context_id
canonical_edge_id
first_question_id
second_question_id
repeat
seed
first_label_texts / first_label_values
second_label_texts / second_label_values
first_choice / second_choice
first_value / second_value
canonical_left_value / canonical_right_value
first_response / second_response
complete
```

The runner also snapshots the exact task file and records a scientific identity containing the model digest, task hash, prompt hash, sampling settings, and base seed. It must reject attempts to resume into the same directory with a different identity.

Never alter old records in place. Schema migrations should write a new run or a versioned derived file.

## 5. Required validation

Before model calls:

```bash
python -m orl_ollama preview --output runs/prompt_preview
python -m orl_ollama self-test
pytest
```

The metric self-test must include:

- an all-equal rank-4 system with zero contextuality excess;
- a PR-box-style correlation pattern `(1,1,1,-1)` with zero ICC and raw excess 2;
- total-variation sanity checks;
- robust response-parser cases.

Before interpreting a run, check:

- no missing cycle contexts;
- comparable valid repeat counts across directions;
- option-label balance;
- response parse method distribution;
- error rate;
- choice entropy and saturation;
- agreement with the explicit answers in resolved-condition task metadata;
- task-level rather than merely pooled results.

## 6. Controls to add next

### 6.1 Prompt and label controls

Add and report:

- question paraphrase variants;
- passage paraphrase variants preserving intended ambiguity;
- alternative neutral system prompts;
- label alphabets other than A/B;
- order-announcement ablation, where the first question is not told the second question;
- a simultaneous-pair condition, where both answers are returned in one JSON object;
- temperature and seed sweeps.

### 6.2 Classical explanatory controls

Before accepting residual contextuality, fit explicit classical models that include:

- answer-position bias;
- label bias;
- first-answer consistency pressure;
- passage-level latent interpretation;
- question-pair-specific latent variables;
- finite-memory Markov update state.

A large unrestricted context-specific latent model will always be able to redescribe the behavior. The relevant question is whether it remains economical under held-out prediction and the same complexity accounting used for the operator model.

### 6.3 Negative-control tasks

Add four-question cycles whose questions are semantically independent. Expected outcome:

```text
low swap defect, low ICC, zero CbD excess.
```

Add deterministic resolved tasks. Expected outcome:

```text
near-zero entropy and near-zero order sensitivity.
```

Add intentionally order-sensitive classical tasks. Expected outcome:

```text
high swap defect and ICC, but no residual CbD excess after correction.
```

These controls are essential to demonstrate that the pipeline does not label ordinary sequential dependence as contextuality.

### 6.4 Data-volume controls

Run synthetic resampling studies at the exact per-context sample sizes used experimentally. Quantify upward bias in `S_odd` and false-positive rates for the bootstrap rule. Prefer a parametric or permutation-calibrated null in addition to the naive bootstrap.

## 7. White-box extension: testing the phase hypothesis

Ollama's public generation API is not the right substrate for this stage. Add a second backend using a local model runtime that exposes hidden states, such as a Hugging Face transformer or a custom llama.cpp instrumentation layer.

### 7.1 Hidden-state collection

For each task and sequential query context, record:

- residual stream vectors at selected layers;
- attention-head outputs;
- MLP outputs;
- final-token and passage-token states;
- states before first judgment and after conditioning on it;
- repeated inference passes if using a recurrent or predictive-coding model.

Use a versioned tensor format with model digest, layer names, token mapping, and prompt hash.

### 7.2 Frame and grammar probes

Train small probes for the four task contents and for higher-level frame variables. Separate diagnostic predictability from causality. A state is a candidate carrier only if intervention on it changes the corresponding judgment.

### 7.3 Dynamical modes

For an explicitly iterative model, estimate a coarse transfer/Koopman operator over probe states or learned observer states. Methods may include:

- dynamic mode decomposition;
- extended DMD with nonlinear observables;
- Hankel delay embeddings;
- predictive-state reconstruction;
- singular-spectrum analysis.

Look for off-axis eigenvalues with modulus near one. Compare:

- ambiguous versus resolved conditions;
- real-decay tasks versus reanalysis/oscillatory tasks;
- task-aligned versus randomly rotated observation interfaces;
- original versus token/order-shuffled controls.

A complex eigenpair alone is insufficient. Require persistence, replication, task relevance, and an associated compression advantage.

### 7.4 Observer-relative test

Construct multiple observers of the same hidden dynamics:

- fine observer with broad hidden-state access;
- intermediate semantic-frame observer;
- coarse answer-only observer;
- mode-aligned observer whose probes approximate the leading complex eigenfunctions;
- random-interface observers matched for dimension and marginal frequency.

Test the predicted interaction:

```text
operator advantage = intrinsic complex mode x observer misalignment.
```

In particular, aligning the observer with the complex mode should reduce the need for an operator representation because the phase becomes directly readable.

### 7.5 Causal interventions

Use activation patching, causal scrubbing, or steering along candidate mode directions. Required predictions:

- perturbing phase should alter later frame judgments in a phase-dependent way;
- lesioning the candidate subspace should reduce the complex compression advantage;
- patching a resolved-state representation into an ambiguous run should accelerate the collapse of swap/contextuality effects;
- unrelated subspace interventions should not produce the same pattern.

## 8. Relationship to category-guided causal coding

The white-box implementation should first seek a classical modular explanation:

1. identify context-local supports;
2. locate explicit mediators among syntax, semantics, discourse, and reference;
3. estimate intervention footprints;
4. remove redundant/double-counted channels;
5. classify commutators as avoidable interference or task-required contextual dependence.

Only the residual after this process is eligible for operator modeling.

A useful model-selection objective is a Pareto table rather than one scalar score:

```text
held-out fit
memory/parameter cost
swap or commutator defect reproduced
mediator leakage
double-counting
operator dimension
stability across tasks and paraphrases
```

The operator account should dominate or occupy a genuinely different Pareto region, not merely win after arbitrary weighting.

## 9. Acceptance criteria for the current package

A coding-agent revision is acceptable only if:

- installation works in a clean Python 3.10+ virtual environment;
- `pytest` and `python -m orl_ollama self-test` pass;
- prompt preview works without an Ollama server;
- server/model checks fail with actionable errors;
- interrupted runs resume without duplicating records;
- every generated choice is traceable to raw content and label mapping;
- CbD formulas pass synthetic known cases;
- analysis tolerates partial runs and reports missing contexts rather than fabricating values;
- compression models normalize probabilities correctly;
- complex and real POVM effects sum numerically to identity;
- train/test splits are reproducible and leakage-free by repeat index;
- all plots and CSVs are generated without manual editing;
- documentation states limitations as prominently as positive interpretations.

## 10. Interpretation policy

Use the following language in automated reports.

### Allowed after entropy only

> The ambiguity manipulation affected response variability.

### Allowed after swap defect

> The model's sequential judgments are order-sensitive under this observer interface.

### Allowed after positive CbD excess with replication

> The context-indexed behavioral data show residual CbD contextuality beyond the measured marginal/direct influences.

### Allowed after complex held-out compression win

> A low-dimensional complex operator model is a more economical predictor of this observer's behavioral kernel than the tested matched classical and real-operator alternatives.

### Not allowed from this package

- Language is intrinsically quantum.
- The model is physically quantum.
- Words are qubits.
- Ambiguity is superposition.
- Order effects prove quantum cognition.
- A Hilbert-space fit proves quantum ontology.
- Complex eigenvalues alone establish observer-relative quantumness.

## 11. Recommended development sequence

1. Reproduce the bundled smoke test and inspect raw records.
2. Increase repetitions and validate finite-sample calibration on synthetic nulls.
3. Add negative controls and paraphrase variants.
4. Compare several small local models and quantizations.
5. Run the five-model compression comparison with multiple restarts.
6. Add explicit classical latent-update baselines.
7. Implement a hidden-state backend and frame probes.
8. Estimate complex modes and test observer alignment.
9. Add causal interventions.
10. Only then consider an operator-valued linguistic type layer as an architectural component rather than an analysis tool.
