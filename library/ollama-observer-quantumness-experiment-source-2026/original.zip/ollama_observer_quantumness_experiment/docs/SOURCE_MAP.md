# Source map for the conceptual design

This implementation was designed around the following internal manuscripts supplied with the project:

1. **Classical Dynamical Systems with Oscillatory Chaos-Onset Display Observer-Relative Quantumness**
   - Sections 3-4: nonnegative-rank versus PSD-rank compression; contextuality rather than mere noncommutation.
   - Section 5: complex-resonance criterion and observer/coarse-graining interaction.
   - Section 12: incompatible inference queries, pre-confluence regime, and the operator-valued observer of classical inference.
   - Section 13: falsification-oriented experiment design.

2. **Category-Guided Causal-Coding Transformers**
   - Sections 3-6: cognition-frame-language probes, naturality, mediator, commutator, and double-counting losses.
   - Section 9: minimal experiment, metrics, and reversed-order/intervention tests.
   - Section 11: probes are not causes; category theory is a design language rather than an empirical substitute.

3. **Linguistic Universals as Quantale-Enriched Cognition-Language Correspondences**
   - Section 2: TUG observation interface and weakest operational quotient.
   - Sections 6-8: commutator/swap transport, mediators, and context-indexed gluing.
   - Section 10: computational research program and confusion-graph estimation.

4. **Quasi-Chomskyan Universal Grammar Framed in Terms of Type Theory and Quantale Weakness**
   - Observation interfaces, visible meaning-bearing actions, scope/binding/voice/tense stores, and dependency/noncommutation structure.

External implementation references:

- Ollama native API documentation for `/api/chat`, structured-output schemas, non-streaming responses, and generation options.
- Dzhafarov and Kujala's Contextuality-by-Default theory and the cyclic-system criterion for inconsistently connected binary measurements.

The code intentionally implements only claims that can be tested through an answer-level interface. Hidden-state phase and causal-module claims remain future work.
