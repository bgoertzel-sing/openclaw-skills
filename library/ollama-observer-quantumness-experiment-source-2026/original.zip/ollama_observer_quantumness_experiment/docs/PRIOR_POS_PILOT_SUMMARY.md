# Minimal Sandbox Probe of Observer-Relative Operator Linguistics

## Question

Does a grammar-defined bounded observer of natural language expose (a) phase-bearing predictive dynamics and (b) a compact operator/PSD representation that beats equally economical classical representations?

## Corpus and observer

The experiment used 10,296 sentences and 200,110 non-punctuation tagged tokens drawn from six Brown Corpus genre exports: humor, reviews, science fiction, religion, editorial prose, and mystery. The main observer mapped the Brown tags to 11 universal-style part-of-speech categories. Fine and coarser observers were also tested.

The experiment deliberately tests grammatical dynamics, not lexical semantics, consciousness, or physical quantumness.

## Test 1: phase-bearing transfer mode

The first-order POS transfer operator has a leading nontrivial complex-conjugate pair

    lambda = -0.137082 +/- 0.338224 i
    |lambda| = 0.364948
    phase increment = 1.955862 radians
    implied period = 3.212 tokens
    e-folding time = 0.992 tokens

Against 5,000 frequency-stratified random tag-to-category interfaces, the grammatical observer's complex radius had permutation p = 0.002200. The random-interface mean was 0.217340 (SD 0.072710).

Against 100 within-sentence sequence shuffles, the null mean was 0.006076, with permutation p = 0.009901.

All six genres independently showed a complex radius between 0.337 and 0.393, far above their shuffled-order controls.

The category phases form an interpretable local syntactic cycle: determiner/adjective -> noun -> verb/adverb -> adposition/conjunction -> determiner/adjective.

**Interpretation:** Natural grammatical order contains a real off-axis predictive mode that is unusually well exposed by the grammatical observer. But its modulus is only 0.365, so the mode decays in about one token. It is not a near-unit-circle, long-lived resonance.

## Test 2: matched-budget predictive compression

A conditional matrix was built from past POS bigrams to future POS bigrams. The top 50 past and future contexts covered 84.7% of held-out transitions. Lower held-out cross-entropy is better.

### Operator dimension 2 / classical rank 4

| Model | Held-out bits |
|---|---:|
| Nonnegative rank 4 | 4.603375 |
| Signed real rank 4 | 4.554389 |
| Complex PSD dimension 2 | 4.686562 |

The complex PSD model was worse by 0.083187 bits than the nonnegative model and by 0.132174 bits than the signed real model.

### Operator dimension 3 / classical rank 9

| Model | Held-out bits |
|---|---:|
| Nonnegative rank 9 | 4.519064 |
| Signed real rank 9 | 4.499252 |
| Complex PSD dimension 3 | 4.558810 |

The complex PSD model was worse by 0.039747 bits than the nonnegative model and by 0.059558 bits than the signed real model.

A targeted multi-start check used 10 independent dimension-2 initializations and 6 dimension-3 initializations. Their converged losses were nearly identical, so the result is unlikely to be a simple local-minimum accident.

On shuffled language, all three predictors became almost indistinguishable, as expected when sequence structure is removed.

## Verdict

The experiment gives **weak positive evidence for one necessary ingredient**: grammatical categories expose an interpretable complex predictive mode that arbitrary matched coarse-grainings usually do not.

It gives **negative evidence for the stronger claim** tested here: this POS-level observer does not exhibit an operator/PSD compression advantage. Ordinary signed real low-rank prediction is best, and even a nonnegative mixture beats the complex PSD model.

Thus this sandbox result supports “phase-like grammatical dynamics” but not yet “observer-relative quantumness.” It also warns that noncommuting or oscillatory-looking structure alone is insufficient.

## Important limitations

1. POS syntax is a very shallow observer; semantic frames, ambiguity resolution, discourse reference, and active inference are absent.
2. Static corpus statistics cannot establish contextuality, because all observations are marginals of one global classical string distribution.
3. The PSD-rank calculation is approximate and model-based, not an exact rank computation.
4. The spectral mode is short-lived rather than near-critical.
5. No transformer hidden states or recurrent interpretive dynamics were examined.

The sharper next experiment should use a recurrent or predictive-coding language model on controlled scope, coreference, and garden-path tasks, measure incompatible sequential frame queries before and after interpretive convergence, and jointly test contextual fraction, nonnegative-vs-PSD predictive compression, and latent complex resonances.
