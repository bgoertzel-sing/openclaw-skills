from __future__ import annotations

import copy
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .util import load_jsonl, stable_seed


@dataclass(frozen=True)
class CountTensor:
    train: np.ndarray
    test: np.ndarray
    preparations: list[str]
    contexts: list[str]
    outcomes: list[tuple[int, int]]


def build_count_tensor(run_dir: str | Path, test_modulus: int = 4, test_remainder: int = 0) -> CountTensor:
    records = [record for record in load_jsonl(Path(run_dir) / "records.jsonl") if record.get("complete", False)]
    if not records:
        raise ValueError("No complete records found")
    preparations = sorted({f"{record['task_id']}|{record['condition']}" for record in records})
    contexts = sorted({str(record["context_id"]) for record in records})
    outcomes = [(-1, -1), (-1, 1), (1, -1), (1, 1)]
    p_index = {value: index for index, value in enumerate(preparations)}
    c_index = {value: index for index, value in enumerate(contexts)}
    o_index = {value: index for index, value in enumerate(outcomes)}
    train = np.zeros((len(preparations), len(contexts), 4), dtype=np.float64)
    test = np.zeros_like(train)
    for record in records:
        p = p_index[f"{record['task_id']}|{record['condition']}"]
        c = c_index[str(record["context_id"])]
        outcome = (int(record["first_value"]), int(record["second_value"]))
        o = o_index[outcome]
        repeat = int(record["repeat"])
        target = test if repeat % test_modulus == test_remainder else train
        target[p, c, o] += 1.0
    if train.sum() <= 0 or test.sum() <= 0:
        raise ValueError("Train/test split is empty; use more repeats or alter test_modulus")
    return CountTensor(train=train, test=test, preparations=preparations, contexts=contexts, outcomes=outcomes)


def _require_torch():
    try:
        import torch
        import torch.nn.functional as functional
    except ImportError as exc:
        raise RuntimeError(
            "The compression comparison requires PyTorch. Install with: pip install -e '.[compression]'"
        ) from exc
    return torch, functional


def _parameter_counts(kind: str, p: int, c: int, o: int, rank: int | None, d: int | None) -> tuple[int, int]:
    if kind in {"nmf", "signed"}:
        assert rank is not None
        raw = p * rank + c * o * rank
        return raw, raw
    assert d is not None
    if kind == "real_povm":
        raw = p * d * d + c * o * d * d
        effective = (p + c * o) * d * (d + 1) // 2
        return raw, effective
    if kind == "complex_povm":
        raw = 2 * (p * d * d + c * o * d * d)
        effective = (p + c * o) * d * d
        return raw, effective
    raise ValueError(kind)


def _make_model(kind: str, p: int, c: int, o: int, rank: int | None, d: int | None, seed: int):
    torch, functional = _require_torch()

    class ConditionalModel(torch.nn.Module):
        def __init__(self) -> None:
            super().__init__()
            torch.manual_seed(seed)
            scale = 0.12
            self.kind = kind
            if kind in {"nmf", "signed"}:
                assert rank is not None
                self.u = torch.nn.Parameter(scale * torch.randn(p, rank))
                self.v = torch.nn.Parameter(scale * torch.randn(c, o, rank))
            elif kind == "real_povm":
                assert d is not None
                self.state_factor = torch.nn.Parameter(scale * torch.randn(p, d, d))
                self.effect_factor = torch.nn.Parameter(scale * torch.randn(c, o, d, d))
            elif kind == "complex_povm":
                assert d is not None
                self.state_real = torch.nn.Parameter(scale * torch.randn(p, d, d))
                self.state_imag = torch.nn.Parameter(scale * torch.randn(p, d, d))
                self.effect_real = torch.nn.Parameter(scale * torch.randn(c, o, d, d))
                self.effect_imag = torch.nn.Parameter(scale * torch.randn(c, o, d, d))
            else:
                raise ValueError(kind)

        @staticmethod
        def _inverse_sqrt(matrix):
            eigenvalues, eigenvectors = torch.linalg.eigh(matrix)
            inverse = eigenvalues.clamp_min(1e-6).rsqrt()
            scaled = eigenvectors * inverse.unsqueeze(-2)
            return scaled @ eigenvectors.mH

        def log_probabilities(self):
            if self.kind == "nmf":
                scores = torch.einsum("pr,cor->pco", functional.softplus(self.u), functional.softplus(self.v))
                scores = scores.clamp_min(1e-9)
                return torch.log(scores) - torch.logsumexp(torch.log(scores), dim=-1, keepdim=True)
            if self.kind == "signed":
                logits = torch.einsum("pr,cor->pco", self.u, self.v)
                return functional.log_softmax(logits, dim=-1)

            if self.kind == "real_povm":
                x = self.state_factor
                y = self.effect_factor
            else:
                x = torch.complex(self.state_real, self.state_imag)
                y = torch.complex(self.effect_real, self.effect_imag)

            identity = torch.eye(x.shape[-1], dtype=x.dtype, device=x.device)
            states = x @ x.mH + 1e-5 * identity
            traces = torch.diagonal(states, dim1=-2, dim2=-1).sum(-1).real
            states = states / traces[:, None, None]

            raw_effects = y @ y.mH + 1e-5 * identity
            sums = raw_effects.sum(dim=1)
            inverse_sqrt = self._inverse_sqrt(sums)
            effects = inverse_sqrt[:, None, :, :] @ raw_effects @ inverse_sqrt[:, None, :, :]
            probabilities = torch.einsum("pij,coji->pco", states, effects).real
            probabilities = probabilities.clamp_min(1e-9)
            probabilities = probabilities / probabilities.sum(dim=-1, keepdim=True)
            return torch.log(probabilities)

    return ConditionalModel()


def _fit_once(
    counts: CountTensor,
    *,
    model_label: str,
    kind: str,
    rank: int | None,
    d: int | None,
    seed: int,
    steps: int,
    learning_rate: float,
) -> dict[str, Any]:
    torch, _ = _require_torch()
    torch.set_num_threads(max(1, min(4, torch.get_num_threads())))
    train = torch.tensor(counts.train, dtype=torch.float32)
    test = torch.tensor(counts.test, dtype=torch.float32)
    model = _make_model(kind, *counts.train.shape, rank=rank, d=d, seed=seed)
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    best_loss = math.inf
    best_state = None
    stale = 0
    actual_steps = 0
    for step in range(steps):
        optimizer.zero_grad(set_to_none=True)
        logp = model.log_probabilities()
        loss = -(train * logp).sum() / train.sum()
        regularizer = 1e-7 * sum(parameter.square().mean() for parameter in model.parameters())
        (loss + regularizer).backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=10.0)
        optimizer.step()
        actual_steps = step + 1
        current = float(loss.detach())
        if current < best_loss - 1e-7:
            best_loss = current
            best_state = copy.deepcopy(model.state_dict())
            stale = 0
        else:
            stale += 1
        if step > 300 and stale > 180:
            break
    if best_state is None:
        raise RuntimeError("Optimization produced no valid state")
    model.load_state_dict(best_state)
    with torch.no_grad():
        logp = model.log_probabilities()
        train_bits = float((-(train * logp).sum() / train.sum()) / math.log(2.0))
        test_bits = float((-(test * logp).sum() / test.sum()) / math.log(2.0))
    raw_params, effective_params = _parameter_counts(
        kind, counts.train.shape[0], counts.train.shape[1], counts.train.shape[2], rank, d
    )
    return {
        "model_label": model_label,
        "kind": kind,
        "rank": rank,
        "dimension": d,
        "seed": seed,
        "train_bits_per_pair": train_bits,
        "test_bits_per_pair": test_bits,
        "raw_parameter_count": raw_params,
        "effective_parameter_count_heuristic": effective_params,
        "steps": actual_steps,
    }


def _unconditional_baseline(counts: CountTensor, alpha: float = 0.5) -> float:
    training = counts.train.sum(axis=0) + alpha
    probabilities = training / training.sum(axis=-1, keepdims=True)
    return float(-(counts.test * np.log2(probabilities[None, :, :])).sum() / counts.test.sum())


def run_compression(
    run_dir: str | Path,
    *,
    dimension: int = 2,
    restarts: int = 5,
    steps: int = 1200,
    learning_rate: float = 0.03,
    base_seed: int = 20260812,
) -> Path:
    if dimension < 2:
        raise ValueError("dimension must be at least 2")
    if restarts <= 0:
        raise ValueError("restarts must be positive")
    run_dir = Path(run_dir)
    counts = build_count_tensor(run_dir)
    classical_rank = dimension * dimension
    # A real symmetric d_r x d_r matrix has d_r(d_r+1)/2 real degrees of freedom.
    # Choose the smallest real dimension with at least the d^2 degrees of a complex Hermitian d x d matrix.
    real_matched_dimension = math.ceil((-1.0 + math.sqrt(1.0 + 8.0 * dimension * dimension)) / 2.0)
    specifications = [
        (f"nmf_rank_{classical_rank}", "nmf", classical_rank, None),
        (f"signed_rank_{classical_rank}", "signed", classical_rank, None),
        (f"real_povm_d{dimension}_same_dimension", "real_povm", None, dimension),
        (f"real_povm_d{real_matched_dimension}_matched_or_larger_budget", "real_povm", None, real_matched_dimension),
        (f"complex_povm_d{dimension}", "complex_povm", None, dimension),
    ]
    rows: list[dict[str, Any]] = []
    for model_label, kind, rank, d in specifications:
        for restart in range(restarts):
            seed = stable_seed(base_seed, model_label, dimension, restart)
            print(f"Fitting {model_label}, restart {restart + 1}/{restarts}", flush=True)
            rows.append(
                _fit_once(
                    counts,
                    model_label=model_label,
                    kind=kind,
                    rank=rank,
                    d=d,
                    seed=seed,
                    steps=steps,
                    learning_rate=learning_rate,
                )
            )
    results = pd.DataFrame(rows)
    results["unconditional_test_bits_per_pair"] = _unconditional_baseline(counts)
    results.to_csv(run_dir / f"compression_restarts_d{dimension}.csv", index=False)

    summary = (
        results.groupby(["model_label", "kind", "rank", "dimension"], dropna=False)
        .agg(
            test_bits_mean=("test_bits_per_pair", "mean"),
            test_bits_sd=("test_bits_per_pair", "std"),
            test_bits_best=("test_bits_per_pair", "min"),
            train_bits_mean=("train_bits_per_pair", "mean"),
            raw_parameter_count=("raw_parameter_count", "first"),
            effective_parameter_count_heuristic=("effective_parameter_count_heuristic", "first"),
        )
        .reset_index()
    )
    summary.to_csv(run_dir / f"compression_summary_d{dimension}.csv", index=False)

    fig, axis = plt.subplots(figsize=(11.0, 5.2))
    axis.bar(summary.model_label, summary.test_bits_mean, yerr=summary.test_bits_sd.fillna(0.0), capsize=4)
    axis.axhline(_unconditional_baseline(counts), linestyle="--", linewidth=1.0, label="unconditional baseline")
    axis.set_ylabel("Held-out bits per sequential answer pair")
    axis.set_xlabel("Model family")
    axis.set_title(f"Matched-budget compression comparison (operator dimension {dimension})")
    axis.tick_params(axis="x", rotation=24)
    axis.legend()
    fig.tight_layout()
    fig.savefig(run_dir / f"compression_comparison_d{dimension}.png", dpi=180)
    plt.close(fig)

    print(summary.to_string(index=False))
    return run_dir
