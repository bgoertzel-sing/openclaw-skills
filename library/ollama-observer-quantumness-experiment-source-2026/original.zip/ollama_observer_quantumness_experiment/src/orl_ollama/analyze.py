from __future__ import annotations

import json
import math
from collections import defaultdict
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .metrics import (
    bootstrap_interval,
    cbd_cyclic4,
    empirical_joint,
    jensen_shannon_bits,
    total_variation,
)
from .tasks import load_tasks
from .util import atomic_write_json, binary_entropy, load_jsonl, stable_seed


def _records_frame(run_dir: Path) -> pd.DataFrame:
    records = load_jsonl(run_dir / "records.jsonl")
    if not records:
        raise ValueError(f"No records found in {run_dir / 'records.jsonl'}")
    frame = pd.DataFrame(records)
    required = {
        "task_id",
        "condition",
        "edge_index",
        "direction",
        "canonical_left_value",
        "canonical_right_value",
        "first_value",
        "second_value",
        "repeat",
    }
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"Records are missing fields: {sorted(missing)}")
    frame = frame[frame.get("complete", True).astype(bool)].copy()
    for column in ["canonical_left_value", "canonical_right_value", "first_value", "second_value"]:
        frame[column] = frame[column].astype(int)
    return frame


def _bootstrap_swap(
    forward_pairs: list[tuple[int, int]],
    reverse_pairs: list[tuple[int, int]],
    *,
    samples: int,
    seed: int,
    alpha: float,
) -> tuple[tuple[float, float], tuple[float, float]]:
    if samples <= 0 or not forward_pairs or not reverse_pairs:
        return (math.nan, math.nan), (math.nan, math.nan)
    rng = np.random.default_rng(seed)
    tv_values: list[float] = []
    js_values: list[float] = []
    for _ in range(samples):
        f = [forward_pairs[i] for i in rng.integers(0, len(forward_pairs), len(forward_pairs))]
        r = [reverse_pairs[i] for i in rng.integers(0, len(reverse_pairs), len(reverse_pairs))]
        pf = empirical_joint(f, alpha=alpha)
        pr = empirical_joint(r, alpha=alpha)
        tv_values.append(total_variation(pf, pr))
        js_values.append(jensen_shannon_bits(pf, pr))
    return bootstrap_interval(tv_values), bootstrap_interval(js_values)


def compute_swap_table(frame: pd.DataFrame, bootstrap: int, base_seed: int, alpha: float) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    group_columns = ["task_id", "family", "condition", "edge_index", "canonical_edge_id"]
    for keys, group in frame.groupby(group_columns, dropna=False):
        task_id, family, condition, edge_index, canonical_edge_id = keys
        forward = group[group.direction == "forward"]
        reverse = group[group.direction == "reverse"]
        if forward.empty or reverse.empty:
            continue
        forward_pairs = list(zip(forward.canonical_left_value.astype(int), forward.canonical_right_value.astype(int)))
        # The runner has already stored reverse trials in canonical left/right order.
        reverse_pairs = list(zip(reverse.canonical_left_value.astype(int), reverse.canonical_right_value.astype(int)))
        pf = empirical_joint(forward_pairs, alpha=alpha)
        pr = empirical_joint(reverse_pairs, alpha=alpha)
        tv = total_variation(pf, pr)
        js = jensen_shannon_bits(pf, pr)
        tv_ci, js_ci = _bootstrap_swap(
            forward_pairs,
            reverse_pairs,
            samples=bootstrap,
            seed=stable_seed(base_seed, task_id, condition, edge_index, "swap_bootstrap"),
            alpha=alpha,
        )
        rows.append(
            {
                "task_id": task_id,
                "family": family,
                "condition": condition,
                "edge_index": int(edge_index),
                "canonical_edge_id": canonical_edge_id,
                "n_forward": len(forward_pairs),
                "n_reverse": len(reverse_pairs),
                "swap_tv": tv,
                "swap_tv_ci_low": tv_ci[0],
                "swap_tv_ci_high": tv_ci[1],
                "swap_js_bits": js,
                "swap_js_ci_low": js_ci[0],
                "swap_js_ci_high": js_ci[1],
                "forward_distribution": json.dumps(pf.tolist()),
                "reverse_distribution": json.dumps(pr.tolist()),
            }
        )
    return pd.DataFrame(rows)


def _bootstrap_cbd(contexts: list[list[tuple[int, int]]], samples: int, seed: int) -> dict[str, tuple[float, float]]:
    if samples <= 0:
        return {}
    rng = np.random.default_rng(seed)
    collected: dict[str, list[float]] = defaultdict(list)
    for _ in range(samples):
        resampled = [
            [pairs[index] for index in rng.integers(0, len(pairs), len(pairs))]
            for pairs in contexts
        ]
        result = cbd_cyclic4(resampled)
        collected["s_odd"].append(result.s_odd_value)
        collected["icc"].append(result.inconsistent_connectedness)
        collected["raw_excess"].append(result.raw_excess)
        collected["contextuality_measure"].append(result.contextuality_measure)
    return {key: bootstrap_interval(values) for key, values in collected.items()}


def compute_cbd_table(frame: pd.DataFrame, bootstrap: int, base_seed: int) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    canonical = frame[frame.direction == "forward"]
    for keys, group in canonical.groupby(["task_id", "family", "condition"], dropna=False):
        task_id, family, condition = keys
        contexts: list[list[tuple[int, int]]] = []
        complete = True
        for edge_index in range(4):
            edge = group[group.edge_index == edge_index]
            pairs = list(zip(edge.canonical_left_value.astype(int), edge.canonical_right_value.astype(int)))
            if not pairs:
                complete = False
                break
            contexts.append(pairs)
        if not complete:
            continue
        result = cbd_cyclic4(contexts)
        ci = _bootstrap_cbd(
            contexts,
            samples=bootstrap,
            seed=stable_seed(base_seed, task_id, condition, "cbd_bootstrap"),
        )
        rows.append(
            {
                "task_id": task_id,
                "family": family,
                "condition": condition,
                "n_per_context_min": min(len(context) for context in contexts),
                "correlations": json.dumps(result.correlations),
                "content_means": json.dumps(result.content_means),
                "s_odd": result.s_odd_value,
                "s_odd_ci_low": ci.get("s_odd", (math.nan, math.nan))[0],
                "s_odd_ci_high": ci.get("s_odd", (math.nan, math.nan))[1],
                "inconsistent_connectedness": result.inconsistent_connectedness,
                "icc_ci_low": ci.get("icc", (math.nan, math.nan))[0],
                "icc_ci_high": ci.get("icc", (math.nan, math.nan))[1],
                "noncontextual_bound": result.noncontextual_bound,
                "raw_contextuality_excess": result.raw_excess,
                "raw_excess_ci_low": ci.get("raw_excess", (math.nan, math.nan))[0],
                "raw_excess_ci_high": ci.get("raw_excess", (math.nan, math.nan))[1],
                "cbd_contextuality_measure": result.contextuality_measure,
                "cbd_measure_ci_low": ci.get("contextuality_measure", (math.nan, math.nan))[0],
                "cbd_measure_ci_high": ci.get("contextuality_measure", (math.nan, math.nan))[1],
            }
        )
    return pd.DataFrame(rows)


def compute_choice_entropy(frame: pd.DataFrame) -> pd.DataFrame:
    long_rows: list[dict[str, Any]] = []
    for _, row in frame.iterrows():
        long_rows.append(
            {
                "task_id": row.task_id,
                "family": row.family,
                "condition": row.condition,
                "question_id": row.first_question_id,
                "value": int(row.first_value),
                "position": "first",
            }
        )
        long_rows.append(
            {
                "task_id": row.task_id,
                "family": row.family,
                "condition": row.condition,
                "question_id": row.second_question_id,
                "value": int(row.second_value),
                "position": "second",
            }
        )
    long = pd.DataFrame(long_rows)
    result: list[dict[str, Any]] = []
    for keys, group in long.groupby(["task_id", "family", "condition", "question_id"]):
        task_id, family, condition, question_id = keys
        p_positive = float((group.value == 1).mean())
        result.append(
            {
                "task_id": task_id,
                "family": family,
                "condition": condition,
                "question_id": question_id,
                "n": len(group),
                "p_positive": p_positive,
                "binary_entropy_bits": binary_entropy(p_positive),
                "first_position_p_positive": float((group[group.position == "first"].value == 1).mean()),
                "second_position_p_positive": float((group[group.position == "second"].value == 1).mean()),
            }
        )
    return pd.DataFrame(result)




def compute_resolved_accuracy(frame: pd.DataFrame, task_snapshot: Path) -> pd.DataFrame:
    if not task_snapshot.exists():
        return pd.DataFrame()
    tasks = load_tasks(task_snapshot)
    expected = {
        (task.id, question.id): question.resolved_expected
        for task in tasks
        for question in task.questions
        if question.resolved_expected is not None
    }
    rows: list[dict[str, Any]] = []
    resolved = frame[frame.condition == "resolved"]
    for _, row in resolved.iterrows():
        for position in ("first", "second"):
            question_id = str(row[f"{position}_question_id"])
            key = (str(row.task_id), question_id)
            if key not in expected:
                continue
            value = int(row[f"{position}_value"])
            rows.append(
                {
                    "task_id": row.task_id,
                    "family": row.family,
                    "question_id": question_id,
                    "position": position,
                    "value": value,
                    "expected_value": int(expected[key]),
                    "correct": value == int(expected[key]),
                }
            )
    if not rows:
        return pd.DataFrame()
    raw = pd.DataFrame(rows)
    return (
        raw.groupby(["task_id", "family", "question_id"], dropna=False)
        .correct.agg(["count", "mean"])
        .reset_index()
        .rename(columns={"mean": "resolved_agreement_rate"})
    )

def compute_run_diagnostics(frame: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    counts = (
        frame.groupby(["task_id", "family", "condition", "edge_index", "direction"], dropna=False)
        .size()
        .rename("complete_trials")
        .reset_index()
    )

    parse_rows: list[dict[str, Any]] = []
    for position, column in [("first", "first_response"), ("second", "second_response")]:
        if column not in frame:
            continue
        for value in frame[column]:
            if isinstance(value, dict):
                parse_rows.append(
                    {
                        "position": position,
                        "parse_method": value.get("parse_method", "unknown"),
                    }
                )
    parse_frame = pd.DataFrame(parse_rows)
    if not parse_frame.empty:
        parse_frame = (
            parse_frame.groupby(["position", "parse_method"], dropna=False)
            .size()
            .rename("count")
            .reset_index()
        )

    label_rows: list[dict[str, Any]] = []
    for position, column in [("first", "first_label_values"), ("second", "second_label_values")]:
        if column not in frame:
            continue
        for value in frame[column]:
            if isinstance(value, dict) and "A" in value:
                label_rows.append(
                    {
                        "position": position,
                        "positive_assigned_to_A": int(value["A"]) == 1,
                    }
                )
    label_frame = pd.DataFrame(label_rows)
    if not label_frame.empty:
        label_frame = (
            label_frame.groupby("position", dropna=False)
            .positive_assigned_to_A.agg(["count", "mean"])
            .reset_index()
            .rename(columns={"mean": "fraction_positive_assigned_to_A"})
        )
    return counts, parse_frame, label_frame

def _plot_condition_means(table: pd.DataFrame, value: str, ylabel: str, path: Path) -> None:
    if table.empty or value not in table:
        return
    grouped = table.groupby("condition")[value].agg(["mean", "sem"]).reset_index()
    fig, axis = plt.subplots(figsize=(7.2, 4.6))
    axis.bar(grouped["condition"], grouped["mean"], yerr=grouped["sem"], capsize=4)
    axis.set_ylabel(ylabel)
    axis.set_xlabel("Condition")
    axis.set_title(ylabel + " by ambiguity condition")
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def _write_summary(
    run_dir: Path,
    frame: pd.DataFrame,
    swap: pd.DataFrame,
    cbd: pd.DataFrame,
    entropy: pd.DataFrame,
    trial_counts: pd.DataFrame,
    parse_methods: pd.DataFrame,
    label_balance: pd.DataFrame,
    resolved_accuracy: pd.DataFrame,
) -> None:
    lines: list[str] = [
        "# Ollama observer-relative operator-linguistics analysis",
        "",
        "## What this run can and cannot establish",
        "",
        "This black-box experiment tests observable sequential judgments. It can detect query-order disturbance,",
        "whether that disturbance decreases after disambiguating evidence, and whether a cyclic-4 Contextuality-by-Default",
        "criterion shows residual contextuality after marginal/direct influences are included in the bound.",
        "It does not inspect hidden activations and therefore does not test internal complex resonances or causal circuits.",
        "A positive CbD result is a candidate property of the context-indexed behavior, not evidence of a physically quantum substrate.",
        "",
        "## Run size and validity",
        "",
        f"- Complete paired trials: {len(frame)}",
        f"- Tasks: {frame.task_id.nunique()}",
        f"- Conditions: {', '.join(sorted(frame.condition.unique()))}",
    ]
    errors_path = run_dir / "errors.jsonl"
    error_count = len(load_jsonl(errors_path)) if errors_path.exists() else 0
    lines.append(f"- Failed trials logged: {error_count}")
    if not trial_counts.empty:
        expected_directions = 2 if set(frame.direction.unique()) >= {"forward", "reverse"} else 1
        expected_cells = frame.task_id.nunique() * frame.condition.nunique() * 4 * expected_directions
        observed_cells = len(trial_counts)
        lines.append(f"- Observed task/condition/edge/direction cells: {observed_cells}/{expected_cells}")
        if observed_cells < expected_cells:
            lines.append("- Warning: some contexts are missing; affected swap or CbD rows are omitted rather than imputed.")
    if not label_balance.empty:
        for row in label_balance.itertuples(index=False):
            lines.append(
                f"- Positive interpretation assigned to label A ({row.position} question): "
                f"{row.fraction_positive_assigned_to_A:.3f}"
            )
    if not parse_methods.empty:
        fallback = int(parse_methods.loc[parse_methods.parse_method != "json", "count"].sum())
        total_parsed = int(parse_methods["count"].sum())
        lines.append(f"- Non-JSON fallback parses: {fallback}/{total_parsed}")
    if not resolved_accuracy.empty:
        lines.append(
            f"- Mean agreement with explicit resolved-condition answers: "
            f"{resolved_accuracy.resolved_agreement_rate.mean():.3f}"
        )

    if not swap.empty:
        condition_swap = swap.groupby("condition").swap_tv.mean().to_dict()
        lines.extend(["", "## Query-order / swap defect", ""])
        for condition, value in sorted(condition_swap.items()):
            lines.append(f"- Mean total-variation swap defect, {condition}: {value:.4f}")
        if {"ambiguous", "resolved"}.issubset(condition_swap):
            difference = condition_swap["ambiguous"] - condition_swap["resolved"]
            lines.append(f"- Ambiguous minus resolved mean swap defect: {difference:.4f}")
            if difference > 0:
                lines.append("- Directional reading: consistent with stronger pre-confluence order sensitivity.")
            else:
                lines.append("- Directional reading: does not support the predicted pre-confluence ordering effect.")

    if not cbd.empty:
        lines.extend(["", "## Contextuality-by-Default screen", ""])
        for condition, group in cbd.groupby("condition"):
            positive = int((group.raw_contextuality_excess > 0).sum())
            robust = int((group.raw_excess_ci_low > 0).sum())
            lines.append(
                f"- {condition}: {positive}/{len(group)} tasks have positive point-estimate excess; "
                f"{robust}/{len(group)} have a bootstrap lower bound above zero."
            )
        lines.append(
            "- Interpret positive point estimates cautiously when repeats are small: max-type inequalities are upward-biased in finite samples."
        )

    if not entropy.empty:
        ent = entropy.groupby("condition").binary_entropy_bits.mean().to_dict()
        lines.extend(["", "## Choice entropy", ""])
        for condition, value in sorted(ent.items()):
            lines.append(f"- Mean empirical binary entropy, {condition}: {value:.4f} bits")

    lines.extend(
        [
            "",
            "## Evidence ladder",
            "",
            "1. Higher ambiguous-condition entropy means the task manipulation created unresolved interpretation.",
            "2. Higher ambiguous-condition swap defect means sequential framing changes judgments before resolution.",
            "3. Positive CbD excess means pairwise behavior is not explained by direct marginal shifts alone under the cyclic-4 criterion.",
            "4. A held-out complex-POVM compression win over nonnegative, signed-real, and real-POVM baselines is required before calling the behavior operator-compressible.",
            "5. Hidden-state access is still required to test whether internal dynamics carry long-lived complex resonances.",
            "",
            "The `compress` command performs step 4. Steps 1-3 alone do not establish observer-relative quantumness.",
        ]
    )
    (run_dir / "analysis_summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def analyze_run(run_dir: str | Path, bootstrap: int = 1000, base_seed: int = 481516, alpha: float = 0.5) -> Path:
    run_dir = Path(run_dir)
    frame = _records_frame(run_dir)
    swap = compute_swap_table(frame, bootstrap=bootstrap, base_seed=base_seed, alpha=alpha)
    cbd = compute_cbd_table(frame, bootstrap=bootstrap, base_seed=base_seed)
    entropy = compute_choice_entropy(frame)
    trial_counts, parse_methods, label_balance = compute_run_diagnostics(frame)
    resolved_accuracy = compute_resolved_accuracy(frame, run_dir / "tasks_snapshot.json")

    swap.to_csv(run_dir / "swap_defects.csv", index=False)
    cbd.to_csv(run_dir / "cbd_contextuality.csv", index=False)
    entropy.to_csv(run_dir / "choice_entropy.csv", index=False)
    trial_counts.to_csv(run_dir / "trial_counts.csv", index=False)
    parse_methods.to_csv(run_dir / "parse_methods.csv", index=False)
    label_balance.to_csv(run_dir / "label_randomization_balance.csv", index=False)
    resolved_accuracy.to_csv(run_dir / "resolved_accuracy.csv", index=False)

    _plot_condition_means(swap, "swap_tv", "Mean swap defect (total variation)", run_dir / "swap_defect_by_condition.png")
    _plot_condition_means(
        cbd,
        "raw_contextuality_excess",
        "CbD raw contextuality excess",
        run_dir / "contextuality_by_condition.png",
    )
    _plot_condition_means(
        entropy,
        "binary_entropy_bits",
        "Empirical binary choice entropy (bits)",
        run_dir / "choice_entropy_by_condition.png",
    )
    _write_summary(
        run_dir,
        frame,
        swap,
        cbd,
        entropy,
        trial_counts,
        parse_methods,
        label_balance,
        resolved_accuracy,
    )

    aggregate = {
        "records": len(frame),
        "tasks": int(frame.task_id.nunique()),
        "mean_swap_by_condition": swap.groupby("condition").swap_tv.mean().to_dict() if not swap.empty else {},
        "mean_cbd_excess_by_condition": cbd.groupby("condition").raw_contextuality_excess.mean().to_dict() if not cbd.empty else {},
        "mean_entropy_by_condition": entropy.groupby("condition").binary_entropy_bits.mean().to_dict() if not entropy.empty else {},
    }
    atomic_write_json(run_dir / "analysis_aggregate.json", aggregate)
    print((run_dir / "analysis_summary.md").read_text(encoding="utf-8"))
    return run_dir
