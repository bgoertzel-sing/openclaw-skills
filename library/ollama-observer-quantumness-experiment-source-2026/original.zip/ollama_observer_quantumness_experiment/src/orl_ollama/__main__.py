from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

from .analyze import analyze_run
from .client import OllamaClient, OllamaError
from .compression import run_compression
from .runner import RunConfig, run_experiment
from .tasks import load_tasks


def _parse_think(value: str | None):
    if value is None or value == "omit":
        return None
    if value == "true":
        return True
    if value == "false":
        return False
    if value in {"low", "medium", "high", "max"}:
        return value
    raise argparse.ArgumentTypeError("think must be omit, true, false, low, medium, high, or max")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="orl-ollama",
        description="Behavioral observer-relative operator-linguistics tests over a local Ollama model.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    check = subparsers.add_parser("check", help="Check the Ollama server and list local models")
    check.add_argument("--host", default="http://localhost:11434")
    check.add_argument("--model")
    check.add_argument("--timeout", type=float, default=30.0)

    preview = subparsers.add_parser("preview", help="Validate tasks and write example prompts without model calls")
    preview.add_argument("--tasks", default="tasks/default_tasks.json")
    preview.add_argument("--output", default="runs/prompt_preview")
    preview.add_argument("--model", default="DRY_RUN_MODEL")

    run = subparsers.add_parser("run", help="Run sequential paired-query trials")
    run.add_argument("--model", required=True)
    run.add_argument("--host", default="http://localhost:11434")
    run.add_argument("--tasks", default="tasks/default_tasks.json")
    run.add_argument("--output")
    run.add_argument("--repeats", type=int, default=8)
    run.add_argument("--conditions", nargs="+", choices=["ambiguous", "resolved"], default=["ambiguous", "resolved"])
    run.add_argument("--directions", choices=["both", "canonical"], default="both")
    run.add_argument("--task-id", action="append", default=[])
    run.add_argument("--base-seed", type=int, default=20260812)
    run.add_argument("--temperature", type=float, default=0.85)
    run.add_argument("--top-p", type=float, default=0.95)
    run.add_argument("--num-predict", type=int, default=24)
    run.add_argument("--keep-alive", default="10m")
    run.add_argument("--timeout", type=float, default=120.0)
    run.add_argument("--retries", type=int, default=2)
    run.add_argument("--think", default="omit", choices=["omit", "true", "false", "low", "medium", "high", "max"])
    run.add_argument("--save-full-response", action="store_true")
    run.add_argument("--max-trials", type=int)
    run.add_argument("--analyze", action="store_true")
    run.add_argument("--bootstrap", type=int, default=1000)

    analyze = subparsers.add_parser("analyze", help="Analyze a completed or partial run")
    analyze.add_argument("--run-dir", required=True)
    analyze.add_argument("--bootstrap", type=int, default=1000)
    analyze.add_argument("--seed", type=int, default=481516)
    analyze.add_argument("--smoothing", type=float, default=0.5)

    compress = subparsers.add_parser("compress", help="Fit classical, real-operator, and complex-operator models")
    compress.add_argument("--run-dir", required=True)
    compress.add_argument("--dimension", type=int, default=2)
    compress.add_argument("--restarts", type=int, default=5)
    compress.add_argument("--steps", type=int, default=1200)
    compress.add_argument("--learning-rate", type=float, default=0.03)
    compress.add_argument("--seed", type=int, default=20260812)

    self_test = subparsers.add_parser("self-test", help="Run metric sanity checks without Ollama")
    return parser


def _default_output(model: str) -> str:
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    safe_model = "".join(character if character.isalnum() or character in "-_" else "_" for character in model)
    return f"runs/{timestamp}_{safe_model}"


def _run_self_test() -> int:
    from .metrics import cbd_cyclic4, s_odd

    noncontextual = [[(1, 1)] * 20, [(1, 1)] * 20, [(1, 1)] * 20, [(1, 1)] * 20]
    balanced_same = [(1, 1)] * 10 + [(-1, -1)] * 10
    balanced_opposite = [(1, -1)] * 10 + [(-1, 1)] * 10
    contextual = [balanced_same, balanced_same, balanced_same, balanced_opposite]
    left = cbd_cyclic4(noncontextual)
    right = cbd_cyclic4(contextual)
    assert abs(left.raw_excess) < 1e-12
    assert abs(right.raw_excess - 2.0) < 1e-12
    assert abs(s_odd([1, 1, 1, -1]) - 4.0) < 1e-12
    print(json.dumps({"noncontextual": left.__dict__, "contextual": right.__dict__}, indent=2))
    print("Self-test passed")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.command == "check":
            client = OllamaClient(args.host, timeout_seconds=args.timeout)
            payload = {"version": client.version(), "models": client.available_models()}
            if args.model:
                client.ensure_model(args.model)
                payload["selected_model"] = args.model
            print(json.dumps(payload, indent=2))
            return 0

        if args.command == "preview":
            load_tasks(args.tasks)
            config = RunConfig(model=args.model, host="http://localhost:11434", tasks_path=args.tasks, max_trials=3)
            run_experiment(config, args.output, dry_run=True)
            print(f"Wrote prompt preview to {Path(args.output) / 'dry_run_prompt_preview.json'}")
            return 0

        if args.command == "run":
            output = args.output or _default_output(args.model)
            config = RunConfig(
                model=args.model,
                host=args.host,
                tasks_path=args.tasks,
                repeats=args.repeats,
                conditions=tuple(args.conditions),
                directions=args.directions,
                base_seed=args.base_seed,
                temperature=args.temperature,
                top_p=args.top_p,
                num_predict=args.num_predict,
                keep_alive=args.keep_alive,
                timeout_seconds=args.timeout,
                retries=args.retries,
                think=_parse_think(args.think),
                save_full_response=args.save_full_response,
                selected_task_ids=tuple(args.task_id),
                max_trials=args.max_trials,
            )
            run_experiment(config, output)
            if args.analyze:
                analyze_run(output, bootstrap=args.bootstrap)
            return 0

        if args.command == "analyze":
            analyze_run(args.run_dir, bootstrap=args.bootstrap, base_seed=args.seed, alpha=args.smoothing)
            return 0

        if args.command == "compress":
            run_compression(
                args.run_dir,
                dimension=args.dimension,
                restarts=args.restarts,
                steps=args.steps,
                learning_rate=args.learning_rate,
                base_seed=args.seed,
            )
            return 0

        if args.command == "self-test":
            return _run_self_test()
    except (OllamaError, ValueError, RuntimeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    parser.error("Unknown command")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
