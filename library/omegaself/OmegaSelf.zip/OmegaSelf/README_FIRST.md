# OmegaSelf delivery

**First public edition**

OmegaSelf is an evidence-grounded, continuously tested self-theory and governance
layer for OmegaClaw systems using Hyperon, MeTTa/PeTTa, and PLN-style uncertain
reasoning.

## Start here

1. Read `OmegaSelf_Architecture_and_Deployment_Guide.pdf` for the motivation,
   underlying theory, technical architecture, deployment plan, and coding-agent
   appendix.
2. Read `OmegaSelf_Concise_Design_Proposal.md` for a compact design overview.
3. Read `OMEGASELF_CORE_REQUIREMENTS.md` for the normative implementation
   boundaries.
4. Enter `omegaself-coding-agent-pack/` and read `README.md`, `AGENTS.md`,
   `SKILL.md`, and `OMEGASELF_CODING_AGENT_QUICKSTART.md`.
5. Run `./scripts/smoke_test.sh` before changing a target repository.

## Core requirements embodied in this package

- Evidence is append-only; staleness changes a derived applicability view rather
  than deleting or rewriting history.
- Context transfer preserves original evidence identities and deduplicates them
  before dependence-aware revision.
- Patham9 PLN and OmegaPLN sit behind a typed, substrate-neutral `SelfReasoner`
  interface.
- Concrete NAL/PLN cases are golden regression fixtures rather than the
  production reasoning API.
- Governance consumes normalized operational estimates while preserving raw
  backend truth values and explicit semantics identifiers for audit.
- Only an externally verified, signed policy manifest can configure an
  allow-capable gate.
- Continuity caches are advisory; high-impact mutation requires a valid
  exact-input authorization-grade certificate or fails closed.
- `SelfHereNow` is resolved from renewable live causal control, not copied
  history, display names, provenance records, or secrets alone.
- Forks create branching continuity, and counterfactual spaces cannot license
  live action.

## Validation status

The coding pack includes 21 Draft 2020-12 JSON Schemas and 44 passing Python unit
tests. Its SHA-256 manifest covers every packaged coding-agent file except the
manifest itself. The reference HMAC verifier is test-only; production deployments
must use an asymmetric, hardware-rooted, or remote verifier whose signing key is
unavailable to the agent process. The MeTTa files are version-sensitive
integration scaffolding and must be tested against the pinned OmegaClaw/Hyperon
runtime.
