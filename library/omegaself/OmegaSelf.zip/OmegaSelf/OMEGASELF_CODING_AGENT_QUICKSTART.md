# OmegaSelf coding-agent quick start

## Objective

Insert an evidence-grounded, substrate-neutral, externally governed proposal gate
into OmegaClaw without changing behavior until shadow-mode evidence is collected.

## First fifteen tasks

1. Record the target OmegaClaw/Hyperon commit, Python version, reasoner backend,
   truth-semantics profile, and active policy hash.
2. Run `./scripts/smoke_test.sh` on this pack unchanged.
3. Install `python/omegaself` and import `omegaself_bridge.py`.
4. Add record-only observations for cycle start, parsed calls, receipts, errors,
   policy loads, and reasoner invocations.
5. Verify the ledger on startup and expose its root hash to logs.
6. Implement closure traversal, correction/disqualification events, and dependence groups.
7. Implement renewable `SelfHereNow` using at least one live causal-control binding.
8. Introduce `SelfReasoner`; bind the current Patham9 implementation through one adapter.
9. Add golden NAL tests plus provenance, dependence, and calibration tests.
10. Define exact context keys, context transfers, and evidence-identity deduplication.
11. Add freshness profiles and append-only applicability assessments.
12. Verify a signed policy manifest through an external trust root; do not let the
    agent process hold the signing key.
13. Convert parsed skill expressions into proposals and commit predictions before execution.
14. Enable capability-aware dispatch only for low-impact read-only actions.
15. Add exact-input continuity certificates; a high-impact cache miss must return
    `RequireReview` or `Defer`. Shadow OmegaPLN before a governed backend migration.

## Never do these

- delete old evidence because it is stale;
- count one event again through several contexts;
- make raw STV strength/confidence the policy interface;
- let a reasoner or cache return `Allow`;
- use an unsigned or agent-self-signed policy manifest;
- authorize high-impact mutation from cache miss, heuristic, or budget exhaustion;
- treat copied provenance or a secret as current ownership;
- collapse forked lineage;
- allow non-`Allow` decisions to reach `eval`;
- promote a simulated capability into live belief without a real event.

## Completion evidence for every PR

- commands and test output;
- schema, context, rule, backend, semantics, policy, and calibration versions;
- ledger/snapshot root;
- policy signature verification result;
- replay and evidence-deduplication result;
- feature flag and rollback;
- action behavior delta;
- named consumer for each alert;
- one end-to-end explanation from evidence to policy decision.
