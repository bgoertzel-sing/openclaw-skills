# OmegaSelf core technical requirements

This document states the implementation requirements that define the package. It is
normative for coding agents and reviewers.

## Evidence preservation and applicability

Evidence is append-only. Age, context mismatch, handler changes, provider changes,
or regime changes never delete or rewrite an observation. They create a new,
time- and context-indexed `ApplicabilityAssessment` that governs present use.
Corrections and disqualifications are also new ledger events.

The system must deduplicate original evidence identities across context inheritance,
analogy, and dependence groups. One observation must never acquire additional
weight merely because it is reachable through several derivation paths.

## Substrate-neutral reasoning boundary

Production code calls the typed `SelfReasoner` interface. Patham9 PLN and OmegaPLN
are adapters behind that interface. Backend-specific truth values remain available
for audit, while governance consumes a normalized `OperationalEstimate` with an
explicit truth-semantics identifier, evidence closure, support quality, calibration
profile, and completeness status.

Concrete NAL and PLN examples are migration and regression fixtures. They do not
constitute the production interface. A backend migration requires shadow replay,
semantic and provenance checks, calibration comparison, policy-decision
differentials, an authorized self-transport, and rollback.

## Externally rooted governance

A reasoner, cache, LLM, or self-belief may estimate and propose, but may not issue
a live action license. Only a separately authorized policy consumer may return
`Allow`.

An allow-capable gate must be configured by a signed, immutable, versioned policy
manifest verified against a trust root unavailable to the agent-controlled
revision loop. Unsigned, expired, revoked, wrong-issuer, hash-mismatched, or
wrong-semantics manifests fail closed.

## Continuity certificates and cache semantics

Continuity caches are advisory accelerators. High-impact or irreversible mutations
require an authorization-grade result bound to the exact source snapshot,
proposal, predicted target, evidence snapshot, policy manifest, protected
invariants, ontology, reasoner backend, and truth semantics.

`CacheMiss`, `Heuristic`, `Incomplete`, `BudgetExhausted`, `Expired`, `Invalid`, or
unsupported results cannot authorize a high-impact mutation. They must lead the
policy consumer to `RequireReview`, `Defer`, or `Deny`. A conservative finite-core
certificate may support authorization only for a mutation class and invariant set
for which its soundness claim is explicit and verified.

## Runtime indexical grounding

`SelfHereNow` is resolved from renewable evidence of current causal control:
authenticated runtime identity, process/workspace boundary, controlled capability
leases, active session bindings, lineage head, and current causal provenance.
Copied history, copied provenance records, a display name, or possession of a
copied secret is insufficient. Forks create distinct present anchors and branching
continuity.

## Operational completeness

Every high-severity tripwire has a named consumer. Every selected execution path
passes through the proposal gate. Counterfactual records cannot satisfy live
evidence queries. Every consequential decision is replayable from immutable
records and versioned semantics.
