# License note

The reference code and documentation in this pack are supplied as an original
MIT-style implementation scaffold. No warranty is provided. The pack does not
include or redistribute OmegaClaw source. Before copying files into a target
repository, confirm license compatibility and preserve any notices required by
that repository and its dependencies.
