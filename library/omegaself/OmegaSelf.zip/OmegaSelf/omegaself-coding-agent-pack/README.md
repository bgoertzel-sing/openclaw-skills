# OmegaSelf coding-agent pack

**First public edition — package version 1.0.0**

This pack turns the OmegaSelf architecture into implementation collateral for an
OmegaClaw/PeTTa/MeTTa repository. The self-model is treated as a continuously
tested, evidence-grounded theory about the currently acting system—not as a
privileged ego atom, authoritative autobiography, or direct source of permission.

## What is included

- a dependency-free Python reference runtime for:
  - append-only hash-chained evidence;
  - complete evidence closures and dependence groups;
  - renewable `SelfHereNow` attestation;
  - time/context/regime-indexed evidence applicability;
  - evidence-preserving context transfer;
  - a substrate-neutral Patham9/OmegaPLN reasoner boundary;
  - normalized operational capability estimates;
  - signed policy-manifest verification;
  - exact-input continuity certificates and advisory caches;
  - prediction scoring and a fail-closed proposal gate;
- JSON Schemas for the principal records;
- MeTTa-shaped integration scaffolding for the OmegaClaw pre-`eval` seam;
- ADRs, architecture, phased implementation plan, threat model, test strategy,
  traceability matrix, and adversarial scenarios;
- executable demonstrations and a validation script.

## Important status distinction

The Python package under `python/` is runnable and unit-tested. The files under
`omegaclaw/src/self_model/` are **version-sensitive integration scaffolding**.
They are not a claim of a tested drop-in patch for every PeTTa/Hyperon revision.
A coding agent must pin the target repository and interpreter, preserve local
conventions, and run the supplied contract and adversarial tests.

The HMAC signature code is **test-only**. Production policy and continuity
certificates require an asymmetric, hardware-rooted, or remote verifier whose
signing key is unavailable to the agent process.

## Fast start

```bash
cd omegaself-coding-agent-pack
./scripts/smoke_test.sh
```

The smoke test runs the Python suite, generates and verifies a sample ledger, and
executes demonstrations of:

- correlated provider outcomes;
- staleness without forgetting;
- context-transfer evidence deduplication;
- Patham9-to-OmegaPLN adapter migration;
- policy-differential decisions;
- fail-closed continuity cache misses.

## Core architecture requirements

### Staleness is not forgetting

Evidence remains immutable. Freshness, context mismatch, or version change creates
a new `ApplicabilityAssessment`. The original event and ledger root are preserved.

### Cache miss fails closed

For a high-impact mutation, `CacheMiss`, `Heuristic`, `Incomplete`,
`BudgetExhausted`, `Expired`, or `Invalid` continuity status cannot yield `Allow`.
Only an exact-input `Verified` or policy-accepted `ConservativeSafe` certificate
can pass the continuity stage.

### Reasoning stays substrate-neutral

Production code calls `SelfReasoner`. Patham9 PLN and OmegaPLN are adapters.
NAL-specific examples are golden regression tests, not the production interface.
Raw STVs remain available for audit, while governance consumes a normalized
`OperationalEstimate` with explicit semantics, bounds, support, calibration, and
provenance.

### Governance is externally rooted

The gate defaults to unverified and therefore cannot emit `Allow`. It must be
configured from a signed, versioned policy manifest verified against a trust root
outside the agent-controlled revision loop.

### Context transfer preserves evidence identity

Context generalization uses a typed graph. Original evidence IDs survive every
transfer and are deduplicated before revision, so one observation cannot be
counted again through several inheritance paths.

## Recommended integration order

1. Pin the target OmegaClaw/Hyperon commit and runtime versions.
2. Run the reference validation unchanged.
3. Add the ledger in record-only mode and verify it on startup.
4. Add complete closures, dependence groups, corrections, and disqualifications.
5. Add renewable `SelfHereNow` resolution.
6. Introduce the `SelfReasoner` interface and bind the current Patham9 backend.
7. Add golden NAL, semantic, provenance, and calibration tests.
8. Add exact context keys, transfer rules, and applicability views.
9. Load and externally verify the signed policy manifest.
10. Convert parsed skill expressions into typed proposals before `eval`.
11. Commit predictions before action and append receipts afterward.
12. Enable capability dispatch for low-impact read-only actions first.
13. Add commitment conflict handling.
14. Add continuity certificates and the fail-closed mutation gate.
15. Shadow the OmegaPLN adapter, compare decisions/calibration, then perform a
    governed reasoner self-transport with rollback.

Read `AGENTS.md`, `SKILL.md`, `docs/ARCHITECTURE.md`, and
`docs/IMPLEMENTATION_PLAN.md` before editing a target repository.

## Non-negotiable invariants

- No consequential self-belief without inspectable evidence closure.
- No destructive overwrite or time-based deletion of evidence.
- A stale record may lose current applicability but remains historical evidence.
- One evidence event is counted once across dependence and context-transfer paths.
- Installed, reachable, authorized, and effective remain distinct predicates.
- The reasoner estimates; it never returns an action license.
- Only an externally verified policy consumer can return `Allow`.
- Continuity cache state is advisory unless backed by a valid exact-input certificate.
- `SelfHereNow` requires renewable live causal control.
- Forks create branching continuity.
- Counterfactual spaces cannot directly assert live facts.
- Every high-severity detector has a named consumer.

## Key files

```text
AGENTS.md
SKILL.md
docs/ARCHITECTURE.md
docs/IMPLEMENTATION_PLAN.md
docs/CORE_REQUIREMENTS.md
python/omegaself/
schemas/
omegaclaw/src/self_model/
examples/
```

## License and provenance

The pack is an original implementation scaffold derived from the supplied
OmegaSelf proposal and accompanying Hyperseed formalizations. It does not copy
OmegaClaw source files. Patch examples are deliberately schematic; review the
target repository's license before incorporation.
