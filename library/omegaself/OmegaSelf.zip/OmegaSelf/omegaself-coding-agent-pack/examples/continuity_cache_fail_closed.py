"""Show that a high-impact mutation cache miss cannot become permission."""

from __future__ import annotations

from examples_policy_support import make_demo_gate, make_demo_context
from omegaself.continuity import ContinuityAnalysisResult
from omegaself.types import ActionProposal, Severity


def main() -> None:
    proposal = ActionProposal(
        proposal_id="mutation-1",
        action_type="replace_reasoner_backend",
        action_class="mutation",
        arguments={"from": "patham9", "to": "omegapln"},
        context="runtime",
        subject_anchor="anchor-demo",
        reversible=False,
        external_effect=True,
        estimated_impact=Severity.HIGH,
        required_capability=None,
        evidence_closure_id="closure-migration",
        prediction_id="prediction-migration",
    )
    decision = make_demo_gate().evaluate(
        proposal,
        make_demo_context(continuity_result=ContinuityAnalysisResult.cache_miss()),
    )
    print("Continuity status: cache_miss")
    print("Policy decision:", decision.decision.value)
    print("Reasons:", list(decision.reasons))


if __name__ == "__main__":
    main()
