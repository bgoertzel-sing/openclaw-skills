"""Shared helpers for dependency-free examples; not production configuration."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from omegaself.applicability import ApplicabilityAssessment, ApplicabilityStatus, OperationalEstimate
from omegaself.governance import HmacSha256TrustRoot, PolicyManifest, sign_manifest, verify_policy_manifest
from omegaself.policy import GateConfig, PolicyGate, ProposalContext
from omegaself.types import AnchorStatus

SEMANTICS = "omegapln-evidence-envelope-v1"


def make_demo_gate() -> PolicyGate:
    now = datetime.now(timezone.utc)
    root = HmacSha256TrustRoot({"demo-key": b"demo-only"})
    unsigned = PolicyManifest(
        policy_id="demo-policy-v2",
        policy_version="2.0.0",
        parent_policy_hash=None,
        issuer="demo-authority",
        issuer_key_id="demo-key",
        effective_at=(now - timedelta(minutes=1)).isoformat(),
        expires_at=(now + timedelta(hours=1)).isoformat(),
        admissible_action_classes=("read", "mutation"),
        capability_thresholds={"minimum_capability_lower_bound": 0.6, "minimum_support_mass": 1.0, "require_lower_bound": 1.0},
        assurance_requirements={},
        continuity_requirements={"high_impact_mutation": "verified_or_conservative_core"},
        review_requirements={"critical_impact": "review"},
        protected_invariants=("never-execute-non-Allow",),
        permitted_overrides=(),
        reasoner_semantics_id=SEMANTICS,
        calibration_profile_id="demo-cal",
        regularization_profile_id="demo-reg",
        signature_algorithm="hmac-sha256-test-only",
        signature="",
        manifest_hash="",
        metadata={"demo_only": True},
    )
    manifest = sign_manifest(unsigned, signer=root)
    authority = verify_policy_manifest(manifest, verifier=root, required_reasoner_semantics_id=SEMANTICS)
    return PolicyGate(GateConfig.from_manifest(manifest), authority)


def make_demo_context(**changes) -> ProposalContext:
    values = dict(
        anchor_status=AnchorStatus.RESOLVED,
        anchor_assurance="high",
        authorization=True,
        capability_estimate=OperationalEstimate(
            semantics_id=SEMANTICS,
            point_estimate=0.9,
            lower_bound=0.8,
            upper_bound=0.95,
            support_mass=3.0,
            evidence_quality="mechanical",
            independence_quality="grouped",
            calibration_profile_id="demo-cal",
            evidence_closure_id="closure-demo",
            raw_backend_value={},
        ),
        applicability=ApplicabilityAssessment(
            evidence_id="evt-demo",
            target_query="demo",
            evaluated_at=datetime.now(timezone.utc).isoformat(),
            source_context_id="ctx-demo",
            target_context_id="ctx-demo",
            source_regime_id="regime-demo",
            target_regime_id="regime-demo",
            status=ApplicabilityStatus.CURRENT,
            applicability=1.0,
            reason_codes=(),
            policy_id="freshness-demo",
        ),
        evidence_provenance_closed=True,
        reasoner_semantics_id=SEMANTICS,
    )
    values.update(changes)
    return ProposalContext(**values)
