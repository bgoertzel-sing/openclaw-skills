"""Local governance-seam probe over signed policy thresholds.

Evidence and the normalized reasoner result are held fixed.  Only the signed
policy manifest changes.  HMAC is used solely to make this example dependency-free;
a production gate should verify an asymmetric signature outside the agent's
revision authority.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from omegaself.applicability import ApplicabilityAssessment, ApplicabilityStatus, OperationalEstimate
from omegaself.governance import HmacSha256TrustRoot, PolicyManifest, sign_manifest, verify_policy_manifest
from omegaself.policy import GateConfig, PolicyGate, ProposalContext
from omegaself.types import ActionProposal, AnchorStatus, Severity

SEMANTICS = "omegapln-evidence-envelope-v1"
ROOT = HmacSha256TrustRoot({"demo-policy-key": b"demo-only-not-production"})


def gate(policy_id: str, lower_bound: float, support_mass: float) -> PolicyGate:
    now = datetime.now(timezone.utc)
    unsigned = PolicyManifest(
        policy_id=policy_id,
        policy_version="2.0.0",
        parent_policy_hash=None,
        issuer="demo-external-policy-authority",
        issuer_key_id="demo-policy-key",
        effective_at=(now - timedelta(minutes=1)).isoformat(),
        expires_at=(now + timedelta(hours=1)).isoformat(),
        admissible_action_classes=("read",),
        capability_thresholds={
            "minimum_capability_lower_bound": lower_bound,
            "minimum_support_mass": support_mass,
            "require_lower_bound": 1.0,
        },
        assurance_requirements={},
        continuity_requirements={},
        review_requirements={"critical_impact": "review"},
        protected_invariants=("never-execute-non-Allow",),
        permitted_overrides=(),
        reasoner_semantics_id=SEMANTICS,
        calibration_profile_id="demo-calibration-v1",
        regularization_profile_id="demo-regularization-v1",
        signature_algorithm="hmac-sha256-test-only",
        signature="",
        manifest_hash="",
        metadata={"demo_only": True},
    )
    manifest = sign_manifest(unsigned, signer=ROOT)
    authority = verify_policy_manifest(
        manifest,
        verifier=ROOT,
        required_reasoner_semantics_id=SEMANTICS,
        allowed_issuers=("demo-external-policy-authority",),
        now=now,
    )
    return PolicyGate(GateConfig.from_manifest(manifest), authority)


def main() -> None:
    proposal = ActionProposal(
        proposal_id="proposal-seam-1",
        action_type="extract_pdf",
        action_class="read",
        arguments={"file": "paper.pdf"},
        context="scientific-pdf",
        subject_anchor="anchor-demo",
        reversible=True,
        external_effect=False,
        estimated_impact=Severity.MEDIUM,
        required_capability="pdf-extract-v2",
        evidence_closure_id="closure-44",
        prediction_id="prediction-44",
    )
    context = ProposalContext(
        anchor_status=AnchorStatus.RESOLVED,
        anchor_assurance="high",
        authorization=True,
        capability_estimate=OperationalEstimate(
            semantics_id=SEMANTICS,
            point_estimate=0.72,
            lower_bound=0.64,
            upper_bound=0.81,
            support_mass=2.0,
            evidence_quality="mechanical",
            independence_quality="grouped",
            calibration_profile_id="demo-calibration-v1",
            evidence_closure_id="closure-44",
            raw_backend_value={"stv": [0.72, 0.52]},
        ),
        applicability=ApplicabilityAssessment(
            evidence_id="evt-44",
            target_query="CanDo(pdf-extract-v2)",
            evaluated_at=datetime.now(timezone.utc).isoformat(),
            source_context_id="ctx-scientific-pdf",
            target_context_id="ctx-scientific-pdf",
            source_regime_id="handler-2.1",
            target_regime_id="handler-2.1",
            status=ApplicabilityStatus.CURRENT,
            applicability=1.0,
            reason_codes=(),
            policy_id="freshness-v2",
        ),
        evidence_provenance_closed=True,
        reasoner_semantics_id=SEMANTICS,
    )
    policies = [
        gate("conservative", lower_bound=0.75, support_mass=3.0),
        gate("baseline", lower_bound=0.65, support_mass=1.0),
        gate("exploratory", lower_bound=0.55, support_mass=1.0),
    ]
    decisions = {
        item.config.policy_id: item.evaluate(proposal, context).decision.value
        for item in policies
    }
    print("Policy decisions:", decisions)
    print("Local governance seam:", sorted(set(decisions.values())))
    print(
        "Interpretation: the evidence and reasoner envelope stayed fixed; the action license changed only with the signed policy."
    )


if __name__ == "__main__":
    main()
