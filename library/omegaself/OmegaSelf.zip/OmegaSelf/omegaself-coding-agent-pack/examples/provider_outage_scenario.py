"""Demonstrate why capability beliefs are contextual and dependence-aware."""

from __future__ import annotations

import tempfile
from pathlib import Path

from omegaself.canonical import utc_now_iso
from omegaself.evidence import EvidenceClosureBuilder
from omegaself.ledger import HashChainLedger
from omegaself.types import EventDraft


def main() -> None:
    with tempfile.TemporaryDirectory() as temp_dir:
        ledger = HashChainLedger(Path(temp_dir) / "self_observations.jsonl")
        ids: list[str] = []
        # Three failures occur in one provider incident. They are correlated and
        # must not be interpreted as three independent proofs of incapacity.
        for attempt in range(3):
            event = ledger.append(
                EventDraft(
                    event_type="capability_outcome",
                    subject_anchor="anchor-demo",
                    context="scientific-pdf@provider-a",
                    payload={
                        "capability": "pdf-extract-v2",
                        "attempt": attempt + 1,
                        "outcome": "failure",
                        "failure_class": "provider_unavailable",
                    },
                    causal_time=utc_now_iso(),
                    dependence_group="provider-outage-2026-07-15",
                )
            )
            ids.append(event.event_id)

        # Independent local execution succeeds.
        local = ledger.append(
            EventDraft(
                event_type="capability_outcome",
                subject_anchor="anchor-demo",
                context="scientific-pdf@local",
                payload={
                    "capability": "pdf-extract-v2",
                    "outcome": "success",
                    "rubric_score": 0.91,
                },
                causal_time=utc_now_iso(),
            )
        )
        ids.append(local.event_id)

        closure = EvidenceClosureBuilder(ledger).build(ids, "closure-provider-outage")
        print("Raw outcomes:", len(ids))
        print("Independent evidence units:", len(closure.independent_units))
        print("Dependence groups:", dict(closure.dependence_groups))
        print(
            "Interpretation: provider-specific reachability fell, while general capability was not disproved."
        )


if __name__ == "__main__":
    main()
