"""Show that one observation generalized along two paths remains one evidence item."""

from __future__ import annotations

from omegaself.context_graph import ContextGraph, ContextKey, ContextTransfer


def main() -> None:
    graph = ContextGraph()
    specific = ContextKey("scientific-pdf", "digital", "local", "2.1", "local", "auth-1", "normal", "r1")
    technical = ContextKey("technical-document", "digital", "local", "2.1", "local", "auth-1", "normal", "r1")
    broad = ContextKey("document", "digital", "local", "2.1", "local", "auth-1", "normal", "r1")
    s, t, b = [graph.add_context(item) for item in (specific, technical, broad)]
    graph.add_transfer(ContextTransfer(s, t, "subsumes", 0.9, 0.1, "preserve_identity", "rule-1"))
    graph.add_transfer(ContextTransfer(t, b, "subsumes", 0.8, 0.1, "preserve_identity", "rule-1"))
    graph.add_transfer(ContextTransfer(s, b, "analogous", 0.5, 0.3, "preserve_identity", "rule-2"))
    paths = graph.find_paths(s, b)
    admitted = graph.deduplicate_evidence_paths([("evt-original",) for _ in paths])
    print("Transfer paths:", len(paths))
    print("Unique evidence items admitted:", len(admitted))
    print("Evidence IDs:", admitted)


if __name__ == "__main__":
    main()
