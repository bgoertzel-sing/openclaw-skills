"""Show that staleness changes a derived view, not the evidence ledger."""

from __future__ import annotations

import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

from omegaself.applicability import FreshnessPolicy, assess_applicability
from omegaself.ledger import HashChainLedger
from omegaself.types import EventDraft


def main() -> None:
    with tempfile.TemporaryDirectory() as temp_dir:
        ledger = HashChainLedger(Path(temp_dir) / "evidence.jsonl")
        now = datetime.now(timezone.utc)
        record = ledger.append(
            EventDraft(
                event_type="provider_health_probe",
                subject_anchor="anchor-demo",
                context="provider-a",
                payload={"reachable": True},
                causal_time=(now - timedelta(hours=1)).isoformat(),
            )
        )
        root_before = ledger.root_hash()
        view = assess_applicability(
            evidence_id=record.event_id,
            target_query="Reachable(provider-a, now)",
            observed_at=record.causal_time,
            source_context_id="provider-a",
            target_context_id="provider-a",
            source_regime_id="provider-a-epoch-1",
            target_regime_id="provider-a-epoch-1",
            policy=FreshnessPolicy(
                policy_id="provider-health-5m",
                predicate_class="provider-health",
                current_for_seconds=60,
                stale_after_seconds=300,
            ),
            evaluated_at=now.isoformat(),
        )
        print("Evidence event:", record.event_id)
        print("Derived applicability:", view.status.value, view.applicability)
        print("Ledger unchanged:", root_before == ledger.root_hash())


if __name__ == "__main__":
    main()
