"""Demonstrate one neutral call site across Patham9 and OmegaPLN adapters."""

from __future__ import annotations

from omegaself.reasoner import InferenceRequest, OmegaPLNAdapter, Patham9Adapter, compare_inference_results

SEMANTICS = "nal-compatibility-profile-v1"


def compatibility_backend(payload):
    return {
        "claim": payload["request"]["query"],
        "point_estimate": 0.82,
        "lower_bound": 0.71,
        "upper_bound": 0.9,
        "support_mass": 4.0,
        "evidence_quality": "mechanical",
        "independence_quality": "grouped",
        "calibration_profile_id": "migration-calibration-v1",
        "evidence_event_ids": ["evt-a", "evt-b"],
        "derivation_trace": [{"rule": "NAL-deduction-golden-1"}],
        "truth_semantics_id": SEMANTICS,
        "provenance_status": "closed",
        "convergence_status": "converged",
        "raw_backend_value": {"stv": [0.82, 0.71]},
    }


def main() -> None:
    request = InferenceRequest(
        request_id="migration-1",
        query={"predicate": "CanDo", "capability": "pdf-extract-v2"},
        context_id="ctx-scientific-pdf",
        evidence_snapshot_id="evidence-snapshot-44",
        evidence_closure_id="closure-44",
        rule_profile_id="nal-golden-v1",
        prior_bundle_id=None,
        dependence_model_id="dependence-v1",
        inference_budget={"steps": 500},
        required_provenance_level="complete",
        required_assurance_mode="bounded",
    )
    old = Patham9Adapter(
        compatibility_backend,
        backend_version="patham9-demo",
        truth_semantics_id=SEMANTICS,
    ).infer(request)
    new = OmegaPLNAdapter(
        compatibility_backend,
        backend_version="omegapln-demo",
        truth_semantics_id=SEMANTICS,
    ).infer(request)
    report = compare_inference_results(old, new)
    print("Old backend:", old.backend_id)
    print("New backend:", new.backend_id)
    print("Neutral result compatible:", report.compatible)
    print("Differences:", list(report.differences))


if __name__ == "__main__":
    main()
