# Reference pack validation results

Package version: 1.0.0  
Validation date: 2026-07-15

Commands executed:

```bash
make test
make demo
make validate
./scripts/smoke_test.sh
```

Results:

- **44 Python unit tests passed**;
- all 21 JSON Schemas passed Draft 2020-12 schema checks;
- Python modules compiled successfully;
- append-only ledger seed and verification completed with four records;
- provider-outage demo preserved the distinction between four raw outcomes and
  two independent evidence units;
- staleness demo produced a stale applicability view while leaving the ledger root unchanged;
- context-transfer demo found two derivation paths but admitted one evidence identity;
- Patham9 and OmegaPLN adapters used the same production request interface and
  produced a compatible normalized result in the compatibility demo;
- sampled signed-policy seam produced `RequireProbe` under conservative/baseline
  policies and `Allow` under the exploratory policy while holding evidence fixed;
- a high-impact mutation continuity cache miss produced `RequireReview`;
- unsigned/unverified, expired, tampered, and wrong-semantics policy cases failed closed;
- heuristic and forged-status continuity cases did not authorize mutation;
- evidence disqualification remained append-only and removed the target only from active derivation views.

The Python reference runtime is executable and tested. The HMAC trust root is
explicitly test-only. The MeTTa files and patch examples remain target-version
scaffolding and must be validated against the pinned OmegaClaw/Hyperon interpreter
and production asymmetric/remote trust roots before deployment.
