"""Evidence closure construction, disqualification, and overlap accounting."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping, Sequence

from .canonical import canonical_json, sha256_hex
from .ledger import HashChainLedger
from .types import StoredEvent


# These records belong in the derivation/provenance closure but are not themselves
# independent empirical support units for the derived claim.
DEFAULT_CONTROL_EVENT_TYPES = frozenset(
    {
        "retraction",
        "evidence_disqualification",
        "correction",
        "belief_derivation",
        "self_belief",
        "action_proposal",
        "policy_decision",
        "policy_authority",
        "self_prediction",
        "prediction_resolution",
        "continuity_analysis",
        "tripwire",
    }
)


@dataclass(frozen=True)
class EvidenceClosure:
    closure_id: str
    member_event_ids: Sequence[str]
    active_event_ids: Sequence[str]
    support_event_ids: Sequence[str]
    control_event_ids: Sequence[str]
    inactive_event_ids: Sequence[str]
    retracted_event_ids: Sequence[str]
    disqualified_event_ids: Sequence[str]
    dependence_groups: Mapping[str, Sequence[str]]
    independent_units: Sequence[Sequence[str]]
    root_hash: str
    missing_event_ids: Sequence[str]
    provenance_closed: bool

    def to_dict(self) -> dict[str, object]:
        return {
            "closure_id": self.closure_id,
            "member_event_ids": list(self.member_event_ids),
            "active_event_ids": list(self.active_event_ids),
            "support_event_ids": list(self.support_event_ids),
            "control_event_ids": list(self.control_event_ids),
            "inactive_event_ids": list(self.inactive_event_ids),
            "retracted_event_ids": list(self.retracted_event_ids),
            "disqualified_event_ids": list(self.disqualified_event_ids),
            "dependence_groups": {key: list(value) for key, value in self.dependence_groups.items()},
            "independent_units": [list(unit) for unit in self.independent_units],
            "root_hash": self.root_hash,
            "missing_event_ids": list(self.missing_event_ids),
            "provenance_closed": self.provenance_closed,
        }


class EvidenceClosureBuilder:
    """Build an immutable closure over event records and provenance links.

    The closure retains control events such as retractions and derivations for
    audit, while computing independence units only over active empirical support
    events.  This prevents a derivation summary or retraction record from being
    counted as additional evidence for its own conclusion.
    """

    def __init__(
        self,
        ledger: HashChainLedger,
        *,
        control_event_types: Iterable[str] = DEFAULT_CONTROL_EVENT_TYPES,
    ) -> None:
        self.ledger = ledger
        self.control_event_types = frozenset(str(item) for item in control_event_types)

    def _index(self) -> dict[str, StoredEvent]:
        return {record.event_id: record for record in self.ledger.iter_records()}

    def build(self, seeds: Iterable[str], closure_id: str) -> EvidenceClosure:
        index = self._index()
        pending = list(dict.fromkeys(str(seed) for seed in seeds))
        visited: set[str] = set()
        missing: set[str] = set()

        while pending:
            event_id = pending.pop()
            if event_id in visited:
                continue
            record = index.get(event_id)
            if record is None:
                missing.add(event_id)
                continue
            visited.add(event_id)
            for parent_id in record.provenance:
                if parent_id not in visited:
                    pending.append(parent_id)

        retracted: set[str] = set()
        disqualified: set[str] = set()
        for event_id in visited:
            record = index[event_id]
            if record.event_type in {"retraction", "evidence_disqualification"}:
                target = record.payload.get("target_event_id")
                if isinstance(target, str):
                    if record.event_type == "retraction":
                        retracted.add(target)
                    else:
                        disqualified.add(target)

        inactive = retracted | disqualified
        active = sorted(visited.difference(inactive))
        control = sorted(
            event_id
            for event_id in active
            if index[event_id].event_type in self.control_event_types
        )
        support = sorted(set(active).difference(control))

        dependence_groups: dict[str, list[str]] = {}
        independent: list[list[str]] = []
        for event_id in support:
            group = index[event_id].dependence_group
            if group:
                dependence_groups.setdefault(group, []).append(event_id)
            else:
                independent.append([event_id])
        independent.extend(sorted(values) for _, values in sorted(dependence_groups.items()))

        closure_payload = {
            "closure_id": closure_id,
            "member_event_ids": sorted(visited),
            "active_event_ids": active,
            "support_event_ids": support,
            "control_event_ids": control,
            "inactive_event_ids": sorted(inactive),
            "retracted_event_ids": sorted(retracted),
            "disqualified_event_ids": sorted(disqualified),
            "dependence_groups": {key: sorted(value) for key, value in sorted(dependence_groups.items())},
            "independent_units": independent,
            "missing_event_ids": sorted(missing),
        }
        return EvidenceClosure(
            closure_id=closure_id,
            member_event_ids=tuple(closure_payload["member_event_ids"]),
            active_event_ids=tuple(active),
            support_event_ids=tuple(support),
            control_event_ids=tuple(control),
            inactive_event_ids=tuple(sorted(inactive)),
            retracted_event_ids=tuple(sorted(retracted)),
            disqualified_event_ids=tuple(sorted(disqualified)),
            dependence_groups={key: tuple(sorted(value)) for key, value in dependence_groups.items()},
            independent_units=tuple(tuple(unit) for unit in independent),
            root_hash=sha256_hex(canonical_json(closure_payload)),
            missing_event_ids=tuple(sorted(missing)),
            provenance_closed=not missing,
        )
