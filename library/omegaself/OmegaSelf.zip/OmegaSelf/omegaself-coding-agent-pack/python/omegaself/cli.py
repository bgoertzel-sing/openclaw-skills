"""Command-line tools for inspecting the reference ledger."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .canonical import utc_now_iso
from .ledger import HashChainLedger
from .types import EventDraft


def _ledger(args: argparse.Namespace) -> HashChainLedger:
    return HashChainLedger(Path(args.ledger))


def cmd_init(args: argparse.Namespace) -> int:
    ledger = _ledger(args)
    print(json.dumps({"ledger": str(ledger.path), "root_hash": ledger.root_hash()}, indent=2))
    return 0


def cmd_append(args: argparse.Namespace) -> int:
    try:
        payload = json.loads(args.payload)
    except json.JSONDecodeError as exc:
        print(f"invalid --payload JSON: {exc}", file=sys.stderr)
        return 2
    if not isinstance(payload, dict):
        print("--payload must decode to a JSON object", file=sys.stderr)
        return 2
    event = _ledger(args).append(
        EventDraft(
            event_type=args.event_type,
            subject_anchor=args.subject_anchor,
            context=args.context,
            payload=payload,
            causal_time=args.causal_time or utc_now_iso(),
            dependence_group=args.dependence_group,
        )
    )
    print(json.dumps(event.to_dict(), indent=2, sort_keys=True))
    return 0


def cmd_verify(args: argparse.Namespace) -> int:
    report = _ledger(args).verify()
    print(
        json.dumps(
            {
                "ok": report.ok,
                "record_count": report.record_count,
                "root_hash": report.root_hash,
                "errors": list(report.errors),
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 0 if report.ok else 1


def cmd_root(args: argparse.Namespace) -> int:
    print(_ledger(args).root_hash())
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="omegaself", description=__doc__)
    parser.add_argument(
        "--ledger",
        default="./memory/omegaself/self_observations.jsonl",
        help="path to the append-only JSONL ledger",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    init_parser = subparsers.add_parser("init", help="create the ledger if absent")
    init_parser.set_defaults(func=cmd_init)

    append_parser = subparsers.add_parser("append", help="append one event")
    append_parser.add_argument("--event-type", required=True)
    append_parser.add_argument("--subject-anchor", required=True)
    append_parser.add_argument("--context", required=True)
    append_parser.add_argument("--payload", required=True, help="JSON object")
    append_parser.add_argument("--causal-time")
    append_parser.add_argument("--dependence-group")
    append_parser.set_defaults(func=cmd_append)

    verify_parser = subparsers.add_parser("verify", help="verify the complete hash chain")
    verify_parser.set_defaults(func=cmd_verify)

    root_parser = subparsers.add_parser("root", help="print the current ledger root hash")
    root_parser.set_defaults(func=cmd_root)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
