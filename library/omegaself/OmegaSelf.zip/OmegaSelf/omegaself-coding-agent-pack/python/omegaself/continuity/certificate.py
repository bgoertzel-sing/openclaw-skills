"""Continuity-analysis certificates and fail-closed status values."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field, replace
from enum import Enum
from typing import Any, Mapping, Sequence

from ..canonical import canonical_json, sha256_hex


class CertificateClass(str, Enum):
    VERIFIED = "verified"
    CONSERVATIVE_CORE = "conservative_core"
    HEURISTIC = "heuristic"


class ContinuityOutcome(str, Enum):
    PRESERVED = "preserved"
    VIOLATED = "violated"
    INCONCLUSIVE = "inconclusive"


class ContinuityStatus(str, Enum):
    NOT_REQUIRED = "not_required"
    VERIFIED = "verified"
    CONSERVATIVE_SAFE = "conservative_safe"
    HEURISTIC = "heuristic"
    CONTRADICTED = "contradicted"
    INCOMPLETE = "incomplete"
    UNSUPPORTED = "unsupported"
    BUDGET_EXHAUSTED = "budget_exhausted"
    CACHE_MISS = "cache_miss"
    EXPIRED = "expired"
    INVALID = "invalid"


@dataclass(frozen=True)
class ContinuityCertificate:
    certificate_id: str
    certificate_class: CertificateClass
    outcome: ContinuityOutcome
    from_snapshot_hash: str
    proposal_hash: str
    predicted_to_state_hash: str
    evidence_snapshot_hash: str
    policy_manifest_hash: str
    invariant_set_hash: str
    ontology_version: str
    reasoner_backend_id: str
    reasoner_semantics_id: str
    analysis_algorithm_version: str
    analysis_depth: int
    coverage_claim: str
    created_at: str
    valid_until: str
    issuer: str
    issuer_key_id: str
    signature_algorithm: str
    signature: str
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def unsigned_payload(self) -> dict[str, Any]:
        value = asdict(self)
        value.pop("signature", None)
        value.pop("certificate_id", None)
        value["certificate_class"] = self.certificate_class.value
        value["outcome"] = self.outcome.value
        value["metadata"] = dict(self.metadata)
        return value

    def canonical_unsigned_bytes(self) -> bytes:
        return canonical_json(self.unsigned_payload()).encode("utf-8")

    def computed_id(self) -> str:
        return "ccert-" + sha256_hex(self.canonical_unsigned_bytes())[:32]

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["certificate_class"] = self.certificate_class.value
        value["outcome"] = self.outcome.value
        value["metadata"] = dict(self.metadata)
        return value


@dataclass(frozen=True)
class ContinuityAnalysisResult:
    status: ContinuityStatus
    certificate_id: str | None
    certificate_class: CertificateClass | None
    exact_input_match: bool
    reasons: Sequence[str]
    coverage_claim: str | None = None
    valid_until: str | None = None

    @classmethod
    def not_required(cls) -> "ContinuityAnalysisResult":
        return cls(
            status=ContinuityStatus.NOT_REQUIRED,
            certificate_id=None,
            certificate_class=None,
            exact_input_match=True,
            reasons=("continuity analysis is not required for this proposal class",),
        )

    @classmethod
    def cache_miss(cls) -> "ContinuityAnalysisResult":
        return cls(
            status=ContinuityStatus.CACHE_MISS,
            certificate_id=None,
            certificate_class=None,
            exact_input_match=False,
            reasons=("no continuity certificate exists for the exact mutation inputs",),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status.value,
            "certificate_id": self.certificate_id,
            "certificate_class": None
            if self.certificate_class is None
            else self.certificate_class.value,
            "exact_input_match": self.exact_input_match,
            "reasons": list(self.reasons),
            "coverage_claim": self.coverage_claim,
            "valid_until": self.valid_until,
        }


def sign_continuity_certificate(certificate: ContinuityCertificate, *, signer: Any) -> ContinuityCertificate:
    certificate_id = certificate.computed_id()
    signature = signer.sign(
        payload=certificate.canonical_unsigned_bytes(),
        key_id=certificate.issuer_key_id,
    )
    return replace(certificate, certificate_id=certificate_id, signature=signature)


def continuity_cache_key(
    *,
    from_snapshot_hash: str,
    proposal_hash: str,
    evidence_snapshot_hash: str,
    policy_manifest_hash: str,
    invariant_set_hash: str,
    ontology_version: str,
    reasoner_semantics_id: str,
) -> str:
    payload = {
        "from_snapshot_hash": from_snapshot_hash,
        "proposal_hash": proposal_hash,
        "evidence_snapshot_hash": evidence_snapshot_hash,
        "policy_manifest_hash": policy_manifest_hash,
        "invariant_set_hash": invariant_set_hash,
        "ontology_version": ontology_version,
        "reasoner_semantics_id": reasoner_semantics_id,
    }
    return "ckey-" + sha256_hex(canonical_json(payload))
