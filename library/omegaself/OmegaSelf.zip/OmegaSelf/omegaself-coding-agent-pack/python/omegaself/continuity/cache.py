"""Exact-key continuity certificate cache.

The cache is an accelerator, not an authority source.  A miss is returned as a
first-class status and must fail closed for high-impact mutations at the policy
layer.  Heuristic certificates remain advisory even when cached.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Mapping

from ..governance.signature import SignatureVerifier
from .certificate import (
    ContinuityAnalysisResult,
    ContinuityCertificate,
    continuity_cache_key,
)
from .verifier import verify_continuity_certificate


@dataclass
class ContinuityCache:
    _items: dict[str, ContinuityCertificate] = field(default_factory=dict)

    def put(self, certificate: ContinuityCertificate) -> str:
        key = continuity_cache_key(
            from_snapshot_hash=certificate.from_snapshot_hash,
            proposal_hash=certificate.proposal_hash,
            evidence_snapshot_hash=certificate.evidence_snapshot_hash,
            policy_manifest_hash=certificate.policy_manifest_hash,
            invariant_set_hash=certificate.invariant_set_hash,
            ontology_version=certificate.ontology_version,
            reasoner_semantics_id=certificate.reasoner_semantics_id,
        )
        self._items[key] = certificate
        return key

    def lookup(
        self,
        *,
        verifier: SignatureVerifier,
        expected: Mapping[str, str],
        trusted_issuers: tuple[str, ...] = (),
        now: datetime | None = None,
    ) -> ContinuityAnalysisResult:
        key = continuity_cache_key(
            from_snapshot_hash=expected["from_snapshot_hash"],
            proposal_hash=expected["proposal_hash"],
            evidence_snapshot_hash=expected["evidence_snapshot_hash"],
            policy_manifest_hash=expected["policy_manifest_hash"],
            invariant_set_hash=expected["invariant_set_hash"],
            ontology_version=expected["ontology_version"],
            reasoner_semantics_id=expected["reasoner_semantics_id"],
        )
        certificate = self._items.get(key)
        if certificate is None:
            return ContinuityAnalysisResult.cache_miss()
        return verify_continuity_certificate(
            certificate,
            verifier=verifier,
            expected=expected,
            trusted_issuers=trusted_issuers,
            now=now,
        )
