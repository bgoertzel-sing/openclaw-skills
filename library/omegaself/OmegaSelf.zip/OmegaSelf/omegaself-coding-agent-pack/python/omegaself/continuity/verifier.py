"""Verification of exact-input continuity certificates."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Mapping

from ..governance.signature import SignatureVerifier
from .certificate import (
    CertificateClass,
    ContinuityAnalysisResult,
    ContinuityCertificate,
    ContinuityOutcome,
    ContinuityStatus,
)


def _parse_time(value: str) -> datetime:
    normalized = value[:-1] + "+00:00" if value.endswith("Z") else value
    result = datetime.fromisoformat(normalized)
    if result.tzinfo is None:
        result = result.replace(tzinfo=timezone.utc)
    return result.astimezone(timezone.utc)


def verify_continuity_certificate(
    certificate: ContinuityCertificate,
    *,
    verifier: SignatureVerifier,
    expected: Mapping[str, str],
    trusted_issuers: tuple[str, ...] = (),
    now: datetime | None = None,
) -> ContinuityAnalysisResult:
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    reasons: list[str] = []

    if certificate.computed_id() != certificate.certificate_id:
        return ContinuityAnalysisResult(
            status=ContinuityStatus.INVALID,
            certificate_id=certificate.certificate_id,
            certificate_class=certificate.certificate_class,
            exact_input_match=False,
            reasons=("certificate ID does not match canonical unsigned payload",),
            coverage_claim=certificate.coverage_claim,
            valid_until=certificate.valid_until,
        )
    if trusted_issuers and certificate.issuer not in set(trusted_issuers):
        return ContinuityAnalysisResult(
            status=ContinuityStatus.INVALID,
            certificate_id=certificate.certificate_id,
            certificate_class=certificate.certificate_class,
            exact_input_match=False,
            reasons=("continuity certificate issuer is not trusted",),
            coverage_claim=certificate.coverage_claim,
            valid_until=certificate.valid_until,
        )
    if current >= _parse_time(certificate.valid_until):
        return ContinuityAnalysisResult(
            status=ContinuityStatus.EXPIRED,
            certificate_id=certificate.certificate_id,
            certificate_class=certificate.certificate_class,
            exact_input_match=False,
            reasons=("continuity certificate has expired",),
            coverage_claim=certificate.coverage_claim,
            valid_until=certificate.valid_until,
        )
    if not verifier.verify(
        payload=certificate.canonical_unsigned_bytes(),
        signature=certificate.signature,
        key_id=certificate.issuer_key_id,
        algorithm=certificate.signature_algorithm,
    ):
        return ContinuityAnalysisResult(
            status=ContinuityStatus.INVALID,
            certificate_id=certificate.certificate_id,
            certificate_class=certificate.certificate_class,
            exact_input_match=False,
            reasons=("continuity certificate signature verification failed",),
            coverage_claim=certificate.coverage_claim,
            valid_until=certificate.valid_until,
        )

    field_map = {
        "from_snapshot_hash": certificate.from_snapshot_hash,
        "proposal_hash": certificate.proposal_hash,
        "predicted_to_state_hash": certificate.predicted_to_state_hash,
        "evidence_snapshot_hash": certificate.evidence_snapshot_hash,
        "policy_manifest_hash": certificate.policy_manifest_hash,
        "invariant_set_hash": certificate.invariant_set_hash,
        "ontology_version": certificate.ontology_version,
        "reasoner_semantics_id": certificate.reasoner_semantics_id,
    }
    for name, expected_value in expected.items():
        actual = field_map.get(name)
        if actual != expected_value:
            reasons.append(f"{name} mismatch")
    if reasons:
        return ContinuityAnalysisResult(
            status=ContinuityStatus.UNSUPPORTED,
            certificate_id=certificate.certificate_id,
            certificate_class=certificate.certificate_class,
            exact_input_match=False,
            reasons=tuple(reasons),
            coverage_claim=certificate.coverage_claim,
            valid_until=certificate.valid_until,
        )

    if certificate.outcome is ContinuityOutcome.VIOLATED:
        status = ContinuityStatus.CONTRADICTED
    elif certificate.outcome is ContinuityOutcome.INCONCLUSIVE:
        status = ContinuityStatus.INCOMPLETE
    elif certificate.certificate_class is CertificateClass.VERIFIED:
        status = ContinuityStatus.VERIFIED
    elif certificate.certificate_class is CertificateClass.CONSERVATIVE_CORE:
        status = ContinuityStatus.CONSERVATIVE_SAFE
    else:
        status = ContinuityStatus.HEURISTIC

    return ContinuityAnalysisResult(
        status=status,
        certificate_id=certificate.certificate_id,
        certificate_class=certificate.certificate_class,
        exact_input_match=True,
        reasons=("continuity certificate verified for exact inputs",),
        coverage_claim=certificate.coverage_claim,
        valid_until=certificate.valid_until,
    )
