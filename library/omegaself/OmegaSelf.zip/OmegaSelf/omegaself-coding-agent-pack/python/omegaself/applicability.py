"""Time-, context-, and regime-indexed evidence applicability.

Staleness never mutates or deletes an evidence record.  It creates a fresh
assessment describing whether the preserved observation can still support a
particular current query.  The assessment is itself suitable for append-only
recording in the OmegaSelf ledger.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Mapping, Sequence


def _parse_time(value: str) -> datetime:
    normalized = value[:-1] + "+00:00" if value.endswith("Z") else value
    result = datetime.fromisoformat(normalized)
    if result.tzinfo is None:
        result = result.replace(tzinfo=timezone.utc)
    return result.astimezone(timezone.utc)


class ApplicabilityStatus(str, Enum):
    CURRENT = "current"
    AGING = "aging"
    STALE = "stale"
    SUPERSEDED = "superseded"
    INAPPLICABLE = "inapplicable"


@dataclass(frozen=True)
class FreshnessPolicy:
    """Versioned recency policy for one predicate/evidence class.

    ``current_for_seconds`` and ``stale_after_seconds`` affect the derived view
    only.  They do not alter the underlying evidence or its ledger hash.
    """

    policy_id: str
    predicate_class: str
    current_for_seconds: float
    stale_after_seconds: float
    allow_cross_regime_transfer: bool = False

    def __post_init__(self) -> None:
        if self.current_for_seconds < 0:
            raise ValueError("current_for_seconds must be non-negative")
        if self.stale_after_seconds < self.current_for_seconds:
            raise ValueError("stale_after_seconds must be >= current_for_seconds")


@dataclass(frozen=True)
class ApplicabilityAssessment:
    evidence_id: str
    target_query: str
    evaluated_at: str
    source_context_id: str
    target_context_id: str
    source_regime_id: str
    target_regime_id: str
    status: ApplicabilityStatus
    applicability: float
    reason_codes: Sequence[str]
    policy_id: str
    next_probe_due: str | None = None

    def __post_init__(self) -> None:
        if not 0.0 <= self.applicability <= 1.0:
            raise ValueError("applicability must be in [0, 1]")

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["status"] = self.status.value
        value["reason_codes"] = list(self.reason_codes)
        return value


@dataclass(frozen=True)
class OperationalEstimate:
    """Reasoner-neutral envelope consumed by governance.

    ``raw_backend_value`` is retained for audit and backend-specific analysis,
    but policy code must decide from the normalized fields rather than assuming
    one backend's STV semantics.
    """

    semantics_id: str
    point_estimate: float | None
    lower_bound: float | None
    upper_bound: float | None
    support_mass: float | None
    evidence_quality: str
    independence_quality: str
    calibration_profile_id: str | None
    evidence_closure_id: str | None
    raw_backend_value: Mapping[str, Any] = field(default_factory=dict)
    assumptions: Sequence[str] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        for name, value in (
            ("point_estimate", self.point_estimate),
            ("lower_bound", self.lower_bound),
            ("upper_bound", self.upper_bound),
        ):
            if value is not None and not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must be in [0, 1]")
        if self.support_mass is not None and self.support_mass < 0.0:
            raise ValueError("support_mass must be non-negative")
        if (
            self.lower_bound is not None
            and self.upper_bound is not None
            and self.lower_bound > self.upper_bound
        ):
            raise ValueError("lower_bound must be <= upper_bound")

    def conservative_value(self) -> float | None:
        return self.lower_bound if self.lower_bound is not None else self.point_estimate

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["raw_backend_value"] = dict(self.raw_backend_value)
        value["assumptions"] = list(self.assumptions)
        return value


def assess_applicability(
    *,
    evidence_id: str,
    target_query: str,
    observed_at: str,
    source_context_id: str,
    target_context_id: str,
    source_regime_id: str,
    target_regime_id: str,
    policy: FreshnessPolicy,
    context_transfer_applicability: float = 1.0,
    evaluated_at: str | None = None,
    next_probe_due: str | None = None,
) -> ApplicabilityAssessment:
    """Create a new applicability view without changing the evidence record."""

    if not 0.0 <= context_transfer_applicability <= 1.0:
        raise ValueError("context_transfer_applicability must be in [0, 1]")

    now = _parse_time(evaluated_at) if evaluated_at else datetime.now(timezone.utc)
    occurred = _parse_time(observed_at)
    age_seconds = max(0.0, (now - occurred).total_seconds())
    reasons: list[str] = []

    if source_regime_id != target_regime_id and not policy.allow_cross_regime_transfer:
        status = ApplicabilityStatus.SUPERSEDED
        applicability = 0.0
        reasons.append("regime_mismatch")
    elif context_transfer_applicability <= 0.0:
        status = ApplicabilityStatus.INAPPLICABLE
        applicability = 0.0
        reasons.append("no_context_transfer")
    elif age_seconds <= policy.current_for_seconds:
        status = ApplicabilityStatus.CURRENT
        applicability = context_transfer_applicability
    elif age_seconds < policy.stale_after_seconds:
        status = ApplicabilityStatus.AGING
        denominator = max(policy.stale_after_seconds - policy.current_for_seconds, 1e-12)
        age_fraction = (age_seconds - policy.current_for_seconds) / denominator
        applicability = context_transfer_applicability * max(0.0, 1.0 - age_fraction)
        reasons.append("recency_discount")
    else:
        status = ApplicabilityStatus.STALE
        applicability = 0.0
        reasons.append("freshness_horizon_exceeded")

    if source_context_id != target_context_id:
        reasons.append("context_transfer_applied")

    return ApplicabilityAssessment(
        evidence_id=evidence_id,
        target_query=target_query,
        evaluated_at=now.isoformat().replace("+00:00", "Z"),
        source_context_id=source_context_id,
        target_context_id=target_context_id,
        source_regime_id=source_regime_id,
        target_regime_id=target_regime_id,
        status=status,
        applicability=round(applicability, 12),
        reason_codes=tuple(reasons),
        policy_id=policy.policy_id,
        next_probe_due=next_probe_due,
    )
