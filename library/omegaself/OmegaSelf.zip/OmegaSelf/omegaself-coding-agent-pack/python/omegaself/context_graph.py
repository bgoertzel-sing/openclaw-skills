"""Context individuation and evidence-preserving transfer.

Contexts form a typed directed graph/partial order rather than assuming a total
hierarchy or a mathematical lattice.  Generalization transfers support while
retaining original evidence identities so one observation is never counted again
through every ancestor context.
"""

from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass, field
from typing import Any, Iterable, Mapping, Sequence

from .canonical import canonical_json, sha256_hex


@dataclass(frozen=True)
class ContextKey:
    task_class: str
    input_modality: str
    environment: str
    handler_version: str
    provider: str
    authorization_epoch: str
    resource_class: str
    rubric: str
    extra: Mapping[str, str] = field(default_factory=dict)

    @property
    def context_id(self) -> str:
        return "ctx-" + sha256_hex(canonical_json(self.to_dict()))[:20]

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["extra"] = dict(sorted(self.extra.items()))
        return value


@dataclass(frozen=True)
class ContextTransfer:
    source_context_id: str
    target_context_id: str
    relation: str
    applicability: float
    confidence_penalty: float
    evidence_reuse_policy: str
    rule_version: str
    assumptions: Sequence[str] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        if not 0.0 <= self.applicability <= 1.0:
            raise ValueError("applicability must be in [0, 1]")
        if not 0.0 <= self.confidence_penalty <= 1.0:
            raise ValueError("confidence_penalty must be in [0, 1]")
        if self.evidence_reuse_policy not in {"preserve_identity", "forbid", "aggregate_once"}:
            raise ValueError("unsupported evidence_reuse_policy")

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["assumptions"] = list(self.assumptions)
        return value


@dataclass(frozen=True)
class TransferPath:
    context_ids: Sequence[str]
    transfers: Sequence[ContextTransfer]
    applicability: float
    confidence_multiplier: float


class ContextGraph:
    """Small dependency-free context-transfer graph."""

    def __init__(self) -> None:
        self._contexts: dict[str, ContextKey] = {}
        self._edges: dict[str, list[ContextTransfer]] = {}

    def add_context(self, context: ContextKey) -> str:
        context_id = context.context_id
        existing = self._contexts.get(context_id)
        if existing is not None and existing != context:
            raise ValueError(f"context hash collision for {context_id}")
        self._contexts[context_id] = context
        return context_id

    def add_transfer(self, transfer: ContextTransfer) -> None:
        if transfer.source_context_id == transfer.target_context_id:
            raise ValueError("self transfers should be represented as identity, not an edge")
        self._edges.setdefault(transfer.source_context_id, []).append(transfer)

    def find_paths(
        self,
        source_context_id: str,
        target_context_id: str,
        *,
        max_depth: int = 4,
    ) -> tuple[TransferPath, ...]:
        if source_context_id == target_context_id:
            return (
                TransferPath(
                    context_ids=(source_context_id,),
                    transfers=(),
                    applicability=1.0,
                    confidence_multiplier=1.0,
                ),
            )
        queue: deque[tuple[str, tuple[str, ...], tuple[ContextTransfer, ...], float, float]] = deque()
        queue.append((source_context_id, (source_context_id,), (), 1.0, 1.0))
        results: list[TransferPath] = []
        while queue:
            node, context_ids, transfers, applicability, confidence = queue.popleft()
            if len(transfers) >= max_depth:
                continue
            for edge in self._edges.get(node, []):
                if edge.target_context_id in context_ids:
                    continue
                next_ids = context_ids + (edge.target_context_id,)
                next_transfers = transfers + (edge,)
                next_applicability = applicability * edge.applicability
                next_confidence = confidence * (1.0 - edge.confidence_penalty)
                if edge.target_context_id == target_context_id:
                    results.append(
                        TransferPath(
                            context_ids=next_ids,
                            transfers=next_transfers,
                            applicability=next_applicability,
                            confidence_multiplier=next_confidence,
                        )
                    )
                else:
                    queue.append(
                        (
                            edge.target_context_id,
                            next_ids,
                            next_transfers,
                            next_applicability,
                            next_confidence,
                        )
                    )
        return tuple(results)

    @staticmethod
    def deduplicate_evidence_paths(paths: Iterable[Iterable[str]]) -> tuple[str, ...]:
        """Union evidence identities without multiplying support by path count."""

        ordered: dict[str, None] = {}
        for path in paths:
            for evidence_id in path:
                ordered.setdefault(str(evidence_id), None)
        return tuple(ordered)

    @staticmethod
    def deduplicate_independence_units(
        units: Iterable[Iterable[str]],
    ) -> tuple[tuple[str, ...], ...]:
        """Deduplicate event IDs and identical dependence units.

        The caller remains responsible for detecting partially overlapping units;
        those should trigger a dependence-model warning rather than silent merge.
        """

        seen_units: set[tuple[str, ...]] = set()
        result: list[tuple[str, ...]] = []
        for unit in units:
            canonical = tuple(sorted(dict.fromkeys(str(item) for item in unit)))
            if not canonical or canonical in seen_units:
                continue
            seen_units.add(canonical)
            result.append(canonical)
        return tuple(result)
