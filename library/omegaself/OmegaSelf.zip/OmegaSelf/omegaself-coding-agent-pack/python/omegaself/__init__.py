"""OmegaSelf dependency-free reference runtime.

The package implements the durable evidence ledger, evidence closure, renewable
``SelfHereNow`` resolution, time/context-indexed applicability, a substrate-neutral
reasoner seam, continuity certificates, signed-policy verification, prediction
scoring, and a fail-closed proposal gate.  MeTTa files in the adjacent
``omegaclaw`` directory remain target-version integration scaffolding.
"""

from .applicability import (
    ApplicabilityAssessment,
    ApplicabilityStatus,
    FreshnessPolicy,
    OperationalEstimate,
    assess_applicability,
)
from .attestation import AttestationInput, Lease, SelfAnchorResolution, SelfHereNowResolver
from .context_graph import ContextGraph, ContextKey, ContextTransfer, TransferPath
from .continuity import (
    CertificateClass,
    ContinuityAnalysisResult,
    ContinuityCache,
    ContinuityCertificate,
    ContinuityOutcome,
    ContinuityStatus,
    sign_continuity_certificate,
    verify_continuity_certificate,
)
from .evidence import EvidenceClosure, EvidenceClosureBuilder
from .governance import (
    ExternalPolicyTrustRoot,
    HmacSha256TrustRoot,
    PolicyAuthorityAssessment,
    PolicyAuthorityStatus,
    PolicyManifest,
    sign_manifest,
    verify_policy_manifest,
)
from .ledger import HashChainLedger, LedgerVerification
from .policy import GateConfig, PolicyGate, ProposalContext
from .predictions import Prediction, PredictionResolution, score_prediction
from .reasoner import OmegaPLNAdapter, Patham9Adapter, SelfReasoner
from .service import OmegaSelfService
from .types import (
    ActionProposal,
    AnchorStatus,
    Decision,
    EventDraft,
    Facet,
    PolicyDecision,
    Severity,
    StoredEvent,
)

__all__ = [
    "ActionProposal",
    "AnchorStatus",
    "ApplicabilityAssessment",
    "ApplicabilityStatus",
    "AttestationInput",
    "CertificateClass",
    "ContextGraph",
    "ContextKey",
    "ContextTransfer",
    "ContinuityAnalysisResult",
    "ContinuityCache",
    "ContinuityCertificate",
    "ContinuityOutcome",
    "ContinuityStatus",
    "Decision",
    "EventDraft",
    "EvidenceClosure",
    "EvidenceClosureBuilder",
    "ExternalPolicyTrustRoot",
    "Facet",
    "FreshnessPolicy",
    "GateConfig",
    "HashChainLedger",
    "HmacSha256TrustRoot",
    "Lease",
    "LedgerVerification",
    "OmegaPLNAdapter",
    "OmegaSelfService",
    "OperationalEstimate",
    "Patham9Adapter",
    "PolicyAuthorityAssessment",
    "PolicyAuthorityStatus",
    "PolicyDecision",
    "PolicyGate",
    "PolicyManifest",
    "Prediction",
    "PredictionResolution",
    "ProposalContext",
    "SelfAnchorResolution",
    "SelfHereNowResolver",
    "SelfReasoner",
    "Severity",
    "StoredEvent",
    "TransferPath",
    "assess_applicability",
    "score_prediction",
    "sign_continuity_certificate",
    "sign_manifest",
    "verify_continuity_certificate",
    "verify_policy_manifest",
]
