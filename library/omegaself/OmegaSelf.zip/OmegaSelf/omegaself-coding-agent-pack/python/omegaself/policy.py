"""Fail-closed proposal gate consuming substrate-neutral self-model conclusions."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence

from .applicability import ApplicabilityAssessment, ApplicabilityStatus, OperationalEstimate
from .continuity import CertificateClass, ContinuityAnalysisResult, ContinuityStatus
from .governance import PolicyAuthorityAssessment, PolicyAuthorityStatus, PolicyManifest
from .types import ActionProposal, AnchorStatus, Decision, PolicyDecision, Severity


@dataclass(frozen=True)
class ProposalContext:
    anchor_status: AnchorStatus
    anchor_assurance: str
    authorization: bool | None
    capability_estimate: OperationalEstimate | None
    applicability: ApplicabilityAssessment | None
    evidence_provenance_closed: bool
    reasoner_semantics_id: str
    active_tripwires: Sequence[Severity] = field(default_factory=tuple)
    commitment_conflicts: Sequence[str] = field(default_factory=tuple)
    continuity_result: ContinuityAnalysisResult = field(
        default_factory=ContinuityAnalysisResult.not_required
    )
    counterfactual_taint: bool = False


@dataclass(frozen=True)
class GateConfig:
    policy_id: str
    policy_manifest_hash: str
    reasoner_semantics_id: str
    admissible_action_classes: Sequence[str] = field(default_factory=tuple)
    minimum_capability_lower_bound: float = 0.65
    minimum_support_mass: float = 1.0
    require_lower_bound: bool = True
    accepted_evidence_qualities: Sequence[str] = (
        "mechanical",
        "authenticated",
        "external_evaluation",
        "mixed",
    )
    accepted_independence_qualities: Sequence[str] = (
        "verified",
        "grouped",
        "conservative",
    )
    aging_requires_probe_for_high_effect: bool = True
    high_impact_review: bool = True

    @classmethod
    def from_manifest(cls, manifest: PolicyManifest) -> "GateConfig":
        thresholds = dict(manifest.capability_thresholds)
        return cls(
            policy_id=manifest.policy_id,
            policy_manifest_hash=manifest.manifest_hash,
            reasoner_semantics_id=manifest.reasoner_semantics_id,
            admissible_action_classes=tuple(manifest.admissible_action_classes),
            minimum_capability_lower_bound=float(
                thresholds.get("minimum_capability_lower_bound", 0.65)
            ),
            minimum_support_mass=float(thresholds.get("minimum_support_mass", 1.0)),
            require_lower_bound=bool(thresholds.get("require_lower_bound", 1.0)),
            high_impact_review=manifest.review_requirements.get("critical_impact", "review")
            == "review",
        )


class PolicyGate:
    """Return a typed decision; never execute the proposal itself.

    The gate requires an externally verified policy-authority assessment.  The
    default is deliberately unverified, so constructing ``PolicyGate()`` cannot
    accidentally create an authority root inside the agent.
    """

    def __init__(
        self,
        config: GateConfig | None = None,
        authority: PolicyAuthorityAssessment | None = None,
    ) -> None:
        self.config = config or GateConfig(
            policy_id="unconfigured",
            policy_manifest_hash="",
            reasoner_semantics_id="unconfigured",
        )
        self.authority = authority or PolicyAuthorityAssessment.unverified()

    def evaluate(self, proposal: ActionProposal, context: ProposalContext) -> PolicyDecision:
        reasons: list[str] = []
        followups: list[str] = []

        authority_failure = self._authority_failure(context)
        if authority_failure is not None:
            return self._decision(
                proposal,
                Decision.DEFER,
                [authority_failure],
                ["load and verify an externally authorized policy manifest"],
            )

        if self.config.admissible_action_classes and proposal.action_class not in set(
            self.config.admissible_action_classes
        ):
            return self._decision(
                proposal,
                Decision.DENY,
                ["proposal action class is outside the signed policy manifest"],
            )

        if context.counterfactual_taint:
            return self._decision(
                proposal,
                Decision.DENY,
                ["proposal depends on quarantined counterfactual assertions"],
                ["reconstruct proposal from live evidence only"],
            )

        high_effect = proposal.external_effect or not proposal.reversible or proposal.estimated_impact in {
            Severity.HIGH,
            Severity.CRITICAL,
        }
        if context.anchor_status is AnchorStatus.UNRESOLVED and high_effect:
            return self._decision(
                proposal,
                Decision.DENY,
                ["SelfHereNow is unresolved for an external or irreversible action"],
                ["renew runtime attestation and re-resolve the anchor"],
            )
        if context.anchor_status is AnchorStatus.DEGRADED and high_effect:
            return self._decision(
                proposal,
                Decision.REQUIRE_REVIEW,
                ["SelfHereNow is only weakly resolved"],
                ["renew an exclusive or higher-assurance causal-control binding"],
            )

        if context.authorization is False:
            return self._decision(
                proposal,
                Decision.DENY,
                ["the current signed policy explicitly denies this action class"],
            )
        if context.authorization is None:
            return self._decision(
                proposal,
                Decision.REQUIRE_PROBE,
                ["authorization is unknown"],
                ["probe permissions or consult the authoritative policy space"],
            )

        if not context.evidence_provenance_closed:
            return self._decision(
                proposal,
                Decision.REQUIRE_PROBE,
                ["the supporting self-belief lacks complete provenance closure"],
                ["reconstruct the complete evidence derivation"],
            )

        if Severity.CRITICAL in context.active_tripwires:
            return self._decision(
                proposal,
                Decision.DENY,
                ["a critical self-model tripwire is active"],
                ["resolve it or obtain an explicit override from a higher authority"],
            )
        if Severity.HIGH in context.active_tripwires:
            reasons.append("a high-severity tripwire is active")
            followups.append("obtain independent review")

        continuity_decision = self._check_continuity(proposal, context, high_effect)
        if continuity_decision is not None:
            return continuity_decision

        if context.commitment_conflicts:
            reasons.append("proposal conflicts with active commitments")
            followups.append("open a commitment deliberation item")

        if proposal.required_capability:
            capability_decision = self._check_capability(proposal, context, high_effect)
            if capability_decision is not None:
                return capability_decision
            if context.applicability is not None and context.applicability.status is ApplicabilityStatus.AGING:
                reasons.append("supporting evidence is aging under the current freshness policy")
                followups.append("schedule a context-specific capability probe")

        if context.commitment_conflicts or Severity.HIGH in context.active_tripwires:
            return self._decision(proposal, Decision.REQUIRE_REVIEW, reasons, followups)
        if self.config.high_impact_review and proposal.estimated_impact is Severity.CRITICAL:
            return self._decision(
                proposal,
                Decision.REQUIRE_REVIEW,
                ["critical-impact proposals require review even when other checks pass"],
            )
        return self._decision(proposal, Decision.ALLOW, ["all configured gate conditions passed"])

    def _authority_failure(self, context: ProposalContext) -> str | None:
        if self.authority.status is not PolicyAuthorityStatus.VERIFIED:
            return "policy authority is not verified: " + "; ".join(self.authority.reasons)
        if self.authority.policy_id != self.config.policy_id:
            return "verified policy ID does not match gate configuration"
        if self.authority.manifest_hash != self.config.policy_manifest_hash:
            return "verified policy manifest hash does not match gate configuration"
        if self.authority.reasoner_semantics_id != self.config.reasoner_semantics_id:
            return "verified policy was signed for a different reasoner semantics profile"
        if context.reasoner_semantics_id != self.config.reasoner_semantics_id:
            return "proposal context was inferred under a different reasoner semantics profile"
        return None

    def _check_continuity(
        self,
        proposal: ActionProposal,
        context: ProposalContext,
        high_effect: bool,
    ) -> PolicyDecision | None:
        if proposal.action_class != "mutation":
            return None
        status = context.continuity_result.status
        if status is ContinuityStatus.CONTRADICTED:
            return self._decision(
                proposal,
                Decision.DENY,
                ["continuity analysis found a protected-invariant violation"],
                ["reject or redesign the mutation"],
            )
        if status in {ContinuityStatus.VERIFIED, ContinuityStatus.CONSERVATIVE_SAFE}:
            expected_class = (
                CertificateClass.VERIFIED
                if status is ContinuityStatus.VERIFIED
                else CertificateClass.CONSERVATIVE_CORE
            )
            if (
                not context.continuity_result.certificate_id
                or context.continuity_result.certificate_class is not expected_class
            ):
                return self._decision(
                    proposal,
                    Decision.REQUIRE_REVIEW,
                    ["continuity status is inconsistent with its certificate identity/class"],
                    ["verify the signed continuity certificate rather than trusting a status flag"],
                )
            if not context.continuity_result.exact_input_match:
                return self._decision(
                    proposal,
                    Decision.REQUIRE_REVIEW,
                    ["continuity certificate does not bind the exact mutation inputs"],
                    ["compute an exact-input certificate"],
                )
            return None

        reason = (
            "continuity analysis is not authorization-grade: "
            f"{status.value}; cached heuristic extensions and finite-core guesses are advisory only"
        )
        if high_effect:
            return self._decision(
                proposal,
                Decision.REQUIRE_REVIEW,
                [reason],
                ["obtain a verified or conservative-core exact-input certificate, or defer"],
            )
        return self._decision(
            proposal,
            Decision.REQUIRE_PROBE,
            [reason],
            ["run bounded continuity analysis before mutation"],
        )

    def _check_capability(
        self,
        proposal: ActionProposal,
        context: ProposalContext,
        high_effect: bool,
    ) -> PolicyDecision | None:
        estimate = context.capability_estimate
        applicability = context.applicability
        if estimate is None:
            return self._decision(
                proposal,
                Decision.REQUIRE_PROBE,
                ["required capability estimate is missing"],
                ["run a context-specific capability probe"],
            )
        if estimate.semantics_id != self.config.reasoner_semantics_id:
            return self._decision(
                proposal,
                Decision.DEFER,
                ["capability estimate uses an unapproved truth-semantics profile"],
                ["recompute through the configured reasoner adapter"],
            )
        if applicability is None:
            return self._decision(
                proposal,
                Decision.REQUIRE_PROBE,
                ["evidence applicability assessment is missing"],
                ["derive a fresh time/context/regime-indexed applicability view"],
            )
        if applicability.status in {
            ApplicabilityStatus.STALE,
            ApplicabilityStatus.SUPERSEDED,
            ApplicabilityStatus.INAPPLICABLE,
        }:
            return self._decision(
                proposal,
                Decision.REQUIRE_PROBE,
                [
                    "preserved evidence does not currently license this capability claim "
                    f"({applicability.status.value})"
                ],
                ["run a current-context probe; do not delete the historical evidence"],
            )
        if (
            applicability.status is ApplicabilityStatus.AGING
            and high_effect
            and self.config.aging_requires_probe_for_high_effect
        ):
            return self._decision(
                proposal,
                Decision.REQUIRE_PROBE,
                ["capability evidence is aging for a high-impact action"],
                ["refresh the evidence with a current-context probe"],
            )
        if estimate.evidence_quality not in set(self.config.accepted_evidence_qualities):
            return self._decision(
                proposal,
                Decision.REQUIRE_PROBE,
                [f"evidence quality is not policy-accepted: {estimate.evidence_quality}"],
                ["obtain mechanical, authenticated, or external evaluation evidence"],
            )
        if estimate.independence_quality not in set(self.config.accepted_independence_qualities):
            return self._decision(
                proposal,
                Decision.REQUIRE_PROBE,
                [
                    "independence/dependence accounting is not policy-accepted: "
                    f"{estimate.independence_quality}"
                ],
                ["rebuild the closure with dependence-group and inherited-evidence deduplication"],
            )
        conservative = estimate.conservative_value()
        if self.config.require_lower_bound and estimate.lower_bound is None:
            return self._decision(
                proposal,
                Decision.REQUIRE_PROBE,
                ["policy requires a normalized conservative lower bound"],
                ["recompute an operational estimate envelope"],
            )
        if conservative is None:
            return self._decision(
                proposal,
                Decision.REQUIRE_PROBE,
                ["capability estimate has no usable normalized value"],
                ["run or adapt the reasoner to produce an operational envelope"],
            )
        if conservative < self.config.minimum_capability_lower_bound:
            return self._decision(
                proposal,
                Decision.REQUIRE_PROBE,
                [
                    "capability lower bound is below the signed policy threshold "
                    f"({conservative:.3f} < {self.config.minimum_capability_lower_bound:.3f})"
                ],
                ["probe, choose another handler, or ask for help"],
            )
        if estimate.support_mass is None or estimate.support_mass < self.config.minimum_support_mass:
            return self._decision(
                proposal,
                Decision.REQUIRE_PROBE,
                ["independent support mass is below the signed policy threshold"],
                ["collect additional independent evidence"],
            )
        return None

    def _decision(
        self,
        proposal: ActionProposal,
        decision: Decision,
        reasons: Sequence[str],
        followups: Sequence[str] = (),
    ) -> PolicyDecision:
        return PolicyDecision(
            proposal_id=proposal.proposal_id,
            decision=decision,
            policy_id=self.config.policy_id,
            policy_manifest_hash=self.config.policy_manifest_hash,
            reasoner_semantics_id=self.config.reasoner_semantics_id,
            reasons=tuple(reasons),
            required_followups=tuple(followups),
            evidence_refs=tuple(
                ref
                for ref in (proposal.evidence_closure_id, proposal.prediction_id)
                if ref is not None
            ),
        )
