"""Falsifiable self-predictions and calibration scoring."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Mapping


@dataclass(frozen=True)
class Prediction:
    prediction_id: str
    proposition: str
    probability: float
    rubric: str
    context: str
    evidence_closure_id: str | None = None
    proposal_id: str | None = None

    def __post_init__(self) -> None:
        if not 0.0 <= self.probability <= 1.0:
            raise ValueError("Prediction probability must be in [0, 1]")


@dataclass(frozen=True)
class PredictionResolution:
    prediction_id: str
    observed: bool
    brier_score: float
    log_loss: float
    rubric_result: Mapping[str, object]


def score_prediction(
    prediction: Prediction,
    observed: bool,
    rubric_result: Mapping[str, object] | None = None,
) -> PredictionResolution:
    outcome = 1.0 if observed else 0.0
    probability = prediction.probability
    brier = (probability - outcome) ** 2
    epsilon = 1e-12
    clipped = min(max(probability, epsilon), 1.0 - epsilon)
    log_loss = -(outcome * math.log(clipped) + (1.0 - outcome) * math.log(1.0 - clipped))
    return PredictionResolution(
        prediction_id=prediction.prediction_id,
        observed=observed,
        brier_score=brier,
        log_loss=log_loss,
        rubric_result={} if rubric_result is None else dict(rubric_result),
    )
