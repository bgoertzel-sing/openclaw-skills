"""High-level orchestration service for the reference runtime."""

from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Any

from .canonical import utc_now_iso
from .ledger import HashChainLedger
from .policy import PolicyGate, ProposalContext
from .types import ActionProposal, EventDraft, PolicyDecision


class OmegaSelfService:
    """Small façade suitable for a Python-to-MeTTa bridge."""

    def __init__(self, data_dir: str | Path, policy_gate: PolicyGate | None = None) -> None:
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.ledger = HashChainLedger(self.data_dir / "self_observations.jsonl")
        self.policy_gate = policy_gate or PolicyGate()

    def record_event(
        self,
        *,
        event_type: str,
        subject_anchor: str,
        context: str,
        payload: dict[str, Any],
        causal_time: str | None = None,
        provenance: tuple[str, ...] = (),
        dependence_group: str | None = None,
    ) -> str:
        event = self.ledger.append(
            EventDraft(
                event_type=event_type,
                subject_anchor=subject_anchor,
                context=context,
                payload=payload,
                causal_time=causal_time or utc_now_iso(),
                provenance=provenance,
                dependence_group=dependence_group,
            )
        )
        return event.event_id

    def gate(
        self,
        proposal: ActionProposal,
        context: ProposalContext,
    ) -> PolicyDecision:
        proposal_event = self.ledger.append(
            EventDraft(
                event_type="action_proposal",
                subject_anchor=proposal.subject_anchor,
                context=proposal.context,
                payload=proposal.to_dict(),
                causal_time=utc_now_iso(),
                provenance=tuple(
                    ref
                    for ref in (proposal.evidence_closure_id, proposal.prediction_id)
                    if ref is not None
                ),
            )
        )
        decision = self.policy_gate.evaluate(proposal, context)
        self.ledger.append(
            EventDraft(
                event_type="policy_decision",
                subject_anchor=proposal.subject_anchor,
                context=proposal.context,
                payload=decision.to_dict(),
                causal_time=utc_now_iso(),
                provenance=(proposal_event.event_id,),
            )
        )
        return decision
