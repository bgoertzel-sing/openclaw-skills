"""Runtime-scoped resolution of the SelfHereNow indexical anchor."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Mapping, Sequence

from .canonical import canonical_json, sha256_hex
from .types import AnchorStatus


def _parse_time(value: str) -> datetime:
    normalized = value[:-1] + "+00:00" if value.endswith("Z") else value
    result = datetime.fromisoformat(normalized)
    if result.tzinfo is None:
        result = result.replace(tzinfo=timezone.utc)
    return result.astimezone(timezone.utc)


@dataclass(frozen=True)
class Lease:
    lease_id: str
    resource: str
    holder_instance: str
    issued_at: str
    expires_at: str
    exclusive: bool
    proof: str

    def is_live(self, now: datetime, runtime_instance: str) -> bool:
        return (
            self.holder_instance == runtime_instance
            and bool(self.proof)
            and _parse_time(self.issued_at) <= now < _parse_time(self.expires_at)
        )


@dataclass(frozen=True)
class AttestationInput:
    runtime_instance: str
    process_boundary: str
    workspace_boundary: str
    controlled_capabilities: Sequence[str]
    session_bindings: Sequence[str]
    lineage_head: str
    causal_provenance_head: str
    leases: Sequence[Lease] = field(default_factory=tuple)
    static_identity_claims: Mapping[str, str] = field(default_factory=dict)
    epoch: str = ""


@dataclass(frozen=True)
class SelfAnchorResolution:
    status: AnchorStatus
    anchor_id: str | None
    assurance: str
    reasons: Sequence[str]
    live_control_bindings: Sequence[str]
    expires_at: str | None
    bundle_hash: str | None

    def to_dict(self) -> dict[str, object]:
        return {
            "status": self.status.value,
            "anchor_id": self.anchor_id,
            "assurance": self.assurance,
            "reasons": list(self.reasons),
            "live_control_bindings": list(self.live_control_bindings),
            "expires_at": self.expires_at,
            "bundle_hash": self.bundle_hash,
        }


class SelfHereNowResolver:
    """Resolve an indexical anchor from live causal control, not stored identity alone."""

    def resolve(
        self,
        attestation: AttestationInput,
        *,
        now: datetime | None = None,
    ) -> SelfAnchorResolution:
        current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
        reasons: list[str] = []
        if not attestation.runtime_instance:
            reasons.append("missing runtime instance identity")
        if not attestation.process_boundary:
            reasons.append("missing process boundary")
        if not attestation.workspace_boundary:
            reasons.append("missing workspace boundary")
        if not attestation.lineage_head:
            reasons.append("missing lineage head")
        if not attestation.causal_provenance_head:
            reasons.append("missing causal provenance head")

        live_leases = [
            lease
            for lease in attestation.leases
            if lease.is_live(current, attestation.runtime_instance)
        ]
        exclusive_live = [lease for lease in live_leases if lease.exclusive]
        live_bindings = [lease.resource for lease in live_leases]

        # This is the copy-symmetry-breaking condition in the reference model:
        # at least one renewable, live, causally controlled binding.  A copied
        # secret or copied provenance ledger is not enough.
        if not live_leases:
            reasons.append("no renewable live causal-control attestation")

        complete_bundle = not reasons
        partial_bundle = bool(attestation.runtime_instance and live_leases)

        if complete_bundle:
            status = AnchorStatus.RESOLVED
            assurance = "high" if exclusive_live else "medium"
        elif partial_bundle:
            status = AnchorStatus.DEGRADED
            assurance = "low"
        else:
            return SelfAnchorResolution(
                status=AnchorStatus.UNRESOLVED,
                anchor_id=None,
                assurance="none",
                reasons=tuple(reasons),
                live_control_bindings=tuple(live_bindings),
                expires_at=None,
                bundle_hash=None,
            )

        expires_at = min((_parse_time(lease.expires_at) for lease in live_leases)).isoformat().replace(
            "+00:00", "Z"
        )
        bundle = {
            "runtime_instance": attestation.runtime_instance,
            "process_boundary": attestation.process_boundary,
            "workspace_boundary": attestation.workspace_boundary,
            "controlled_capabilities": sorted(attestation.controlled_capabilities),
            "session_bindings": sorted(attestation.session_bindings),
            "lineage_head": attestation.lineage_head,
            "causal_provenance_head": attestation.causal_provenance_head,
            "live_control_bindings": sorted(live_bindings),
            "epoch": attestation.epoch,
            "expires_at": expires_at,
        }
        bundle_hash = sha256_hex(canonical_json(bundle))
        anchor_id = f"anchor-{bundle_hash[:20]}"
        return SelfAnchorResolution(
            status=status,
            anchor_id=anchor_id,
            assurance=assurance,
            reasons=tuple(reasons),
            live_control_bindings=tuple(sorted(live_bindings)),
            expires_at=expires_at,
            bundle_hash=bundle_hash,
        )
