"""Canonical serialization and hashing helpers."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any


def utc_now_iso() -> str:
    """Return an RFC 3339 UTC timestamp with microsecond precision."""

    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def canonical_json(value: Any) -> str:
    """Serialize *value* deterministically for hashing.

    The ledger intentionally uses a small canonicalization contract: UTF-8 JSON,
    sorted keys, no insignificant whitespace, and no NaN/Infinity values.  A
    production deployment may replace this with RFC 8785 JCS, but all writers and
    verifiers must agree on exactly one format.
    """

    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )


def sha256_hex(value: bytes | str) -> str:
    """Return a lowercase SHA-256 hex digest."""

    data = value.encode("utf-8") if isinstance(value, str) else value
    return hashlib.sha256(data).hexdigest()
