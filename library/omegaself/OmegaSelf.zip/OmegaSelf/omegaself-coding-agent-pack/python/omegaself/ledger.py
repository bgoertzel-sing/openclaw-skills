"""Append-only hash-chained JSONL evidence ledger."""

from __future__ import annotations

import json
import os
import uuid
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator, Sequence

from .canonical import canonical_json, sha256_hex, utc_now_iso
from .types import EventDraft, StoredEvent

try:  # Unix/POSIX deployment path used by OmegaClaw.
    import fcntl  # type: ignore
except ImportError:  # pragma: no cover - Windows fallback is intentionally weaker.
    fcntl = None  # type: ignore


GENESIS_HASH = "0" * 64


@dataclass(frozen=True)
class LedgerVerification:
    ok: bool
    record_count: int
    root_hash: str
    errors: Sequence[str]


class HashChainLedger:
    """Durable ledger where each JSON line commits to the previous line.

    The ledger is append-only by API.  The operating system permissions and
    deployment sandbox should also deny in-place mutation to the agent process.
    """

    def __init__(self, path: str | os.PathLike[str]) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.touch(exist_ok=True)

    @contextmanager
    def _locked_file(self, mode: str):
        with self.path.open(mode, encoding="utf-8", newline="") as handle:
            if fcntl is not None:
                lock_mode = fcntl.LOCK_EX if any(flag in mode for flag in ("a", "w", "+")) else fcntl.LOCK_SH
                fcntl.flock(handle.fileno(), lock_mode)
            try:
                yield handle
            finally:
                handle.flush()
                if any(flag in mode for flag in ("a", "w", "+")):
                    os.fsync(handle.fileno())
                if fcntl is not None:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)

    def _last_record_unlocked(self) -> StoredEvent | None:
        last_nonempty: str | None = None
        with self.path.open("r", encoding="utf-8") as handle:
            for line in handle:
                if line.strip():
                    last_nonempty = line
        if last_nonempty is None:
            return None
        return StoredEvent.from_dict(json.loads(last_nonempty))

    def append(self, draft: EventDraft) -> StoredEvent:
        """Commit one event and return the stored record."""

        # A separate lock file avoids taking a second descriptor to read the tail
        # while another process appends.  This keeps the JSONL stream itself clean.
        lock_path = self.path.with_suffix(self.path.suffix + ".lock")
        lock_path.touch(exist_ok=True)
        with lock_path.open("a+", encoding="utf-8") as lock_handle:
            if fcntl is not None:
                fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX)
            try:
                last = self._last_record_unlocked()
                sequence = 1 if last is None else last.sequence + 1
                previous_hash = GENESIS_HASH if last is None else last.record_hash
                event_id = draft.event_id or f"evt-{uuid.uuid4()}"
                unsigned = {
                    "sequence": sequence,
                    "event_id": event_id,
                    "event_type": draft.event_type,
                    "schema_version": draft.schema_version,
                    "subject_anchor": draft.subject_anchor,
                    "context": draft.context,
                    "causal_time": draft.causal_time,
                    "recorded_time": utc_now_iso(),
                    "adopted_time": draft.adopted_time,
                    "payload": dict(draft.payload),
                    "provenance": list(draft.provenance),
                    "dependence_group": draft.dependence_group,
                    "previous_hash": previous_hash,
                }
                record_hash = sha256_hex(canonical_json(unsigned))
                stored = StoredEvent.from_dict({**unsigned, "record_hash": record_hash})
                with self.path.open("a", encoding="utf-8", newline="") as handle:
                    handle.write(canonical_json(stored.to_dict()) + "\n")
                    handle.flush()
                    os.fsync(handle.fileno())
                return stored
            finally:
                if fcntl is not None:
                    fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)

    def iter_records(self) -> Iterator[StoredEvent]:
        with self._locked_file("r") as handle:
            for line_number, line in enumerate(handle, start=1):
                if not line.strip():
                    continue
                try:
                    yield StoredEvent.from_dict(json.loads(line))
                except (json.JSONDecodeError, TypeError, ValueError) as exc:
                    raise ValueError(f"Invalid ledger record on line {line_number}: {exc}") from exc

    def get(self, event_id: str) -> StoredEvent | None:
        for record in self.iter_records():
            if record.event_id == event_id:
                return record
        return None

    def root_hash(self) -> str:
        last = None
        for last in self.iter_records():
            pass
        return GENESIS_HASH if last is None else last.record_hash

    def verify(self) -> LedgerVerification:
        errors: list[str] = []
        previous_hash = GENESIS_HASH
        expected_sequence = 1
        count = 0
        root_hash = GENESIS_HASH
        try:
            records = self.iter_records()
            for record in records:
                count += 1
                if record.sequence != expected_sequence:
                    errors.append(
                        f"sequence mismatch at {record.event_id}: expected {expected_sequence}, got {record.sequence}"
                    )
                if record.previous_hash != previous_hash:
                    errors.append(
                        f"previous_hash mismatch at {record.event_id}: expected {previous_hash}, got {record.previous_hash}"
                    )
                unsigned = record.to_dict()
                stored_hash = unsigned.pop("record_hash")
                computed_hash = sha256_hex(canonical_json(unsigned))
                if stored_hash != computed_hash:
                    errors.append(
                        f"record_hash mismatch at {record.event_id}: expected {computed_hash}, got {stored_hash}"
                    )
                previous_hash = record.record_hash
                root_hash = record.record_hash
                expected_sequence += 1
        except ValueError as exc:
            errors.append(str(exc))
        return LedgerVerification(
            ok=not errors,
            record_count=count,
            root_hash=root_hash,
            errors=tuple(errors),
        )
