"""Substrate-neutral reasoning boundary and backend adapters."""

from .adapters import BackendUnavailable, CallableReasonerAdapter
from .base import (
    DerivationClosureView,
    DifferentialInferenceRequest,
    DifferentialInferenceResult,
    InferenceRequest,
    InferenceResult,
    ReasonerCapabilities,
    RevisionRequest,
    RevisionResult,
    SelfReasoner,
)
from .compatibility import (
    CompatibilityReport,
    CompatibilityTolerance,
    compare_inference_results,
)
from .omegapln_adapter import OmegaPLNAdapter
from .patham9_adapter import Patham9Adapter

__all__ = [
    "BackendUnavailable",
    "CallableReasonerAdapter",
    "CompatibilityReport",
    "CompatibilityTolerance",
    "DerivationClosureView",
    "DifferentialInferenceRequest",
    "DifferentialInferenceResult",
    "InferenceRequest",
    "InferenceResult",
    "OmegaPLNAdapter",
    "Patham9Adapter",
    "ReasonerCapabilities",
    "RevisionRequest",
    "RevisionResult",
    "SelfReasoner",
    "compare_inference_results",
]
