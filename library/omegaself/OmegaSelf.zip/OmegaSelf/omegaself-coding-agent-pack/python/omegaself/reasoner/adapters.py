"""Dependency-injected adapters for Patham9 PLN and OmegaPLN.

The adapters deliberately accept a callable backend so this pack does not claim
a stable import path for rapidly evolving Hyperon libraries.  A deployment binds
that callable at one integration point; the rest of OmegaSelf remains unchanged.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Mapping

from ..applicability import OperationalEstimate
from .base import (
    DerivationClosureView,
    DifferentialInferenceRequest,
    DifferentialInferenceResult,
    InferenceRequest,
    InferenceResult,
    ReasonerCapabilities,
    RevisionRequest,
    RevisionResult,
)

BackendCallable = Callable[[Mapping[str, Any]], Mapping[str, Any]]


class BackendUnavailable(RuntimeError):
    pass


@dataclass
class CallableReasonerAdapter:
    backend_id: str
    backend_version: str
    truth_semantics_id: str
    backend: BackendCallable | None
    _capabilities: ReasonerCapabilities

    @property
    def capabilities(self) -> ReasonerCapabilities:
        return self._capabilities

    def _call(self, payload: Mapping[str, Any]) -> Mapping[str, Any]:
        if self.backend is None:
            raise BackendUnavailable(
                f"{self.backend_id} backend is not bound; inject the target runtime adapter"
            )
        value = self.backend(payload)
        if not isinstance(value, Mapping):
            raise TypeError("reasoner backend must return a mapping")
        return value

    def _estimate(self, raw: Mapping[str, Any], closure_id: str | None) -> OperationalEstimate:
        return OperationalEstimate(
            semantics_id=str(raw.get("truth_semantics_id", self.truth_semantics_id)),
            point_estimate=_optional_float(raw.get("point_estimate")),
            lower_bound=_optional_float(raw.get("lower_bound")),
            upper_bound=_optional_float(raw.get("upper_bound")),
            support_mass=_optional_float(raw.get("support_mass")),
            evidence_quality=str(raw.get("evidence_quality", "unknown")),
            independence_quality=str(raw.get("independence_quality", "unknown")),
            calibration_profile_id=None
            if raw.get("calibration_profile_id") is None
            else str(raw.get("calibration_profile_id")),
            evidence_closure_id=closure_id,
            raw_backend_value=dict(raw.get("raw_backend_value", raw)),
            assumptions=tuple(str(item) for item in raw.get("assumptions", [])),
        )

    def infer(self, request: InferenceRequest) -> InferenceResult:
        raw = self._call({"operation": "infer", "request": request.to_dict()})
        estimate = self._estimate(raw, request.evidence_closure_id)
        return InferenceResult(
            request_id=request.request_id,
            claim=dict(raw.get("claim", request.query)),
            estimate=estimate,
            evidence_event_ids=tuple(str(item) for item in raw.get("evidence_event_ids", [])),
            derivation_trace=tuple(dict(item) for item in raw.get("derivation_trace", [])),
            assumptions=tuple(str(item) for item in raw.get("assumptions", [])),
            backend_id=self.backend_id,
            backend_version=self.backend_version,
            truth_semantics_id=estimate.semantics_id,
            rule_profile_id=request.rule_profile_id,
            convergence_status=str(raw.get("convergence_status", "unknown")),
            provenance_status=str(raw.get("provenance_status", "unknown")),
            warnings=tuple(str(item) for item in raw.get("warnings", [])),
            extensions=dict(raw.get("extensions", {})),
        )

    def revise(self, request: RevisionRequest) -> RevisionResult:
        raw = self._call(
            {
                "operation": "revise",
                "request": {
                    "request_id": request.request_id,
                    "current_claim": dict(request.current_claim),
                    "current_estimate": None
                    if request.current_estimate is None
                    else request.current_estimate.to_dict(),
                    "incoming_evidence_event_ids": list(request.incoming_evidence_event_ids),
                    "context_id": request.context_id,
                    "evidence_snapshot_id": request.evidence_snapshot_id,
                    "rule_profile_id": request.rule_profile_id,
                    "dependence_model_id": request.dependence_model_id,
                    "required_provenance_level": request.required_provenance_level,
                    "extensions": dict(request.extensions),
                },
            }
        )
        estimate = self._estimate(raw, raw.get("evidence_closure_id"))
        return RevisionResult(
            request_id=request.request_id,
            claim=dict(raw.get("claim", request.current_claim)),
            estimate=estimate,
            evidence_event_ids=tuple(str(item) for item in raw.get("evidence_event_ids", [])),
            derivation_trace=tuple(dict(item) for item in raw.get("derivation_trace", [])),
            backend_id=self.backend_id,
            backend_version=self.backend_version,
            truth_semantics_id=estimate.semantics_id,
            provenance_status=str(raw.get("provenance_status", "unknown")),
            warnings=tuple(str(item) for item in raw.get("warnings", [])),
        )

    def explain(self, claim_id: str, evidence_snapshot_id: str) -> DerivationClosureView:
        raw = self._call(
            {
                "operation": "explain",
                "claim_id": claim_id,
                "evidence_snapshot_id": evidence_snapshot_id,
            }
        )
        return DerivationClosureView(
            claim_id=claim_id,
            evidence_snapshot_id=evidence_snapshot_id,
            evidence_event_ids=tuple(str(item) for item in raw.get("evidence_event_ids", [])),
            derivation_trace=tuple(dict(item) for item in raw.get("derivation_trace", [])),
            provenance_closed=bool(raw.get("provenance_closed", False)),
            missing_event_ids=tuple(str(item) for item in raw.get("missing_event_ids", [])),
            root_hash=str(raw.get("root_hash", "")),
        )

    def compare(self, request: DifferentialInferenceRequest) -> DifferentialInferenceResult:
        raw = self._call(
            {
                "operation": "compare",
                "request_id": request.request_id,
                "base_request": request.base_request.to_dict(),
                "policy_profile_ids": list(request.policy_profile_ids),
            }
        )
        results: dict[str, InferenceResult] = {}
        for policy_id, value in dict(raw.get("results_by_policy", {})).items():
            if not isinstance(value, Mapping):
                raise TypeError("comparison result entries must be mappings")
            estimate = self._estimate(value, request.base_request.evidence_closure_id)
            results[str(policy_id)] = InferenceResult(
                request_id=request.base_request.request_id,
                claim=dict(value.get("claim", request.base_request.query)),
                estimate=estimate,
                evidence_event_ids=tuple(str(item) for item in value.get("evidence_event_ids", [])),
                derivation_trace=tuple(dict(item) for item in value.get("derivation_trace", [])),
                assumptions=tuple(str(item) for item in value.get("assumptions", [])),
                backend_id=self.backend_id,
                backend_version=self.backend_version,
                truth_semantics_id=estimate.semantics_id,
                rule_profile_id=request.base_request.rule_profile_id,
                convergence_status=str(value.get("convergence_status", "unknown")),
                provenance_status=str(value.get("provenance_status", "unknown")),
                warnings=tuple(str(item) for item in value.get("warnings", [])),
            )
        return DifferentialInferenceResult(
            request_id=request.request_id,
            results_by_policy=results,
            differing_claim_fields=tuple(str(item) for item in raw.get("differing_claim_fields", [])),
            differing_estimate_fields=tuple(
                str(item) for item in raw.get("differing_estimate_fields", [])
            ),
            warnings=tuple(str(item) for item in raw.get("warnings", [])),
        )


def _optional_float(value: Any) -> float | None:
    return None if value is None else float(value)
