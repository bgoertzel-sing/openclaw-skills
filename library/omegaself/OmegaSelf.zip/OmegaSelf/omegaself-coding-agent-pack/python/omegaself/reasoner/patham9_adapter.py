"""Patham9 PLN adapter bound to the substrate-neutral reasoner seam."""

from __future__ import annotations

from .adapters import BackendCallable, CallableReasonerAdapter
from .base import ReasonerCapabilities


class Patham9Adapter(CallableReasonerAdapter):
    def __init__(
        self,
        backend: BackendCallable | None,
        *,
        backend_version: str = "unbound",
        truth_semantics_id: str = "patham9-nal-stv-v1",
    ) -> None:
        super().__init__(
            backend_id="patham9-pln",
            backend_version=backend_version,
            truth_semantics_id=truth_semantics_id,
            backend=backend,
            _capabilities=ReasonerCapabilities(
                backend_id="patham9-pln",
                backend_version=backend_version,
                truth_semantics_id=truth_semantics_id,
                supports_revision=True,
                supports_nonmonotonic_retraction=False,
                supports_dependence_stamps=False,
                supports_full_derivation_closure=False,
                supports_bounded_soundness=False,
                supports_counterfactual_spaces=True,
                extensions={"status": "integration-adapter"},
            ),
        )
