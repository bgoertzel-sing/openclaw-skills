"""Substrate-neutral reasoning service-provider interface.

The rest of OmegaSelf asks for typed inference, revision, explanation, and
policy-differential comparison.  It does not import Patham9- or OmegaPLN-specific
truth-value classes.  Backend-specific values remain available in the result for
audit, but governance consumes only the normalized operational envelope.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Mapping, Protocol, Sequence

from ..applicability import OperationalEstimate


@dataclass(frozen=True)
class ReasonerCapabilities:
    backend_id: str
    backend_version: str
    truth_semantics_id: str
    supports_revision: bool
    supports_nonmonotonic_retraction: bool
    supports_dependence_stamps: bool
    supports_full_derivation_closure: bool
    supports_bounded_soundness: bool
    supports_counterfactual_spaces: bool
    extensions: Mapping[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["extensions"] = dict(self.extensions)
        return value


@dataclass(frozen=True)
class InferenceRequest:
    request_id: str
    query: Mapping[str, Any]
    context_id: str
    evidence_snapshot_id: str
    evidence_closure_id: str
    rule_profile_id: str
    prior_bundle_id: str | None
    dependence_model_id: str
    inference_budget: Mapping[str, Any]
    required_provenance_level: str
    required_assurance_mode: str
    extensions: Mapping[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        for key in ("query", "inference_budget", "extensions"):
            value[key] = dict(value[key])
        return value


@dataclass(frozen=True)
class InferenceResult:
    request_id: str
    claim: Mapping[str, Any]
    estimate: OperationalEstimate
    evidence_event_ids: Sequence[str]
    derivation_trace: Sequence[Mapping[str, Any]]
    assumptions: Sequence[str]
    backend_id: str
    backend_version: str
    truth_semantics_id: str
    rule_profile_id: str
    convergence_status: str
    provenance_status: str
    warnings: Sequence[str] = field(default_factory=tuple)
    extensions: Mapping[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "request_id": self.request_id,
            "claim": dict(self.claim),
            "estimate": self.estimate.to_dict(),
            "evidence_event_ids": list(self.evidence_event_ids),
            "derivation_trace": [dict(item) for item in self.derivation_trace],
            "assumptions": list(self.assumptions),
            "backend_id": self.backend_id,
            "backend_version": self.backend_version,
            "truth_semantics_id": self.truth_semantics_id,
            "rule_profile_id": self.rule_profile_id,
            "convergence_status": self.convergence_status,
            "provenance_status": self.provenance_status,
            "warnings": list(self.warnings),
            "extensions": dict(self.extensions),
        }


@dataclass(frozen=True)
class RevisionRequest:
    request_id: str
    current_claim: Mapping[str, Any]
    current_estimate: OperationalEstimate | None
    incoming_evidence_event_ids: Sequence[str]
    context_id: str
    evidence_snapshot_id: str
    rule_profile_id: str
    dependence_model_id: str
    required_provenance_level: str
    extensions: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class RevisionResult:
    request_id: str
    claim: Mapping[str, Any]
    estimate: OperationalEstimate
    evidence_event_ids: Sequence[str]
    derivation_trace: Sequence[Mapping[str, Any]]
    backend_id: str
    backend_version: str
    truth_semantics_id: str
    provenance_status: str
    warnings: Sequence[str] = field(default_factory=tuple)


@dataclass(frozen=True)
class DerivationClosureView:
    claim_id: str
    evidence_snapshot_id: str
    evidence_event_ids: Sequence[str]
    derivation_trace: Sequence[Mapping[str, Any]]
    provenance_closed: bool
    missing_event_ids: Sequence[str]
    root_hash: str


@dataclass(frozen=True)
class DifferentialInferenceRequest:
    request_id: str
    base_request: InferenceRequest
    policy_profile_ids: Sequence[str]


@dataclass(frozen=True)
class DifferentialInferenceResult:
    request_id: str
    results_by_policy: Mapping[str, InferenceResult]
    differing_claim_fields: Sequence[str]
    differing_estimate_fields: Sequence[str]
    warnings: Sequence[str] = field(default_factory=tuple)


class SelfReasoner(Protocol):
    """Production seam implemented by Patham9 and OmegaPLN adapters."""

    @property
    def capabilities(self) -> ReasonerCapabilities: ...

    def infer(self, request: InferenceRequest) -> InferenceResult: ...

    def revise(self, request: RevisionRequest) -> RevisionResult: ...

    def explain(self, claim_id: str, evidence_snapshot_id: str) -> DerivationClosureView: ...

    def compare(self, request: DifferentialInferenceRequest) -> DifferentialInferenceResult: ...
