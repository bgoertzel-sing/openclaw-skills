"""Golden, semantic, and decision-differential reasoner comparisons."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from .base import InferenceResult


@dataclass(frozen=True)
class CompatibilityTolerance:
    point_estimate: float = 1e-9
    lower_bound: float = 1e-9
    upper_bound: float = 1e-9
    support_mass: float = 1e-9


@dataclass(frozen=True)
class CompatibilityReport:
    compatible: bool
    differences: Sequence[str]
    warnings: Sequence[str]


def compare_inference_results(
    expected: InferenceResult,
    actual: InferenceResult,
    *,
    tolerance: CompatibilityTolerance | None = None,
    require_exact_semantics: bool = True,
    require_exact_evidence: bool = True,
) -> CompatibilityReport:
    tol = tolerance or CompatibilityTolerance()
    differences: list[str] = []
    warnings: list[str] = []

    if dict(expected.claim) != dict(actual.claim):
        differences.append("claim differs")
    if require_exact_semantics and expected.truth_semantics_id != actual.truth_semantics_id:
        differences.append("truth semantics differs")
    elif expected.truth_semantics_id != actual.truth_semantics_id:
        warnings.append("truth semantics differs; comparing normalized envelope only")

    for field, epsilon in (
        ("point_estimate", tol.point_estimate),
        ("lower_bound", tol.lower_bound),
        ("upper_bound", tol.upper_bound),
        ("support_mass", tol.support_mass),
    ):
        left = getattr(expected.estimate, field)
        right = getattr(actual.estimate, field)
        if left is None or right is None:
            if left != right:
                differences.append(f"{field} presence differs")
        elif abs(left - right) > epsilon:
            differences.append(f"{field} differs: {left} vs {right}")

    expected_evidence = tuple(sorted(set(expected.evidence_event_ids)))
    actual_evidence = tuple(sorted(set(actual.evidence_event_ids)))
    if expected_evidence != actual_evidence:
        message = "evidence identity set differs"
        if require_exact_evidence:
            differences.append(message)
        else:
            warnings.append(message)
    if expected.provenance_status != actual.provenance_status:
        differences.append("provenance status differs")
    return CompatibilityReport(
        compatible=not differences,
        differences=tuple(differences),
        warnings=tuple(warnings),
    )
