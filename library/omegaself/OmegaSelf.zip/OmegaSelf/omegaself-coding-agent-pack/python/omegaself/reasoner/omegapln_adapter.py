"""OmegaPLN adapter bound to the substrate-neutral reasoner seam."""

from __future__ import annotations

from .adapters import BackendCallable, CallableReasonerAdapter
from .base import ReasonerCapabilities


class OmegaPLNAdapter(CallableReasonerAdapter):
    def __init__(
        self,
        backend: BackendCallable | None,
        *,
        backend_version: str = "unbound",
        truth_semantics_id: str = "omegapln-evidence-envelope-v1",
    ) -> None:
        super().__init__(
            backend_id="omegapln",
            backend_version=backend_version,
            truth_semantics_id=truth_semantics_id,
            backend=backend,
            _capabilities=ReasonerCapabilities(
                backend_id="omegapln",
                backend_version=backend_version,
                truth_semantics_id=truth_semantics_id,
                supports_revision=True,
                supports_nonmonotonic_retraction=True,
                supports_dependence_stamps=True,
                supports_full_derivation_closure=True,
                supports_bounded_soundness=True,
                supports_counterfactual_spaces=True,
                extensions={"status": "integration-adapter"},
            ),
        )
