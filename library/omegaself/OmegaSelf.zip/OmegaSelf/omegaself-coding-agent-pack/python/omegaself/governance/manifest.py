"""Versioned signed governance policy manifests."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field, replace
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Mapping, Sequence

from ..canonical import canonical_json, sha256_hex
from .signature import SignatureVerifier


def _parse_time(value: str) -> datetime:
    normalized = value[:-1] + "+00:00" if value.endswith("Z") else value
    result = datetime.fromisoformat(normalized)
    if result.tzinfo is None:
        result = result.replace(tzinfo=timezone.utc)
    return result.astimezone(timezone.utc)


class PolicyAuthorityStatus(str, Enum):
    VERIFIED = "verified"
    UNVERIFIED = "unverified"
    BAD_SIGNATURE = "bad_signature"
    EXPIRED = "expired"
    NOT_YET_VALID = "not_yet_valid"
    WRONG_SEMANTICS = "wrong_semantics"
    REVOKED = "revoked"
    HASH_MISMATCH = "hash_mismatch"
    WRONG_ISSUER = "wrong_issuer"


@dataclass(frozen=True)
class PolicyManifest:
    policy_id: str
    policy_version: str
    parent_policy_hash: str | None
    issuer: str
    issuer_key_id: str
    effective_at: str
    expires_at: str
    admissible_action_classes: Sequence[str]
    capability_thresholds: Mapping[str, float]
    assurance_requirements: Mapping[str, str]
    continuity_requirements: Mapping[str, str]
    review_requirements: Mapping[str, str]
    protected_invariants: Sequence[str]
    permitted_overrides: Sequence[str]
    reasoner_semantics_id: str
    calibration_profile_id: str | None
    regularization_profile_id: str | None
    signature_algorithm: str
    signature: str
    manifest_hash: str
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def unsigned_payload(self) -> dict[str, Any]:
        value = asdict(self)
        value.pop("signature", None)
        value.pop("manifest_hash", None)
        value["admissible_action_classes"] = list(self.admissible_action_classes)
        value["protected_invariants"] = list(self.protected_invariants)
        value["permitted_overrides"] = list(self.permitted_overrides)
        value["capability_thresholds"] = dict(self.capability_thresholds)
        value["assurance_requirements"] = dict(self.assurance_requirements)
        value["continuity_requirements"] = dict(self.continuity_requirements)
        value["review_requirements"] = dict(self.review_requirements)
        value["metadata"] = dict(self.metadata)
        return value

    def canonical_unsigned_bytes(self) -> bytes:
        return canonical_json(self.unsigned_payload()).encode("utf-8")

    def computed_hash(self) -> str:
        return sha256_hex(self.canonical_unsigned_bytes())

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["admissible_action_classes"] = list(self.admissible_action_classes)
        value["protected_invariants"] = list(self.protected_invariants)
        value["permitted_overrides"] = list(self.permitted_overrides)
        value["capability_thresholds"] = dict(self.capability_thresholds)
        value["assurance_requirements"] = dict(self.assurance_requirements)
        value["continuity_requirements"] = dict(self.continuity_requirements)
        value["review_requirements"] = dict(self.review_requirements)
        value["metadata"] = dict(self.metadata)
        return value


@dataclass(frozen=True)
class PolicyAuthorityAssessment:
    status: PolicyAuthorityStatus
    policy_id: str | None
    manifest_hash: str | None
    reasoner_semantics_id: str | None
    issuer: str | None
    reasons: Sequence[str]
    verified_at: str

    @property
    def verified(self) -> bool:
        return self.status is PolicyAuthorityStatus.VERIFIED

    @classmethod
    def unverified(cls, reason: str = "policy manifest was not verified") -> "PolicyAuthorityAssessment":
        now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        return cls(
            status=PolicyAuthorityStatus.UNVERIFIED,
            policy_id=None,
            manifest_hash=None,
            reasoner_semantics_id=None,
            issuer=None,
            reasons=(reason,),
            verified_at=now,
        )


def sign_manifest(
    manifest: PolicyManifest,
    *,
    signer: Any,
) -> PolicyManifest:
    """Return a copy with canonical hash and signature populated.

    ``signer`` must expose ``sign(payload=bytes, key_id=str) -> str``.  This is
    intentionally separate from the gate so the agent cannot silently self-sign.
    """

    manifest_hash = manifest.computed_hash()
    signature = signer.sign(
        payload=manifest.canonical_unsigned_bytes(),
        key_id=manifest.issuer_key_id,
    )
    return replace(manifest, manifest_hash=manifest_hash, signature=signature)


def verify_policy_manifest(
    manifest: PolicyManifest,
    *,
    verifier: SignatureVerifier,
    required_reasoner_semantics_id: str | None = None,
    allowed_issuers: Sequence[str] = (),
    revoked_policy_ids: Sequence[str] = (),
    revoked_key_ids: Sequence[str] = (),
    now: datetime | None = None,
) -> PolicyAuthorityAssessment:
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    current_iso = current.isoformat().replace("+00:00", "Z")

    def assessment(status: PolicyAuthorityStatus, *reasons: str) -> PolicyAuthorityAssessment:
        return PolicyAuthorityAssessment(
            status=status,
            policy_id=manifest.policy_id,
            manifest_hash=manifest.manifest_hash,
            reasoner_semantics_id=manifest.reasoner_semantics_id,
            issuer=manifest.issuer,
            reasons=tuple(reasons),
            verified_at=current_iso,
        )

    if manifest.policy_id in set(revoked_policy_ids) or manifest.issuer_key_id in set(revoked_key_ids):
        return assessment(PolicyAuthorityStatus.REVOKED, "policy or signing key is revoked")
    if allowed_issuers and manifest.issuer not in set(allowed_issuers):
        return assessment(PolicyAuthorityStatus.WRONG_ISSUER, "issuer is not trusted")
    if manifest.computed_hash() != manifest.manifest_hash:
        return assessment(PolicyAuthorityStatus.HASH_MISMATCH, "manifest hash does not match canonical payload")
    if current < _parse_time(manifest.effective_at):
        return assessment(PolicyAuthorityStatus.NOT_YET_VALID, "policy is not yet effective")
    if current >= _parse_time(manifest.expires_at):
        return assessment(PolicyAuthorityStatus.EXPIRED, "policy manifest has expired")
    if (
        required_reasoner_semantics_id is not None
        and manifest.reasoner_semantics_id != required_reasoner_semantics_id
    ):
        return assessment(
            PolicyAuthorityStatus.WRONG_SEMANTICS,
            "policy was signed for a different reasoner semantics profile",
        )
    if not verifier.verify(
        payload=manifest.canonical_unsigned_bytes(),
        signature=manifest.signature,
        key_id=manifest.issuer_key_id,
        algorithm=manifest.signature_algorithm,
    ):
        return assessment(PolicyAuthorityStatus.BAD_SIGNATURE, "policy signature verification failed")
    return assessment(PolicyAuthorityStatus.VERIFIED, "policy authority verified")
