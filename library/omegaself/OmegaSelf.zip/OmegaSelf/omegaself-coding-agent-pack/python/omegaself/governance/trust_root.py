"""Externally configured policy trust-root wrapper."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Sequence

from .manifest import PolicyAuthorityAssessment, PolicyManifest, verify_policy_manifest
from .signature import SignatureVerifier


@dataclass(frozen=True)
class ExternalPolicyTrustRoot:
    verifier: SignatureVerifier
    allowed_issuers: Sequence[str] = field(default_factory=tuple)
    revoked_policy_ids: Sequence[str] = field(default_factory=tuple)
    revoked_key_ids: Sequence[str] = field(default_factory=tuple)

    def assess(
        self,
        manifest: PolicyManifest,
        *,
        required_reasoner_semantics_id: str | None = None,
        now: datetime | None = None,
    ) -> PolicyAuthorityAssessment:
        return verify_policy_manifest(
            manifest,
            verifier=self.verifier,
            required_reasoner_semantics_id=required_reasoner_semantics_id,
            allowed_issuers=self.allowed_issuers,
            revoked_policy_ids=self.revoked_policy_ids,
            revoked_key_ids=self.revoked_key_ids,
            now=now,
        )
