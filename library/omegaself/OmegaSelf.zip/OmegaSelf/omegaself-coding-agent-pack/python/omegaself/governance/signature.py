"""Signature-verification interfaces for externally rooted policy authority.

The dependency-free HMAC implementation is suitable for tests and isolated
examples only.  A production deployment should provide an asymmetric verifier
(Ed25519, a hardware root, or a remote policy authority) whose signing key is not
available to the agent process.
"""

from __future__ import annotations

import hashlib
import hmac
from dataclasses import dataclass
from typing import Mapping, Protocol


class SignatureVerifier(Protocol):
    def verify(
        self,
        *,
        payload: bytes,
        signature: str,
        key_id: str,
        algorithm: str,
    ) -> bool: ...


@dataclass(frozen=True)
class HmacSha256TrustRoot:
    """Test-only symmetric trust root.

    Keeping the key in the agent process would not provide an exogenous policy
    root.  Use this class for deterministic reference tests, never as the final
    production authority boundary.
    """

    keys: Mapping[str, bytes]

    def sign(self, *, payload: bytes, key_id: str) -> str:
        key = self.keys.get(key_id)
        if key is None:
            raise KeyError(f"unknown key_id: {key_id}")
        return hmac.new(key, payload, hashlib.sha256).hexdigest()

    def verify(
        self,
        *,
        payload: bytes,
        signature: str,
        key_id: str,
        algorithm: str,
    ) -> bool:
        if algorithm != "hmac-sha256-test-only":
            return False
        key = self.keys.get(key_id)
        if key is None:
            return False
        expected = hmac.new(key, payload, hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, signature)
