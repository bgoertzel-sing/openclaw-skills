"""Typed domain objects shared across the OmegaSelf reference runtime."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Mapping, Sequence


class Facet(str, Enum):
    SUBSTRATE = "substrate"
    CAPABILITY = "capability"
    EPISTEMIC = "epistemic"
    CONATIVE = "conative"
    SOCIAL = "social"
    CONTINUITY = "continuity"
    APPRAISAL = "appraisal"
    GOVERNANCE = "governance"


class Severity(str, Enum):
    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class Decision(str, Enum):
    ALLOW = "allow"
    DENY = "deny"
    REQUIRE_PROBE = "require_probe"
    REQUIRE_REVIEW = "require_review"
    DEFER = "defer"


class AnchorStatus(str, Enum):
    RESOLVED = "resolved"
    DEGRADED = "degraded"
    UNRESOLVED = "unresolved"


@dataclass(frozen=True)
class EventDraft:
    """Uncommitted ledger event.

    ``causal_time`` is when the represented event occurred. ``recorded_time`` is
    assigned by the ledger. ``adopted_time`` is optional and records when a
    belief was adopted because of the event.  The separation prevents later
    summaries from masquerading as original observations.
    """

    event_type: str
    subject_anchor: str
    context: str
    payload: Mapping[str, Any]
    causal_time: str
    adopted_time: str | None = None
    provenance: Sequence[str] = field(default_factory=tuple)
    dependence_group: str | None = None
    event_id: str | None = None
    schema_version: str = "1.0"

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["provenance"] = list(self.provenance)
        result["payload"] = dict(self.payload)
        return result


@dataclass(frozen=True)
class StoredEvent:
    sequence: int
    event_id: str
    event_type: str
    schema_version: str
    subject_anchor: str
    context: str
    causal_time: str
    recorded_time: str
    adopted_time: str | None
    payload: Mapping[str, Any]
    provenance: Sequence[str]
    dependence_group: str | None
    previous_hash: str
    record_hash: str

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["payload"] = dict(self.payload)
        data["provenance"] = list(self.provenance)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "StoredEvent":
        required = {
            "sequence",
            "event_id",
            "event_type",
            "schema_version",
            "subject_anchor",
            "context",
            "causal_time",
            "recorded_time",
            "adopted_time",
            "payload",
            "provenance",
            "dependence_group",
            "previous_hash",
            "record_hash",
        }
        missing = required.difference(data)
        if missing:
            raise ValueError(f"Stored event is missing fields: {sorted(missing)}")
        return cls(
            sequence=int(data["sequence"]),
            event_id=str(data["event_id"]),
            event_type=str(data["event_type"]),
            schema_version=str(data["schema_version"]),
            subject_anchor=str(data["subject_anchor"]),
            context=str(data["context"]),
            causal_time=str(data["causal_time"]),
            recorded_time=str(data["recorded_time"]),
            adopted_time=None if data["adopted_time"] is None else str(data["adopted_time"]),
            payload=dict(data["payload"]),
            provenance=tuple(str(item) for item in data["provenance"]),
            dependence_group=None
            if data["dependence_group"] is None
            else str(data["dependence_group"]),
            previous_hash=str(data["previous_hash"]),
            record_hash=str(data["record_hash"]),
        )


@dataclass(frozen=True)
class ActionProposal:
    proposal_id: str
    action_type: str
    action_class: str
    arguments: Mapping[str, Any]
    context: str
    subject_anchor: str
    reversible: bool
    external_effect: bool
    estimated_impact: Severity = Severity.MEDIUM
    required_capability: str | None = None
    evidence_closure_id: str | None = None
    prediction_id: str | None = None
    commitment_refs: Sequence[str] = field(default_factory=tuple)

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["estimated_impact"] = self.estimated_impact.value
        data["arguments"] = dict(self.arguments)
        data["commitment_refs"] = list(self.commitment_refs)
        return data


@dataclass(frozen=True)
class PolicyDecision:
    proposal_id: str
    decision: Decision
    policy_id: str
    policy_manifest_hash: str
    reasoner_semantics_id: str
    reasons: Sequence[str]
    required_followups: Sequence[str] = field(default_factory=tuple)
    evidence_refs: Sequence[str] = field(default_factory=tuple)

    def to_dict(self) -> dict[str, Any]:
        return {
            "proposal_id": self.proposal_id,
            "decision": self.decision.value,
            "policy_id": self.policy_id,
            "policy_manifest_hash": self.policy_manifest_hash,
            "reasoner_semantics_id": self.reasoner_semantics_id,
            "reasons": list(self.reasons),
            "required_followups": list(self.required_followups),
            "evidence_refs": list(self.evidence_refs),
        }
