from __future__ import annotations

import unittest
from datetime import datetime, timedelta, timezone

from omegaself.applicability import ApplicabilityStatus
from omegaself.continuity import CertificateClass, ContinuityAnalysisResult, ContinuityStatus
from omegaself.governance import verify_policy_manifest
from omegaself.policy import GateConfig, PolicyGate
from omegaself.types import ActionProposal, AnchorStatus, Decision, Severity
from support import current_applicability, operational_estimate, proposal_context, signed_manifest, verified_gate


def proposal(**changes):
    values = dict(
        proposal_id="proposal-1",
        action_type="read_file",
        action_class="read",
        arguments={"path": "/tmp/x"},
        context="test",
        subject_anchor="anchor-a",
        reversible=True,
        external_effect=False,
        estimated_impact=Severity.LOW,
        required_capability="file-read",
        evidence_closure_id="closure-1",
        prediction_id="prediction-1",
    )
    values.update(changes)
    return ActionProposal(**values)


class PolicyTests(unittest.TestCase):
    def test_happy_path_allows(self) -> None:
        decision = verified_gate().evaluate(proposal(), proposal_context())
        self.assertEqual(decision.decision, Decision.ALLOW)

    def test_unverified_policy_authority_defers(self) -> None:
        decision = PolicyGate().evaluate(proposal(), proposal_context())
        self.assertEqual(decision.decision, Decision.DEFER)

    def test_expired_policy_authority_cannot_authorize(self) -> None:
        now = datetime.now(timezone.utc)
        manifest, root = signed_manifest(now=now, expires_delta=timedelta(seconds=-1))
        authority = verify_policy_manifest(manifest, verifier=root, now=now)
        gate = PolicyGate(GateConfig.from_manifest(manifest), authority)
        decision = gate.evaluate(proposal(), proposal_context())
        self.assertEqual(decision.decision, Decision.DEFER)

    def test_unresolved_anchor_denies_external_action(self) -> None:
        action = proposal(external_effect=True, action_class="send_message")
        decision = verified_gate().evaluate(
            action, proposal_context(anchor_status=AnchorStatus.UNRESOLVED)
        )
        self.assertEqual(decision.decision, Decision.DENY)

    def test_missing_provenance_requires_probe(self) -> None:
        decision = verified_gate().evaluate(
            proposal(), proposal_context(evidence_provenance_closed=False)
        )
        self.assertEqual(decision.decision, Decision.REQUIRE_PROBE)

    def test_high_impact_mutation_cache_miss_requires_review(self) -> None:
        action = proposal(
            action_type="install_skill",
            action_class="mutation",
            reversible=False,
            external_effect=True,
            estimated_impact=Severity.HIGH,
        )
        decision = verified_gate().evaluate(
            action,
            proposal_context(continuity_result=ContinuityAnalysisResult.cache_miss()),
        )
        self.assertEqual(decision.decision, Decision.REQUIRE_REVIEW)

    def test_heuristic_continuity_never_authorizes_high_impact_mutation(self) -> None:
        action = proposal(
            action_type="rewrite_policy_adapter",
            action_class="mutation",
            reversible=False,
            external_effect=True,
            estimated_impact=Severity.HIGH,
        )
        continuity = ContinuityAnalysisResult(
            status=ContinuityStatus.HEURISTIC,
            certificate_id="ccert-heuristic",
            certificate_class=None,
            exact_input_match=True,
            reasons=("speculative extension",),
        )
        decision = verified_gate().evaluate(
            action, proposal_context(continuity_result=continuity)
        )
        self.assertEqual(decision.decision, Decision.REQUIRE_REVIEW)

    def test_forged_verified_status_without_certificate_class_requires_review(self) -> None:
        action = proposal(
            action_type="install_reversible_skill",
            action_class="mutation",
            reversible=True,
            external_effect=False,
            estimated_impact=Severity.MEDIUM,
        )
        continuity = ContinuityAnalysisResult(
            status=ContinuityStatus.VERIFIED,
            certificate_id="ccert-status-only",
            certificate_class=None,
            exact_input_match=True,
            reasons=("unverified status flag",),
        )
        decision = verified_gate().evaluate(
            action, proposal_context(continuity_result=continuity)
        )
        self.assertEqual(decision.decision, Decision.REQUIRE_REVIEW)

    def test_verified_continuity_can_pass_mutation_gate(self) -> None:
        action = proposal(
            action_type="install_reversible_skill",
            action_class="mutation",
            reversible=True,
            external_effect=False,
            estimated_impact=Severity.MEDIUM,
        )
        continuity = ContinuityAnalysisResult(
            status=ContinuityStatus.VERIFIED,
            certificate_id="ccert-verified",
            certificate_class=CertificateClass.VERIFIED,
            exact_input_match=True,
            reasons=("verified",),
        )
        decision = verified_gate().evaluate(
            action, proposal_context(continuity_result=continuity)
        )
        self.assertEqual(decision.decision, Decision.ALLOW)

    def test_counterfactual_leakage_is_denied(self) -> None:
        decision = verified_gate().evaluate(
            proposal(), proposal_context(counterfactual_taint=True)
        )
        self.assertEqual(decision.decision, Decision.DENY)

    def test_stale_evidence_requires_probe_but_is_not_deleted(self) -> None:
        stale = current_applicability()
        stale = type(stale)(
            **{**stale.__dict__, "status": ApplicabilityStatus.STALE, "applicability": 0.0}
        )
        decision = verified_gate().evaluate(proposal(), proposal_context(applicability=stale))
        self.assertEqual(decision.decision, Decision.REQUIRE_PROBE)
        self.assertTrue(any("do not delete" in item for item in decision.required_followups))

    def test_semantics_mismatch_defers(self) -> None:
        decision = verified_gate().evaluate(
            proposal(), proposal_context(reasoner_semantics_id="patham9-nal-stv-v1")
        )
        self.assertEqual(decision.decision, Decision.DEFER)

    def test_raw_backend_stv_does_not_override_low_lower_bound(self) -> None:
        estimate = operational_estimate(lower_bound=0.2, point_estimate=0.99)
        decision = verified_gate().evaluate(
            proposal(), proposal_context(capability_estimate=estimate)
        )
        self.assertEqual(decision.decision, Decision.REQUIRE_PROBE)


if __name__ == "__main__":
    unittest.main()
