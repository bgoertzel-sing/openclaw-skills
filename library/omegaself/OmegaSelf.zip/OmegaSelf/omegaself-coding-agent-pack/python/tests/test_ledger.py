from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from omegaself.canonical import utc_now_iso
from omegaself.ledger import HashChainLedger
from omegaself.types import EventDraft


class LedgerTests(unittest.TestCase):
    def test_append_and_verify(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            ledger = HashChainLedger(Path(temp_dir) / "ledger.jsonl")
            first = ledger.append(
                EventDraft(
                    event_type="runtime_probe",
                    subject_anchor="anchor-a",
                    context="test",
                    payload={"ok": True},
                    causal_time=utc_now_iso(),
                )
            )
            second = ledger.append(
                EventDraft(
                    event_type="prediction_resolution",
                    subject_anchor="anchor-a",
                    context="test",
                    payload={"observed": True},
                    causal_time=utc_now_iso(),
                    provenance=(first.event_id,),
                )
            )
            report = ledger.verify()
            self.assertTrue(report.ok, report.errors)
            self.assertEqual(report.record_count, 2)
            self.assertEqual(report.root_hash, second.record_hash)
            self.assertEqual(ledger.get(first.event_id), first)

    def test_tampering_is_detected(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "ledger.jsonl"
            ledger = HashChainLedger(path)
            ledger.append(
                EventDraft(
                    event_type="runtime_probe",
                    subject_anchor="anchor-a",
                    context="test",
                    payload={"value": 1},
                    causal_time=utc_now_iso(),
                )
            )
            record = json.loads(path.read_text(encoding="utf-8"))
            record["payload"]["value"] = 2
            path.write_text(json.dumps(record) + "\n", encoding="utf-8")
            report = ledger.verify()
            self.assertFalse(report.ok)
            self.assertTrue(any("record_hash mismatch" in error for error in report.errors))


if __name__ == "__main__":
    unittest.main()
