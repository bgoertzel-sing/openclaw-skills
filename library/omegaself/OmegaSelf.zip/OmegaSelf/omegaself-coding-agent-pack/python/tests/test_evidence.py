from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from omegaself.canonical import utc_now_iso
from omegaself.evidence import EvidenceClosureBuilder
from omegaself.ledger import HashChainLedger
from omegaself.types import EventDraft


class EvidenceTests(unittest.TestCase):
    def test_closure_follows_provenance_and_groups_dependence(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            ledger = HashChainLedger(Path(temp_dir) / "ledger.jsonl")
            a = ledger.append(
                EventDraft(
                    event_type="capability_outcome",
                    subject_anchor="anchor-a",
                    context="pdf",
                    payload={"success": True},
                    causal_time=utc_now_iso(),
                    dependence_group="provider-run-1",
                )
            )
            b = ledger.append(
                EventDraft(
                    event_type="capability_outcome",
                    subject_anchor="anchor-a",
                    context="pdf",
                    payload={"success": True},
                    causal_time=utc_now_iso(),
                    dependence_group="provider-run-1",
                    provenance=(a.event_id,),
                )
            )
            c = ledger.append(
                EventDraft(
                    event_type="external_evaluation",
                    subject_anchor="anchor-a",
                    context="pdf",
                    payload={"score": 0.8},
                    causal_time=utc_now_iso(),
                    provenance=(b.event_id,),
                )
            )
            closure = EvidenceClosureBuilder(ledger).build([c.event_id], "closure-1")
            self.assertTrue(closure.provenance_closed)
            self.assertEqual(set(closure.member_event_ids), {a.event_id, b.event_id, c.event_id})
            self.assertEqual(set(closure.dependence_groups["provider-run-1"]), {a.event_id, b.event_id})
            self.assertEqual(len(closure.independent_units), 2)

    def test_disqualification_is_append_only_and_not_counted_as_support(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            ledger = HashChainLedger(Path(temp_dir) / "ledger.jsonl")
            evidence = ledger.append(
                EventDraft(
                    event_type="capability_outcome",
                    subject_anchor="anchor-a",
                    context="pdf",
                    payload={"success": True},
                    causal_time=utc_now_iso(),
                )
            )
            disqualification = ledger.append(
                EventDraft(
                    event_type="evidence_disqualification",
                    subject_anchor="anchor-a",
                    context="pdf",
                    payload={"target_event_id": evidence.event_id, "reason": "instrument compromised"},
                    causal_time=utc_now_iso(),
                    provenance=(evidence.event_id,),
                )
            )
            closure = EvidenceClosureBuilder(ledger).build([disqualification.event_id], "closure-dq")
            self.assertIn(evidence.event_id, closure.member_event_ids)
            self.assertIn(evidence.event_id, closure.disqualified_event_ids)
            self.assertNotIn(evidence.event_id, closure.active_event_ids)
            self.assertIn(disqualification.event_id, closure.control_event_ids)
            self.assertEqual(closure.independent_units, ())

    def test_missing_parent_breaks_provenance_closure(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            ledger = HashChainLedger(Path(temp_dir) / "ledger.jsonl")
            event = ledger.append(
                EventDraft(
                    event_type="belief_derivation",
                    subject_anchor="anchor-a",
                    context="test",
                    payload={},
                    causal_time=utc_now_iso(),
                    provenance=("missing-parent",),
                )
            )
            closure = EvidenceClosureBuilder(ledger).build([event.event_id], "closure-2")
            self.assertFalse(closure.provenance_closed)
            self.assertEqual(closure.missing_event_ids, ("missing-parent",))


if __name__ == "__main__":
    unittest.main()
