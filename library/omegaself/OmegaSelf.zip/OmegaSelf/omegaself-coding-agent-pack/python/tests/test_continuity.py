from __future__ import annotations

import unittest
from datetime import datetime, timedelta, timezone

from omegaself.continuity import (
    CertificateClass,
    ContinuityCache,
    ContinuityCertificate,
    ContinuityOutcome,
    ContinuityStatus,
    sign_continuity_certificate,
    verify_continuity_certificate,
)
from omegaself.governance import HmacSha256TrustRoot


KEY_ID = "continuity-test-key"
ROOT = HmacSha256TrustRoot({KEY_ID: b"continuity-test-secret"})


def expected_inputs() -> dict[str, str]:
    return {
        "from_snapshot_hash": "snap-a",
        "proposal_hash": "proposal-hash",
        "predicted_to_state_hash": "snap-b",
        "evidence_snapshot_hash": "evidence-root",
        "policy_manifest_hash": "policy-root",
        "invariant_set_hash": "invariants-root",
        "ontology_version": "ontology-7",
        "reasoner_semantics_id": "omegapln-evidence-envelope-v1",
    }


def certificate(
    certificate_class: CertificateClass = CertificateClass.VERIFIED,
    outcome: ContinuityOutcome = ContinuityOutcome.PRESERVED,
) -> ContinuityCertificate:
    now = datetime.now(timezone.utc)
    values = expected_inputs()
    unsigned = ContinuityCertificate(
        certificate_id="",
        certificate_class=certificate_class,
        outcome=outcome,
        from_snapshot_hash=values["from_snapshot_hash"],
        proposal_hash=values["proposal_hash"],
        predicted_to_state_hash=values["predicted_to_state_hash"],
        evidence_snapshot_hash=values["evidence_snapshot_hash"],
        policy_manifest_hash=values["policy_manifest_hash"],
        invariant_set_hash=values["invariant_set_hash"],
        ontology_version=values["ontology_version"],
        reasoner_backend_id="omegapln",
        reasoner_semantics_id=values["reasoner_semantics_id"],
        analysis_algorithm_version="continuity-core-2",
        analysis_depth=3,
        coverage_claim="protected invariants and rollback reachability",
        created_at=now.isoformat(),
        valid_until=(now + timedelta(minutes=10)).isoformat(),
        issuer="continuity-review-service",
        issuer_key_id=KEY_ID,
        signature_algorithm="hmac-sha256-test-only",
        signature="",
        metadata={"test_only": True},
    )
    return sign_continuity_certificate(unsigned, signer=ROOT)


class ContinuityTests(unittest.TestCase):
    def test_verified_exact_certificate(self) -> None:
        result = verify_continuity_certificate(
            certificate(),
            verifier=ROOT,
            expected=expected_inputs(),
            trusted_issuers=("continuity-review-service",),
        )
        self.assertEqual(result.status, ContinuityStatus.VERIFIED)
        self.assertTrue(result.exact_input_match)

    def test_heuristic_certificate_remains_heuristic(self) -> None:
        result = verify_continuity_certificate(
            certificate(CertificateClass.HEURISTIC),
            verifier=ROOT,
            expected=expected_inputs(),
        )
        self.assertEqual(result.status, ContinuityStatus.HEURISTIC)

    def test_violation_certificate_is_contradicted(self) -> None:
        result = verify_continuity_certificate(
            certificate(outcome=ContinuityOutcome.VIOLATED),
            verifier=ROOT,
            expected=expected_inputs(),
        )
        self.assertEqual(result.status, ContinuityStatus.CONTRADICTED)

    def test_cache_miss_is_explicit(self) -> None:
        result = ContinuityCache().lookup(
            verifier=ROOT,
            expected=expected_inputs(),
        )
        self.assertEqual(result.status, ContinuityStatus.CACHE_MISS)

    def test_cache_hit_verifies_exact_input(self) -> None:
        cache = ContinuityCache()
        cache.put(certificate(CertificateClass.CONSERVATIVE_CORE))
        result = cache.lookup(verifier=ROOT, expected=expected_inputs())
        self.assertEqual(result.status, ContinuityStatus.CONSERVATIVE_SAFE)

    def test_wrong_input_does_not_reuse_certificate(self) -> None:
        cache = ContinuityCache()
        cache.put(certificate())
        expected = expected_inputs()
        expected["proposal_hash"] = "different-proposal"
        result = cache.lookup(verifier=ROOT, expected=expected)
        self.assertEqual(result.status, ContinuityStatus.CACHE_MISS)


if __name__ == "__main__":
    unittest.main()
