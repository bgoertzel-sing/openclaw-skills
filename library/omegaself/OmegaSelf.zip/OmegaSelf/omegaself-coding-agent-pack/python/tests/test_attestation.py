from __future__ import annotations

import unittest
from datetime import datetime, timedelta, timezone

from omegaself.attestation import AttestationInput, Lease, SelfHereNowResolver
from omegaself.types import AnchorStatus


class AttestationTests(unittest.TestCase):
    def test_static_identity_without_live_control_is_unresolved(self) -> None:
        now = datetime.now(timezone.utc)
        result = SelfHereNowResolver().resolve(
            AttestationInput(
                runtime_instance="instance-a",
                process_boundary="pidns-1",
                workspace_boundary="workspace-1",
                controlled_capabilities=("shell",),
                session_bindings=("telegram-1",),
                lineage_head="snapshot-1",
                causal_provenance_head="event-9",
                static_identity_claims={"display_name": "Omega"},
            ),
            now=now,
        )
        self.assertEqual(result.status, AnchorStatus.UNRESOLVED)

    def test_live_exclusive_lease_resolves_anchor(self) -> None:
        now = datetime.now(timezone.utc)
        lease = Lease(
            lease_id="lease-1",
            resource="workspace:/agent",
            holder_instance="instance-a",
            issued_at=(now - timedelta(seconds=1)).isoformat(),
            expires_at=(now + timedelta(minutes=1)).isoformat(),
            exclusive=True,
            proof="challenge-response-1",
        )
        result = SelfHereNowResolver().resolve(
            AttestationInput(
                runtime_instance="instance-a",
                process_boundary="pidns-1",
                workspace_boundary="workspace-1",
                controlled_capabilities=("shell",),
                session_bindings=("telegram-1",),
                lineage_head="snapshot-1",
                causal_provenance_head="event-9",
                leases=(lease,),
                epoch="epoch-4",
            ),
            now=now,
        )
        self.assertEqual(result.status, AnchorStatus.RESOLVED)
        self.assertEqual(result.assurance, "high")
        self.assertTrue(result.anchor_id)

    def test_fork_branches_can_both_resolve_with_distinct_leases(self) -> None:
        now = datetime.now(timezone.utc)

        def resolve(instance: str, resource: str):
            return SelfHereNowResolver().resolve(
                AttestationInput(
                    runtime_instance=instance,
                    process_boundary=f"pidns-{instance}",
                    workspace_boundary=resource,
                    controlled_capabilities=("read",),
                    session_bindings=(),
                    lineage_head="shared-parent-snapshot",
                    causal_provenance_head="shared-parent-event",
                    leases=(
                        Lease(
                            lease_id=f"lease-{instance}",
                            resource=resource,
                            holder_instance=instance,
                            issued_at=(now - timedelta(seconds=1)).isoformat(),
                            expires_at=(now + timedelta(minutes=1)).isoformat(),
                            exclusive=True,
                            proof=f"proof-{instance}",
                        ),
                    ),
                ),
                now=now,
            )

        a = resolve("a", "workspace-a")
        b = resolve("b", "workspace-b")
        self.assertEqual(a.status, AnchorStatus.RESOLVED)
        self.assertEqual(b.status, AnchorStatus.RESOLVED)
        self.assertNotEqual(a.anchor_id, b.anchor_id)


if __name__ == "__main__":
    unittest.main()
