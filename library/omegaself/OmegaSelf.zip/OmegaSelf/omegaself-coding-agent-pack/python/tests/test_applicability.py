from __future__ import annotations

import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from omegaself.applicability import (
    ApplicabilityStatus,
    FreshnessPolicy,
    assess_applicability,
)
from omegaself.canonical import utc_now_iso
from omegaself.ledger import HashChainLedger
from omegaself.types import EventDraft


class ApplicabilityTests(unittest.TestCase):
    def test_staleness_creates_derived_view_without_changing_ledger(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            ledger = HashChainLedger(Path(temp_dir) / "ledger.jsonl")
            now = datetime.now(timezone.utc)
            event = ledger.append(
                EventDraft(
                    event_type="capability_outcome",
                    subject_anchor="anchor-a",
                    context="ctx-a",
                    payload={"success": True},
                    causal_time=(now - timedelta(hours=2)).isoformat(),
                )
            )
            root_before = ledger.root_hash()
            assessment = assess_applicability(
                evidence_id=event.event_id,
                target_query="CanDo(pdf-extract)",
                observed_at=event.causal_time,
                source_context_id="ctx-a",
                target_context_id="ctx-a",
                source_regime_id="handler-1",
                target_regime_id="handler-1",
                policy=FreshnessPolicy(
                    policy_id="freshness-v1",
                    predicate_class="provider-health",
                    current_for_seconds=60,
                    stale_after_seconds=300,
                ),
                evaluated_at=now.isoformat(),
            )
            self.assertEqual(assessment.status, ApplicabilityStatus.STALE)
            self.assertEqual(ledger.root_hash(), root_before)
            self.assertEqual(ledger.get(event.event_id), event)

    def test_regime_change_supersedes_without_deleting_evidence(self) -> None:
        now = datetime.now(timezone.utc)
        assessment = assess_applicability(
            evidence_id="evt-1",
            target_query="CanDo(pdf-extract)",
            observed_at=(now - timedelta(seconds=1)).isoformat(),
            source_context_id="ctx-a",
            target_context_id="ctx-a",
            source_regime_id="handler-1",
            target_regime_id="handler-2",
            policy=FreshnessPolicy(
                policy_id="freshness-v1",
                predicate_class="capability",
                current_for_seconds=60,
                stale_after_seconds=3600,
                allow_cross_regime_transfer=False,
            ),
            evaluated_at=now.isoformat(),
        )
        self.assertEqual(assessment.status, ApplicabilityStatus.SUPERSEDED)
        self.assertEqual(assessment.applicability, 0.0)

    def test_aging_applies_recency_discount(self) -> None:
        now = datetime.now(timezone.utc)
        assessment = assess_applicability(
            evidence_id="evt-1",
            target_query="CanDo(pdf-extract)",
            observed_at=(now - timedelta(seconds=150)).isoformat(),
            source_context_id="ctx-specific",
            target_context_id="ctx-general",
            source_regime_id="handler-1",
            target_regime_id="handler-1",
            context_transfer_applicability=0.8,
            policy=FreshnessPolicy(
                policy_id="freshness-v1",
                predicate_class="capability",
                current_for_seconds=100,
                stale_after_seconds=200,
            ),
            evaluated_at=now.isoformat(),
        )
        self.assertEqual(assessment.status, ApplicabilityStatus.AGING)
        self.assertAlmostEqual(assessment.applicability, 0.4, places=6)
        self.assertIn("context_transfer_applied", assessment.reason_codes)


if __name__ == "__main__":
    unittest.main()
