from __future__ import annotations

import unittest
from dataclasses import replace
from datetime import datetime, timedelta, timezone

from omegaself.governance import PolicyAuthorityStatus, verify_policy_manifest
from support import SEMANTICS, signed_manifest


class GovernanceTests(unittest.TestCase):
    def test_valid_signed_manifest_verifies(self) -> None:
        now = datetime.now(timezone.utc)
        manifest, root = signed_manifest(now=now)
        result = verify_policy_manifest(
            manifest,
            verifier=root,
            required_reasoner_semantics_id=SEMANTICS,
            allowed_issuers=("unit-test-policy-authority",),
            now=now,
        )
        self.assertEqual(result.status, PolicyAuthorityStatus.VERIFIED)

    def test_expired_manifest_cannot_authorize(self) -> None:
        now = datetime.now(timezone.utc)
        manifest, root = signed_manifest(now=now, expires_delta=timedelta(seconds=-1))
        # Re-sign after setting the already-expired timestamp.
        result = verify_policy_manifest(manifest, verifier=root, now=now)
        self.assertEqual(result.status, PolicyAuthorityStatus.EXPIRED)

    def test_wrong_semantics_cannot_authorize(self) -> None:
        now = datetime.now(timezone.utc)
        manifest, root = signed_manifest(now=now, semantics_id="patham9-nal-stv-v1")
        result = verify_policy_manifest(
            manifest,
            verifier=root,
            required_reasoner_semantics_id=SEMANTICS,
            now=now,
        )
        self.assertEqual(result.status, PolicyAuthorityStatus.WRONG_SEMANTICS)

    def test_tampered_manifest_fails_hash_before_signature(self) -> None:
        now = datetime.now(timezone.utc)
        manifest, root = signed_manifest(now=now)
        tampered = replace(
            manifest,
            capability_thresholds={"minimum_capability_lower_bound": 0.01},
        )
        result = verify_policy_manifest(tampered, verifier=root, now=now)
        self.assertEqual(result.status, PolicyAuthorityStatus.HASH_MISMATCH)


if __name__ == "__main__":
    unittest.main()
