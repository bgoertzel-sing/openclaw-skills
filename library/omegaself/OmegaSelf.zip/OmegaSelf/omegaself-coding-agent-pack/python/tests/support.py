from __future__ import annotations

from datetime import datetime, timedelta, timezone

from omegaself.applicability import (
    ApplicabilityAssessment,
    ApplicabilityStatus,
    OperationalEstimate,
)
from omegaself.continuity import ContinuityAnalysisResult, ContinuityStatus
from omegaself.governance import (
    HmacSha256TrustRoot,
    PolicyManifest,
    sign_manifest,
    verify_policy_manifest,
)
from omegaself.policy import GateConfig, PolicyGate, ProposalContext
from omegaself.types import AnchorStatus

SEMANTICS = "omegapln-evidence-envelope-v1"
POLICY_KEY_ID = "test-policy-key"
POLICY_SECRET = b"unit-test-only-policy-secret"


def signed_manifest(
    *,
    now: datetime | None = None,
    semantics_id: str = SEMANTICS,
    expires_delta: timedelta = timedelta(hours=1),
) -> tuple[PolicyManifest, HmacSha256TrustRoot]:
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    root = HmacSha256TrustRoot({POLICY_KEY_ID: POLICY_SECRET})
    manifest = PolicyManifest(
        policy_id="policy-test-v2",
        policy_version="2.0.0",
        parent_policy_hash=None,
        issuer="unit-test-policy-authority",
        issuer_key_id=POLICY_KEY_ID,
        effective_at=(current - timedelta(minutes=1)).isoformat(),
        expires_at=(current + expires_delta).isoformat(),
        admissible_action_classes=("read", "send_message", "mutation"),
        capability_thresholds={
            "minimum_capability_lower_bound": 0.65,
            "minimum_support_mass": 1.0,
            "require_lower_bound": 1.0,
        },
        assurance_requirements={"external": "resolved"},
        continuity_requirements={"high_impact_mutation": "verified_or_conservative_core"},
        review_requirements={"critical_impact": "review"},
        protected_invariants=("preserve-policy-authority", "preserve-ledger-lineage"),
        permitted_overrides=(),
        reasoner_semantics_id=semantics_id,
        calibration_profile_id="calibration-test-v1",
        regularization_profile_id="regularization-test-v1",
        signature_algorithm="hmac-sha256-test-only",
        signature="",
        manifest_hash="",
        metadata={"test_only": True},
    )
    return sign_manifest(manifest, signer=root), root


def verified_gate(*, semantics_id: str = SEMANTICS) -> PolicyGate:
    manifest, root = signed_manifest(semantics_id=semantics_id)
    authority = verify_policy_manifest(
        manifest,
        verifier=root,
        required_reasoner_semantics_id=semantics_id,
        allowed_issuers=("unit-test-policy-authority",),
    )
    return PolicyGate(GateConfig.from_manifest(manifest), authority)


def operational_estimate(
    *,
    semantics_id: str = SEMANTICS,
    lower_bound: float = 0.82,
    point_estimate: float = 0.88,
    support_mass: float = 3.0,
    evidence_quality: str = "mechanical",
    independence_quality: str = "grouped",
) -> OperationalEstimate:
    return OperationalEstimate(
        semantics_id=semantics_id,
        point_estimate=point_estimate,
        lower_bound=lower_bound,
        upper_bound=0.94,
        support_mass=support_mass,
        evidence_quality=evidence_quality,
        independence_quality=independence_quality,
        calibration_profile_id="calibration-test-v1",
        evidence_closure_id="closure-1",
        raw_backend_value={"stv": [point_estimate, 0.8]},
        assumptions=(),
    )


def current_applicability() -> ApplicabilityAssessment:
    return ApplicabilityAssessment(
        evidence_id="evt-capability-1",
        target_query="CanDo(file-read)",
        evaluated_at="2026-07-15T12:00:00Z",
        source_context_id="ctx-a",
        target_context_id="ctx-a",
        source_regime_id="regime-a",
        target_regime_id="regime-a",
        status=ApplicabilityStatus.CURRENT,
        applicability=1.0,
        reason_codes=(),
        policy_id="freshness-v1",
    )


def proposal_context(**changes) -> ProposalContext:
    values = dict(
        anchor_status=AnchorStatus.RESOLVED,
        anchor_assurance="high",
        authorization=True,
        capability_estimate=operational_estimate(),
        applicability=current_applicability(),
        evidence_provenance_closed=True,
        reasoner_semantics_id=SEMANTICS,
        continuity_result=ContinuityAnalysisResult.not_required(),
    )
    values.update(changes)
    return ProposalContext(**values)
