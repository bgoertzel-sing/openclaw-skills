from __future__ import annotations

import unittest

from omegaself.reasoner import (
    BackendUnavailable,
    InferenceRequest,
    OmegaPLNAdapter,
    Patham9Adapter,
    compare_inference_results,
)


SEMANTICS = "compat-nal-stv-v1"


def request() -> InferenceRequest:
    return InferenceRequest(
        request_id="infer-1",
        query={"predicate": "CanDo", "capability": "pdf-extract"},
        context_id="ctx-1",
        evidence_snapshot_id="snapshot-e-1",
        evidence_closure_id="closure-1",
        rule_profile_id="nal-golden-v1",
        prior_bundle_id=None,
        dependence_model_id="dep-v1",
        inference_budget={"steps": 100},
        required_provenance_level="complete",
        required_assurance_mode="bounded",
    )


def backend(payload):
    assert payload["operation"] == "infer"
    return {
        "claim": payload["request"]["query"],
        "point_estimate": 0.8,
        "lower_bound": 0.7,
        "upper_bound": 0.9,
        "support_mass": 4.0,
        "evidence_quality": "mechanical",
        "independence_quality": "grouped",
        "calibration_profile_id": "cal-1",
        "evidence_event_ids": ["evt-1", "evt-2"],
        "derivation_trace": [{"rule": "deduction"}],
        "truth_semantics_id": SEMANTICS,
        "provenance_status": "closed",
        "convergence_status": "converged",
        "raw_backend_value": {"stv": [0.8, 0.75]},
    }


class ReasonerTests(unittest.TestCase):
    def test_same_callsite_can_swap_adapters(self) -> None:
        adapters = [
            Patham9Adapter(backend, backend_version="p9-test", truth_semantics_id=SEMANTICS),
            OmegaPLNAdapter(backend, backend_version="omega-test", truth_semantics_id=SEMANTICS),
        ]
        results = [adapter.infer(request()) for adapter in adapters]
        self.assertEqual(results[0].claim, results[1].claim)
        self.assertEqual(results[0].estimate.lower_bound, results[1].estimate.lower_bound)
        self.assertNotEqual(results[0].backend_id, results[1].backend_id)

    def test_golden_compatibility_can_require_exact_semantics_and_evidence(self) -> None:
        old = Patham9Adapter(backend, truth_semantics_id=SEMANTICS).infer(request())
        new = OmegaPLNAdapter(backend, truth_semantics_id=SEMANTICS).infer(request())
        report = compare_inference_results(old, new)
        self.assertTrue(report.compatible, report.differences)

    def test_reasoner_result_has_no_governance_decision(self) -> None:
        result = OmegaPLNAdapter(backend, truth_semantics_id=SEMANTICS).infer(request())
        value = result.to_dict()
        self.assertNotIn("decision", value)
        self.assertNotIn("allow", str(value).lower())

    def test_unbound_adapter_fails_explicitly(self) -> None:
        adapter = OmegaPLNAdapter(None)
        with self.assertRaises(BackendUnavailable):
            adapter.infer(request())

    def test_semantics_difference_is_visible(self) -> None:
        old = Patham9Adapter(backend, truth_semantics_id=SEMANTICS).infer(request())

        def changed(payload):
            value = dict(backend(payload))
            value["truth_semantics_id"] = "omegapln-native-v2"
            return value

        new = OmegaPLNAdapter(changed, truth_semantics_id="omegapln-native-v2").infer(request())
        report = compare_inference_results(old, new, require_exact_semantics=False)
        self.assertTrue(report.compatible)
        self.assertTrue(report.warnings)


if __name__ == "__main__":
    unittest.main()
