from __future__ import annotations

import unittest

from omegaself.context_graph import ContextGraph, ContextKey, ContextTransfer


class ContextGraphTests(unittest.TestCase):
    def test_context_ids_are_deterministic(self) -> None:
        key = ContextKey(
            task_class="scientific-pdf",
            input_modality="digital-pdf",
            environment="local",
            handler_version="2.1",
            provider="local",
            authorization_epoch="auth-1",
            resource_class="normal",
            rubric="exact-text-v1",
        )
        self.assertEqual(key.context_id, key.context_id)

    def test_generalization_paths_preserve_one_evidence_identity(self) -> None:
        graph = ContextGraph()
        specific = ContextKey("scientific-pdf", "digital", "local", "2.1", "local", "a1", "normal", "r1")
        technical = ContextKey("technical-document", "digital", "local", "2.1", "local", "a1", "normal", "r1")
        broad = ContextKey("document", "digital", "local", "2.1", "local", "a1", "normal", "r1")
        s, t, b = [graph.add_context(item) for item in (specific, technical, broad)]
        graph.add_transfer(ContextTransfer(s, t, "subsumes", 0.9, 0.1, "preserve_identity", "r1"))
        graph.add_transfer(ContextTransfer(t, b, "subsumes", 0.8, 0.1, "preserve_identity", "r1"))
        graph.add_transfer(ContextTransfer(s, b, "analogous", 0.5, 0.3, "preserve_identity", "r2"))
        paths = graph.find_paths(s, b)
        self.assertEqual(len(paths), 2)
        evidence = graph.deduplicate_evidence_paths(
            [["evt-1"] for _ in paths] + [["evt-1", "evt-2"]]
        )
        self.assertEqual(evidence, ("evt-1", "evt-2"))

    def test_independence_units_are_deduplicated(self) -> None:
        units = ContextGraph.deduplicate_independence_units(
            [("evt-a", "evt-b"), ("evt-b", "evt-a"), ("evt-c",), ("evt-c",)]
        )
        self.assertEqual(units, (("evt-a", "evt-b"), ("evt-c",)))


if __name__ == "__main__":
    unittest.main()
