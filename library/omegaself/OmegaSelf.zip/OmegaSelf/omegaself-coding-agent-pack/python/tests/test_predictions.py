from __future__ import annotations

import unittest

from omegaself.predictions import Prediction, score_prediction


class PredictionTests(unittest.TestCase):
    def test_brier_score_rewards_calibrated_success(self) -> None:
        prediction = Prediction(
            prediction_id="p1",
            proposition="handler succeeds",
            probability=0.8,
            rubric="exit code zero",
            context="test",
        )
        resolution = score_prediction(prediction, True)
        self.assertAlmostEqual(resolution.brier_score, 0.04)
        self.assertGreater(resolution.log_loss, 0.0)

    def test_probability_is_validated(self) -> None:
        with self.assertRaises(ValueError):
            Prediction(
                prediction_id="p2",
                proposition="invalid",
                probability=1.2,
                rubric="binary",
                context="test",
            )


if __name__ == "__main__":
    unittest.main()
