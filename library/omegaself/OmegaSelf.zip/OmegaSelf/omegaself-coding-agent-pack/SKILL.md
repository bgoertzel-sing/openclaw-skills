---
name: omegaself-implementation
description: Implement, audit, or extend OmegaSelf in an OmegaClaw/PeTTa/MeTTa codebase, including immutable evidence, applicability and context transfer, substrate-neutral PLN adapters, renewable SelfHereNow attestation, predictions, signed-policy proposal gates, continuity certificates, tripwires, and migration tests.
---

# OmegaSelf implementation skill

Use this skill for changes to self-observation, self-belief, capability estimation,
context generalization, self-prediction, continuity, identity attribution,
reasoner migration, or governance.

## Operating stance

Treat the self-model as a continuously tested theory about the currently acting
system. Preserve this closed loop:

```text
evidence → closure/applicability → contextual estimate → prediction → proposal
         → externally authorized policy decision → action/probe → receipt
         → discrepancy → revised derived view
```

Evidence remains preserved throughout. A current view may supersede an earlier
view without deleting the event that supported it.

## Workflow

### 1. Inspect before editing

Locate and pin:

- exact loop seam after parse and before `eval`;
- skill catalog and dispatch path;
- Python bridge pattern;
- memory/history stores;
- Patham9/OmegaPLN interfaces and truth semantics;
- sandbox and policy enforcement process;
- policy trust roots and signing workflow;
- tests and deployment configuration.

### 2. Classify the change

Assign it to one or more planes:

- evidence substrate;
- applicability/context transfer;
- reasoner adapter and derivation;
- prediction/calibration;
- continuity/indexical grounding;
- governance/consumer.

Name the causal consumer. A detector or estimate with no consumer is incomplete.

### 3. Add or version the event first

Include:

- event ID and sequence;
- causal, recorded, and optional adoption time;
- anchor and exact context key;
- provenance parents and dependence group;
- schema, handler/provider regime, rubric, and evaluator version;
- previous hash and record hash.

Corrections, retractions, and disqualifications are new events.

### 4. Define applicability without forgetting

Create a versioned `FreshnessPolicy` per predicate class. Derive an
`ApplicabilityAssessment` for the present query. Regime mismatch, context shift,
and elapsed time may reduce applicability; none modifies the original event.

### 5. Define context transfer and deduplication

Use exact multidimensional context keys and typed transfer edges. Preserve source
evidence IDs and deduplicate before revision. Generalization must state target
population assumptions; plain inheritance is not automatically valid.

### 6. Call the reasoner through the neutral SPI

Construct a typed request naming context, snapshot, closure, rules, priors,
dependence model, budget, provenance requirement, and assurance mode. Record:

- backend and version;
- truth-semantics identifier;
- normalized operational estimate;
- raw backend value;
- evidence identities and derivation trace;
- convergence and provenance status.

The reasoner never returns a governance decision.

### 7. Add a falsifiable prediction

Any belief that can alter dispatch or mutation must produce a pre-action
prediction with an evaluation rubric. Commit it before execution.

### 8. Verify external policy authority

Load a versioned signed manifest through a trust root the agent cannot mutate or
use to sign. Reject unsigned, expired, revoked, wrong-issuer, hash-mismatched, or
wrong-semantics manifests. The reference HMAC verifier is test-only.

### 9. Add the consumer and fail-safe behavior

Return exactly one:

```text
Allow | Deny | RequireProbe | RequireReview | Defer
```

Only `Allow` reaches the evaluator. Unknown authorization, missing closure,
expired attestation, stale applicability, semantics mismatch, and inadequate
continuity analysis never default to `Allow`.

### 10. Certify continuity for mutations

Bind certificates to exact source/proposal/target/evidence/policy/invariant/
ontology/semantics inputs. `Verified` and a policy-accepted `ConservativeCore`
may support authorization. `Heuristic` and `CacheMiss` are advisory.

### 11. Test migrations, not only examples

Use substrate-specific NAL examples as golden tests, then add:

- semantic/metamorphic invariants;
- provenance and dependence checks;
- context-transfer deduplication;
- prediction calibration;
- action-decision equivalence;
- governance-seam comparison.

### 12. Roll out in shadow mode

Record decisions without changing behavior. Compare false allows/denials,
latency, success, calibration, closure completeness, and operator explanations.
Enable one consumer at a time.

## Completion report

Return:

- files and schemas changed;
- target repository and runtime versions;
- reasoner backend/semantics before and after;
- policy manifest and trust-root hashes;
- ledger/snapshot root;
- tests, replay, calibration, and decision-differential results;
- action behavior delta;
- unresolved questions;
- rollback command or configuration.
