# Instructions for coding agents working on OmegaSelf

## Mission

Implement an event-sourced, PLN-interpreted self-theory and governance layer in
OmegaClaw without turning an LLM self-description, backend truth value, cache
entry, or agent-controlled policy file into authority.

## Read first

1. `README.md`
2. `CHANGELOG.md`
3. `SKILL.md`
4. `docs/ARCHITECTURE.md`
5. `docs/IMPLEMENTATION_PLAN.md`
6. `docs/REVIEW_FEEDBACK_INTEGRATION.md`
7. `docs/THREAT_MODEL.md`
8. The target OmegaClaw loop, skills, memory, reasoner rules, policy enforcement,
   sandbox, and tests.

Record the target repository revision, Hyperon/PeTTa version, active Patham9 or
OmegaPLN profile, and policy-manifest hash before changing code.

## Non-negotiable engineering rules

1. **Never execute from the self-model or reasoner.** They emit evidence,
   estimates, predictions, alerts, explanations, and proposals. Only a separately
   authorized policy gate may return `Allow`.
2. **Staleness is not forgetting.** Preserve every evidence event. Create a new
   applicability assessment and belief view; never rewrite the original record.
3. **Fail closed at mutation boundaries.** A high-impact continuity cache miss,
   heuristic result, budget exhaustion, or incomplete finite-core analysis maps
   to `RequireReview` or `Defer`, never `Allow`.
4. **Keep the reasoner seam substrate-neutral.** No production caller may import
   Patham9- or OmegaPLN-specific STV classes. Put backend details in one adapter.
5. **Preserve evidence identity through context transfer.** One event cannot be
   counted again through child, parent, and analogous context paths.
6. **Do not count correlated outcomes as independent.** Preserve and verify
   dependence-group stamps.
7. **Externally root governance.** The agent may propose but cannot self-sign or
   ratify the policy manifest that configures the Allow-emitting gate.
8. **Do not infer identity from display name, copied memory, or static secret.**
   Require renewable live causal-control attestation.
9. **Do not collapse forks.** Multiple successors may be valid continuations.
10. **Do not let a counterfactual space write into live assertion authority.**
11. **Do not add a high/critical tripwire without its consumer and integration test.**
12. **Do not claim MeTTa scaffolding is production-ready without target-runtime tests.**

## Required layer boundaries

```text
runtime sensors / receipts
        ↓
append-only evidence ledger
        ↓
closure + applicability + context transfer
        ↓
SelfReasoner SPI (Patham9 or OmegaPLN adapter)
        ↓
normalized OperationalEstimate + derivation
        ↓
typed proposal
        ↓
externally configured deterministic policy gate
        ↓
Allow only → evaluator
```

The continuity service returns epistemic status such as `Verified`, `Heuristic`,
or `CacheMiss`. The policy gate alone maps that status to `Allow`, `Deny`,
`RequireProbe`, `RequireReview`, or `Defer`.

## Work decomposition

Keep pull requests small and independently reversible:

- PR 1: event schemas, canonicalization, ledger, verification.
- PR 2: runtime probes and record-only loop hooks.
- PR 3: evidence closure, dependence groups, correction/disqualification events.
- PR 4: renewable `SelfHereNow` resolver.
- PR 5: substrate-neutral `SelfReasoner` interface and current-backend adapter.
- PR 6: golden NAL and semantic/metamorphic reasoner tests.
- PR 7: exact context keys, context-transfer graph, evidence deduplication.
- PR 8: freshness profiles and append-only applicability assessments.
- PR 9: externally verified policy manifest and trust-root process.
- PR 10: typed proposals and shadow policy decisions before `eval`.
- PR 11: pre-action predictions and outcome resolution.
- PR 12: capability-aware dispatch.
- PR 13: commitment conflicts and attribution relations.
- PR 14: continuity certificates, cache, mutation gate, rollback rehearsal.
- PR 15: OmegaPLN shadow migration and governed self-transport.

Every PR includes migration notes, rollback, unit/integration/replay tests, and an
explicit statement of whether action behavior changed.

## Required verification loop

```bash
make validate
./scripts/smoke_test.sh
```

In the target repository also run:

- native Python tests;
- native MeTTa/PeTTa tests;
- golden Patham9/OmegaPLN compatibility cases;
- replay from a frozen evidence snapshot;
- action-decision differentials;
- calibration comparison;
- adversarial scenarios in `examples/adversarial_scenarios.md`.

## Stop conditions

Stop and request design review when:

- the ledger must be writable by the same unconfined shell skill it audits;
- a rule converts raw confidence directly into permission;
- a context-generalization rule duplicates evidence identity;
- the current backend cannot expose provenance or dependence limits explicitly;
- a gate would accept an unsigned, expired, revoked, or wrong-semantics policy;
- a high-impact mutation could pass on cache miss or heuristic continuity output;
- a fork/merge implementation requires strict equality;
- the admissible policy class or regularization profile is implicit;
- replay from the same evidence/policy/semantics snapshot is not reproducible;
- a reasoner migration changes decision behavior without recorded approval and rollback.

## Definition of done for an implementation slice

- schema and migration documented;
- evidence, context, rule, backend, semantics, policy, and calibration versions recorded;
- tests and replay pass;
- ledger root is reported;
- no evidence was overwritten;
- inherited and correlated evidence are deduplicated;
- each alert has a consumer;
- policy signature and trust root are verified outside agent authority;
- feature flag and rollback work;
- operator can explain one representative decision from closure through policy;
- only `Allow` reaches execution.
