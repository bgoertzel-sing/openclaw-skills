# ADR 0009 — High-impact continuity analysis fails closed

## Decision

A high-impact or irreversible mutation without an authorization-grade, exact-input
continuity result returns `RequireReview` or `Defer`; an invariant violation
returns `Deny`. Cache miss, budget exhaustion, incomplete analysis, and heuristic
extensions cannot yield `Allow`.

## Rationale

The need for deeper continuity analysis is greatest at the mutations where an
unbounded synchronous computation is least acceptable. Latency optimization must
not convert epistemic incompleteness into permission.
