# ADR 0004: Represent continuity as directed, branching transport

**Status:** Accepted

## Context

Agent changes are often non-invertible, and forks can preserve continuity along
more than one branch. Strict equality or a single lineage chain misrepresents this.

## Decision

Represent significant states as snapshots and changes as directed transports.
Allow multiple parents and children. Store ancestry, preserved witnesses,
reconciliation policy, measured defect/loss, authorization, and reversibility.
Never infer strict equality from a transport.

## Consequences

- merge/fork audit is explicit;
- path-order tests can expose non-commuting changes;
- "same bot" becomes an attributed continuation query rather than a Boolean field.
