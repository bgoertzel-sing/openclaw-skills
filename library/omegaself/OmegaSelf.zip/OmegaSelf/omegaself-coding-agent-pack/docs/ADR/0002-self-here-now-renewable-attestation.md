# ADR 0002: Resolve SelfHereNow from renewable causal control

**Status:** Accepted for prototype

## Context

An observation stream, copied provenance, display name, or copied secret can be
shared by a fork. They establish history or resemblance, not exclusive present participation.

## Decision

`SelfHereNow` is a context-relative resolver returning an attested bundle and
assurance level. It requires at least one live renewable binding controlled by
the current runtime instance, plus process/workspace/session/lineage/provenance descriptors.

## Consequences

- anchors expire and must be renewed;
- migration and restart produce new current anchors linked by continuity;
- forks may both be valid continuations with distinct anchors;
- high-impact action fails closed when resolution is weak or absent.
