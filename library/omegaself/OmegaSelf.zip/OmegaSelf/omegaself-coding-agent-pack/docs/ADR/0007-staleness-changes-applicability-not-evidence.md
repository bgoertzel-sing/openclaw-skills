# ADR 0007 — Staleness changes applicability, not evidence

## Decision

Evidence remains append-only and historically addressable. A freshness or regime
change creates a new `EvidenceApplicability` assessment and a new derived belief
view. It never deletes, rewrites, or silently discounts the stored event in place.

## Rationale

Staleness answers whether an observation licenses a present conclusion. It does
not change whether the observation occurred. Keeping these separate preserves
replay, causal history, and policy-differential experiments.

## Consequences

- Freshness profiles are versioned policy inputs.
- Retractions and disqualifications are new events.
- Capability gates consume applicability status, not a destructive forgetting store.
- Context, handler/provider regime, rubric, and elapsed time can all affect applicability.
