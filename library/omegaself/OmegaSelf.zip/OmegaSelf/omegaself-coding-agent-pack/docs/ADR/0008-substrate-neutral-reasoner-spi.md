# ADR 0008 — Use a substrate-neutral reasoner SPI

## Decision

OmegaSelf production code calls a typed `SelfReasoner` interface for inference,
revision, explanation, and policy-differential comparison. Patham9 PLN and
OmegaPLN are adapters behind this boundary.

## Rationale

The transition to OmegaPLN should change one adapter and its integration tests,
not every belief and governance call site. Raw backend truth values remain in
audit output; policy consumes a normalized operational estimate envelope.

## Consequences

- Every result names backend version and truth-semantics profile.
- Unsupported backend capabilities are explicit.
- The reasoner never returns `Allow`, `Deny`, or another governance decision.
- NAL examples remain substrate-specific golden migration tests.
