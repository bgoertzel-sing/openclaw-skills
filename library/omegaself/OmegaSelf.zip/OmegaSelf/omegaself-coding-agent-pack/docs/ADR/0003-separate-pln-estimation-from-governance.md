# ADR 0003: Separate PLN estimation from action licensing

**Status:** Accepted

## Context

A probabilistic claim that an action will succeed does not answer whether the
action is permitted, aligned with commitments, or safe to execute.

## Decision

PLN/NAL derives contextual self-beliefs and predictions. A distinct deterministic,
versioned policy gate consumes those outputs and emits a typed decision. Only
`Allow` reaches execution.

## Consequences

- capability confidence cannot authorize a denied action;
- policy sensitivity is measurable;
- gate behavior can be replayed with fixed evidence and policy;
- the gate becomes a critical security component requiring conservative defaults.
