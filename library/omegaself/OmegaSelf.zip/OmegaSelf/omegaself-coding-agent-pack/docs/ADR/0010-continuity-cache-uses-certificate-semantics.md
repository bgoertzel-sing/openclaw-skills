# ADR 0010 — Cached continuity results require certificate semantics

## Decision

Continuity cache entries bind the exact source snapshot, proposal, predicted
result state, evidence snapshot, policy manifest, invariant set, ontology, and
reasoner semantics. They are classified as `Verified`, `ConservativeCore`, or
`Heuristic`, signed, versioned, and expiring.

## Rationale

A cache is storage, not authority. Only a valid certificate can support a policy
decision. Heuristic speculative materialization remains advisory even on a hit.
