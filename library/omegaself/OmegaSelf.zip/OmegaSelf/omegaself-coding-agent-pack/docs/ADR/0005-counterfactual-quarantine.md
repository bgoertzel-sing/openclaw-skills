# ADR 0005: Quarantine counterfactual self-models

**Status:** Accepted

## Context

Simulation is useful for planning, but an imagined capability or future permission
must not become a present-tense belief or license.

## Decision

Use a separate counterfactual assertion authority and propagate taint to proposals.
Promotion into live spaces requires an actual evidence-producing transition and
policy decision.

## Consequences

- planning remains expressive;
- tainted proposals can be deterministically denied;
- cross-space copy/promotion APIs require audit and tests.
