# ADR 0013 — Reasoner migration is a governed self-transport

## Decision

Replacing Patham9 PLN with OmegaPLN is localized in code by the neutral SPI, but
is treated behaviorally as a significant self-transport. It requires pinned
semantics identifiers, shadow replay, golden tests, semantic/metamorphic tests,
decision differentials, calibration comparison, approval, and rollback.

## Rationale

A small code diff can still create a large belief or action-policy differential.
The adapter boundary reduces blast radius; it does not prove semantic equivalence.
