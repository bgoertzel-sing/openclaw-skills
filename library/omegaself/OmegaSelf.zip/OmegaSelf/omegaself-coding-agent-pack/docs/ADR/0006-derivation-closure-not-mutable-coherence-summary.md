# ADR 0006: Store complete derivation closure, not one mutable CoherenceLink

**Status:** Accepted

## Context

A single mutable coherence link can become another unsupported summary and can
hide stale, retracted, or correlated support.

## Decision

Each consequential belief names an immutable evidence closure: a queryable
derivation DAG plus root hash, dependence groups, retractions, and rule/policy versions.
Tripwires inspect closure validity rather than merely checking for one designated link.

## Consequences

- explanations and replay are grounded;
- storage/indexing is more complex;
- stale or missing support can be localized;
- the system can detect overlap and counterfactual contamination.
