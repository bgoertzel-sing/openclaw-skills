# ADR 0011 — Governance authority is externally rooted

## Decision

The Allow-emitting policy gate is configured from a versioned manifest signed by
an authority outside the agent-controlled revision loop. The agent may propose a
policy change but cannot ratify or self-sign it.

## Rationale

A self-model grounded in an agent-controlled ledger still has a soft center if
the same agent can redefine the consumer that licenses action. Policy authority,
enforcement integrity, evidence authority, and audit authority are separate roles.

## Consequences

The dependency-free HMAC verifier in the reference code is test-only. Production
uses asymmetric or remote verification with the signing key unavailable to the
agent process.
