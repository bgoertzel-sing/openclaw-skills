# ADR 0001: Use an append-only event-sourced evidence ledger

**Status:** Accepted for prototype

## Context

A self-model must remain auditable under correction, contradiction, replay, and
self-modification. Mutable "current self" records destroy the evidence needed to
explain how a belief changed.

## Decision

Persist mechanically grounded observations as canonical, hash-chained, append-only
events. AtomSpaces are inference projections; they are not the sole durable source.
Corrections and retractions are new events.

## Consequences

- replay and tamper detection become possible;
- storage grows monotonically and needs retention/compaction policies for derived data;
- ledger append authority becomes a security boundary;
- event and rule versions must be explicit.
