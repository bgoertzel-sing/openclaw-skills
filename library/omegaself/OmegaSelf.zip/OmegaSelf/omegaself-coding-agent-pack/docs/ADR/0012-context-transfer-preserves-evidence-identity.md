# ADR 0012 — Context transfer preserves evidence identity

## Decision

Capability contexts form a typed graph/partial order. Transfer rules can move
support between contexts, but the original event IDs are preserved and deduplicated
before revision. One observation cannot be counted once in a child and again in
each ancestor.

## Rationale

Overly narrow contexts prevent learning; overly broad contexts create false
capability claims. Evidence-preserving transfer permits controlled generalization
without multiplying support through inheritance paths.
