# Open questions

## Evidence and applicability

- How should freshness profiles be learned without allowing the learner to erase
  inconvenient evidence?
- Which predicate classes should be effectively timeless, and who decides?
- How should external evaluator quality and selection bias enter support mass?

## Context structure

- Which context dimensions are essential for early deployments?
- When does a context graph need joins/meets, versus a general directed graph?
- How should target workload distributions be represented for upward generalization?
- When may the system propose context splits or merges, and what governance is required?

## Reasoner semantics

- Which Patham9/NAL cases require exact numeric compatibility under OmegaPLN?
- Which properties should be semantic/metamorphic rather than exact-value tests?
- What normalized envelope is honest when two backends have fundamentally different
  uncertainty semantics?
- How should bounded soundness and convergence status affect policy?

## Governance authority

- Which authority architecture is appropriate: offline signatures, multisignature,
  hardware roots, remote policy service, or combinations?
- How should emergency overrides be authorized and audited?
- What is the right admissible policy family, including regularization parameters?
- How can policy authority remain exogenous while supporting legitimate agent-proposed evolution?

## Continuity

- Which mutation classes admit conservative-core certificates?
- How should certificate coverage and information loss be measured?
- Which analyses are valuable to precompute, and how are cache-poisoning risks controlled?
- How should merges reconcile two valid branch certificates and policy lineages?

## Evaluation

- What workloads best measure improvement in self-prediction and dispatch?
- What false-Allow rate is acceptable per action class?
- How should governance-seam thickness be estimated over realistic policy families?
- Which structural identity measures predict practical safety or competence?

## Research interpretation

- Does the Hyperseed/endomorphism framing yield new algorithms, certificates, or
  discrepancy detectors beyond an explanatory metaphor?
- Which claims remain phenomenological interpretations rather than consequences
  of the formal structure?
