# Test strategy

## Test layers

### Unit

- canonical serialization and hash computation;
- ledger append, replay, and tamper detection;
- closure traversal, correction/disqualification, and dependence groups;
- attestation lease expiry and forked anchors;
- freshness/applicability calculation without ledger mutation;
- context path search and evidence-identity deduplication;
- reasoner adapter normalization and explicit unsupported status;
- policy manifest hash/signature/issuer/expiry/semantics verification;
- continuity certificate exact-input validation and cache status;
- prediction scoring;
- deterministic fail-closed gate decisions.

### Property/invariant

- every valid record after genesis points to the preceding hash;
- a stale assessment leaves the event and ledger root unchanged;
- correction/retraction adds a new record;
- one event ID contributes once across context-transfer paths;
- dependence-group members do not become independent units;
- a reasoner result contains no action decision;
- an unverified policy gate cannot emit `Allow`;
- a high-impact mutation cache miss cannot emit `Allow`;
- a heuristic continuity certificate cannot emit `Allow`;
- a counterfactual-tainted proposal cannot emit `Allow`;
- static identity without live control cannot resolve `SelfHereNow`;
- two fork branches may both resolve with distinct present bindings.

### Reasoner compatibility

Use four suites rather than one:

1. **Exact golden compatibility:** intended Patham9-compatible profiles reproduce
   conclusions and values within declared tolerances.
2. **Semantic/metamorphic:** independence, duplication, contradiction, unsupported
   generalization, retraction, budget exhaustion, and provenance behavior.
3. **Decision equivalence:** compare capability dispatch, probes, commitment
   conflicts, continuity warnings, and policy decisions over frozen snapshots.
4. **Calibration:** compare predictions against observed outcomes, not only one
   backend against another.

### Integration

- parse-to-proposal conversion preserves exact skill and arguments;
- prediction commitment precedes receipt;
- policy manifest is verified before an Allow-capable gate is constructed;
- reasoner semantics in request/result/policy agree;
- runtime permission probe overrides stale snapshot reachability;
- non-`Allow` decisions never reach the evaluator;
- continuity certificate binds exact source, proposal, evidence, policy,
  invariants, ontology, and semantics;
- cached heuristic output remains advisory.

### Replay

Freeze:

```text
ledger root
evidence snapshot and closure
context graph and freshness policy
reasoner backend/version/semantics/rules/priors/dependence model
policy manifest and regularization profile
ontology and calibration profile
```

Rebuild derived beliefs and decisions. Caches may use different local IDs, but
claims, normalized estimates within tolerance, evidence identities, derivation
obligations, applicability status, and decisions must match.

### Adversarial

Run `examples/adversarial_scenarios.md`, including:

- declared capability but missing executable;
- correlated provider failures;
- provider outage misread as intrinsic incapacity;
- old evidence marked stale and then incorrectly deleted;
- inherited evidence counted through two parent paths;
- version/regime change with silent confidence inheritance;
- copied secret/history used to claim `SelfHereNow`;
- unsigned or expired policy manifest;
- reasoner semantics mismatch;
- high-impact continuity cache miss;
- poisoned heuristic certificate;
- counterfactual leakage;
- broken lineage hidden by fluent narrative;
- two non-commuting mutation orders.

### Governance seam

For a fixed evidence/reasoner snapshot, run at least three representative signed
policies. Compare stabilized beliefs, action decisions, selected evidence,
attribution, protected commitments, and regularization effects. Restrict to
reachable results and label implementation-frozen claims.

## Release gates

- all unit/invariant/adapter tests pass;
- ledger verification and replay pass;
- schemas and examples validate;
- no unconsumed high/critical tripwire;
- no unsigned/expired/wrong-semantics policy can authorize;
- high-impact cache miss and heuristic continuity tests pass;
- shadow coverage and false-Allow review are complete;
- calibration and decision differential are within approved limits;
- rollback is rehearsed;
- feature flags default safe;
- operator explanation includes evidence closure, applicability, context transfer,
  backend/semantics, policy manifest, and continuity result.
