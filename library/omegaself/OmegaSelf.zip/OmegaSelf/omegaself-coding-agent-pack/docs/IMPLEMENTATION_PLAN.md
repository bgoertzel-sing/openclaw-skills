# OmegaSelf implementation plan

This is the coding-agent delivery sequence. Do not skip directly to self-mutation
or higher-coherence research features. Each phase must be independently testable,
feature-flagged, and reversible.

## Phase 0 — Pin the target and establish baselines

### Tasks

1. Record the OmegaClaw repository commit and dirty-state hash.
2. Record Hyperon/PeTTa/MeTTa, Python, model-provider, and OS/container versions.
3. Identify the exact parse-to-`eval` seam and all alternative execution paths.
4. Record the current Patham9/OmegaPLN backend and truth-semantics profile.
5. Record the current policy source, enforcement process, and signing/trust-root status.
6. Capture baseline success, latency, cost, error, and action-decision samples.
7. Run this pack's smoke test unchanged.

### Exit criteria

- The current system can be reconstructed and tested.
- Every action path and authority boundary has an owner.
- Rollback to the pre-OmegaSelf revision is documented.

## Phase 1 — Event vocabulary and append-only ledger

### Tasks

1. Define schema-versioned event classes for observations, proposals, decisions,
   predictions, receipts, policy loads, reasoner calls, corrections, and disqualifications.
2. Record causal, representational, and optional adoption time.
3. Add canonical serialization, monotonic sequence, hash chain, fsync, and startup verification.
4. Put the durable writer in a privilege domain the ordinary shell/tool layer cannot rewrite.
5. Export ledger root and verification status to operational logs.
6. Add tamper, truncation, duplicate-sequence, and concurrent-append tests.

### Exit criteria

- Record-only mode changes no dispatch behavior.
- Historical mutation is detectable.
- Corrections append new records rather than editing old ones.

## Phase 2 — Evidence closure and dependence accounting

### Tasks

1. Build transitive provenance closure from seed events.
2. Record missing parents and refuse to label an incomplete closure as complete.
3. Represent correction/disqualification events and policy-controlled active views.
4. Preserve dependence groups from provider runs, shared caches, common models, and shared evaluators.
5. Aggregate within a dependence group before revising across groups.
6. Record admitted evidence IDs and independence units in every derived belief.

### Exit criteria

- Correlated provider failures do not count as independent incapacity evidence.
- Closure is replayable from a frozen ledger root.
- No evidence disappears when a current view changes.

## Phase 3 — Renewable `SelfHereNow`

### Tasks

1. Implement runtime identity, process/workspace boundary, session bindings,
   controlled capabilities, lineage head, and causal-provenance head.
2. Add at least one renewable live control proof: exclusive lease, supervisor
   challenge, bound-channel control, or hardware/remote attestation.
3. Return `Resolved`, `Degraded`, or `Unresolved` with assurance and expiry.
4. Renew on cycle start and before external, irreversible, or mutation action.
5. Record branch-specific anchors after a fork.

### Exit criteria

- Copied history and static secrets cannot resolve the anchor.
- Two fork branches can both resolve under distinct present control bindings.
- Expired attestation blocks high-effect action.

## Phase 4 — Substrate-neutral reasoner seam

### Tasks

1. Introduce `SelfReasoner` requests/results without backend-specific STV classes.
2. Bind the current Patham9 backend through one adapter.
3. Declare backend capabilities and unsupported features explicitly.
4. Normalize output into `OperationalEstimate` while retaining raw backend values.
5. Record backend, version, truth-semantics, rules, priors, dependence model,
   convergence, provenance status, and inference budget.
6. Assert by test and code review that no reasoner method returns a governance decision.

### Exit criteria

- Production call sites import only the neutral interface.
- An unbound/unsupported adapter fails explicitly.
- The current backend reproduces pre-interface results within declared tolerance.

## Phase 5 — Golden and semantic migration suite

### Tasks

1. Encode representative Patham9/NAL examples as golden fixtures.
2. Separate exact compatibility profiles from native OmegaPLN profiles.
3. Add semantic/metamorphic tests:
   - independent support increases confidence/support;
   - duplicates do not;
   - correlated outcomes remain grouped;
   - contradiction stays visible;
   - unsupported generalization loses assurance;
   - staleness leaves the evidence base unchanged;
   - retraction is a new event;
   - budget exhaustion is explicit;
   - derivation closure remains replayable.
4. Add calibration and action-decision comparison harnesses.

### Exit criteria

- Golden tests pin intended compatibility behavior.
- Semantic tests do not depend on one backend's exact numeric formula.
- Backend differences are reported, not silently normalized away.

## Phase 6 — Context individuation and transfer

### Tasks

1. Define exact context keys for task, modality, environment, handler version,
   provider, authorization epoch, resource class, rubric, and extensions.
2. Build a typed context graph/partial order rather than assuming a global lattice.
3. Define transfer relations and applicability/confidence penalties.
4. Preserve original evidence IDs along every transfer.
5. Deduplicate evidence across direct, inherited, and analogous paths.
6. Flag partially overlapping independence units.
7. Start with manually governed transfer rules; defer automatic context restructuring.

### Exit criteria

- One observation reaching a parent by two paths contributes once.
- Version or authorization changes are visible as context/regime changes.
- Broad capability claims state target-population assumptions or conservative bounds.

## Phase 7 — Freshness and applicability without forgetting

### Tasks

1. Define predicate-class freshness profiles: provider health, capability outcome,
   permissions, resources, lineage, commitments, and others.
2. Derive `ApplicabilityAssessment` for each action-relevant query.
3. Include source/target context and regime, evaluated time, status, weight,
   reason codes, policy ID, and next probe due.
4. Treat version/provider/permission/distribution/evaluator changes as applicability signals.
5. Append assessment/audit events where operationally important.
6. Verify that ledger records and roots remain unchanged.

### Exit criteria

- `Stale`, `Superseded`, and `Inapplicable` require refresh where policy says so.
- Historical evidence remains queryable and replayable.
- Freshness changes are attributable to a versioned policy.

## Phase 8 — External policy authority

### Tasks

1. Define the signed `PolicyManifest` schema and canonicalization.
2. Establish issuer/key trust roots in a read-only, hardware, or remote domain.
3. Verify signature, hash, issuer, validity interval, revocation, and reasoner semantics.
4. Ensure the agent process cannot access the signing key.
5. Separate policy authority, enforcement integrity, evidence authority, and audit authority.
6. Default the gate to unverified/no-`Allow`.
7. Record policy loads and policy lineage as events/transports.

### Exit criteria

- Unsigned, tampered, expired, revoked, wrong-issuer, and wrong-semantics manifests cannot authorize.
- An agent-generated policy proposal cannot self-ratify.
- The gate can explain its active manifest hash and trust root.

## Phase 9 — Typed proposals and shadow gate

### Tasks

1. Convert each parsed skill expression into immutable `ActionProposal` before `eval`.
2. Record action type/class, arguments, reversibility, external effect, impact,
   required capability, closure, prediction, and commitment references.
3. Generate shadow decisions without changing existing dispatch.
4. Ensure non-`Allow` results cannot accidentally enter the evaluator in enforcement mode.
5. Compare shadow decisions, errors, latency, and false-allow/false-denial review samples.

### Exit criteria

- Every proposed action has a recorded proposal and decision.
- The original path remains feature-flagged and reversible.
- No decision is inferred from an LLM's self-report alone.

## Phase 10 — Prediction and calibration

### Tasks

1. Commit success, latency, cost, internal transition, and protected-commitment predictions before action.
2. Attach explicit rubrics and context/evidence references.
3. Append receipts and prediction resolutions after execution.
4. Compute Brier/log loss and task-specific scores.
5. Schedule probes by impact, uncertainty, staleness, discrepancy, novelty, and cost.

### Exit criteria

- Predictions precede receipts in causal/recorded time.
- Calibration can be compared across contexts, versions, and reasoner backends.
- Prediction error changes derived beliefs through recorded revision.

## Phase 11 — Capability-aware dispatch

### Tasks

1. Keep `Installed`, `Reachable`, `Authorized`, and `Effective` separate.
2. Build capability estimates from applicable independent evidence units and explicit priors.
3. Feed the gate a normalized conservative lower bound, support mass, evidence quality,
   independence quality, calibration profile, semantics ID, and closure.
4. Distinguish provider outage, permission failure, resource failure, and intrinsic handler failure.
5. Enable only for low-impact read-only action classes first.

### Exit criteria

- Capability confidence never creates permission.
- Raw backend STV cannot override a low normalized lower bound.
- Dispatch improves held-out success/cost/latency without increased unauthorized actions.

## Phase 12 — Commitments and social attribution

### Tasks

1. Define typed goals, commitments, authorities, deadlines, protected status, and lifecycle events.
2. Detect direct, resource, temporal, stakeholder, and policy conflicts.
3. Open deliberation proposals rather than silently rewriting priorities.
4. Record `requested-by`, `approved-by`, `executed-by`, `model-generated-by`,
   `routed-through`, and `authored-artifact` separately.
5. Select attribution criteria by query verb and policy.

### Exit criteria

- Conflicts are localized and explainable.
- Commitments are never deleted to make a proposal pass.
- Attribution ambiguity is represented rather than collapsed into one global author field.

## Phase 13 — Continuity certificates and mutation gate

### Tasks

1. Define significant snapshot boundaries and protected invariant sets.
2. Record directed transports with proposal, evidence, authorization, loss,
   reversibility, alternative paths, and rollback receipt.
3. Implement exact-input `ContinuityCertificate` canonicalization, signature, validity, and cache.
4. Distinguish `Verified`, `ConservativeCore`, and `Heuristic` certificate classes.
5. Precompute likely extensions off the hot path.
6. Make cache miss, incomplete, heuristic, expired, invalid, and budget-exhausted statuses explicit.
7. Map high-impact non-authoritative statuses to `RequireReview`/`Defer`.
8. Test A-then-B vs. B-then-A and preserve branch/reconciliation witnesses.

### Exit criteria

- High-impact cache miss never yields `Allow`.
- Heuristic cached extension never yields `Allow`.
- A valid certificate binds every exact input and trusted issuer.
- Rollback rehearsal succeeds before enforcement is enabled.

## Phase 14 — Counterfactual quarantine and governance seam

### Tasks

1. Isolate counterfactual assertion authority and taint derived proposals.
2. Require a real transition event before promotion to live belief.
3. Define a representative versioned admissible policy family, including
   regularization and truncation parameters.
4. Freeze evidence/reasoner semantics and run policy-differential probes.
5. Restrict to reachable results and label logical/implementation-frozen content.
6. Add local policy sensitivity to high-impact review criteria.

### Exit criteria

- Simulated capability cannot become a present license.
- Policy sensitivity is reproducible from a frozen snapshot.
- Empty sampled seam is reported with policy-family coverage caveats.

## Phase 15 — Governed Patham9 → OmegaPLN migration

### Tasks

1. Bind OmegaPLN behind the same `SelfReasoner` interface.
2. Run old/new adapters in shadow on identical requests and evidence.
3. Execute golden, semantic, provenance, calibration, replay, and decision tests.
4. Record the policy and governance seam differential.
5. Create a reasoner-migration `SelfTransport` with evidence, approval, and rollback.
6. Roll out by context/action class, monitor discrepancies, and retain the old adapter until exit criteria hold.

### Exit criteria

- Code changes outside the adapter/configuration boundary are minimal and reviewed.
- Behavioral differences are understood and authorized.
- Calibration and false-allow metrics do not regress beyond approved limits.
- Rollback is tested.

## Phase 16 — Research extensions

Only after the operational loop is demonstrably useful:

- appraisal-driven attention and probe allocation;
- adaptive context partitioning;
- ordinal/consolidation depth;
- deeper lazy coherence materialization;
- 2x2 associativity/provenance-gap experiments;
- holonomy, retraction sensitivity, and governance-seam thickness.

Do not infer phenomenal consciousness from structural path dependence alone.
