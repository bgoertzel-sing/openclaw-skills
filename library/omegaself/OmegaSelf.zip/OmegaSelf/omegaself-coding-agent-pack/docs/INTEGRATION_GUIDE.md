# OmegaClaw integration guide

## 1. Locate the causal seam

Find the code path that repairs/parses an LLM response, produces skill expressions,
and calls `eval`. Insert OmegaSelf after parsing and before any evaluator,
including alternate/background paths.

```text
parsed expression
  → ActionProposal
  → pre-action prediction
  → evidence closure / context / applicability
  → SelfReasoner adapter
  → OperationalEstimate
  → externally verified PolicyGate
  → eval only if Allow
```

## 2. Install the reference package

During development:

```bash
python -m pip install -e path/to/omegaself-coding-agent-pack/python
```

Or add the directory to the target environment's `PYTHONPATH`. Keep the durable
ledger and policy verifier outside an LLM-writable workspace where possible.

## 3. Start in record-only mode

Import the bridge, initialize a separate data directory, and record cycle starts,
parsed calls, receipts, failures, provider/resource probes, policy loads, and
reasoner invocations. Verify the chain on startup. Do not change dispatch.

## 4. Bind the current reasoner through one adapter

Implement a callable or native bridge that maps the target Patham9 API to
`InferenceRequest`/`InferenceResult`. Do not expose backend-specific STV objects
to other modules. Record a capabilities declaration and explicit unsupported
features.

Run golden NAL tests before changing the backend.

## 5. Add context and applicability

Construct exact context keys at proposal time. Build a manually reviewed context
transfer graph. Preserve event IDs along transfers and deduplicate before
revision. Derive a fresh applicability view from time, context, and regime; never
rewrite evidence for staleness.

## 6. Establish policy authority

Provision a signed policy manifest and read-only/remote trust root. Verify:

- canonical hash;
- signature and issuer;
- effective/expiry interval;
- revocation;
- reasoner truth-semantics ID.

Only then construct an Allow-capable gate. The reference HMAC verifier is for
tests; use asymmetric or remote verification in production.

## 7. Add proposals and shadow decisions

Convert each expression without changing its content. Commit the proposal and
prediction before evaluation. Evaluate policy in shadow mode and record the
result. Compare with actual behavior and review false allows/denials.

## 8. Enforce capability dispatch gradually

Use normalized lower bounds, support mass, evidence/independence quality,
calibration, and applicability. Start with low-impact read-only classes. Keep
`Installed`, `Reachable`, `Authorized`, and `Effective` distinct.

## 9. Add continuity certificates

Precompute likely mutation analyses off the hot path. Certificates must bind exact
source/proposal/target/evidence/policy/invariant/ontology/semantics inputs and be
signed by a trusted issuer. Cache miss or heuristic status cannot authorize a
high-impact mutation.

## 10. Migrate the reasoner as a governed transport

Bind OmegaPLN behind the same interface and shadow it against Patham9. Compare
golden values where intended, semantic invariants, provenance, calibration,
action decisions, and governance seam. Record approval and rollback before
enabling it.

## 11. MeTTa files

`omegaclaw/src/self_model/*.metta` is scaffolding. Reconcile import syntax, Atom
constructors, foreign-function registration, and logical-space isolation against
the pinned target interpreter. Do not mark the integration complete until native
MeTTa tests pass.
