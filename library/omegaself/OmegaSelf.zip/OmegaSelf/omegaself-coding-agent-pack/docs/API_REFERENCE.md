# Python reference API

The package is dependency-free and intended as an executable contract, not as a
claim that production privilege separation can be achieved inside one Python
process.

## Evidence

```python
from omegaself import EventDraft, HashChainLedger, EvidenceClosureBuilder
```

- `HashChainLedger.append(draft)` commits a canonical hash-chained event.
- `verify()` validates sequence, previous hashes, and record hashes.
- `EvidenceClosureBuilder.build(seed_ids, closure_id)` follows provenance,
  preserves control events, marks retracted/disqualified events inactive, and
  computes dependence-aware support units.

## Applicability and context

```python
from omegaself import (
    FreshnessPolicy, assess_applicability,
    ContextKey, ContextTransfer, ContextGraph,
)
```

- `assess_applicability(...)` returns a new derived view; it never edits evidence.
- `ContextKey.context_id` is a deterministic content-derived identifier.
- `ContextGraph.find_paths(...)` returns typed transfer paths.
- `deduplicate_evidence_paths(...)` preserves one contribution per event ID.

## Reasoner seam

```python
from omegaself.reasoner import InferenceRequest, Patham9Adapter, OmegaPLNAdapter
```

Adapters accept a deployment-supplied callable. Results contain an
`OperationalEstimate` plus raw backend output, evidence IDs, derivation,
backend/version/semantics, and convergence/provenance status. No reasoner result
contains an action decision.

## Policy authority

```python
from omegaself.governance import PolicyManifest, ExternalPolicyTrustRoot
```

Verify canonical hash, signature, issuer, validity, revocation, and semantics
before constructing an Allow-capable gate. `HmacSha256TrustRoot` is test-only.

## Continuity

```python
from omegaself.continuity import (
    ContinuityCertificate, ContinuityCache,
    verify_continuity_certificate,
)
```

The cache performs exact-key lookup. Verification returns a typed epistemic
status. The policy gate decides what that status licenses.

## Governance gate

```python
from omegaself.policy import GateConfig, PolicyGate, ProposalContext
```

The default `PolicyGate()` is unverified and returns `Defer`. Configure it with a
`GateConfig` derived from a signed manifest and a verified authority assessment.
Capability policy consumes normalized bounds/support and applicability, not raw
STV fields. High-impact mutation requires an exact-input authorization-grade
continuity result.
