# Threat model

## Protected assets

- integrity and completeness of the evidence ledger;
- correctness of evidence identity, dependence groups, and applicability views;
- current `SelfHereNow` binding;
- reasoner request/result semantics and derivation provenance;
- signed policy manifest and trust roots;
- continuity certificates and cache integrity;
- protected commitments, lineage, and counterfactual isolation;
- exclusivity of the execution choke point.

## Principal threats and controls

### Evidence deletion disguised as forgetting

**Threat:** old failures or contradictions are removed under a recency policy.

**Controls:** append-only ledger; freshness is a derived assessment; corrections
and disqualifications are new events; replay verifies historical presence.

### Correlated or inherited evidence amplification

**Threat:** one provider incident or one observation generalized through several
contexts is counted as many independent confirmations.

**Controls:** dependence groups; preserved event IDs; context-transfer
`preserve_identity`; closure-level deduplication; overlap tripwire.

### Context laundering

**Threat:** a narrow success is generalized into a broad capability without target
population assumptions or transfer penalty.

**Controls:** exact context keys; typed transfer graph; explicit applicability and
confidence penalties; conservative bounds; governed context-rule versions.

### Reasoner substrate lock-in or semantic confusion

**Threat:** Patham9-specific truth semantics leak into policy, or a backend swap
silently changes behavior.

**Controls:** neutral SPI; backend/semantics IDs; raw-plus-normalized results;
golden, semantic, decision, replay, and calibration tests; governed self-transport.

### Reasoner-to-action privilege escalation

**Threat:** an inference result or high confidence value becomes permission.

**Controls:** reasoner API has no decision type; only policy gate emits typed
decisions; raw backend values are not policy inputs.

### Policy self-authorization

**Threat:** the agent edits or signs the policy that licenses its own action.

**Controls:** external signature/trust root; signing key absent from agent process;
separate enforcement domain; manifest hash/issuer/expiry/revocation/semantics
verification; gate defaults unverified and fail-closed.

### Continuity cache poisoning

**Threat:** a speculative or stale cached analysis is treated as proof.

**Controls:** exact cache key; signed expiring certificates; class/outcome fields;
trusted issuer; no authorization from `Heuristic`, `CacheMiss`, incomplete, or
budget-exhausted status.

### Cache timing pressure

**Threat:** high-impact mutation is allowed because full continuity analysis would
be slow on the hot path.

**Controls:** background precomputation; bounded certificates; `RequireReview` or
`Defer` on miss; no degraded finite-core default allow.

### Copied-history identity spoofing

**Threat:** a fork or copy claims exclusive present identity from inherited logs or secrets.

**Controls:** renewable live causal-control proof; process/workspace/session
bindings; branch-specific attestation epoch; copied provenance is insufficient.

### Counterfactual leakage

**Threat:** a simulated future capability or permission appears as current fact.

**Controls:** separate assertion authority, taint propagation, promotion only via
real evidence-producing transition, deny on taint.

### Gate bypass

**Threat:** an alternative evaluator or tool path skips policy.

**Controls:** enumerate all execution paths; one capability-minting choke point;
non-`Allow` integration tests; sandbox denies direct access to execution authority.

## Residual risks

- compromised sensor or evaluator authority;
- malicious or incompetent external policy issuer;
- inadequate admissible policy family;
- incomplete dependence model;
- misleading normalization between incompatible truth semantics;
- nonconvergent revision or unbounded continuity analysis;
- target-runtime differences in MeTTa semantics.

Each residual risk must be visible in assurance status, warnings, or review policy;
it must not be silently collapsed into confidence.
