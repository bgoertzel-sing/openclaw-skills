# Requirement-to-component traceability

| Requirement | Component/file | Primary test |
|---|---|---|
| Append-only evidence | `ledger.py` | `test_ledger.py` tamper detection |
| Three temporal orders | observation schema | timestamp fixtures/replay |
| Complete derivation | `evidence.py` | missing-parent closure test |
| Dependence groups | `evidence.py` | provider-run grouping test |
| Staleness is not forgetting | `applicability.py` | ledger root unchanged after stale assessment |
| Regime-aware applicability | `applicability.py` | version/regime supersession test |
| Exact context keys | `context_graph.py`, schema | deterministic context ID test |
| Inherited evidence dedup | `context_graph.py` | two-path one-event test |
| Substrate-neutral reasoner | `reasoner/base.py` | same call site for two adapters |
| Patham9 adapter | `reasoner/patham9_adapter.py` | compatibility test |
| OmegaPLN adapter | `reasoner/omegapln_adapter.py` | compatibility test |
| Raw STV not policy interface | `OperationalEstimate`, `policy.py` | high point/low lower-bound test |
| Reasoner cannot decide | reasoner result schema/API | no decision field test |
| Runtime-scoped indexical | `attestation.py` | static-secret and live-lease tests |
| Branching continuity | attestation/transport schemas | two branch anchors test |
| Exact-input continuity | `continuity/` | certificate verification test |
| Cache miss fails closed | `continuity/cache.py`, `policy.py` | high-impact cache-miss review test |
| Heuristic is advisory | certificate class + gate | heuristic mutation review test |
| External policy authority | `governance/` | valid/tampered/expired/semantics tests |
| PLN separate from permission | `reasoner/`, `policy.py` | unverified gate defers |
| Pre-action prediction | `predictions.py` | scoring/order integration test |
| Counterfactual quarantine | gate taint field | counterfactual deny test |
| Detector has consumer | tripwire schema/startup validator | unconsumed critical fixture |
| Governance seam | `policy_seam_probe.py` | fixed-evidence signed-policy differential |
| Reasoner migration | adapter/compatibility modules | old/new shadow comparison |
| Query-relative attribution | social facet design | multi-criteria attribution scenario |
