# Golden reasoner migration procedure

Concrete NAL/PLN examples and the production reasoner seam serve different jobs.

- The **production seam** is `SelfReasoner` and remains substrate-neutral.
- The **golden suite** is intentionally backend/profile-specific and pins expected
  Patham9 behavior for cases where OmegaPLN is meant to be compatible.

## Capture procedure

1. Pin the Patham9 repository, rule profile, truth-semantics profile, numeric
   precision, context, priors, and evidence/dependence representation.
2. Run every case in `examples/golden_reasoner_cases.example.json`.
3. Record exact input atoms and evidence IDs.
4. Capture conclusion, raw truth value, normalized envelope, derivation trace,
   admitted evidence set, convergence status, and provenance status.
5. Commit the frozen fixture with its backend/version/semantics metadata.
6. Run the same requests through the OmegaPLN adapter in compatibility mode.
7. Compare exact values only where the profile promises exact compatibility.
8. For native OmegaPLN semantics, compare semantic properties, calibration,
   provenance, and action-decision behavior instead of forcing false numeric equality.

## Required controls

- duplicate evidence identity;
- correlated dependence group;
- inherited context evidence reaching a claim along multiple paths;
- contradiction visibility;
- unsupported generalization;
- missing provenance parent;
- inference-budget exhaustion;
- stale applicability with unchanged evidence root.

## Approval evidence

A backend migration report must contain:

- golden compatibility results;
- semantic/metamorphic results;
- frozen-snapshot replay comparison;
- prediction calibration comparison;
- policy-decision differential;
- governance-seam differential;
- accepted deviations and rationale;
- rollout and rollback plan.
