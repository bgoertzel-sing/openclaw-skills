# OmegaSelf architecture specification

## 1. Purpose

OmegaSelf is an event-sourced, PLN-interpreted self-theory and governance layer
for OmegaClaw agents. Its purpose is to improve self-prediction, discrepancy
detection, provenance preservation, capability dispatch, commitment handling,
and controlled self-change.

It initially answers three operational questions:

1. What can this attested instance probably do in this context?
2. What is it currently committed to doing?
3. What authorized changes produced its present state?

The first consumers are capability-aware dispatch, commitment-conflict
deliberation, and a mutation continuity gate.

## 2. Architectural state

A useful operational decomposition is:

```text
OmegaSelf_t = <E, A_t, Theta_t, D_t, Pi_t, K_t, L_t ; G_t>
```

- `E`: append-only evidence;
- `A_t`: current runtime-resolved `SelfHereNow` anchor;
- `Theta_t`: contextual derived self-beliefs;
- `D_t`: evidence closures and derivation records;
- `Pi_t`: committed predictions and resolutions;
- `K_t`: goals and commitments;
- `L_t`: snapshots, transports, forks, and lineage;
- `G_t`: externally authorized governance configuration.

The semicolon indicates that governance authority is not just another empirical
self-belief revised by the same mechanism as `Theta_t`.

## 3. Authority planes

### 3.1 Evidential substrate

A durable append-only ledger records runtime probes, authenticated receipts,
tests, messages, resources, policy loads, reasoner invocations, mutation records,
prediction outcomes, and external evaluations. Python or Rust measures and
persists; MeTTa owns semantic projection and PLN reasoning.

Every event distinguishes:

- causal time: when the represented event happened;
- recorded time: when its trace entered the ledger;
- adoption time: when a belief was adopted from it.

Corrections and disqualifications are new events that refer to prior events.

### 3.2 Applicability and context plane

Evidence existence and evidence applicability are different facts. A current
query receives a fresh `ApplicabilityAssessment` indexed by:

```text
predicate class × time × source context × target context
× source regime × target regime × freshness policy
```

Staleness, supersession, or context mismatch can reduce present licensing power
without changing the historical evidence.

Contexts use exact keys such as:

```text
task class × input modality × environment × handler version × provider
× authorization epoch × resource class × rubric
```

A typed context graph supports subsumption, analogy, compatible-version transfer,
and explicit distribution-shift relations. Original event IDs remain attached to
every transfer and are deduplicated before revision.

### 3.3 Reasoning plane

All production callers use the substrate-neutral `SelfReasoner` service-provider
interface:

```text
infer(request)  -> InferenceResult
revise(request) -> RevisionResult
explain(claim, snapshot) -> DerivationClosureView
compare(policy family) -> DifferentialInferenceResult
```

Patham9 PLN and OmegaPLN are adapters. Each request names context, evidence
snapshot and closure, rule profile, prior bundle, dependence model, budget,
provenance requirement, and assurance mode.

Each result names backend/version, truth-semantics profile, evidence IDs,
derivation, convergence/provenance status, and a normalized
`OperationalEstimate`:

```text
semantics ID
point estimate
lower/upper bounds
independent support mass
evidence and independence quality
calibration profile
evidence closure
raw backend value
```

The raw STV or other backend value is retained for audit. Governance consumes the
normalized envelope and never assumes one backend's semantics.

### 3.4 Prediction and calibration plane

Action-relevant beliefs emit pre-action predictions with explicit rubrics.
Outcomes resolve them with Brier/log scores and append discrepancy events.
Predictions are committed before action to prevent hindsight reconstruction.

### 3.5 Continuity and indexical plane

`SelfHereNow` is resolved per runtime context and attestation epoch from:

- authenticated runtime identity;
- process/workspace boundary;
- controlled capabilities and permissions;
- active session bindings;
- lineage head;
- causal-provenance head;
- renewable evidence of present causal control.

Copied history or copied secrets are insufficient. After a fork, both branches
may be continuations, with distinct present anchors.

Continuity is directed transport rather than equality. Actual revision maps form
an endomorphism monoid in general; inverses and homotopy invariance are not
assumed.

### 3.6 Governance plane

Beliefs and continuity services emit epistemic objects. They do not execute.
Typed proposals are consumed by a deterministic gate configured from an
externally signed, versioned policy manifest. The gate returns:

```text
Allow | Deny | RequireProbe | RequireReview | Defer
```

Only `Allow` reaches execution.

Policy authority, enforcement integrity, evidence authority, and audit authority
should occupy separable privilege domains in production.

## 4. Logical spaces

```text
&self_observations    immutable evidence projections and receipts
&self_applicability   time/context/regime-indexed applicability views
&self_beliefs         contextual reasoner conclusions
&self_predictions     committed predictions and resolutions
&self_continuity      snapshots, transports, certificates, forks
&self_policy          signed policy references, permissions, consumers
&self_alerts          tripwires and resolution state
&self_counterfactual  quarantined simulations
&self_social          roles, sessions, and query-relative attribution
```

Counterfactual spaces cannot share live assertion authority. Promotion requires
a real evidence-producing transition.

## 5. Capability semantics

Keep distinct:

```text
Installed(capability)
Reachable(capability, context)
Authorized(capability, action class)
Effective(capability, task class, context, version, rubric)
```

Evidence-derived capability estimates use independent, applicable,
rubric-compatible evidence units—not raw event counts. Explicit priors are
permitted only as labeled, reversible prior bundles.

A provider outage updates provider reachability more strongly than intrinsic
handler effectiveness. A version change creates a new regime and explicit
transfer/prior, not silent full-confidence inheritance.

## 6. Evidence closure and double-count prevention

A closure is an immutable derivation DAG plus root hash. It records source events,
provenance parents, corrections/disqualifications, missing parents, dependence
groups, and context-transfer paths.

Before reasoner revision:

1. traverse complete provenance;
2. exclude only through append-only disqualification policy;
3. preserve original event IDs;
4. aggregate within dependence groups;
5. deduplicate event IDs across inherited/analogous context paths;
6. flag partially overlapping independence units;
7. record the exact admitted evidence set.

## 7. Staleness without forgetting

A freshness profile is versioned by predicate class. Provider health may expire
in minutes; lineage may remain applicable indefinitely. Applicability also reacts
to version, provider, permissions, task distribution, resources, and evaluator
changes.

A stale record remains queryable as historical evidence. The gate may require a
new probe before current action, but no record is removed to make the current
view cleaner.

## 8. Continuity certificate semantics

A continuity certificate binds:

```text
source snapshot
proposal hash
predicted result-state hash
evidence snapshot
policy manifest
protected invariant set
ontology version
reasoner backend and semantics
analysis algorithm/depth/coverage
issuer, validity, and signature
```

Certificate classes:

- `Verified`: authorization-grade analysis under the declared method;
- `ConservativeCore`: sound preservation proof for a named safe mutation class;
- `Heuristic`: speculative/advisory extension.

A cache is only an accelerator. For high-impact mutations:

- `Verified` or policy-accepted exact-input `ConservativeSafe`: continue checks;
- `Contradicted`: `Deny`;
- `Heuristic`, `CacheMiss`, `Incomplete`, `BudgetExhausted`, `Expired`, or
  `Invalid`: `RequireReview` or `Defer`.

## 9. Signed policy authority

The policy manifest includes identity/version/parent hash, issuer/key, validity,
action classes, capability thresholds, assurance and continuity requirements,
review requirements, protected invariants, permitted overrides, reasoner
semantics, calibration and regularization profiles, and signature.

The gate defaults to unverified and therefore cannot authorize. The agent may
produce a `PolicyMutationProposal`; commitment requires the configured external
authority. The signing key must not be available to the agent process.

## 10. Governance seam

For policy-parameterized revision operators:

```text
Gov(rho) = union_p Fix_p(rho) minus intersection_p Fix_p(rho)
```

Operational probes freeze evidence and reasoner semantics, vary representative
signed policies, run revision to a declared horizon or convergence, and compare
beliefs and decisions. Restrict to reachable results, identify logical and
implementation-frozen content, and include regularization/truncation in the
policy profile.

A large local policy differential around a high-impact proposal triggers review.
An empty sampled seam is not proof of safety; the policy family may be too narrow.

## 11. Reasoner migration

The Patham9-to-OmegaPLN code change is an adapter swap, but the behavioral change
is a governed self-transport. Required evidence:

1. pinned old/new backend and semantics IDs;
2. golden NAL compatibility cases where exact compatibility is intended;
3. semantic/metamorphic tests for independence, contradiction, retraction,
   provenance, budget exhaustion, and staleness;
4. shadow replay over frozen evidence snapshots;
5. policy-decision differential;
6. prediction calibration comparison;
7. governance-seam comparison;
8. approval, rollout, and rollback records.

## 12. OmegaClaw integration seam

Insert OmegaSelf after parsing and before `eval`:

```text
parsed skill expressions
  → immutable typed proposals
  → committed predictions
  → closure/applicability/context/reasoner views
  → signed-policy gate
  → evaluate Allow only
  → append receipts and resolve predictions
```

Add a compact query-derived `SELF_CONTEXT` to prompts. Do not inject the full
ledger or a long self-authored narrative.

## 13. Tripwires and consumers

Required tripwires include missing closure, stale support, cross-facet
contradiction, prediction failure, anchor expiry, broken lineage, correlated or
inherited evidence double-counting, counterfactual leakage, invalid policy
authority, reasoner-semantics mismatch, missing continuity certificate, and high
policy sensitivity.

Startup validation rejects every high/critical tripwire kind without a registered
consumer.
