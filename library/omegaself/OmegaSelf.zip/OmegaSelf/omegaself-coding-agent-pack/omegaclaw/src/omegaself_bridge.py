"""Thin Python bridge intended for import from OmegaClaw/PeTTa.

This file is an integration scaffold.  It uses only the reference package in
``python/omegaself`` and serializes all bridge results as JSON strings so MeTTa
can treat them as opaque values until an AtomSpace projection is implemented.

Before deployment, add the package directory to PYTHONPATH or install it into the
OmegaClaw virtual environment, then adapt function registration to the target
PeTTa revision.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

# Development-pack convenience: locate the sibling reference package.
_PACK_ROOT = Path(__file__).resolve().parents[2]
_REFERENCE_PYTHON = _PACK_ROOT / "python"
if _REFERENCE_PYTHON.exists() and str(_REFERENCE_PYTHON) not in sys.path:
    sys.path.insert(0, str(_REFERENCE_PYTHON))

from omegaself.canonical import utc_now_iso  # noqa: E402
from omegaself.ledger import HashChainLedger  # noqa: E402
from omegaself.types import EventDraft  # noqa: E402

_LEDGER: HashChainLedger | None = None


def _json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def _get_ledger(data_dir: str | None = None) -> HashChainLedger:
    global _LEDGER
    if _LEDGER is None:
        root = Path(data_dir or os.environ.get("OMEGASELF_DATA_DIR", "./memory/omegaself"))
        root.mkdir(parents=True, exist_ok=True)
        _LEDGER = HashChainLedger(root / "self_observations.jsonl")
    return _LEDGER


def init(data_dir: str = "") -> str:
    """Initialize the ledger and return a compact status JSON string."""

    ledger = _get_ledger(data_dir or None)
    verification = ledger.verify()
    return _json(
        {
            "status": "ready" if verification.ok else "ledger_error",
            "ledger": str(ledger.path),
            "record_count": verification.record_count,
            "root_hash": verification.root_hash,
            "errors": list(verification.errors),
        }
    )


def append_observation(event_json: str) -> str:
    """Append a JSON-encoded observation draft.

    Required keys: event_type, subject_anchor, context, payload. Optional keys:
    causal_time, adopted_time, provenance, dependence_group, event_id.
    """

    try:
        value = json.loads(event_json)
        if not isinstance(value, dict):
            raise ValueError("observation must be a JSON object")
        payload = value.get("payload", {})
        if not isinstance(payload, dict):
            raise ValueError("payload must be a JSON object")
        event = _get_ledger().append(
            EventDraft(
                event_type=str(value["event_type"]),
                subject_anchor=str(value["subject_anchor"]),
                context=str(value["context"]),
                payload=payload,
                causal_time=str(value.get("causal_time") or utc_now_iso()),
                adopted_time=None
                if value.get("adopted_time") is None
                else str(value["adopted_time"]),
                provenance=tuple(str(item) for item in value.get("provenance", [])),
                dependence_group=None
                if value.get("dependence_group") is None
                else str(value["dependence_group"]),
                event_id=None if value.get("event_id") is None else str(value["event_id"]),
            )
        )
        return _json({"ok": True, "event": event.to_dict()})
    except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
        return _json({"ok": False, "error": str(exc)})


def verify_ledger() -> str:
    report = _get_ledger().verify()
    return _json(
        {
            "ok": report.ok,
            "record_count": report.record_count,
            "root_hash": report.root_hash,
            "errors": list(report.errors),
        }
    )


def compact_context(max_events: int = 12) -> str:
    """Return a conservative summary for inclusion in the LLM prompt.

    This is intentionally not a self-narrative.  It exposes recent alert and
    decision records and the ledger root.  A production projection should query
    contextual PLN beliefs rather than summarizing raw events.
    """

    ledger = _get_ledger()
    recent = list(ledger.iter_records())[-max(1, int(max_events)) :]
    selected = [
        {
            "event_id": record.event_id,
            "event_type": record.event_type,
            "context": record.context,
            "payload": record.payload,
        }
        for record in recent
        if record.event_type in {
            "tripwire",
            "policy_decision",
            "policy_authority",
            "self_anchor",
            "commitment",
            "continuity_analysis",
            "evidence_applicability",
            "prediction_resolution",
        }
    ]
    return _json({"ledger_root": ledger.root_hash(), "recent_control_events": selected})
