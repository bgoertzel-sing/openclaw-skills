# Schematic OmegaClaw patch notes

These files describe intended edit points and are not guaranteed to apply to a
future checkout. Generate a real patch from the exact pinned target revision.

Required edit points:

1. `lib_omegaclaw.metta`: import `./src/self_model/module` before the main loop.
2. `src/skills.metta`: advertise diagnostics only; never expose the internal gate.
3. Startup/security:
   - verify the ledger;
   - bind the current reasoner through `SelfReasoner`;
   - load context/freshness profiles;
   - verify the externally signed policy manifest and trust root;
   - initialize continuity certificate cache as advisory storage.
4. `src/loop.metta`:
   - renew `SelfHereNow` and append probes;
   - add compact query-derived `SELF_CONTEXT`;
   - convert parsed expressions to immutable proposals;
   - commit predictions;
   - derive closure, applicability, context transfer, and reasoner estimate;
   - gate before every `eval` path;
   - append receipts and resolve predictions.
5. Deployment policy:
   - ordinary shell/file skills cannot rewrite the ledger, policy bundle, trust
     root, or continuity certificates;
   - the agent process cannot access policy signing keys;
   - only a separate enforcement component mints execution capability after `Allow`.
6. Tests:
   - prove every non-`Allow` decision is excluded from execution;
   - prove stale evidence remains in the ledger;
   - prove inherited evidence is deduplicated;
   - prove high-impact cache miss and heuristic continuity never authorize;
   - prove Patham9/OmegaPLN adapters share one production call site.
