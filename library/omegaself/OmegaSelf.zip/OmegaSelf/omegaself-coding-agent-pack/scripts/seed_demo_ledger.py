"""Create a small, valid demonstration ledger under examples/."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PYTHON_DIR = ROOT / "python"
if str(PYTHON_DIR) not in sys.path:
    sys.path.insert(0, str(PYTHON_DIR))

from omegaself.canonical import utc_now_iso  # noqa: E402
from omegaself.ledger import HashChainLedger  # noqa: E402
from omegaself.types import EventDraft  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "examples" / "sample_events.jsonl",
        help="ledger path; smoke tests pass a temporary path so the frozen pack is not modified",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    target = args.output.resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    lock = target.with_suffix(target.suffix + ".lock")
    target.unlink(missing_ok=True)
    lock.unlink(missing_ok=True)
    ledger = HashChainLedger(target)
    probe = ledger.append(
        EventDraft(
            event_id="obs-runtime-1",
            event_type="runtime_probe",
            subject_anchor="anchor-demo",
            context="local-workspace",
            payload={"predicate": "tool_reachable", "tool": "pdf-extract-v2", "value": True},
            causal_time=utc_now_iso(),
        )
    )
    prediction = ledger.append(
        EventDraft(
            event_id="prediction-1",
            event_type="self_prediction",
            subject_anchor="anchor-demo",
            context="scientific-pdf",
            payload={
                "proposition": "pdf-extract-v2 succeeds under exact-layout rubric",
                "probability": 0.82,
                "rubric": "exit-zero and layout-score>=0.8",
            },
            causal_time=utc_now_iso(),
            provenance=(probe.event_id,),
        )
    )
    outcome = ledger.append(
        EventDraft(
            event_id="receipt-1",
            event_type="capability_outcome",
            subject_anchor="anchor-demo",
            context="scientific-pdf",
            payload={"outcome": "partial_success", "layout_score": 0.76},
            causal_time=utc_now_iso(),
            provenance=(prediction.event_id,),
            dependence_group="provider-run-demo",
        )
    )
    ledger.append(
        EventDraft(
            event_id="resolution-1",
            event_type="prediction_resolution",
            subject_anchor="anchor-demo",
            context="scientific-pdf",
            payload={"prediction_id": prediction.event_id, "observed": False, "brier_score": 0.6724},
            causal_time=utc_now_iso(),
            provenance=(prediction.event_id, outcome.event_id),
        )
    )
    report = ledger.verify()
    if not report.ok:
        raise SystemExit(f"generated ledger failed verification: {report.errors}")
    print(f"wrote {report.record_count} records to {target}")
    print(f"root hash: {report.root_hash}")


if __name__ == "__main__":
    main()
