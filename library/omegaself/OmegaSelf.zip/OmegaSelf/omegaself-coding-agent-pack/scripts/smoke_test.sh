#!/usr/bin/env sh
set -eu
export PYTHONDONTWRITEBYTECODE=1
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TMP_ROOT=$(mktemp -d)
trap 'rm -rf "$TMP_ROOT"' EXIT HUP INT TERM
cd "$ROOT/python"
PYTHONPATH=. python -m unittest discover -s tests -v
cd "$ROOT"
python scripts/seed_demo_ledger.py --output "$TMP_ROOT/sample_events.jsonl"
PYTHONPATH=python python examples/provider_outage_scenario.py
PYTHONPATH=python python examples/staleness_not_forgetting.py
PYTHONPATH=python python examples/context_transfer_dedup.py
PYTHONPATH=python python examples/reasoner_adapter_migration.py
PYTHONPATH=python python examples/policy_seam_probe.py
PYTHONPATH=python python examples/continuity_cache_fail_closed.py
python scripts/validate_pack.py
