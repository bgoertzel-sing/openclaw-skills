"""Validate collateral structure, schemas, configuration, and reference tests."""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

REQUIRED = [
    "README.md",
    "AGENTS.md",
    "SKILL.md",
    "docs/ARCHITECTURE.md",
    "docs/IMPLEMENTATION_PLAN.md",
    "docs/CORE_REQUIREMENTS.md",
    "docs/ADR/0007-staleness-changes-applicability-not-evidence.md",
    "docs/ADR/0008-substrate-neutral-reasoner-spi.md",
    "docs/ADR/0009-high-impact-continuity-fails-closed.md",
    "docs/ADR/0011-governance-authority-is-externally-rooted.md",
    "omegaclaw/src/self_model/module.metta",
    "omegaclaw/src/self_model/applicability.metta",
    "omegaclaw/src/self_model/reasoner_seam.metta",
    "omegaclaw/src/self_model/continuity_certificates.metta",
    "omegaclaw/src/self_model/policy_authority.metta",
    "python/omegaself/ledger.py",
    "python/omegaself/applicability.py",
    "python/omegaself/context_graph.py",
    "python/omegaself/reasoner/base.py",
    "python/omegaself/continuity/certificate.py",
    "python/omegaself/governance/manifest.py",
    "schemas/self_observation.schema.json",
    "schemas/evidence_applicability.schema.json",
    "schemas/reasoner_request.schema.json",
    "schemas/continuity_certificate.schema.json",
    "schemas/policy_manifest.schema.json",
]


def main() -> int:
    errors: list[str] = []
    for relative in REQUIRED:
        if not (ROOT / relative).is_file():
            errors.append(f"missing required file: {relative}")

    for schema_path in sorted((ROOT / "schemas").glob("*.json")):
        try:
            value = json.loads(schema_path.read_text(encoding="utf-8"))
            if value.get("$schema") != "https://json-schema.org/draft/2020-12/schema":
                errors.append(f"unexpected schema dialect: {schema_path.name}")
        except (OSError, json.JSONDecodeError) as exc:
            errors.append(f"invalid schema {schema_path.name}: {exc}")

    for config_path in sorted((ROOT / "config").glob("*.json")):
        try:
            json.loads(config_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            errors.append(f"invalid config JSON {config_path.name}: {exc}")

    version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    pyproject = (ROOT / "python" / "pyproject.toml").read_text(encoding="utf-8")
    match = re.search(r'^version\s*=\s*"([^"]+)"', pyproject, re.MULTILINE)
    if match is None or match.group(1) != version:
        errors.append("VERSION and python/pyproject.toml version do not match")

    reasoner_base = (ROOT / "python/omegaself/reasoner/base.py").read_text(encoding="utf-8")
    if "Decision" in reasoner_base or "ALLOW" in reasoner_base:
        errors.append("reasoner SPI appears to contain governance decision vocabulary")

    for source_path in sorted((ROOT / "python").rglob("*.py")):
        try:
            compile(source_path.read_text(encoding="utf-8"), str(source_path), "exec")
        except (OSError, SyntaxError) as exc:
            errors.append(f"Python source does not compile: {source_path.relative_to(ROOT)}: {exc}")

    test = subprocess.run(
        [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"],
        cwd=ROOT / "python",
        env={**dict(os.environ), "PYTHONPATH": ".", "PYTHONDONTWRITEBYTECODE": "1"},
        text=True,
        capture_output=True,
        check=False,
    )
    if test.returncode != 0:
        errors.append("reference-runtime unit tests failed:\n" + test.stdout + test.stderr)

    if errors:
        print("PACK VALIDATION FAILED")
        for error in errors:
            print("-", error)
        return 1
    print("PACK VALIDATION PASSED")
    print(test.stderr.strip() or test.stdout.strip())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
