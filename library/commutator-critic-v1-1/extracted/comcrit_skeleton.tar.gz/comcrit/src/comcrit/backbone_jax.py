"""JAX backend (first-class, working; ported from the validated sandbox
`mlp_demo_jax.py`).

The host supplies: a pure gated StepFunction over an opaque state pytree
(params + optimizer moments), a params_of lens, Oracles built from loss
closures, and a BatchPlan. The backbone computes:

  inject     EXACT full-state perturbation: one gated vs one ordinary step
  propagate  exact-D (default): jax.jvp through the ENTIRE step, moments
             included; frozen-D optionally alongside for the probe gate
  project    tau_hat^A/B at each requested horizon via a loss-jvp

The stress-test result that fixed the defaults: at 10x learning rate,
frozen-D collapsed (Spearman ~0.16/-0.05/0.20 at h=5/10/25) while exact-D
held >= 0.997. Exact-D is the default; frozen-D exists for the probe gate
and as a cost fallback that must EARN admission (cosine >= 0.95, magnitude
ratio in [0.5, 2] at >= 50 probe states).
"""
from __future__ import annotations

from typing import Any, Callable, Mapping, Sequence

import numpy as np

try:
    import jax
    import jax.numpy as jnp
    from jax import jvp, tree_util as jtu
    HAVE_JAX = True
except Exception:                                    # pragma: no cover
    HAVE_JAX = False

from .protocols import Action, BackboneTerms, BatchPlan


def oracles_hvp(loss: Callable, params, v):
    """H v for a loss(params) closure, via forward-over-reverse."""
    return jvp(jax.grad(loss), (params,), (v,))[1]


def tree_dot(a, b) -> float:
    return float(sum(jnp.vdot(x, y) for x, y in
                     zip(jtu.tree_leaves(a), jtu.tree_leaves(b))))


class JaxBackbone:
    def __init__(self, step: Callable, params_of: Callable,
                 moments_view: Callable | None = None,
                 lr_for_frozen: float | None = None):
        """step(state, batch, t, gate) -> state, pure. params_of(state) ->
        params pytree. For frozen-D, `moments_view(state) -> D pytree`
        (elementwise preconditioner) and `lr_for_frozen` must be given."""
        self.step = step
        self.params_of = params_of
        self.moments_view = moments_view
        self.lr = lr_for_frozen

    # ---- injection ---------------------------------------------------
    def inject(self, state, batch0, t0, gate_a, gate_o):
        st_g = self.step(state, batch0, t0, gate_a)
        st_o = self.step(state, batch0, t0, gate_o)
        tan = jtu.tree_map(lambda x, y: x - y, st_g, st_o)   # EXACT, full state
        return st_o, tan

    # ---- measurement -------------------------------------------------
    def measure(self, state, t0: int, plan: BatchPlan,
                actions: Sequence[Action], horizons: Sequence[int],
                gate_of: Callable[[Action | None], Mapping[str, float]],
                loss_A: Callable, loss_B: Callable | None = None,
                frozen_d: bool = False,
                loss_B_of_batch: Callable | None = None,
                ) -> dict[str, dict[int, BackboneTerms]]:
        """Returns {repr(action): {h: BackboneTerms}}. Also stashes the
        injected theta-perturbation in terms.extras['u_theta'] at the first
        horizon, for synergy checks. One baseline pass serves all actions
        (tangents ride along); actions loop for clarity at skeleton stage —
        batch tangent columns before scaling up."""
        gate_o = gate_of(None)
        out: dict[str, dict[int, BackboneTerms]] = {}
        maxh = max(horizons)
        for act in actions:
            st_base, tan = self.inject(state, plan.batches[0], t0,
                                       gate_of(act), gate_o)
            u_theta = self.params_of(tan)
            tan_f = jtu.tree_map(jnp.array, u_theta) if frozen_d else None
            st, res = st_base, {}
            for k in range(1, maxh + 1):
                if k > 1:
                    batch = plan.batches[k - 1]
                    t = t0 + k - 1
                    fn = lambda s: self.step(s, batch, t, gate_o)
                    st_next, tan = jvp(fn, (st,), (tan,))          # exact-D
                    if frozen_d:
                        # frozen-D: tan_f <- tan_f - lr * D_k * HVP_B(tan_f)
                        p = self.params_of(st)
                        lossB_b = lambda q: loss_B_of_batch(q, batch)
                        hvp = jvp(jax.grad(lossB_b), (p,), (tan_f,))[1]
                        D = self.moments_view(st_next)
                        tan_f = jtu.tree_map(
                            lambda tf, dd, hh: tf - self.lr * dd * hh,
                            tan_f, D, hvp)
                    st = st_next
                if k in horizons:
                    p = self.params_of(st)
                    dt = self.params_of(tan)
                    tA = jvp(loss_A, (p,), (dt,))[1]
                    tB = (jvp(loss_B, (p,), (dt,))[1]
                          if loss_B is not None else None)
                    terms = BackboneTerms(
                        action=act, horizon=k, mode="exact_d",
                        tau_hat_A=float(tA),
                        tau_hat_B=None if tB is None else float(tB))
                    if frozen_d:
                        terms.extras["tau_hat_A_frozen_d"] = float(
                            jvp(loss_A, (p,), (tan_f,))[1])
                    if k == min(horizons):
                        terms.extras["u_theta"] = u_theta
                    res[k] = terms
            out[repr(act)] = res
        return out

    # ---- synergy -----------------------------------------------------
    @staticmethod
    def synergy_hat(u_m, u_n, hvp_A: Callable) -> float:
        """u_m' H_A u_n — the exact one-step pair-minus-singles identity;
        one HVP and one dot product."""
        return tree_dot(u_m, hvp_A(u_n))


# ---------------------------------------------------------------------
# reference pure Adam step (a host-code template; hosts may bring optax)
# ---------------------------------------------------------------------

def make_adam_step(loss_of_batch: Callable, lr: float, b1=0.9, b2=0.999,
                   eps=1e-8):
    """loss_of_batch(params, batch) -> scalar. State = (params, m, v).
    Gate is a {leaf: scalar} dict applied post-backward (requirement R3)."""

    def step(state, batch, t, gate):
        p, m, v = state
        g = jax.grad(lambda q: loss_of_batch(q, batch))(p)
        g = {k: gate[k] * g[k] for k in g}
        m2 = jtu.tree_map(lambda a, b: b1 * a + (1 - b1) * b, m, g)
        v2 = jtu.tree_map(lambda a, b: b2 * a + (1 - b2) * b * b, v, g)
        bc1, bc2 = 1 - b1 ** t, 1 - b2 ** t
        p2 = jtu.tree_map(
            lambda pp, mm, vv: pp - lr * (mm / bc1)
            / (jnp.sqrt(vv / bc2) + eps), p, m2, v2)
        return (p2, m2, v2)

    def params_of(state):
        return state[0]

    def moments_view(state, t_hint=None):
        # elementwise D from second moments (bias correction folded coarsely;
        # frozen-D is an approximation by definition — validate at probes)
        _, _, v = state
        return jtu.tree_map(lambda vv: 1.0 / (jnp.sqrt(vv) + eps), v)

    return step, params_of, moments_view
